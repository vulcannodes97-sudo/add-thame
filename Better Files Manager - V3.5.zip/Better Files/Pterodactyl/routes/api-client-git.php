<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Api\Client\Servers\GitController;
use Pterodactyl\Http\Middleware\Api\Client\RequirePermission;
use Pterodactyl\Models\Permission;

// These routes should be registered inside the existing
// api-client.php server group, e.g.:
//
// Route::group(['prefix' => '/servers/{server}', ...], function () {
//     ...existing routes...
//
//     Route::group(['prefix' => '/git'], function () {
//         Route::get('/status', [GitController::class, 'status']);
//         Route::post('/clone', [GitController::class, 'cloneRepository']);
//         Route::post('/pull', [GitController::class, 'pull']);
//         Route::post('/diff', [GitController::class, 'diff']);
//     });
// });
//
// Or include this file from api-client.php:
//   require __DIR__ . '/api-client-git.php';

Route::group(['prefix' => '/git'], function () {
    Route::get('/status', [GitController::class, 'status'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ]);
    Route::post('/clone', [GitController::class, 'cloneRepository'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
    Route::post('/pull', [GitController::class, 'pull'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
    Route::post('/diff', [GitController::class, 'diff'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
});
