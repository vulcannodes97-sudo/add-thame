<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Api\Client;
use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Middleware\Api\Client\RequirePermission;

Route::post('/files/pull-url/query', [Client\Servers\FilePullController::class, 'query'])->middleware(['throttle:5,1', RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
Route::post('/files/pull-url/pull', [Client\Servers\FilePullController::class, 'pull'])->middleware(['throttle:10,5', RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
Route::delete('/files/pull-url/pull/{id}', [Client\Servers\FilePullController::class, 'cancel'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
Route::get('/files/pull-url/status', [Client\Servers\FilePullController::class, 'status'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
Route::post('/files/pull-url', [Client\Servers\FilePullController::class, 'pullFromUrl'])->middleware(['throttle:10,5', RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);

Route::group(['prefix' => '/beautifier'], function () {
    Route::get('/check', [Client\Servers\FileBeautifierController::class, 'check'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
    Route::get('/preview', [Client\Servers\FileBeautifierController::class, 'preview'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
    Route::post('/beautify', [Client\Servers\FileBeautifierController::class, 'beautify'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
    Route::post('/beautify-async', [Client\Servers\FileBeautifierController::class, 'beautifyAsync'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
});

Route::get('/files/search', [Client\Servers\FileSearchController::class, 'search'])->middleware(['throttle:30,1', RequirePermission::class . ':' . Permission::ACTION_FILE_READ]);
Route::get('/files/stream', [Client\Servers\FileStreamsController::class, 'stream'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
Route::get('/files/trash', [Client\Servers\FileTrashController::class, 'index'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ]);
Route::post('/files/move-to-trash', [Client\Servers\FileTrashController::class, 'moveToTrash'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_DELETE]);
Route::post('/files/restore-from-trash', [Client\Servers\FileTrashController::class, 'restore'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_CREATE]);
Route::post('/files/empty-trash', [Client\Servers\FileTrashController::class, 'empty'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_DELETE]);
Route::get('/files/trash/settings', [Client\Servers\FileTrashSettingsController::class, 'index'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
Route::put('/files/trash/settings', [Client\Servers\FileTrashSettingsController::class, 'update'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);

Route::get('/git/status', [Client\Servers\GitController::class, 'status'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ]);
Route::post('/git/clone', [Client\Servers\GitController::class, 'cloneRepository'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
Route::post('/git/pull', [Client\Servers\GitController::class, 'pull'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_UPDATE]);
Route::post('/git/diff', [Client\Servers\GitController::class, 'diff'])->middleware([RequirePermission::class . ':' . Permission::ACTION_FILE_READ_CONTENT]);
