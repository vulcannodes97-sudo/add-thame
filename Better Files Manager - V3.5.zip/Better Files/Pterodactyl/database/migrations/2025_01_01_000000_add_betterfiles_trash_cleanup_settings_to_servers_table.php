<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('servers', function (Blueprint $table) {
            $table->boolean('bf_trash_cleanup_enabled')->default(false);
            $table->unsignedTinyInteger('bf_trash_retention_days')->default(30);
        });
    }

    public function down(): void
    {
        Schema::table('servers', function (Blueprint $table) {
            $table->dropColumn(['bf_trash_cleanup_enabled', 'bf_trash_retention_days']);
        });
    }
};
