<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('servers', function (Blueprint $table) {
            if (!Schema::hasColumn('servers', 'bf_trash_retention_unit')) {
                $table->string('bf_trash_retention_unit', 8)->default('days')->after('bf_trash_retention_days');
            }
        });
    }

    public function down(): void
    {
        Schema::table('servers', function (Blueprint $table) {
            if (Schema::hasColumn('servers', 'bf_trash_retention_unit')) {
                $table->dropColumn('bf_trash_retention_unit');
            }
        });
    }
};
