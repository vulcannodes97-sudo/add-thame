<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (!DB::getSchemaBuilder()->hasTable('settings')) {
            return;
        }

        DB::table('settings')->updateOrInsert(
            ['key' => 'betterfiles:pull_url_max_size_mb'],
            ['value' => '100']
        );
    }

    public function down(): void
    {
        if (!DB::getSchemaBuilder()->hasTable('settings')) {
            return;
        }

        DB::table('settings')->where('key', 'betterfiles:pull_url_max_size_mb')->delete();
    }
};
