<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (!DB::getSchemaBuilder()->hasTable('settings')) {
            return;
        }

        DB::table('settings')->updateOrInsert(
            ['key' => 'betterfiles:trash_cleanup_default_unit'],
            ['value' => 'days']
        );
    }

    public function down(): void
    {
        if (!DB::getSchemaBuilder()->hasTable('settings')) {
            return;
        }

        DB::table('settings')->where('key', 'betterfiles:trash_cleanup_default_unit')->delete();
    }
};
