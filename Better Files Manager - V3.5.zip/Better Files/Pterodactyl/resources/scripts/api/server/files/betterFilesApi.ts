import http from '@/api/http';

export interface PullFromUrlData {
    url: string;
    directory: string;
    filename?: string;
}

export interface PullFromUrlResponse {
    identifier?: string;
    id?: string;
    filename?: string;
    size?: number;
    directory?: string;
}

export interface PullUrlQueryResponse {
    filename?: string | null;
    size?: number | null;
}

export interface PullUrlStatusDownload {
    identifier: string;
    progress: number;
}

export interface PullUrlStatusResponse {
    downloads?: PullUrlStatusDownload[];
}

export const queryPullUrl = async (uuid: string, url: string): Promise<PullUrlQueryResponse> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/files/pull-url/query`, { url });
    return data;
};

export const pullFromUrl = async (uuid: string, data: PullFromUrlData): Promise<PullFromUrlResponse> => {
    const response = await http.post(`/api/client/servers/${uuid}/files/pull-url/pull`, data);
    return response.data ?? {};
};

export const getPullUrlStatus = async (uuid: string): Promise<PullUrlStatusResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/files/pull-url/status`);
    return data ?? {};
};

export const cancelPullUrl = async (uuid: string, id: string): Promise<void> => {
    const encodedId = encodeURIComponent(id);
    await http.delete(`/api/client/servers/${uuid}/files/pull-url/pull/${encodedId}`);
};

export const moveToTrash = async (uuid: string, directory: string, files: string[]): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/move-to-trash`, {
        root: directory,
        files,
    });
};

export const restoreFromTrash = async (uuid: string, files: string[]): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/restore-from-trash`, {
        files,
    });
};

export const emptyTrash = async (uuid: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/empty-trash`);
};

export const getTrashContents = async (uuid: string): Promise<any[]> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/files/trash`);
    return data.data || [];
};

export interface TrashCleanupSettings {
    allow_user_override: boolean;
    global_enabled: boolean;
    trash_cleanup_enabled: boolean;
    trash_retention_days: number;
    trash_retention_unit: 'days' | 'hours';
    default_days: number;
    default_unit: 'days' | 'hours';
    content_search_enabled?: boolean;
    git_enabled?: boolean;
}

export const getTrashCleanupSettings = async (uuid: string): Promise<TrashCleanupSettings> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/files/trash/settings`);
    return data.data || data;
};

export const updateTrashCleanupSettings = async (
    uuid: string,
    settings: { trash_cleanup_enabled: boolean; trash_retention_days: number; trash_retention_unit: 'days' | 'hours' }
): Promise<TrashCleanupSettings> => {
    const { data } = await http.put(`/api/client/servers/${uuid}/files/trash/settings`, settings);
    return data.data || data;
};

export interface FileSearchResult {
    name: string;
    path: string;
    directory: string;
    is_file: boolean;
    size: number;
    modified_at: string;
}

export interface FileSearchMeta {
    search_time_ms: number;
    truncated: boolean;
    query: string;
    max_results: number;
    max_depth: number;
    total_scanned: number;
}

export interface FileSearchResponse {
    data: FileSearchResult[];
    meta: FileSearchMeta;
}

export interface FileSearchError {
    error: string;
    error_code:
        | 'INVALID_PARAMS'
        | 'SEARCH_FAILED'
        | 'ENDPOINT_UNAVAILABLE'
        | 'TIMEOUT'
        | 'WINGS_UNREACHABLE'
        | 'UNEXPECTED_ERROR'
        | 'CONTENT_SEARCH_DISABLED'
        | 'INSUFFICIENT_PERMISSIONS';
}

export interface FileSearchOptions {
    maxResults?: number;
    maxDepth?: number;
    timeout?: number;
    includeContent?: boolean;
}

export const searchFiles = async (
    uuid: string,
    query: string,
    options: FileSearchOptions = {}
): Promise<FileSearchResponse> => {
    const { maxResults = 0, maxDepth, timeout = 8, includeContent = false } = options;

    try {
        const { data } = await http.get<{ data: FileSearchResult[]; meta: FileSearchMeta }>(
            `/api/client/servers/${uuid}/files/search`,
            {
                params: {
                    query,
                    max_results: maxResults,
                    timeout,
                    ...(typeof maxDepth === 'number' && maxDepth > 0 ? { max_depth: maxDepth } : {}),
                    ...(includeContent ? { content: '1' } : {}),
                },
            }
        );

        return {
            data: data.data || [],
            meta: data.meta || {
                search_time_ms: 0,
                truncated: false,
                query,
                max_results: maxResults,
                max_depth: maxDepth,
                total_scanned: 0,
            },
        };
    } catch (error: any) {
        if (error.response?.data?.error_code) {
            const searchError: FileSearchError = error.response.data;
            throw new SearchError(searchError.error, searchError.error_code, error.response.status);
        }
        throw error;
    }
};

export class SearchError extends Error {
    constructor(
        message: string,
        public readonly code: FileSearchError['error_code'],
        public readonly statusCode: number
    ) {
        super(message);
        this.name = 'SearchError';
    }

    get isTimeout(): boolean {
        return this.code === 'TIMEOUT';
    }

    get isUnavailable(): boolean {
        return this.code === 'ENDPOINT_UNAVAILABLE' || this.code === 'WINGS_UNREACHABLE';
    }
}
