import http from '@/api/http';

export interface GitStatus {
    available: boolean;
    is_repo: boolean;
    branch?: string;
    status?: string;
    remotes?: string;
    log?: string;
    error?: string;
}

export interface GitOperationResult {
    stdout: string;
    stderr: string;
    exit_code: number;
}

export const getGitStatus = async (uuid: string, workDir?: string): Promise<GitStatus> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/git/status`, {
        params: { work_dir: workDir || '/' },
    });

    return data;
};

export const cloneGitRepository = async (
    uuid: string,
    repositoryUrl: string,
    targetDirectory?: string,
    workDir?: string
): Promise<GitOperationResult> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/git/clone`, {
        repository_url: repositoryUrl,
        target_directory: targetDirectory || '',
        work_dir: workDir || '/',
    });

    return data;
};

export const pullGitRepository = async (uuid: string, workDir?: string): Promise<GitOperationResult> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/git/pull`, {
        work_dir: workDir || '/',
    });

    return data;
};

export const getGitDiff = async (uuid: string, workDir?: string, file?: string): Promise<GitOperationResult> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/git/diff`, {
        work_dir: workDir || '/',
        file: file || '',
    });

    return data;
};
