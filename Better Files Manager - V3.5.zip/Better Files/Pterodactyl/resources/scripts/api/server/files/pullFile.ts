import http from '@/api/http';

export interface PullFileData {
    url: string;
    directory: string;
    filename?: string;
    use_header?: boolean;
    foreground?: boolean;
}

export default (uuid: string, data: PullFileData): Promise<void> => {
    return new Promise((resolve, reject) => {
        http.post(`/api/client/servers/${uuid}/files/pull`, data)
            .then(() => resolve())
            .catch(reject);
    });
};
