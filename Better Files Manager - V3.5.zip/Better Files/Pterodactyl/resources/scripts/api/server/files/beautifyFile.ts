import http from '@/api/http';

export interface BeautifyResponse {
    success: boolean;
    message: string;
    file_path: string;
    content?: string;
    original_size?: number;
    beautified_size?: number;
    queued?: boolean;
}

export interface BeautifyCheckResponse {
    supported: boolean;
    file_path: string;
    file_type: string;
}

export interface BeautifyPreviewResponse {
    success: boolean;
    file_path: string;
    original: string;
    beautified: string;
    original_size: number;
    beautified_size: number;
}

export const checkBeautifySupport = async (uuid: string, filePath: string): Promise<BeautifyCheckResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/beautifier/check`, {
        params: { file: filePath },
    });

    return data;
};

export const beautifyFile = async (uuid: string, filePath: string, content?: string): Promise<BeautifyResponse> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/beautifier/beautify`, { content }, {
        params: { file: filePath },
    });

    return data;
};

export const beautifyFileAsync = async (uuid: string, filePath: string): Promise<BeautifyResponse> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/beautifier/beautify-async`, null, {
        params: { file: filePath },
    });

    return data;
};

export const previewBeautify = async (uuid: string, filePath: string): Promise<BeautifyPreviewResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/beautifier/preview`, {
        params: { file: filePath },
    });

    return data;
};
