import http from '@/api/http';
import { rawDataToFileObject } from '@/api/transformers';

export interface FileObject {
    key: string;
    name: string;
    mode: string;
    modeBits: string;
    size: number;
    isFile: boolean;
    isSymlink: boolean;
    mimetype: string;
    createdAt: Date;
    modifiedAt: Date | null;
    isArchiveType: () => boolean;
    isEditable: () => boolean;
}

export const getDirectoryContents = async (uuid: string, directory: string): Promise<FileObject[]> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/files/list`, {
        params: { directory },
    });

    return (data.data || []).map(rawDataToFileObject);
};

export const getFileContents = async (uuid: string, file: string): Promise<string> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/files/contents`, {
        params: { file },
        transformResponse: [(data) => data], 
    });
    return typeof data === 'string' ? data : '';
};

export const saveFileContents = async (uuid: string, file: string, content: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/write`, content, {
        params: { file },
        headers: {
            'Content-Type': 'text/plain',
        },
    });
};

export const deleteFiles = async (uuid: string, directory: string, files: string[]): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/delete`, {
        root: directory,
        files,
    });
};

export const createFolder = async (uuid: string, directory: string, name: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/create-folder`, {
        root: directory,
        name,
    });
};

export const renameFile = async (uuid: string, directory: string, files: { from: string; to: string }[]): Promise<void> => {
    await http.put(`/api/client/servers/${uuid}/files/rename`, {
        root: directory,
        files,
    });
};

export const compressFiles = async (uuid: string, directory: string, files: string[]): Promise<FileObject> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/files/compress`, {
        root: directory,
        files,
    });

    return rawDataToFileObject(data);
};

export const decompressFile = async (uuid: string, directory: string, file: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/decompress`, {
        root: directory,
        file,
    }, {
        timeout: 300000,
        timeoutErrorMessage: 'Archive extraction is taking longer than expected. The files will appear once extraction completes.',
    });
};

export const chmodFiles = async (uuid: string, directory: string, files: { file: string; mode: string }[]): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/files/chmod`, {
        root: directory,
        files,
    });
};

