
export type ThemeMode = 'tailwind' | 'nebula';
export const THEME_MODE: ThemeMode = 'nebula';
export const USE_NEBULA_THEME: boolean = THEME_MODE === 'nebula';
export const TAILWIND_GRAY = {
  bg900: 'hsl(210, 24%, 16%)',
  bg800: 'hsl(209, 20%, 25%)',
  bg700: 'hsl(209, 18%, 30%)',
  bg600: 'hsl(209, 14%, 37%)',
  bg500: 'hsl(211, 12%, 43%)',
  text100: 'hsl(214, 15%, 91%)',
  text300: 'hsl(211, 13%, 65%)',
} as const;
