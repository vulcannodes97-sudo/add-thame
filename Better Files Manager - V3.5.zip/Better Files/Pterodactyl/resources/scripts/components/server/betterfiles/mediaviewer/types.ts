export interface MediaViewerProps {
    uuid: string;
    filePath: string;
    fileType: 'image' | 'video' | 'audio';
}

export interface ParsedAudioMetadata {
    title?: string;
    artist?: string;
    album?: string;
    picture?: { mime: string; data: Uint8Array };
}

export interface ResumeState {
    time: number;
    wasPlaying: boolean;
    token: number;
}

export interface VideoPlayerProps {
    src: string;
    blobUrl: string | null;
    fileName: string;
    isStreaming: boolean;
    resumeState: ResumeState | null;
    onError: (e: React.SyntheticEvent<HTMLVideoElement>) => void;
    onWaiting: () => void;
    onPlaying: () => void;
    onTimeUpdate: (time: number) => void;
    onPlayingChange: (playing: boolean) => void;
}

export interface AudioPlayerProps {
    src: string;
    blobUrl: string | null;
    blob: Blob | null;
    blobPartial: boolean;
    isStreaming: boolean;
    resumeState: ResumeState | null;
    filePath: string;
    uuid: string;
    fileName: string;
    onRequestFullDownload?: () => void;
    onError: (e: React.SyntheticEvent<HTMLAudioElement>) => void;
    onTimeUpdate: (time: number) => void;
    onPlayingChange: (playing: boolean) => void;
}

export interface ImageViewerProps {
    src: string;
    alt: string;
}

export interface BeatInfo {
    beat: boolean;
    strength: number;
    drop: boolean;
}

export interface Particle {
    x: number;
    y: number;
    vx: number;
    vy: number;
    size: number;
    baseSize: number;
    alpha: number;
    phase: number;
}

export interface WaveformConfig {
    fftSize: number;
    smoothingTimeConstant: number;
    minDecibels: number;
    maxDecibels: number;
    barCount: number;
    barGap: number;
    maxBarHeightRatio: number;
    showParticles: boolean;
    particleCount: number;
    showBeatNotes: boolean;
    timelineHistorySize: number;
}

export const DEFAULT_WAVEFORM_CONFIG: WaveformConfig = {
    fftSize: 512,
    smoothingTimeConstant: 0.8,
    minDecibels: -90,
    maxDecibels: -10,
    barCount: 128,
    barGap: 1,
    maxBarHeightRatio: 0.85,
    showParticles: true,
    particleCount: 45,
    showBeatNotes: true,
    timelineHistorySize: 10,
};
