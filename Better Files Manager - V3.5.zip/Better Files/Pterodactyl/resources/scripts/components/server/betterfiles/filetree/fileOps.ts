import { compressFiles, deleteFiles, renameFile, decompressFile, saveFileContents, createFolder } from '@/api/server/files';
import { moveToTrash } from '@/api/server/files/betterFilesApi';

export interface FileOpsOptions {
    uuid: string;
    getModalTargetPath: () => string;
    setModalTargetPath: (path: string) => void;
    setShowDeleteConfirm: (value: boolean) => void;
    setShowMoveToTrashConfirm: (value: boolean) => void;
    setShowUnarchiveConfirm: (value: boolean) => void;
    setShowRenameModal: (value: boolean) => void;
    setShowPermissionsModal: (value: boolean) => void;
    setShowCreateModal: (value: boolean) => void;
    setActionTargetDirectories: (paths: string[]) => void;
    setActionMode: (mode: 'file' | 'folder') => void;
    setUnarchiveProgress: (value: { filename: string; isExtracting: boolean } | null) => void;
    onDirectoryLoad: (path: string) => Promise<unknown>;
    onFileSelect: (path: string, isFile: boolean) => void;
    clearAndAddHttpError: (error: Error) => void;
    addFlash: (args: { key: string; type: 'success' | 'error' | 'info'; message: string; title?: string }) => void;
    clearFlashes: () => void;
    refreshTrashCount?: () => void;
}

export const isArchiveFile = (filename: string): boolean => {
    const ext = filename.split('.').pop()?.toLowerCase();
    return ['zip', 'tar', 'gz', 'rar', '7z', 'bz2', 'xz', 'tgz'].includes(ext || '') || filename.includes('.tar.');
};

export const createFileOps = (opts: FileOpsOptions) => {
    const {
        uuid,
        getModalTargetPath,
        setModalTargetPath,
        setShowDeleteConfirm,
        setShowMoveToTrashConfirm,
        setShowUnarchiveConfirm,
        setShowRenameModal,
        setShowPermissionsModal,
        setShowCreateModal,
        setActionTargetDirectories,
        setActionMode,
        setUnarchiveProgress,
        onDirectoryLoad,
        onFileSelect,
        clearAndAddHttpError,
        addFlash,
        clearFlashes,
    } = opts;

    const handleDelete = (path: string) => {
        setModalTargetPath(path);
        setShowDeleteConfirm(true);
    };

    const submitDelete = async () => {
        const modalTargetPath = getModalTargetPath();
        const lastSlashIndex = modalTargetPath.lastIndexOf('/');
        const directory = lastSlashIndex > 0 ? modalTargetPath.substring(0, lastSlashIndex) : '/';
        const filename = modalTargetPath.substring(lastSlashIndex + 1);
        setShowDeleteConfirm(false);
        clearFlashes();
        deleteFiles(uuid, directory, [filename])
            .then(() => {
                addFlash({
                    key: 'better-files',
                    type: 'success',
                    message: `Successfully deleted "${filename}"`,
                });
                return onDirectoryLoad(directory);
            })
            .catch((error) => {
                const errorMessage = error?.response?.data?.errors?.[0]?.detail
                    || error?.response?.data?.message
                    || error?.message
                    || 'Failed to delete file';
                addFlash({
                    key: 'better-files',
                    type: 'error',
                    title: 'Delete Failed',
                    message: errorMessage,
                });
            });
    };

    const handleMoveToTrash = (path: string) => {
        setModalTargetPath(path);
        setShowMoveToTrashConfirm(true);
    };

    const submitMoveToTrash = async () => {
        try {
            const modalTargetPath = getModalTargetPath();
            const directory = modalTargetPath.substring(0, modalTargetPath.lastIndexOf('/')) || '/';
            const filename = modalTargetPath.substring(modalTargetPath.lastIndexOf('/') + 1);
            await moveToTrash(uuid, directory, [filename]);
            await onDirectoryLoad(directory);
            setShowMoveToTrashConfirm(false);
            addFlash({
                key: 'better-files',
                type: 'success',
                message: `"${filename}" moved to trash`,
            });
            if (opts.refreshTrashCount) opts.refreshTrashCount();
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    };

    const handleCreateFolder = (targetPath: string) => {
        setModalTargetPath(targetPath);
        setActionTargetDirectories([targetPath]);
        setActionMode('folder');
        setShowCreateModal(true);
    };

    const handleCreateFile = (targetPath: string) => {
        setModalTargetPath(targetPath);
        setActionTargetDirectories([targetPath]);
        setActionMode('file');
        setShowCreateModal(true);
    };

    const handleArchive = async (path: string) => {
        const directory = path.substring(0, path.lastIndexOf('/')) || '/';
        const filename = path.substring(path.lastIndexOf('/') + 1);
        addFlash({
            key: 'file-compress',
            type: 'info',
            message: `Compressing ${filename}...`,
        });
        try {
            await compressFiles(uuid, directory, [filename]);
            await onDirectoryLoad(directory);
            clearFlashes();
            addFlash({
                key: 'file-compress-success',
                type: 'success',
                message: `Successfully compressed ${filename}`,
            });
        } catch (error) {
            clearFlashes();
            clearAndAddHttpError(error as Error);
        }
    };

    const handlePermissions = (path: string) => {
        setModalTargetPath(path);
        setShowPermissionsModal(true);
    };

    const handleUnarchive = (path: string) => {
        setModalTargetPath(path);
        const filename = path.substring(path.lastIndexOf('/') + 1);
        setUnarchiveProgress({ filename, isExtracting: false });
        setShowUnarchiveConfirm(true);
    };

    const submitUnarchive = async () => {
        const modalTargetPath = getModalTargetPath();
        const directory = modalTargetPath.substring(0, modalTargetPath.lastIndexOf('/')) || '/';
        const filename = modalTargetPath.substring(modalTargetPath.lastIndexOf('/') + 1);
        try {
            setUnarchiveProgress({ filename, isExtracting: true });
            await decompressFile(uuid, directory, filename);
            await new Promise((resolve) => setTimeout(resolve, 2000));
            await onDirectoryLoad(directory);
            setUnarchiveProgress(null);
            addFlash({
                key: 'file-unarchive-success',
                type: 'success',
                message: `Successfully extracted ${filename}.`,
            });
            setTimeout(() => {
                clearFlashes();
            }, 5000);
        } catch (error: any) {
            setUnarchiveProgress(null);
            addFlash({
                key: 'file-unarchive-error',
                type: 'error',
                message: error?.response?.data?.errors?.[0]?.detail || error?.message || 'Failed to extract archive',
            });
        }
    };

    const handleRename = (oldPath: string) => {
        setModalTargetPath(oldPath);
        setShowRenameModal(true);
    };

    const submitRename = async (newName: string) => {
        const modalTargetPath = getModalTargetPath();
        const directory = modalTargetPath.substring(0, modalTargetPath.lastIndexOf('/')) || '/';
        const oldName = modalTargetPath.substring(modalTargetPath.lastIndexOf('/') + 1);
        if (newName === oldName) {
            setShowRenameModal(false);
            return;
        }
        try {
            await renameFile(uuid, directory, [{ from: oldName, to: newName }]);
            await onDirectoryLoad(directory);
            setShowRenameModal(false);
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    };

    const submitCreateFile = async (name: string, directory: string, content?: string) => {
        const filePath = directory === '/' ? '/' + name : directory + '/' + name;
        await saveFileContents(uuid, filePath, content ?? '');
    };

    const submitCreateFolder = async (directory: string, name: string) => {
        await createFolder(uuid, directory, name);
        await onDirectoryLoad(directory);
    };

    return {
        handleDelete,
        submitDelete,
        handleMoveToTrash,
        submitMoveToTrash,
        handleCreateFolder,
        handleCreateFile,
        handleArchive,
        handlePermissions,
        handleUnarchive,
        submitUnarchive,
        handleRename,
        submitRename,
        submitCreateFile,
        submitCreateFolder,
    };
};
