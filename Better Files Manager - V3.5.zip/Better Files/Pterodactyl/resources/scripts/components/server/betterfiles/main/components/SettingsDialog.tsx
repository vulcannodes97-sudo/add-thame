import React, { useState, useCallback } from 'react';
import { Formik, Form } from 'formik';
import { boolean, number, object, string } from 'yup';
import { Button } from '@/components/elements/button';
import { Dialog } from '@/components/elements/dialog';
import Spinner from '@/components/elements/Spinner';
import Switch from '@/components/elements/Switch';
import Input from '@/components/elements/Input';
import { Textarea } from '@/components/elements/Input';
import Field from '@/components/elements/Field';
import type { ViewMode, TrashCleanupSettings } from '../types';

export interface FileTemplate {
    id: string;
    name: string;
    filename: string;
    content: string;
    builtin?: boolean;
}

const BUILTIN_TEMPLATES: FileTemplate[] = [
    { id: 'json', name: 'JSON', filename: 'config.json', content: '{\n    \n}\n', builtin: true },
    { id: 'yaml', name: 'YAML Config', filename: 'config.yml', content: '# Configuration\n\n', builtin: true },
    { id: 'env', name: 'Environment', filename: '.env', content: '# Environment Variables\n\n', builtin: true },
    { id: 'dockerfile', name: 'Dockerfile', filename: 'Dockerfile', content: 'FROM node:20-alpine\n\nWORKDIR /app\n\nCOPY . .\n\nRUN npm install\n\nCMD ["node", "index.js"]\n', builtin: true },
    { id: 'shell', name: 'Shell Script', filename: 'script.sh', content: '#!/bin/bash\n\n', builtin: true },
    { id: 'python', name: 'Python', filename: 'main.py', content: '#!/usr/bin/env python3\n\n', builtin: true },
    { id: 'html', name: 'HTML', filename: 'index.html', content: '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>Page</title>\n</head>\n<body>\n    \n</body>\n</html>\n', builtin: true },
];

export function getTemplates(): FileTemplate[] {
    try {
        const stored = localStorage.getItem('bfm-file-templates');
        const custom: FileTemplate[] = stored ? JSON.parse(stored) : [];
        return [...BUILTIN_TEMPLATES, ...custom];
    } catch {
        return [...BUILTIN_TEMPLATES];
    }
}

function saveCustomTemplates(templates: FileTemplate[]) {
    localStorage.setItem('bfm-file-templates', JSON.stringify(templates.filter(t => !t.builtin)));
}

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

interface SettingsDialogProps {
    open: boolean;
    onClose: () => void;
    viewMode: ViewMode;
    onViewModeChange: (mode: ViewMode) => void;
    canConfigureTrash: boolean;
    trashCleanupSettings: TrashCleanupSettings | null;
    onSaveTrashSettings: (settings: TrashCleanupSettings) => Promise<void>;
}

const TemplatesSection: React.FC = () => {
    const [templates, setTemplates] = useState(getTemplates);
    const [editing, setEditing] = useState<FileTemplate | null>(null);
    const [adding, setAdding] = useState(false);
    const [newName, setNewName] = useState('');
    const [newFilename, setNewFilename] = useState('');
    const [newContent, setNewContent] = useState('');

    const refresh = useCallback(() => setTemplates(getTemplates()), []);

    const handleAdd = () => {
        if (!newName.trim() || !newFilename.trim()) return;
        const custom = templates.filter(t => !t.builtin);
        const template: FileTemplate = {
            id: `custom-${Date.now()}`,
            name: newName.trim(),
            filename: newFilename.trim(),
            content: newContent,
        };
        saveCustomTemplates([...custom, template]);
        setAdding(false);
        setNewName('');
        setNewFilename('');
        setNewContent('');
        refresh();
    };

    const handleDelete = (id: string) => {
        const custom = templates.filter(t => !t.builtin && t.id !== id);
        saveCustomTemplates(custom);
        refresh();
    };

    const handleExport = () => {
        const custom = templates.filter(t => !t.builtin);
        if (custom.length === 0) return;
        const blob = new Blob([JSON.stringify(custom, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'bfm-templates.json';
        a.click();
        URL.revokeObjectURL(url);
    };

    const handleImport = () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = async (e) => {
            const file = (e.target as HTMLInputElement).files?.[0];
            if (!file) return;
            try {
                const text = await file.text();
                const imported: FileTemplate[] = JSON.parse(text);
                if (!Array.isArray(imported)) return;
                const existing = templates.filter(t => !t.builtin);
                const merged = [...existing];
                for (const t of imported) {
                    if (!t.name || !t.filename) continue;
                    if (merged.some(m => m.id === t.id)) continue;
                    merged.push({ ...t, id: t.id || `custom-${Date.now()}-${Math.random().toString(36).slice(2)}`, builtin: false });
                }
                saveCustomTemplates(merged);
                refresh();
            } catch {}
        };
        input.click();
    };

    const handleSaveEdit = () => {
        if (!editing || !editing.name.trim() || !editing.filename.trim()) return;
        const custom = templates.filter(t => !t.builtin).map(t =>
            t.id === editing.id ? editing : t
        );
        saveCustomTemplates(custom);
        setEditing(null);
        refresh();
    };

    return (
        <div className='border-t border-neutral-700 pt-4'>
            <div className='flex items-center justify-between mb-3'>
                <p className='text-[10px] uppercase tracking-wider text-neutral-400'>File Templates</p>
                <div className='flex items-center gap-2'>
                    {templates.some(t => !t.builtin) && (
                        <Button.Text type='button' size={Button.Sizes.Small} onClick={handleExport}>
                            Export
                        </Button.Text>
                    )}
                    <Button.Text type='button' size={Button.Sizes.Small} onClick={handleImport}>
                        Import
                    </Button.Text>
                    <Button.Text
                        type='button'
                        size={Button.Sizes.Small}
                        onClick={() => setAdding(!adding)}
                    >
                        {adding ? 'Cancel' : 'Add'}
                    </Button.Text>
                </div>
            </div>

            {adding && (
                <div className='mb-4 p-3 rounded bg-neutral-700/50 border border-neutral-600 space-y-2'>
                    <div className='grid grid-cols-2 gap-2'>
                        <div>
                            <label className='block text-xs text-neutral-400 mb-1'>Template Name</label>
                            <Input
                                type='text'
                                placeholder='My Template'
                                value={newName}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewName(e.target.value)}
                            />
                        </div>
                        <div>
                            <label className='block text-xs text-neutral-400 mb-1'>Default Filename</label>
                            <Input
                                type='text'
                                placeholder='config.yml'
                                value={newFilename}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewFilename(e.target.value)}
                            />
                        </div>
                    </div>
                    <div>
                        <label className='block text-xs text-neutral-400 mb-1'>Content</label>
                        <Textarea
                            rows={4}
                            placeholder='Template content...'
                            value={newContent}
                            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNewContent(e.target.value)}
                            className='font-mono text-xs'
                        />
                    </div>
                    <Button type='button' size={Button.Sizes.Small} onClick={handleAdd}>
                        Save Template
                    </Button>
                </div>
            )}

            {editing && (
                <div className='mb-4 p-3 rounded bg-neutral-700/50 border border-neutral-600 space-y-2'>
                    <div className='grid grid-cols-2 gap-2'>
                        <div>
                            <label className='block text-xs text-neutral-400 mb-1'>Template Name</label>
                            <Input
                                type='text'
                                value={editing.name}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditing({ ...editing, name: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className='block text-xs text-neutral-400 mb-1'>Default Filename</label>
                            <Input
                                type='text'
                                value={editing.filename}
                                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setEditing({ ...editing, filename: e.target.value })}
                            />
                        </div>
                    </div>
                    <div>
                        <label className='block text-xs text-neutral-400 mb-1'>Content</label>
                        <Textarea
                            rows={4}
                            value={editing.content}
                            onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setEditing({ ...editing, content: e.target.value })}
                            className='font-mono text-xs'
                        />
                    </div>
                    <div className='flex gap-2'>
                        <Button type='button' size={Button.Sizes.Small} onClick={handleSaveEdit}>Save</Button>
                        <Button.Text type='button' size={Button.Sizes.Small} onClick={() => setEditing(null)}>Cancel</Button.Text>
                    </div>
                </div>
            )}

            <div className='space-y-1 max-h-48 overflow-y-auto'>
                {templates.map((t) => (
                    <div key={t.id} className='flex items-center justify-between py-1.5 px-2 rounded hover:bg-neutral-700/50 group'>
                        <div className='min-w-0'>
                            <span className='text-sm text-neutral-200'>{t.name}</span>
                            <span className='text-xs text-neutral-500 ml-2'>{t.filename}</span>
                            {t.builtin && <span className='text-[10px] text-neutral-600 ml-2'>built-in</span>}
                        </div>
                        {!t.builtin && (
                            <div className='flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity'>
                                <Button.Text
                                    type='button'
                                    size={Button.Sizes.Small}
                                    onClick={() => { setEditing(t); setAdding(false); }}
                                >
                                    Edit
                                </Button.Text>
                                <Button.Danger
                                    type='button'
                                    size={Button.Sizes.Small}
                                    onClick={() => handleDelete(t.id)}
                                >
                                    Delete
                                </Button.Danger>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export const SettingsDialog: React.FC<SettingsDialogProps> = ({
    open,
    onClose,
    viewMode,
    onViewModeChange,
    canConfigureTrash,
    trashCleanupSettings,
    onSaveTrashSettings,
}) => {
    return (
        <Dialog open={open} onClose={onClose} title='File Manager Settings'>
            <div className='grid gap-6'>
                <div>
                    <p className='text-[10px] uppercase tracking-wider text-neutral-400 mb-2'>View Mode</p>
                    <div className='flex gap-2'>
                        {([
                            { key: 'tree' as const, label: 'Tree', icon: 'M4 4h7v7H4V4zm9 0h7v7h-7V4zM4 13h7v7H4v-7zm9 0h7v7h-7v-7z' },
                            { key: 'browse' as const, label: 'Browse', icon: 'M4 6h12M4 12h16M4 18h10' },
                            { key: 'grid' as const, label: 'Grid', icon: 'M4 5a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zM14 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z' },
                        ]).map(({ key, label, icon }) => (
                            <button
                                key={key}
                                type='button'
                                onClick={() => onViewModeChange(key)}
                                className={cx(
                                    'flex-1 px-4 py-2.5 rounded flex items-center justify-center gap-2 text-sm font-medium transition-colors',
                                    viewMode === key
                                        ? 'bg-neutral-600 border border-neutral-500 text-neutral-100'
                                        : 'bg-neutral-700 border border-neutral-600 text-neutral-400 hover:text-neutral-200 hover:border-neutral-500'
                                )}
                            >
                                <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d={icon} />
                                </svg>
                                {label}
                            </button>
                        ))}
                    </div>
                </div>

                <div className='border-t border-neutral-700 pt-4'>
                    <p className='text-[10px] uppercase tracking-wider text-neutral-400 mb-3'>Editor</p>
                    <Switch
                        name='live_autocomplete'
                        label='Live Autocomplete'
                        description='Show suggestions as you type. Ctrl+Space always works.'
                        defaultChecked={localStorage.getItem('bfm-live-autocomplete') !== 'false'}
                        onChange={() => {
                            const current = localStorage.getItem('bfm-live-autocomplete') !== 'false';
                            const next = !current;
                            localStorage.setItem('bfm-live-autocomplete', next.toString());
                            window.dispatchEvent(new CustomEvent('bfm:autocomplete-toggle', { detail: { enabled: next } }));
                        }}
                    />
                </div>

                <div className='border-t border-neutral-700 pt-4'>
                    <p className='text-[10px] uppercase tracking-wider text-neutral-400 mb-3'>Drag & Drop</p>
                    <Switch
                        name='drag_confirm'
                        label='Confirm before moving files'
                        description='When disabled, files are moved immediately on drop.'
                        defaultChecked={localStorage.getItem('bfm-drag-confirm-enabled') !== 'false'}
                        onChange={() => {
                            const current = localStorage.getItem('bfm-drag-confirm-enabled') !== 'false';
                            localStorage.setItem('bfm-drag-confirm-enabled', (!current).toString());
                        }}
                    />
                </div>

                <TemplatesSection />

                {canConfigureTrash && (
                    <div className='border-t border-neutral-700 pt-4'>
                        <p className='text-[10px] uppercase tracking-wider text-neutral-400 mb-3'>Trash Cleanup</p>
                        {!trashCleanupSettings ? (
                            <div className='py-4 flex items-center justify-center'>
                                <Spinner size='small' />
                                <span className='ml-2 text-sm text-neutral-400'>Loading settings...</span>
                            </div>
                        ) : (
                            <Formik
                                enableReinitialize
                                initialValues={{
                                    trash_cleanup_enabled: trashCleanupSettings.trash_cleanup_enabled ?? false,
                                    trash_retention_days: trashCleanupSettings.trash_retention_days ?? 30,
                                    trash_retention_unit: trashCleanupSettings.trash_retention_unit ?? 'days',
                                }}
                                validationSchema={object().shape({
                                    trash_cleanup_enabled: boolean().required(),
                                    trash_retention_days: number().required().min(1),
                                    trash_retention_unit: string().required().oneOf(['days', 'hours']),
                                })}
                                onSubmit={async (values, { setSubmitting }) => {
                                    try {
                                        await onSaveTrashSettings({
                                            trash_cleanup_enabled: values.trash_cleanup_enabled,
                                            trash_retention_days: Number(values.trash_retention_days),
                                            trash_retention_unit: values.trash_retention_unit as 'days' | 'hours',
                                        });
                                    } finally {
                                        setSubmitting(false);
                                    }
                                }}
                            >
                                {({ submitForm, values, setFieldValue, isSubmitting, dirty }) => (
                                    <Form>
                                        <div className='mb-4'>
                                            <Switch
                                                name='trash_cleanup_enabled'
                                                label='Enable automatic trash cleanup'
                                                defaultChecked={values.trash_cleanup_enabled}
                                                onChange={() => setFieldValue('trash_cleanup_enabled', !values.trash_cleanup_enabled)}
                                            />
                                        </div>
                                        <div className='grid grid-cols-1 gap-3 md:grid-cols-2 mb-3'>
                                            <Field
                                                id='trash_retention_days'
                                                name='trash_retention_days'
                                                type='number'
                                                min={1}
                                                label='Delete items older than'
                                            />
                                            <div>
                                                <label className='block text-xs uppercase text-neutral-200 mb-1 sm:mb-2'>Unit</label>
                                                <select
                                                    name='trash_retention_unit'
                                                    value={values.trash_retention_unit}
                                                    onChange={(e) => setFieldValue('trash_retention_unit', e.target.value)}
                                                    className='w-full rounded bg-neutral-600 border border-neutral-500 px-3 py-2 text-sm text-neutral-200 focus:border-neutral-400 focus:outline-none'
                                                >
                                                    <option value='hours'>Hours</option>
                                                    <option value='days'>Days</option>
                                                </select>
                                            </div>
                                        </div>
                                        <p className='text-xs text-neutral-500 mb-4'>
                                            Set how old items must be before automatic deletion.
                                        </p>
                                        {dirty && (
                                            <Dialog.Footer>
                                                <Button.Text onClick={onClose}>Cancel</Button.Text>
                                                <Button onClick={submitForm} disabled={isSubmitting}>
                                                    {isSubmitting ? 'Saving...' : 'Save Trash Settings'}
                                                </Button>
                                            </Dialog.Footer>
                                        )}
                                    </Form>
                                )}
                            </Formik>
                        )}
                    </div>
                )}
            </div>
        </Dialog>
    );
};
