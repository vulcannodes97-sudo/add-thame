import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import styled from 'styled-components/macro';
import { FileObject, renameFile, copyFile } from '@/api/server/files';
import { type TrashCleanupSettings } from '@/api/server/files/betterFilesApi';
import { type FileSearchResult } from '@/api/server/files/betterFilesApi';
import ContextMenu from './ContextMenu';
import FileTypeBadge from './FileTypeBadge';
import FilePermissions from './FilePermissions';
import { ServerContext } from '@/state/server';
import useFlash, { useFlashKey } from './useFlash';
import { Button } from '@/components/elements/button';
import { Dialog } from '@/components/elements/dialog';
import Code from '@/components/elements/Code';
import { colors } from './colors';
import { themeColors } from './colorExtractor';
import GreyRowBox from '@/components/elements/GreyRowBox';
import DragOverlay from './filetree/DragOverlay';
import useDragAndDropListener, { InternalDragData } from './filetree/DragAndDropListener';
import Input from '@/components/elements/Input';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import { type FolderFile } from './filetree/dragUtils';
import { createUploadHandlers, type UploadProgress } from './filetree/uploadUtils';
import UploadProgressPanel from './filetree/UploadProgressPanel';
import SearchResultsList from './filetree/SearchResultsList';
import BrowseList from './filetree/BrowseList';
import TreeList from './filetree/TreeList';
import GridList from './filetree/GridList';
import SearchPanel from './filetree/SearchPanel';
import FileTreeModals from './filetree/FileTreeModals';
import { buildContextMenuItems } from './filetree/contextMenuActions';
import { createFileOps, isArchiveFile } from './filetree/fileOps';
import {
    getParentPath as getParentPathUtil,
    joinDirectoryAndName,
    normalizeDirectory,
    normalizePath as normalizePathUtil,
    safeNormalizePath as safeNormalizePathUtil,
} from './filetree/pathUtils';
import { isDirectoryPath as isDirectoryPathUtil, resolveActionTargetPaths as resolveActionTargetPathsUtil } from './filetree/selectionUtils';
import { useFileSearch } from './filetree/useFileSearch';
import { useTrashSettings } from './filetree/useTrashSettings';
interface OptimisticMove {
    id: string;
    fromPath: string;
    toPath: string;
    isFile: boolean;
}

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');
const getDragHiddenStyle = (isDragged: boolean): React.CSSProperties => ({
    opacity: isDragged ? 0 : 1,
    pointerEvents: isDragged ? 'none' : undefined,
    transition: 'opacity 120ms ease',
});

const sameSelectionSet = (a: Set<string> | null, b: Set<string>) => {
    if (!a || a.size !== b.size) return false;
    for (const item of b) {
        if (!a.has(item)) return false;
    }
    return true;
};

const TreeContainer = React.forwardRef<
    HTMLDivElement,
    React.HTMLAttributes<HTMLDivElement> & { isDragging?: boolean; embedded?: boolean }
>(({ isDragging, embedded, className, style, ...props }, ref) => (
        <div
            ref={ref}
            className={cx(
                'flex-1 min-h-0 w-full overflow-y-auto overflow-x-auto relative',
                embedded ? 'p-0 bg-transparent border-0 shadow-none' : 'p-4 bg-gray-700/40 border border-white/5 pb-24 shadow-2xl',
                isDragging && 'bg-primary-500/10 border-2 border-dashed border-primary-400/50',
                className
            )}
            style={{
                ...style,
                position: 'relative',
                overflowAnchor: 'none',
            }}
            {...props}
        />
    )
);
TreeContainer.displayName = 'TreeContainer';

const Header: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, ...props }) => (
    <div className={cx('px-3 py-2 bg-gray-700/30 border-b border-white/5 w-full', className)} {...props} />
);

const Title: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({ className, ...props }) => (
    <h2 className={cx('text-neutral-200/90 font-semibold text-sm flex items-center gap-2.5', className)} {...props} />
);

const TreeItemBox = styled(GreyRowBox)`
    && {
        background-color: var(--tree-item-bg, transparent) !important;
        border-left-color: var(--tree-item-border, transparent) !important;
    }
    &&:hover {
        background-color: var(--tree-item-hover-bg, var(--tree-item-bg, transparent)) !important;
        border-left-color: var(--tree-item-hover-border, var(--tree-item-border, transparent)) !important;
    }
    /* When parent has .is-dragging class, disable hover effects and transitions */
    .is-dragging && {
        transition: none !important;
    }
    .is-dragging &&:hover {
        background-color: var(--tree-item-bg, transparent) !important;
        border-left-color: var(--tree-item-border, transparent) !important;
    }
`;

const TreeItem: React.FC<React.HTMLAttributes<HTMLDivElement> & { depth: number; selected?: boolean; checked?: boolean }> = ({
    depth,
    selected,
    checked,
    className,
    style,
    ...props
}) => {
    const base = cx(
        'group flex w-full items-center gap-2 box-border cursor-crosshair text-xs relative select-none [&>*]:cursor-grab [&>*]:active:cursor-grabbing',
        'tree-item', 
        'border border-transparent transition-colors',
        !(checked || selected) && 'text-neutral-300 hover:text-neutral-200',
        (checked || selected) && 'text-neutral-100', 
        'border-transparent shadow-none p-0',
        className
    );
    const isActive = !!(checked || selected);
    const computedStyle: React.CSSProperties & Record<string, string | number | undefined> = {
        paddingLeft: `${12 + depth * 18}px`,
        paddingRight: 12,
        paddingTop: 6,
        paddingBottom: 6,
        borderLeftWidth: 4,
        borderLeftStyle: 'solid',
        width: '100%',
        transition: 'background-color 150ms ease-in-out, border-left-color 150ms ease-in-out, color 150ms ease',
        contain: 'layout style',
        '--tree-item-bg': isActive ? themeColors.page.secondary : 'transparent',
        '--tree-item-border': isActive ? colors.primary.default : 'transparent',
        '--tree-item-hover-bg': themeColors.page.secondary,
        '--tree-item-hover-border': colors.primary.default,
        ...style,
        ['--bfm-depth' as any]: depth,
    };
    return (
        <TreeItemBox
            className={base}
            style={{
                padding: 0,
                ...computedStyle,
            }}
            $hoverable={false}
            {...props}
        />
    );
};

const FileName: React.FC<React.HTMLAttributes<HTMLSpanElement>> = ({ className, ...props }) => (
    <span className={cx('whitespace-nowrap py-1.5 -my-1.5', className)} {...props} />
);

const FileSize: React.FC<React.HTMLAttributes<HTMLSpanElement>> = ({ className, ...props }) => (
    <span className={cx('text-[10px] text-neutral-300 font-mono', className)} {...props} />
);

const NestedItems: React.FC<React.HTMLAttributes<HTMLDivElement> & { isExpanded: boolean; isDragOver?: boolean }> = ({
                                                                                                                         isExpanded,
                                                                                                                         isDragOver,
                                                                                                                         className,
                                                                                                                         style,
                                                                                                                         children,
                                                                                                                         ...props
                                                                                                                     }) => (
    <div
        className={cx(className)}
        style={{
            display: 'grid',
            gridTemplateRows: isExpanded ? '1fr' : '0fr',
            opacity: isExpanded ? 1 : 0,
            transition: 'grid-template-rows 0.25s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease-in-out',
            willChange: 'grid-template-rows, opacity',
            ...(isDragOver
                ? {
                    backgroundColor: colors.primary.opacity(0.12),
                    outline: `2px dashed ${colors.primary.opacity(0.45)}`,
                    outlineOffset: -2,
                }
                : {}),
            ...style,
        }}
        {...props}
    >
        <div style={{ overflow: 'hidden', minHeight: 0 }}>{children}</div>
    </div>
);

const TreeItemWrapper = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement> & { depth: number; isLastChild?: boolean }>(
    ({ depth, isLastChild, className, style, children, ...props }, ref) => {
        const lineX = depth > 0 ? depth * 18 + 8 : 0;
        return (
            <div
                ref={ref}
                className={cx('relative', className)}
                data-depth={depth}
                data-last={isLastChild ? '1' : '0'}
                style={{
                    width: '100%',
                    height: 40, 
                    paddingBottom: 4, 
                    ...(style || {}),
                    ['--bfm-depth' as any]: depth,
                }}
                {...props}
            >
                {depth > 0 && (
                    <>
                        <span
                            aria-hidden
                            className="border-l border-dotted border-gray-300/50"
                            style={{
                                position: 'absolute',
                                left: `${lineX}px`,
                                top: 0,
                                bottom: isLastChild ? '50%' : 0,
                                pointerEvents: 'none',
                            }}
                        />
                        <span
                            aria-hidden
                            className="border-t border-dotted border-gray-300/50"
                            style={{
                                position: 'absolute',
                                left: `${lineX}px`,
                                top: '50%',
                                width: '14px',
                                pointerEvents: 'none',
                            }}
                        />
                    </>
                )}
                {children}
            </div>
        );
    }
);
TreeItemWrapper.displayName = 'TreeItemWrapper';

interface FileTreeProps {
    fileTree: Record<string, FileObject[]>;
    currentPath: string;
    selectedFile: string | null;
    selectedFiles: string[];
    sortBy: 'name' | 'size' | 'date' | 'type';
    sortDirection: 'asc' | 'desc';
    onFileSelect: (path: string, isFile: boolean) => void;
    onPathChange: (path: string) => void;
    onDirectoryLoad: (path: string) => Promise<FileObject[]>;
    onToggleFileSelection: (path: string) => void;
    onSetSelectedFiles?: (files: string[]) => void;
    onSortChange?: (sortBy: 'name' | 'size' | 'date' | 'type') => void;
    onSelectAll?: () => void;
    onClearSelection?: () => void;
    onNewFile?: () => void;
    onNewFolder?: () => void;
    onPullUrl?: () => void;
    onFileClose?: () => void;
    onShowProperties?: (path: string) => void;
    trashRefreshNonce?: number;
    onRegisterUploadTrigger?: (trigger: (() => void) | null) => void;
    onRegisterSearchFocus?: (trigger: (() => void) | null) => void;
    onRegisterTrashTrigger?: (trigger: (() => void) | null) => void;
    onRegisterTrashSettingsTrigger?: (trigger: (() => void) | null) => void;
    onRegisterViewModeChange?: (trigger: ((mode: 'tree' | 'browse' | 'grid') => void) | null, currentMode: 'tree' | 'browse' | 'grid') => void;
    onRegisterTrashCleanupState?: (
        settings: TrashCleanupSettings | null,
        onSave: (values: { trash_cleanup_enabled: boolean; trash_retention_days: number; trash_retention_unit: 'days' | 'hours' }) => Promise<void>,
        canConfigure: boolean
    ) => void;
    showTrashIcons?: boolean;
    onOpenSettings?: () => void;
    onOpenHistory?: () => void;
    embedded?: boolean;
}
const FileTree: React.FC<FileTreeProps> = ({
    fileTree,
    currentPath,
    selectedFile,
    selectedFiles,
    sortBy,
    sortDirection,
    onFileSelect,
    onPathChange,
    onDirectoryLoad,
    onToggleFileSelection,
    onSetSelectedFiles,
    onSortChange,
    onSelectAll,
    onClearSelection,
    onNewFile,
    onNewFolder,
    onFileClose,
    onShowProperties,
    trashRefreshNonce,
    onRegisterUploadTrigger,
    onRegisterSearchFocus,
    onRegisterTrashTrigger,
    onRegisterTrashSettingsTrigger,
    onRegisterViewModeChange,
    onRegisterTrashCleanupState,
    showTrashIcons = false,
    onOpenSettings,
    onOpenHistory,
    embedded = false,
}) => {
    const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['/']));
    const [viewMode, setViewMode] = useState<'tree' | 'browse' | 'grid'>(() => {
        if (typeof window === 'undefined') return 'tree';
        const stored = window.localStorage.getItem('bfm-file-view-mode');
        return (stored === 'browse' || stored === 'grid') ? stored : 'tree';
    });
    const [isEditingPath, setIsEditingPath] = useState(false);
    const [pathInput, setPathInput] = useState(currentPath);
    const [contextMenu, setContextMenu] = useState<{ x: number; y: number; path: string; isFile: boolean } | null>(null);
    const [uploads, setUploads] = useState<Map<string, UploadProgress>>(new Map());
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showUploadPickerModal, setShowUploadPickerModal] = useState(false);
    const [uploadMode, setUploadMode] = useState<'device' | 'url'>('device');
    const [uploadTargetDirectories, setUploadTargetDirectories] = useState<string[]>([]);
    const [actionMode, setActionMode] = useState<'file' | 'folder'>('file');
    const [actionTargetDirectories, setActionTargetDirectories] = useState<string[]>([]);
    const [showSearchPanel, setShowSearchPanel] = useState(false);
    const [showRenameModal, setShowRenameModal] = useState(false);
    const [showPermissionsModal, setShowPermissionsModal] = useState(false);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [showMoveToTrashConfirm, setShowMoveToTrashConfirm] = useState(false);
    const [showUnarchiveConfirm, setShowUnarchiveConfirm] = useState(false);
    const [showTrashBinModal, setShowTrashBinModal] = useState(false);
    const [showTrashCleanupModal, setShowTrashCleanupModal] = useState(false);
    const [unarchiveProgress, setUnarchiveProgress] = useState<{ filename: string; isExtracting: boolean } | null>(null);
    const [optimisticMoves, setOptimisticMoves] = useState<OptimisticMove[]>([]);
    const [pendingDragMove, setPendingDragMove] = useState<{ dragData: InternalDragData; destination: string } | null>(null);
    const [modalTargetPath, setModalTargetPath] = useState<string>('');
    const fileInputRef = React.useRef<HTMLInputElement>(null);
    const expandedFoldersRef = React.useRef<Set<string>>(expandedFolders);
    const searchInputRef = React.useRef<HTMLInputElement>(null);
    const uploadTargetRef = React.useRef<string[] | null>(null);
    const [isMobileViewport, setIsMobileViewport] = useState(false);
    const [marquee, setMarquee] = useState<{ startX: number; startY: number; currentX: number; currentY: number } | null>(null);
    const marqueeBoxRef = useRef<HTMLDivElement>(null);
    const marqueeActiveRef = useRef(false);
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('better-files');
    const { addFlash } = useFlash();

    const { uploadFiles, uploadFoldersWithNotice } = useMemo(
        () =>
            createUploadHandlers({
                uuid,
                setUploads,
                setShowUploadModal,
                onDirectoryLoad,
                addFlash,
                onError: clearAndAddHttpError,
            }),
        [addFlash, clearAndAddHttpError, onDirectoryLoad, setShowUploadModal, setUploads, uuid]
    );

    useEffect(() => {
        expandedFoldersRef.current = expandedFolders;
    }, [expandedFolders]);

    useEffect(() => {
        if (typeof window === 'undefined') return;
        window.localStorage.setItem('bfm-file-view-mode', viewMode);
    }, [viewMode]);

    useEffect(() => {
        if (!isEditingPath) {
            setPathInput(currentPath);
        }
    }, [currentPath, isEditingPath]);

    const getParentPath = useCallback(getParentPathUtil, []);
    const safeNormalizePath = useCallback(safeNormalizePathUtil, []);
    const normalizePath = useCallback(normalizePathUtil, []);
    const selectedFilesSet = useMemo(() => new Set(selectedFiles), [selectedFiles]);

    const applyOptimisticMoves = useCallback((baseTree: Record<string, FileObject[]>, moves: OptimisticMove[]) => {
        if (moves.length === 0) return baseTree;
        const nextTree: Record<string, FileObject[]> = { ...baseTree };
        const ensureDir = (dir: string) => {
            if (!nextTree[dir]) nextTree[dir] = [];
            else nextTree[dir] = [...nextTree[dir]];
        };
        moves.forEach((move) => {
            const fromDir = getParentPath(move.fromPath);
            const toDir = getParentPath(move.toPath);
            const fromName = move.fromPath.substring(move.fromPath.lastIndexOf('/') + 1);
            const toName = move.toPath.substring(move.toPath.lastIndexOf('/') + 1);
            if (!fromDir || !toDir) return;
            ensureDir(fromDir);
            ensureDir(toDir);
            const fromList = nextTree[fromDir];
            const fromIndex = fromList.findIndex((entry) => entry.name === fromName);
            if (fromIndex === -1) return;
            const [movedItem] = fromList.splice(fromIndex, 1);
            if (fromDir === toDir) {
                fromList.splice(fromIndex, 0, { ...movedItem, name: toName });
            } else {
                nextTree[toDir].push({ ...movedItem, name: toName });
            }
        });
        return nextTree;
    }, [getParentPath]);

    const viewFileTree = useMemo(
        () => applyOptimisticMoves(fileTree, optimisticMoves),
        [applyOptimisticMoves, fileTree, optimisticMoves]
    );

    const refreshQueueRef = useRef<Set<string>>(new Set());
    const refreshResolversRef = useRef<Array<() => void>>([]);
    const refreshTimerRef = useRef<NodeJS.Timeout | null>(null);

    const scheduleDirectoryRefresh = useCallback((paths: string[]) => {
        const normalized = paths.map((path) => safeNormalizePath(path || '/'));
        normalized.forEach((path) => refreshQueueRef.current.add(path));
        return new Promise<void>((resolve) => {
            refreshResolversRef.current.push(resolve);
            if (refreshTimerRef.current) return;
            refreshTimerRef.current = setTimeout(async () => {
                const dirs = Array.from(refreshQueueRef.current);
                refreshQueueRef.current.clear();
                refreshTimerRef.current = null;
                try {
                    await Promise.all(dirs.map((dir) => onDirectoryLoad(dir)));
                } finally {
                    const resolvers = refreshResolversRef.current;
                    refreshResolversRef.current = [];
                    resolvers.forEach((fn) => fn());
                }
            }, 350);
        });
    }, [onDirectoryLoad, safeNormalizePath]);

    const addOptimisticMoves = useCallback((moves: OptimisticMove[]) => {
        if (moves.length === 0) return;
        setOptimisticMoves((prev) => [...prev, ...moves]);
    }, []);

    const removeOptimisticMoves = useCallback((moves: OptimisticMove[]) => {
        if (moves.length === 0) return;
        const ids = new Set(moves.map((move) => move.id));
        setOptimisticMoves((prev) => prev.filter((move) => !ids.has(move.id)));
    }, []);

    const getSearchResultDirectory = useCallback((result: FileSearchResult): string => {
        if (!result.is_file) return safeNormalizePath(result.path);
        if (result.directory && result.directory !== '/') return safeNormalizePath(result.directory);
        const lastSlash = result.path.lastIndexOf('/');
        if (lastSlash <= 0) return '/';
        return safeNormalizePath(result.path.slice(0, lastSlash));
    }, [safeNormalizePath]);

    const ensureDirectoryLoaded = useCallback(async (path: string) => {
        const normalized = safeNormalizePath(path || '/');
        if (normalized === '/' || Object.prototype.hasOwnProperty.call(fileTree, normalized)) return;
        try {
            await onDirectoryLoad(normalized);
        } catch {
        }
    }, [fileTree, onDirectoryLoad, safeNormalizePath]);

    const expandToPath = useCallback(async (path: string) => {
        const normalized = safeNormalizePath(path || '/');
        const parts = normalized.split('/').filter(Boolean);
        const nextExpanded = new Set(expandedFoldersRef.current);
        nextExpanded.add('/');
        let current = '';
        for (const part of parts) {
            current = current ? `${current}/${part}` : `/${part}`;
            nextExpanded.add(current);
            await ensureDirectoryLoaded(current);
        }
        setExpandedFolders(nextExpanded);
    }, [ensureDirectoryLoaded, safeNormalizePath]);

    const {
        trashCleanupSettings,
        canSearchContents,
        refreshTrashCount,
        handleTrashCleanupSave,
    } = useTrashSettings({
        uuid,
        trashRefreshNonce,
        clearAndAddHttpError,
        addFlash,
        onRegisterTrashTrigger,
        onRegisterTrashSettingsTrigger,
        onRegisterTrashCleanupState,
        setShowTrashBinModal,
        setShowTrashCleanupModal,
    });

    const {
        searchQuery,
        setSearchQuery,
        searchResults,
        isSearching,
        searchError,
        isLocalSearch,
        searchIncludeContent,
        setSearchIncludeContent,
        openSearchResult,
        revealSearchPath,
    } = useFileSearch({
        uuid,
        viewFileTree,
        canSearchContents,
        onFileSelect,
        onPathChange,
        viewMode,
        safeNormalizePath,
        getParentPath,
        ensureDirectoryLoaded,
        expandToPath,
        getSearchResultDirectory,
    });

    useEffect(() => {
        if (!canSearchContents && searchIncludeContent) {
            setSearchIncludeContent(false);
        }
    }, [canSearchContents, searchIncludeContent, setSearchIncludeContent]);

    useEffect(() => {
        if (!onRegisterUploadTrigger) return;
        onRegisterUploadTrigger(() => {
            fileInputRef.current?.click();
        });
        return () => {
            onRegisterUploadTrigger(null);
        };
    }, [onRegisterUploadTrigger]);


    useEffect(() => {
        if (!onRegisterSearchFocus) return;
        const focusSearch = () => {
            searchInputRef.current?.focus();
            searchInputRef.current?.select();
        };
        onRegisterSearchFocus(focusSearch);
        return () => {
            onRegisterSearchFocus(null);
        };
    }, [onRegisterSearchFocus]);

    useEffect(() => {
        if (!onRegisterViewModeChange) return;
        onRegisterViewModeChange((mode) => {
            setViewMode(mode);
            if (typeof window !== 'undefined') {
                window.localStorage.setItem('bfm-file-view-mode', mode);
            }
        }, viewMode);
        return () => {
            onRegisterViewModeChange(null, viewMode);
        };
    }, [onRegisterViewModeChange, viewMode]);

    useEffect(() => {
        if (typeof window === 'undefined') return;
        const media = window.matchMedia('(max-width: 767px)');
        const update = () => setIsMobileViewport(media.matches);
        update();
        if (media.addEventListener) {
            media.addEventListener('change', update);
            return () => media.removeEventListener('change', update);
        }
        media.addListener(update);
        return () => media.removeListener(update);
    }, []);

    const toggleFolder = async (path: string) => {
        const newExpanded = new Set(expandedFolders);
        if (newExpanded.has(path)) {
            newExpanded.delete(path);
        } else {
            newExpanded.add(path);
            await onDirectoryLoad(path);
        }
        setExpandedFolders(newExpanded);
    };
    const formatSize = (bytes: number): string => {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    };
    const formatDate = (date: Date): string => {
        if (!date || isNaN(date.getTime())) return '';
        const diffMs = Date.now() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        if (diffMins < 1) return 'now';
        if (diffMins < 60) return `${diffMins}m`;
        const diffHours = Math.floor(diffMs / 3600000);
        if (diffHours < 24) return `${diffHours}h`;
        const diffDays = Math.floor(diffMs / 86400000);
        if (diffDays < 30) return `${diffDays}d`;
        return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    };
    const handleContextMenu = (e: React.MouseEvent, path: string, isFile: boolean) => {
        e.preventDefault();
        setContextMenu({ x: e.clientX, y: e.clientY, path, isFile });
    };

    const handleEditAudioMetadata = (path: string) => {
        onFileSelect(path, true);
        if (typeof window !== 'undefined') {
            (window as any).__bfmEditAudioMetadataPath = path;
            window.dispatchEvent(new CustomEvent('bfm:edit-audio-metadata', { detail: { path } }));
        }
    };
    const handleCopyFile = useCallback(async (path: string) => {
        try {
            await copyFile(uuid, path);
            const dir = path.substring(0, path.lastIndexOf('/')) || '/';
            await onDirectoryLoad(dir);
            addFlash({ key: 'better-files', type: 'success', message: `Duplicated ${path.split('/').pop()}` });
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, onDirectoryLoad, addFlash, clearAndAddHttpError]);
    const shouldSuppressClick = useCallback(() => {
        if (!suppressClickRef.current) return false;
        suppressClickRef.current = false;
        return true;
    }, []);

    const dragActiveRefProxy = useRef<React.MutableRefObject<boolean> | null>(null);
    const marqueeRafRef = useRef<number | null>(null);
    const handleMarqueeDown = useCallback((e: React.PointerEvent) => {
        if (e.button !== 0) return;
        if (isMobileViewport) return;
        if (!onSetSelectedFiles) return;
        const target = e.target as HTMLElement;
        if (target.closest('input, button, a, label, [data-no-drag]')) return;

        const treeItem = target.closest('.tree-item');
        if (treeItem && treeItem !== target) return;
        if (treeItem) e.stopPropagation();

        const container = treeContainerRef.current;
        if (!container) return;

        const rect = container.getBoundingClientRect();
        const startClientX = e.clientX;
        const startClientY = e.clientY;
        const scrollStartX = e.clientX - rect.left;
        const scrollStartY = e.clientY - rect.top + container.scrollTop;
        let activated = false;
        let itemCache: { path: string; top: number; bottom: number }[] | null = null;
        let baseSelection = new Set<string>();
        let lastPublishedSelection: Set<string> | null = null;
        let latestClientX = startClientX;
        let latestClientY = startClientY;

        const buildItemCache = () => {
            const containerRect = container.getBoundingClientRect();
            const scrollTop = container.scrollTop;
            const items = container.querySelectorAll('.tree-item');
            const cache: { path: string; top: number; bottom: number }[] = [];
            items.forEach((el) => {
                const htmlEl = el as HTMLElement;
                const path = htmlEl.dataset.filePath || htmlEl.dataset.folderId;
                if (!path) return;
                const elRect = htmlEl.getBoundingClientRect();
                cache.push({
                    path,
                    top: elRect.top - containerRect.top + scrollTop,
                    bottom: elRect.bottom - containerRect.top + scrollTop,
                });
            });
            return cache;
        };

        const handleMove = (me: PointerEvent) => {
            if (dragActiveRefProxy.current?.current) {
                handleUp();
                return;
            }
            latestClientX = me.clientX;
            latestClientY = me.clientY;

            if (!activated) {
                const dx = me.clientX - startClientX;
                const dy = me.clientY - startClientY;
                if (Math.hypot(dx, dy) < 5) return;
                activated = true;
                marqueeActiveRef.current = true;
                baseSelection = me.shiftKey ? new Set(selectedFiles) : new Set();
                lastPublishedSelection = baseSelection.size > 0 ? new Set(baseSelection) : null;
                itemCache = buildItemCache();
                setMarquee({ startX: scrollStartX, startY: scrollStartY, currentX: scrollStartX, currentY: scrollStartY });
            }

            if (marqueeRafRef.current !== null) return;
            marqueeRafRef.current = requestAnimationFrame(() => {
                marqueeRafRef.current = null;
                if (!itemCache) return;

                const mx = latestClientX - rect.left;
                const my = latestClientY - rect.top + container.scrollTop;
                const x = Math.min(scrollStartX, mx);
                const y = Math.min(scrollStartY, my);
                const w = Math.abs(mx - scrollStartX);
                const h = Math.abs(my - scrollStartY);
                const marqueeEl = marqueeBoxRef.current;
                if (marqueeEl) {
                    marqueeEl.style.transform = `translate3d(${x}px, ${y}px, 0)`;
                    marqueeEl.style.width = `${w}px`;
                    marqueeEl.style.height = `${h}px`;
                    marqueeEl.style.opacity = w < 4 && h < 4 ? '0' : '1';
                }

                const minY = Math.min(scrollStartY, my);
                const maxY = Math.max(scrollStartY, my);
                const merged = new Set(baseSelection);
                for (const item of itemCache) {
                    if (item.bottom > minY && item.top < maxY) {
                        merged.add(item.path);
                    }
                }

                if (sameSelectionSet(lastPublishedSelection, merged)) return;
                lastPublishedSelection = new Set(merged);
                onSetSelectedFiles(Array.from(merged));
            });
        };

        const handleUp = () => {
            window.removeEventListener('pointermove', handleMove);
            window.removeEventListener('pointerup', handleUp);
            if (marqueeRafRef.current !== null) {
                cancelAnimationFrame(marqueeRafRef.current);
                marqueeRafRef.current = null;
            }
            marqueeActiveRef.current = false;
            setMarquee(null);
        };

        window.addEventListener('pointermove', handleMove);
        window.addEventListener('pointerup', handleUp);
    }, [isMobileViewport, onSetSelectedFiles, selectedFiles]);

    const executeDragMove = useCallback(async (dragData: InternalDragData, destination: string) => {
        if (dragData.multiple) {
            const files = dragData.files;
            const renameData: { from: string; to: string }[] = [];
            const optimisticBatch: OptimisticMove[] = [];
            const sourceDirs = new Set<string>();
            let movedSelectedFile = false;
            for (const file of files) {
                const sourceDir = file.path.substring(0, file.path.lastIndexOf('/')) || '/';
                sourceDirs.add(sourceDir);
                if (destination === sourceDir) continue;
                if (destination === file.path) continue;
                let fromPath = file.path;
                if (fromPath.startsWith('/')) fromPath = fromPath.substring(1);
                let destDir = destination;
                if (destDir.startsWith('/')) destDir = destDir.substring(1);
                let toPath = destDir ? `${destDir}/${file.name}` : file.name;
                fromPath = fromPath.replace(/\/+/g, '/');
                toPath = toPath.replace(/\/+/g, '/');
                renameData.push({ from: fromPath, to: toPath });
                const fromFull = normalizePath(file.path);
                const toFull = normalizePath(destination === '/' ? `/${file.name}` : `${destination}/${file.name}`);
                optimisticBatch.push({
                    id: `${fromFull}->${toFull}`,
                    fromPath: fromFull,
                    toPath: toFull,
                    isFile: true,
                });
                if (selectedFile === file.path) {
                    movedSelectedFile = true;
                }
            }
            if (renameData.length > 0) {
                addOptimisticMoves(optimisticBatch);
                try {
                    await renameFile(uuid, '/', renameData);
                    const refreshDirs = new Set<string>(sourceDirs);
                    refreshDirs.add(destination);
                    if (!refreshDirs.has(currentPath) && destination !== currentPath) {
                        refreshDirs.add(currentPath);
                    }
                    scheduleDirectoryRefresh(Array.from(refreshDirs)).then(() => {
                        removeOptimisticMoves(optimisticBatch);
                    });
                    if (onClearSelection) {
                        onClearSelection();
                    }
                    addFlash({
                        key: 'file-move-success',
                        type: 'success',
                        message: `Moved ${renameData.length} files to ${destination}`,
                    });
                    if (movedSelectedFile && onFileClose) {
                        onFileClose();
                    }
                } catch (error) {
                    removeOptimisticMoves(optimisticBatch);
                    clearAndAddHttpError(error as Error);
                }
            }
            return;
        }

        const sourceDir = dragData.path.substring(0, dragData.path.lastIndexOf('/')) || '/';
        if (destination === dragData.path || destination === sourceDir) {
            return;
        }
        if (!dragData.isFile && destination.startsWith(dragData.path + '/')) {
            clearAndAddHttpError({ message: 'Cannot move a folder into itself' } as Error);
            return;
        }
        let fromPath = dragData.path;
        if (fromPath.startsWith('/')) fromPath = fromPath.substring(1);
        let destDir = destination;
        if (destDir.startsWith('/')) destDir = destDir.substring(1);
        let toPath = destDir ? `${destDir}/${dragData.name}` : dragData.name;
        fromPath = fromPath.replace(/\/+/g, '/');
        toPath = toPath.replace(/\/+/g, '/');
        const fromFull = normalizePath(dragData.path);
        const toFull = normalizePath(destination === '/' ? `/${dragData.name}` : `${destination}/${dragData.name}`);
        const optimisticMove: OptimisticMove = {
            id: `${fromFull}->${toFull}`,
            fromPath: fromFull,
            toPath: toFull,
            isFile: dragData.isFile,
        };
        addOptimisticMoves([optimisticMove]);
        try {
            await renameFile(uuid, '/', [{ from: fromPath, to: toPath }]);
            const refreshDirs = new Set<string>([sourceDir, destination]);
            if (currentPath !== sourceDir && currentPath !== destination) {
                refreshDirs.add(currentPath);
            }
            scheduleDirectoryRefresh(Array.from(refreshDirs)).then(() => {
                removeOptimisticMoves([optimisticMove]);
            });
            addFlash({
                key: 'file-move-success',
                type: 'success',
                message: `Moved ${dragData.name} to ${destination}`,
            });
            if (selectedFile === dragData.path && onFileClose) {
                onFileClose();
            }
        } catch (error) {
            removeOptimisticMoves([optimisticMove]);
            clearAndAddHttpError(error as Error);
        }
    }, [
        addFlash,
        addOptimisticMoves,
        clearAndAddHttpError,
        currentPath,
        normalizePath,
        onClearSelection,
        onFileClose,
        removeOptimisticMoves,
        renameFile,
        scheduleDirectoryRefresh,
        selectedFile,
        uuid,
    ]);

    const performInternalMove = useCallback(async (dragData: InternalDragData, destination: string) => {
        const confirmEnabled = localStorage.getItem('bfm-drag-confirm-enabled') !== 'false';
        if (confirmEnabled) {
            setPendingDragMove({ dragData, destination });
            return;
        }
        await executeDragMove(dragData, destination);
    }, [executeDragMove]);

    const cancelUpload = (fileName: string) => {
        const upload = uploads.get(fileName);
        if (upload) {
            upload.controller.abort();
            const newUploads = new Map(uploads);
            newUploads.delete(fileName);
            setUploads(newUploads);
        }
    };
    const cancelAllUploads = () => {
        uploads.forEach((upload) => upload.controller.abort());
        setUploads(new Map());
        setShowUploadModal(false);
    };
    const isDirectoryPath = useCallback((path: string) => isDirectoryPathUtil(viewFileTree, path), [viewFileTree]);

    const resolveActionTargetPaths = useCallback(
        () =>
            resolveActionTargetPathsUtil({
                fileTree: viewFileTree,
                selectedFiles,
                currentPath,
                viewMode,
                isDirectory: isDirectoryPath,
            }),
        [currentPath, isDirectoryPath, selectedFiles, viewFileTree, viewMode]
    );

    const getModalTargetPath = useCallback(() => modalTargetPath, [modalTargetPath]);
    const {
        handleDelete,
        submitDelete,
        handleMoveToTrash,
        submitMoveToTrash,
        handleCreateFolder,
        handleCreateFile,
        handleArchive,
        handlePermissions,
        handleUnarchive,
        submitUnarchive,
        handleRename,
        submitRename,
        submitCreateFile,
        submitCreateFolder,
    } = useMemo(
        () =>
            createFileOps({
                uuid,
                getModalTargetPath,
                setModalTargetPath,
                setShowDeleteConfirm,
                setShowMoveToTrashConfirm,
                setShowUnarchiveConfirm,
                setShowRenameModal,
                setShowPermissionsModal,
                setShowCreateModal,
                setActionTargetDirectories,
                setActionMode,
                setUnarchiveProgress,
                onDirectoryLoad,
                onFileSelect,
                clearAndAddHttpError,
                addFlash,
                clearFlashes,
                refreshTrashCount,
            }),
        [
            addFlash,
            clearAndAddHttpError,
            clearFlashes,
            getModalTargetPath,
            onDirectoryLoad,
            onFileSelect,
            refreshTrashCount,
            setActionMode,
            setActionTargetDirectories,
            setModalTargetPath,
            setShowCreateModal,
            setShowDeleteConfirm,
            setShowMoveToTrashConfirm,
            setShowPermissionsModal,
            setShowRenameModal,
            setShowUnarchiveConfirm,
            setUnarchiveProgress,
            uuid,
        ]
    );

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.currentTarget.files ? Array.from(e.currentTarget.files) : [];
        if (files.length === 0) return;
        const targetPaths = uploadTargetRef.current ?? resolveActionTargetPaths();
        uploadTargetRef.current = null;
        for (const targetPath of targetPaths) {
            await uploadFiles(files, targetPath);
        }
        e.currentTarget.value = '';
    };
    const handleExternalDrop = useCallback(async (folderFiles: FolderFile[], destination: string, hasFolders: boolean) => {
        if (folderFiles.length === 0) return;
        await uploadFoldersWithNotice(folderFiles, destination, hasFolders);
    }, [uploadFoldersWithNotice]);

    const {
        isDragging,
        draggingFile,
        draggedPaths,
        dragOverPath,
        dragGhostInfo,
        dragGhostRef,
        hoverOverlayRef,
        treeContainerRef,
        suppressClickRef,
        dragActiveRef,
        handleItemPointerDown,
        handleDragOver,
        handleDragLeave,
        handleDrop,
        allowDrop,
    } = useDragAndDropListener({
        isMobileViewport,
        currentPath,
        viewMode,
        selectedFiles,
        normalizePath,
        getParentPath,
        onInternalMove: performInternalMove,
        onExternalDrop: handleExternalDrop,
        onError: (error) => clearAndAddHttpError(error),
        trackDragOverPath: true, 
        onDragStartSplit: () => {
            window.dispatchEvent(new Event('bfm:split-drag-start'));
            document.dispatchEvent(new Event('bfm:split-drag-start'));
        },
        onDragEndSplit: () => {
            window.dispatchEvent(new Event('bfm:split-drag-end'));
            document.dispatchEvent(new Event('bfm:split-drag-end'));
        },
        onSplitHover: (over, pane) => {
            window.dispatchEvent(new CustomEvent('bfm:split-hover', { detail: { over, pane } }));
        },
        marqueeActiveRef,
    });
    dragActiveRefProxy.current = dragActiveRef;

    const isDraggedPath = useCallback((path: string): boolean => draggedPaths.has(normalizePath(path)), [draggedPaths, normalizePath]);

    const getTooltipContent = useCallback((name: string, path: string, isDirectory: boolean) => (
        <div className="flex flex-col gap-1">
            <span className="text-xs font-semibold text-neutral-100">{name}</span>
            <span className="text-[11px] font-mono text-neutral-300 break-all">{path}</span>
            {isDirectory ? <span className="text-[10px] uppercase tracking-wide text-neutral-400">Folder</span> : null}
        </div>
    ), []);


    const renderSearchResults = () => (
        <SearchResultsList
            results={searchResults}
            searchQuery={searchQuery}
            renderItem={(result, derivedDirectory) => {
                const isDragged = isDraggedPath(result.path);
                const isSelected = selectedFile === result.path;
                const isChecked = selectedFilesSet.has(result.path);

                return (
                    <Tooltip
                        disabled={!!draggingFile || isDragging}
                        delay={{ open: 250, close: 0 }}
                        placement="right"
                        content={getTooltipContent(result.name, result.path, !result.is_file)}
                    >
                        <TreeItemWrapper key={result.path} depth={0}>
                            <TreeItem
                                depth={0}
                                selected={isSelected}
                                checked={isChecked}
                                data-folder-id={!result.is_file ? result.path : undefined}
                                data-file-path={result.is_file ? result.path : undefined}
                                style={getDragHiddenStyle(isDragged)}
                                onPointerDown={(e: React.PointerEvent) => handleItemPointerDown(e, result.path, result.name, result.is_file)}
                                onClick={() => {
                                    if (shouldSuppressClick()) return;
                                    void openSearchResult(result);
                                }}
                                onContextMenu={(e: React.MouseEvent) => handleContextMenu(e, result.path, result.is_file)}
                                {...(!result.is_file && {
                                    onDragOver: allowDrop,
                                    onDrop: (e: React.DragEvent) => handleDrop(e, result.path),
                                })}
                            >
                                <Input
                                    type="checkbox"
                                    checked={isChecked}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                        e.stopPropagation();
                                        onToggleFileSelection(result.path);
                                    }}
                                    onClick={(e: React.MouseEvent) => e.stopPropagation()}
                                />
                                <FileTypeBadge filename={result.name} isFolder={!result.is_file} isActive={isChecked || isSelected} />
                                <div className="flex-1 min-w-0">
                                    <FileName className="transition-colors block">{result.name}</FileName>
                                    <div className="text-xs text-neutral-300 font-mono truncate">
                                        {derivedDirectory}
                                    </div>
                                </div>
                                {result.is_file && (
                                    <FileSize className={cx('transition-colors', (isChecked || isSelected) && 'text-neutral-300')}>
                                        {formatSize(result.size)}
                                    </FileSize>
                                )}
                            </TreeItem>
                        </TreeItemWrapper>
                    </Tooltip>
                );
            }}
        />
    );

    const parentPath = getParentPath(currentPath);
    const renderBrowseParentRow = () => (
        <Tooltip
            disabled={!!draggingFile || isDragging}
            delay={{ open: 250, close: 0 }}
            placement="right"
            content={getTooltipContent('..', parentPath, true)}
        >
            <TreeItemWrapper key={`${currentPath}::__parent__`} depth={0}>
                <TreeItem
                    depth={0}
                    selected={false}
                    checked={false}
                    data-folder-id={parentPath}
                    onClick={() => {
                        if (shouldSuppressClick()) return;
                        onFileSelect(parentPath, false);
                    }}
                    onContextMenu={(e) => handleContextMenu(e, parentPath, false)}
                    onDragOver={allowDrop}
                    onDrop={(e: React.DragEvent) => handleDrop(e, parentPath)}
                >
                    <Input
                        type="checkbox"
                        checked={false}
                        disabled
                        onChange={() => { }}
                        onClick={(e) => e.stopPropagation()}
                    />
                    <FileTypeBadge filename=".." isFolder={true} />
                    <FileName className="transition-colors">..</FileName>
                    <span className="text-xs text-neutral-300 ml-2">Parent directory</span>
                </TreeItem>
            </TreeItemWrapper>
        </Tooltip>
    );

    const renderBrowseRow = (file: FileObject, fullPath: string, isLastChild: boolean) => {
        const isDragged = isDraggedPath(fullPath);
        const isSelected = selectedFile === fullPath;
        const isChecked = selectedFilesSet.has(fullPath);

        return (
            <Tooltip
                disabled={!!draggingFile || isDragging}
                delay={{ open: 250, close: 0 }}
                placement="right"
                content={getTooltipContent(file.name, fullPath, !file.isFile)}
            >
                <TreeItemWrapper key={fullPath} depth={0} isLastChild={isLastChild}>
                    <TreeItem
                        depth={0}
                        selected={isSelected}
                        checked={isChecked}
                        data-folder-id={!file.isFile ? fullPath : undefined}
                        data-file-path={file.isFile ? fullPath : undefined}
                        style={getDragHiddenStyle(isDragged)}
                        onPointerDown={(e: React.PointerEvent) => handleItemPointerDown(e, fullPath, file.name, file.isFile)}
                        onClick={() => {
                            if (shouldSuppressClick()) return;
                            if (file.isFile) {
                                onFileSelect(fullPath, true);
                            } else {
                                onFileSelect(fullPath, false);
                            }
                        }}
                        onContextMenu={(e) => handleContextMenu(e, fullPath, file.isFile)}
                        {...(!file.isFile && {
                            onDragOver: allowDrop,
                            onDrop: (e: React.DragEvent) => handleDrop(e, fullPath),
                        })}
                    >
                        <Input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                                e.stopPropagation();
                                onToggleFileSelection(fullPath);
                            }}
                            onClick={(e) => e.stopPropagation()}
                        />
                        <FileTypeBadge filename={file.name} isFolder={!file.isFile} isActive={isChecked || isSelected} />
                        <FileName className="transition-colors">{file.name}</FileName>
                        {file.isFile && (
                            <>
                                <FilePermissions mode={file.mode} modeBits={file.modeBits} compact />
                                <FileSize className={cx('transition-colors', (isChecked || isSelected) && 'text-neutral-300')}>
                                    {formatSize(file.size)}
                                </FileSize>
                            </>
                        )}
                        {file.modifiedAt && (
                            <FileSize className={cx('transition-colors ml-auto', (isChecked || isSelected) ? 'text-neutral-300' : 'text-neutral-500')}>
                                {formatDate(new Date(file.modifiedAt))}
                            </FileSize>
                        )}
                    </TreeItem>
                </TreeItemWrapper>
            </Tooltip>
        );
    };

    const renderFolderRow = (
        file: FileObject,
        fullPath: string,
        depth: number,
        isLastChild: boolean,
        isExpanded: boolean
    ) => {
        const isDragged = isDraggedPath(fullPath);
        const isSelected = selectedFile === fullPath;
        const isChecked = selectedFilesSet.has(fullPath);

        return (
            <Tooltip
                disabled={!!draggingFile || isDragging}
                delay={{ open: 250, close: 0 }}
                placement="right"
                content={getTooltipContent(file.name, fullPath, true)}
            >
                <TreeItemWrapper
                    depth={depth}
                    isLastChild={isLastChild}
                >
                    <TreeItem
                        depth={depth}
                        selected={isSelected}
                        checked={isChecked}
                        data-folder-id={fullPath}
                        style={{
                            ...getDragHiddenStyle(isDragged),
                        }}
                        onPointerDown={(e: React.PointerEvent) => handleItemPointerDown(e, fullPath, file.name, false)}
                        onClick={() => {
                            if (shouldSuppressClick()) return;
                            toggleFolder(fullPath);
                        }}
                        onContextMenu={(e) => handleContextMenu(e, fullPath, false)}
                        onDragOver={allowDrop}
                        onDrop={(e) => handleDrop(e, fullPath)}
                    >
                        <Input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                                e.stopPropagation();
                                onToggleFileSelection(fullPath);
                            }}
                            onClick={(e) => e.stopPropagation()}
                        />
                        <svg
                            className={cx(
                                'w-4 h-4 flex-shrink-0 transition-transform duration-200 ease-in-out',
                                isChecked || isSelected ? 'text-neutral-300' : 'text-neutral-300'
                            )}
                            style={{
                                transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)',
                            }}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                        <FileTypeBadge filename={file.name} isFolder={true} isOpen={isExpanded} isActive={isChecked || isSelected} />
                        <FileName className="transition-colors">{file.name}</FileName>
                    </TreeItem>
                </TreeItemWrapper>
            </Tooltip>
        );
    };

    const renderTreeFileRow = (file: FileObject, fullPath: string, depth: number, isLastChild: boolean) => {
        const isDragged = isDraggedPath(fullPath);
        const isSelected = selectedFile === fullPath;
        const isChecked = selectedFilesSet.has(fullPath);

        return (
            <Tooltip
                disabled={!!draggingFile || isDragging}
                delay={{ open: 250, close: 0 }}
                placement="right"
                content={getTooltipContent(file.name, fullPath, false)}
            >
                <TreeItemWrapper
                    depth={depth}
                    isLastChild={isLastChild}
                >
                    <TreeItem
                        depth={depth}
                        selected={isSelected}
                        checked={isChecked}
                        style={getDragHiddenStyle(isDragged)}
                        data-file-path={fullPath}
                        onPointerDown={(e: React.PointerEvent) => handleItemPointerDown(e, fullPath, file.name, true)}
                        onClick={() => {
                            if (shouldSuppressClick()) return;
                            onFileSelect(fullPath, true);
                        }}
                        onContextMenu={(e) => handleContextMenu(e, fullPath, true)}
                    >
                        <Input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                                e.stopPropagation();
                                onToggleFileSelection(fullPath);
                            }}
                            onClick={(e) => e.stopPropagation()}
                        />
                        <FileTypeBadge filename={file.name} isFolder={false} isActive={isChecked || isSelected} />
                        <FileName className="transition-colors">{file.name}</FileName>
                        <FilePermissions mode={file.mode} modeBits={file.modeBits} compact />
                        <FileSize className={cx('transition-colors', (isChecked || isSelected) && 'text-neutral-300')}>
                            {formatSize(file.size)}
                        </FileSize>
                        {file.modifiedAt && (
                            <FileSize className={cx('transition-colors', (isChecked || isSelected) ? 'text-neutral-300' : 'text-neutral-500')}>
                                {formatDate(new Date(file.modifiedAt))}
                            </FileSize>
                        )}
                    </TreeItem>
                </TreeItemWrapper>
            </Tooltip>
        );
    };

    const renderGridItem = (file: FileObject, fullPath: string) => {
        const isDragged = isDraggedPath(fullPath);
        const isSelected = selectedFile === fullPath;
        const isChecked = selectedFilesSet.has(fullPath);
        const isActive = isSelected || isChecked;

        return (
            <div
                data-folder-id={!file.isFile ? fullPath : undefined}
                data-file-path={file.isFile ? fullPath : undefined}
                style={getDragHiddenStyle(isDragged)}
                onPointerDown={(e: React.PointerEvent) => handleItemPointerDown(e, fullPath, file.name, file.isFile)}
                onClick={() => {
                    if (shouldSuppressClick()) return;
                    if (file.isFile) {
                        onFileSelect(fullPath, true);
                    } else {
                        onFileSelect(fullPath, false);
                    }
                }}
                onContextMenu={(e) => handleContextMenu(e, fullPath, file.isFile)}
                {...(!file.isFile && {
                    onDragOver: allowDrop,
                    onDrop: (e: React.DragEvent) => handleDrop(e, fullPath),
                })}
                className={cx(
                    'group relative flex flex-col items-center gap-2 rounded-md border border-transparent',
                    'w-full min-h-[92px] px-2 pt-3 pb-2 cursor-pointer transition-colors duration-150',
                    'hover:bg-gray-600/25 hover:border-white/10',
                    isActive && 'bg-blue-500/20 border-blue-400/40',
                    isChecked && 'ring-1 ring-blue-400/40'
                )}
            >
                <Input
                    type="checkbox"
                    checked={isChecked}
                    onChange={(e) => {
                        e.stopPropagation();
                        onToggleFileSelection(fullPath);
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="absolute top-2 left-2 h-4 w-4"
                />
                <FileTypeBadge filename={file.name} isFolder={!file.isFile} isActive={isActive} className="scale-[1.05]" />
                <div className="text-[11px] leading-snug text-neutral-200 text-center w-full line-clamp-2 min-h-[28px]" title={file.name}>
                    {file.name}
                </div>
                {file.isFile && file.size !== undefined && (
                    <div className="text-[10px] text-neutral-400">
                        {formatSize(file.size)}
                    </div>
                )}
                {file.modifiedAt && (
                    <div className="text-[10px] text-neutral-500">
                        {formatDate(new Date(file.modifiedAt))}
                    </div>
                )}
            </div>
        );
    };

    const isSearchActive = searchQuery.trim().length > 0;
    const fieldClassName = 'bg-gray-500 border-gray-600 text-neutral-300 focus:border-gray-500';
    const targetDirectories = useMemo(() => {
        const baseList = actionTargetDirectories.length ? actionTargetDirectories : ['/'];
        return Array.from(
            new Set(baseList.map((path) => (path.startsWith('/') ? path : `/${path}`)))
        );
    }, [actionTargetDirectories]);
    const uploadDirectories = useMemo(() => {
        const baseList = uploadTargetDirectories.length ? uploadTargetDirectories : ['/'];
        return Array.from(
            new Set(baseList.map((path) => (path.startsWith('/') ? path : `/${path}`)))
        );
    }, [uploadTargetDirectories]);
    const handlePullComplete = useCallback(async () => {
        const dirs = new Set(uploadDirectories.length ? uploadDirectories : ['/']);
        dirs.add(currentPath || '/');
        await Promise.all(Array.from(dirs).map(dir => onDirectoryLoad(dir)));
    }, [currentPath, onDirectoryLoad, uploadDirectories]);
    return (
        <div className="flex flex-col min-h-0 h-full">
            <Header>
                <div className="flex items-center justify-between gap-2 mb-2">
                    <Title className="flex-1 text-xs uppercase tracking-widest text-neutral-300/80">
                        {onSelectAll && onClearSelection && (
                            <label className="flex items-center" title="Select all">
                                <span className="sr-only">Select all files</span>
                                <Input
                                    type="checkbox"
                                    checked={selectedFiles.length > 0}
                                    onChange={(e) => {
                                        if (e.target.checked) {
                                            onSelectAll();
                                        } else {
                                            onClearSelection();
                                        }
                                    }}
                                />
                            </label>
                        )}
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" style={{ color: colors.primary.light }}>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                        </svg>
                        <span>Files</span>
                    </Title>
                    <div
                        className="flex items-center gap-1 flex-nowrap overflow-x-auto overflow-y-hidden max-w-[65%] sm:max-w-none pb-1 -mb-1 [&>*]:shrink-0"
                        style={{ WebkitOverflowScrolling: 'touch', scrollbarWidth: 'thin', touchAction: 'pan-x' }}
                    >
                        <Button.Text
                            type="button"
                            onClick={() => {
                                setModalTargetPath(currentPath);
                                setActionMode('file');
                                setActionTargetDirectories(resolveActionTargetPaths());
                                setShowCreateModal(true);
                            }}
                            title="Create"
                            size={Button.Sizes.Small}
                            shape={Button.Shapes.IconSquare}
                            className="bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0"
                        >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v14m-7-7h14" />
                            </svg>
                        </Button.Text>
                        <Button.Text
                            type="button"
                            onClick={() => {
                                setModalTargetPath(currentPath);
                                setUploadMode('device');
                                setUploadTargetDirectories(resolveActionTargetPaths());
                                setShowUploadPickerModal(true);
                            }}
                            title="Upload"
                            size={Button.Sizes.Small}
                            shape={Button.Shapes.IconSquare}
                            className="bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0"
                        >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                            </svg>
                        </Button.Text>
                        {showTrashIcons && (
                            <>
                                <Button.Text
                                    type="button"
                                    onClick={() => setShowTrashBinModal(true)}
                                    title="Trash Bin"
                                    size={Button.Sizes.Small}
                                    shape={Button.Shapes.IconSquare}
                                    className="bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                </Button.Text>
                                <Button.Text
                                    type="button"
                                    onClick={() => onOpenSettings?.()}
                                    title="File Manager Settings"
                                    size={Button.Sizes.Small}
                                    shape={Button.Shapes.IconSquare}
                                    className="bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                </Button.Text>
                                <Button.Text
                                    type="button"
                                    onClick={() => onOpenHistory?.()}
                                    title="Recent Files"
                                    size={Button.Sizes.Small}
                                    shape={Button.Shapes.IconSquare}
                                    className="bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                </Button.Text>
                            </>
                        )}
                        <Button.Text
                            type="button"
                            onClick={() => {
                                setShowSearchPanel(!showSearchPanel);
                                if (!showSearchPanel) {
                                    setTimeout(() => searchInputRef.current?.focus(), 100);
                                }
                            }}
                            title={showSearchPanel ? 'Hide search' : 'Search files'}
                            className={cx(
                                'bg-transparent border-0 transition-colors',
                                showSearchPanel
                                    ? 'text-neutral-200 bg-gray-600/60'
                                    : 'text-neutral-300 hover:bg-gray-600/60'
                            )}
                            size={Button.Sizes.Small}
                            shape={Button.Shapes.IconSquare}
                            style={showSearchPanel ? { boxShadow: `0 0 0 1px ${colors.primary.opacity(0.35)}` } : undefined}
                        >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                        </Button.Text>
                        <Button.Text
                            type="button"
                            onClick={() => {
                                if (onSortChange) {
                                    const sortOptions: ('name' | 'size' | 'date' | 'type')[] = ['name', 'size', 'date', 'type'];
                                    const currentIndex = sortOptions.indexOf(sortBy);
                                    const nextIndex = (currentIndex + 1) % sortOptions.length;
                                    onSortChange(sortOptions[nextIndex]);
                                }
                            }}
                            title={`Sort by ${sortBy} (${sortDirection === 'asc' ? 'ascending' : 'descending'}) - Click to change`}
                            size={Button.Sizes.Small}
                            shape={Button.Shapes.IconSquare}
                            className="bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0 flex items-center gap-0.5"
                        >
                            {sortBy === 'name' && (
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
                                </svg>
                            )}
                            {sortBy === 'size' && (
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2 1 3 3 3h10c2 0 3-1 3-3V7c0-2-1-3-3-3H7c-2 0-3 1-3 3zm4 3h8M8 14h5" />
                                </svg>
                            )}
                            {sortBy === 'date' && (
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                            )}
                            {sortBy === 'type' && (
                                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                                </svg>
                            )}
                            <span className="text-[10px] font-semibold">
                                {sortDirection === 'asc' ? '↑' : '↓'}
                            </span>
                        </Button.Text>
                    </div>
                </div>
                {viewMode === 'browse' && (
                    <div className="flex items-center gap-2 mb-2">
                        <div className="flex-1 min-w-0 text-xs text-neutral-300">
                            {isEditingPath ? (
                                <div className="relative w-full">
                                    <svg
                                        className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-300 pointer-events-none"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                    </svg>
                                    <Input
                                        value={pathInput}
                                        onChange={(e) => setPathInput(e.target.value)}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter') {
                                                e.preventDefault();
                                                const nextPath = safeNormalizePath(pathInput);
                                                setIsEditingPath(false);
                                                if (nextPath !== currentPath) {
                                                    onFileSelect(nextPath, false);
                                                }
                                            }
                                            if (e.key === 'Escape') {
                                                e.preventDefault();
                                                setIsEditingPath(false);
                                                setPathInput(currentPath);
                                            }
                                        }}
                                        onBlur={() => {
                                            const nextPath = safeNormalizePath(pathInput);
                                            setIsEditingPath(false);
                                            if (nextPath !== currentPath) {
                                                onFileSelect(nextPath, false);
                                            }
                                        }}
                                        className="w-full text-xs text-neutral-300"
                                        style={{
                                            height: 28,
                                            padding: '4px 30px 4px 28px',
                                        }}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const nextPath = safeNormalizePath(pathInput);
                                            setIsEditingPath(false);
                                            if (nextPath !== currentPath) {
                                                onFileSelect(nextPath, false);
                                            }
                                        }}
                                        className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1 text-neutral-300 hover:text-neutral-200"
                                        title="Go"
                                    >
                                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M13 5l7 7-7 7" />
                                        </svg>
                                    </button>
                                </div>
                            ) : (
                                <div className="relative w-full">
                                    <svg
                                        className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-300 pointer-events-none"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                    </svg>
                                    <Input
                                        readOnly
                                        value={currentPath || '/'}
                                        onClick={() => setIsEditingPath(true)}
                                        onFocus={() => setIsEditingPath(true)}
                                        className="w-full text-xs text-neutral-300 cursor-pointer"
                                        title="Edit path"
                                        style={{
                                            height: 28,
                                            padding: '4px 30px 4px 28px',
                                        }}
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setIsEditingPath(true)}
                                        className="absolute right-1.5 top-1/2 -translate-y-1/2 p-1 text-neutral-300 hover:text-neutral-200"
                                        title="Edit path"
                                    >
                                        <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536M9 11l6.232-6.232a2 2 0 112.828 2.828L11.828 13.828a4 4 0 01-1.414.94L8 15l.232-2.414a4 4 0 01.94-1.414z" />
                                        </svg>
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                )}
                <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={handleFileInputChange}
                />


                <SearchPanel
                    showSearchPanel={showSearchPanel}
                    searchQuery={searchQuery}
                    setSearchQuery={setSearchQuery}
                    isSearching={isSearching}
                    searchError={searchError}
                    searchInputRef={searchInputRef}
                    canSearchContents={canSearchContents}
                    searchIncludeContent={searchIncludeContent}
                    setSearchIncludeContent={setSearchIncludeContent}
                    isLocalSearch={isLocalSearch}
                    searchResultsLength={searchResults.length}
                />

                {unarchiveProgress && (
                    <div
                        className="
                            flex items-center gap-2 mb-2 p-2.5
                            bg-primary-500/10 border border-primary-500/30
                            text-primary-400 text-sm
                        "
                        
                    >
                        <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        <span className="truncate flex-1">Extracting {unarchiveProgress.filename}...</span>
                    </div>
                )}
            </Header>
            <div className="relative flex-1 min-h-0" style={{ borderRadius: 'inherit' }}>
                <TreeContainer
                    ref={treeContainerRef}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, viewMode === 'tree' ? '/' : currentPath)}
                    isDragging={isDragging && !draggingFile}
                    embedded={embedded}
                    className={cx('h-full', (isDragging || draggingFile) && 'is-dragging')}
                    onPointerDownCapture={handleMarqueeDown}
                >
                    <div
                        className="flex flex-col items-stretch w-full relative z-10"
                        style={{ minHeight: '100%' }}
                    >
                        {typeof document !== 'undefined'
                            ? createPortal(
                                <div className="fixed inset-0 pointer-events-none z-[9999]">
                                    <GreyRowBox
                                        ref={hoverOverlayRef}
                                        data-overlay-mode="viewport"
                                        className="absolute left-0 top-0 pointer-events-none !p-0 border-[3px] border-dashed transition-all duration-150"
                                        $hoverable={false}
                                        style={{
                                            borderRadius: 8,
                                            transform: 'translate3d(-9999px, -9999px, 0)',
                                            opacity: 0,
                                            width: 0,
                                            height: 0,
                                            willChange: 'transform, width, height',
                                            backgroundColor: colors.primary.opacity(0.18),
                                            borderColor: colors.primary.dark,
                                        }}
                                    />
                                </div>,
                                document.body
                            )
                            : null}
                        {draggingFile && dragGhostInfo && typeof document !== 'undefined'
                            ? createPortal(
                                <div className="fixed inset-0 pointer-events-none z-[10000]">
                                    <GreyRowBox
                                        ref={dragGhostRef}
                                        data-ghost-mode="viewport"
                                        className="absolute left-0 top-0 px-3 py-2 shadow-2xl flex items-center gap-2 pointer-events-none"
                                        $hoverable={false}
                                        style={{
                                            width: 'max-content',
                                            borderWidth: '1px',
                                            borderColor: colors.primary.default,
                                            willChange: 'transform',
                                            transform: 'translate3d(-9999px, -9999px, 0)',
                                        }}
                                    >
                                        <FileTypeBadge filename={dragGhostInfo.filename} isFolder={dragGhostInfo.isFolder} isActive />
                                        <span className="text-neutral-300 font-medium">
                                            {dragGhostInfo.name}
                                        </span>
                                    </GreyRowBox>
                                </div>,
                                document.body
                            )
                            : null}
                        {searchQuery && searchResults.length > 0
                            ? renderSearchResults()
                            : viewMode === 'browse'
                                ? (
                                    <BrowseList
                                        currentPath={currentPath}
                                        files={viewFileTree[currentPath] || []}
                                        sortBy={sortBy}
                                        sortDirection={sortDirection}
                                        parentPath={parentPath}
                                        containerRef={treeContainerRef}
                                        renderParentRow={renderBrowseParentRow}
                                        renderRow={renderBrowseRow}
                                        selectedFile={selectedFile}
                                        selectedFiles={selectedFiles}
                                        draggedPaths={draggedPaths}
                                        isDragging={!!draggingFile}
                                    />
                                )
                                : viewMode === 'grid'
                                ? (
                                    <GridList
                                        currentPath={currentPath}
                                        files={viewFileTree[currentPath] || []}
                                        sortBy={sortBy}
                                        sortDirection={sortDirection}
                                        parentPath={parentPath}
                                        containerRef={treeContainerRef}
                                        renderParentRow={renderBrowseParentRow}
                                        renderGridItem={renderGridItem}
                                        selectedFile={selectedFile}
                                        selectedFiles={selectedFiles}
                                        draggedPaths={draggedPaths}
                                        isDragging={!!draggingFile}
                                    />
                                )
                                : (
                                    <TreeList
                                        tree={viewFileTree}
                                        rootPath="/"
                                        expandedFolders={expandedFolders}
                                        sortBy={sortBy}
                                        sortDirection={sortDirection}
                                        containerRef={treeContainerRef}
                                        renderFolderRow={renderFolderRow}
                                        renderFileRow={renderTreeFileRow}
                                        selectedFile={selectedFile}
                                        selectedFiles={selectedFiles}
                                        draggedPaths={draggedPaths}
                                        isDragging={!!draggingFile}
                                    />
                                )}
                    </div>
                    {marquee && (
                        <div
                            ref={marqueeBoxRef}
                            className='absolute left-0 top-0 pointer-events-none border border-blue-400/50 bg-blue-500/15 z-20'
                            style={{
                                width: 0,
                                height: 0,
                                opacity: 0,
                                transform: `translate3d(${marquee.startX}px, ${marquee.startY}px, 0)`,
                                willChange: 'transform, width, height',
                            }}
                        />
                    )}
                </TreeContainer>
                <DragOverlay 
                    active={isDragging || !!draggingFile} 
                    containerRef={treeContainerRef} 
                    dropTargetPath={dragOverPath}
                />
            </div>
            <UploadProgressPanel
                uploads={uploads}
                showUploadModal={showUploadModal}
                setShowUploadModal={setShowUploadModal}
                cancelAllUploads={cancelAllUploads}
                cancelUpload={cancelUpload}
                formatBytes={formatSize}
            />
            {contextMenu
                ? createPortal(
                    <ContextMenu
                        x={contextMenu.x}
                        y={contextMenu.y}
                        onClose={() => setContextMenu(null)}
                        items={buildContextMenuItems({
                            uuid,
                            isSearchActive,
                            contextMenu,
                            isArchiveFile,
                            handleCreateFile,
                            handleCreateFolder,
                            handleRename,
                            revealSearchPath,
                            handleUnarchive,
                            handleArchive,
                            handlePermissions,
                            onShowProperties,
                            handleEditAudioMetadata,
                            handleCopyFile,
                            handleMoveToTrash,
                            handleDelete,
                            clearAndAddHttpError,
                        })}
                    />,
                    document.body
                )
                : null}
            <FileTreeModals
                modalTargetPath={modalTargetPath}
                currentPath={currentPath}
                showRenameModal={showRenameModal}
                showPermissionsModal={showPermissionsModal}
                showDeleteConfirm={showDeleteConfirm}
                showMoveToTrashConfirm={showMoveToTrashConfirm}
                showUnarchiveConfirm={showUnarchiveConfirm}
                showCreateModal={showCreateModal}
                showUploadPickerModal={showUploadPickerModal}
                showTrashBinModal={showTrashBinModal}
                showTrashCleanupModal={showTrashCleanupModal}
                actionMode={actionMode}
                uploadMode={uploadMode}
                targetDirectories={targetDirectories}
                uploadDirectories={uploadDirectories}
                trashCleanupSettings={trashCleanupSettings}
                fieldClassName={fieldClassName}
                setShowRenameModal={setShowRenameModal}
                setShowPermissionsModal={setShowPermissionsModal}
                setShowDeleteConfirm={setShowDeleteConfirm}
                setShowMoveToTrashConfirm={setShowMoveToTrashConfirm}
                setShowUnarchiveConfirm={setShowUnarchiveConfirm}
                setShowCreateModal={setShowCreateModal}
                setShowUploadPickerModal={setShowUploadPickerModal}
                setShowTrashBinModal={setShowTrashBinModal}
                setShowTrashCleanupModal={setShowTrashCleanupModal}
                setActionMode={setActionMode}
                setUploadMode={setUploadMode}
                setActionTargetDirectories={setActionTargetDirectories}
                handlePullComplete={handlePullComplete}
                normalizeDirectory={normalizeDirectory}
                joinDirectoryAndName={joinDirectoryAndName}
                submitDelete={submitDelete}
                submitMoveToTrash={submitMoveToTrash}
                submitUnarchive={submitUnarchive}
                submitCreateFile={submitCreateFile}
                submitCreateFolder={submitCreateFolder}
                handleUploadClick={handleUploadClick}
                uploadTargetRef={uploadTargetRef}
                onDirectoryLoad={onDirectoryLoad}
                onFilesRestored={async (paths) => {
                    const directories = new Set<string>();
                    if (paths && paths.length > 0) {
                        for (const rawPath of paths) {
                            const normalized = rawPath.startsWith('/') ? rawPath : `/${rawPath}`;
                            const lastSlash = normalized.lastIndexOf('/');
                            const directory = lastSlash <= 0 ? '/' : normalized.slice(0, lastSlash);
                            directories.add(directory);
                        }
                    } else {
                        directories.add(currentPath);
                    }

                    const dirs = Array.from(directories);
                    await Promise.all(dirs.map(dir => onDirectoryLoad(dir)));
                    if (!directories.has(currentPath)) {
                        await onDirectoryLoad(currentPath);
                    }
                    refreshTrashCount();
                    setTimeout(() => {
                        dirs.forEach(dir => {
                            onDirectoryLoad(dir);
                        });
                        if (!directories.has(currentPath)) {
                            onDirectoryLoad(currentPath);
                        }
                    }, 500);
                }}
                onSaveTrashCleanup={handleTrashCleanupSave}
                clearAndAddHttpError={clearAndAddHttpError}
                cx={cx}
            />
            <Dialog.Confirm
                open={!!pendingDragMove}
                onClose={() => setPendingDragMove(null)}
                title='Move Files'
                confirm='Move'
                onConfirmed={async () => {
                    if (pendingDragMove) {
                        await executeDragMove(pendingDragMove.dragData, pendingDragMove.destination);
                    }
                    setPendingDragMove(null);
                }}
            >
                Move{' '}
                <Code>
                    {pendingDragMove?.dragData.multiple
                        ? `${pendingDragMove.dragData.files.length} items`
                        : pendingDragMove?.dragData.name}
                </Code>{' '}
                to <Code>{pendingDragMove?.destination || '/'}</Code>?
            </Dialog.Confirm>
        </div>
    );
};
export default React.memo(FileTree);
