import React, { useEffect, useRef, useState, useImperativeHandle } from 'react';
import styled from 'styled-components';
import { themeColors } from './colorExtractor';
import { colors } from './colors';
// @ts-ignore
import ace from 'ace-builds/src-noconflict/ace';

// @ts-ignore
import 'ace-builds/src-noconflict/theme-one_dark';

// @ts-ignore
import 'ace-builds/src-noconflict/ext-language_tools';

// @ts-ignore
import 'ace-builds/src-noconflict/ext-searchbox';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-javascript';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-typescript';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-html';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-css';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-json';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-xml';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-yaml';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-markdown';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-php';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-python';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-ruby';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-java';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-c_cpp';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-csharp';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-golang';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-rust';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-swift';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-kotlin';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-lua';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-perl';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-sql';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-sh';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-powershell';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-dockerfile';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-ini';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-properties';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-diff';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-text';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-toml';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-nginx';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-apache_conf';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-sass';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-scss';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-less';

// @ts-ignore
import 'ace-builds/src-noconflict/mode-graphqlschema';

let aceTouchPreventDefaultPatched = false;
const patchAcePreventDefaultForTouchScroll = () => {
    if (aceTouchPreventDefaultPatched) return;
    try {
        const aceEvent = ace.require('ace/lib/event');
        if (!aceEvent || typeof aceEvent.preventDefault !== 'function') return;
        const originalPreventDefault = aceEvent.preventDefault.bind(aceEvent);
        aceEvent.preventDefault = (event: any) => {
            if (event && typeof event.cancelable === 'boolean' && !event.cancelable) return;
            return originalPreventDefault(event);
        };
        aceTouchPreventDefaultPatched = true;
    } catch {
        // Ignore patch failures; editor continues with Ace defaults.
    }
};

type TouchScrollAxis = 'x' | 'y' | null;

const TOUCH_AXIS_LOCK_THRESHOLD = 8;
const aceTouchAxisState: {
    pointerId: number | null;
    startX: number;
    startY: number;
    axis: TouchScrollAxis;
} = {
    pointerId: null,
    startX: 0,
    startY: 0,
    axis: null,
};

const resetAceTouchAxisState = () => {
    aceTouchAxisState.pointerId = null;
    aceTouchAxisState.axis = null;
    aceTouchAxisState.startX = 0;
    aceTouchAxisState.startY = 0;
};

const getTouchById = (touches: TouchList, id: number): Touch | null => {
    for (let index = 0; index < touches.length; index += 1) {
        const touch = touches.item(index);
        if (touch && touch.identifier === id) {
            return touch;
        }
    }
    return null;
};

const getTrackedTouch = (event: TouchEvent): Touch | null => {
    if (aceTouchAxisState.pointerId !== null) {
        return (
            getTouchById(event.touches, aceTouchAxisState.pointerId) ||
            getTouchById(event.changedTouches, aceTouchAxisState.pointerId)
        );
    }
    return event.touches.item(0) || event.changedTouches.item(0);
};

const trackAceTouchStart = (event: TouchEvent) => {
    const touch = event.touches.item(0) || event.changedTouches.item(0);
    if (!touch) return;
    aceTouchAxisState.pointerId = touch.identifier;
    aceTouchAxisState.startX = touch.clientX;
    aceTouchAxisState.startY = touch.clientY;
    aceTouchAxisState.axis = null;
};

const trackAceTouchMove = (event: TouchEvent) => {
    const touch = getTrackedTouch(event);
    if (!touch) return;

    if (aceTouchAxisState.pointerId === null) {
        aceTouchAxisState.pointerId = touch.identifier;
        aceTouchAxisState.startX = touch.clientX;
        aceTouchAxisState.startY = touch.clientY;
        aceTouchAxisState.axis = null;
    }

    if (aceTouchAxisState.axis) return;

    const deltaX = Math.abs(touch.clientX - aceTouchAxisState.startX);
    const deltaY = Math.abs(touch.clientY - aceTouchAxisState.startY);
    if (deltaX < TOUCH_AXIS_LOCK_THRESHOLD && deltaY < TOUCH_AXIS_LOCK_THRESHOLD) return;

    aceTouchAxisState.axis = deltaX > deltaY ? 'x' : 'y';
};

const trackAceTouchEnd = (event: TouchEvent) => {
    if (event.touches.length === 0) {
        resetAceTouchAxisState();
        return;
    }

    const pointerId = aceTouchAxisState.pointerId;
    if (pointerId === null) return;

    for (let index = 0; index < event.changedTouches.length; index += 1) {
        const touch = event.changedTouches.item(index);
        if (touch && touch.identifier === pointerId) {
            resetAceTouchAxisState();
            return;
        }
    }
};

let aceTouchAxisLockPatched = false;
const patchAceTouchAxisLock = () => {
    if (aceTouchAxisLockPatched) return;
    try {
        const handlersModule = ace.require('ace/mouse/default_handlers');
        const DefaultHandlers = handlersModule?.DefaultHandlers;
        if (!DefaultHandlers || typeof DefaultHandlers.prototype.onMouseWheel !== 'function') return;
        const originalOnMouseWheel = DefaultHandlers.prototype.onMouseWheel;
        DefaultHandlers.prototype.onMouseWheel = function (event: any) {
            if (event?.domEvent?.type === 'touchmove') {
                trackAceTouchMove(event.domEvent as TouchEvent);
                const wheelX = Math.abs(event.wheelX || 0);
                const wheelY = Math.abs(event.wheelY || 0);
                if (aceTouchAxisState.axis === 'x') {
                    event.wheelY = 0;
                } else if (aceTouchAxisState.axis === 'y') {
                    event.wheelX = 0;
                } else if (wheelX > wheelY) {
                    event.wheelY = 0;
                } else if (wheelY > wheelX) {
                    event.wheelX = 0;
                }
            }
            return originalOnMouseWheel.call(this, event);
        };
        aceTouchAxisLockPatched = true;
    } catch {
        // Ignore patch failures; editor continues with Ace defaults.
    }
};

const EditorWrapper = styled.div`
    flex: 1;
    overflow: hidden;
    padding: 0;
    position: relative;
    width: 100%;
    height: 100%;
    min-height: 0;
    max-width: 100%;
    min-width: 0;
    border-radius: inherit;
    scrollbar-width: thin;
    scrollbar-color: ${themeColors.page.secondaryActive} ${themeColors.page.background};

    &::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }

    &::-webkit-scrollbar-track {
        background: ${themeColors.page.background};
    }

    &::-webkit-scrollbar-thumb {
        background: ${themeColors.page.secondaryActive};
        border: 2px solid ${themeColors.page.background};
    }

    &::-webkit-scrollbar-thumb:hover {
        background: ${themeColors.page.secondaryHover};
    }
`;

const EditorContainer = styled.div`
    width: 100%;
    height: 100%;
    background: ${themeColors.page.background};
    overflow: hidden;
    border-radius: inherit;

    .ace_editor {
        font-family: 'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace !important;
        background: ${themeColors.page.background};
        line-height: 1.5;
    }

    .ace_gutter-cell {
        line-height: 1.5;
        padding-top: 0;
        padding-bottom: 0;
    }

    .ace_gutter {
        background: ${themeColors.page.background};
        border-right: 1px solid ${themeColors.page.secondary};
        color: ${themeColors.page.primaryHover};
        padding-top: 4px;
    }

    .ace_gutter-active-line {
        background: ${themeColors.page.secondary};
        color: ${themeColors.page.primary};
    }

    .ace_print-margin {
        display: none !important;
    }

    .ace_cursor {
        border-left-color: ${colors.primary.default} !important;
    }

    .ace_active-line {
        background: ${colors.primary.opacity(0.1)} !important;
    }

    .ace_marker-layer .ace_selection,
    .ace_selection {
        background: ${colors.primary.opacity(0.35)} !important;
        border: 1px solid ${colors.primary.opacity(0.35)};
    }

    .ace_marker-layer .ace_selection.ace_start,
    .ace_marker-layer .ace_selection.ace_bracket {
        border-radius: 0;
    }

    /* Custom Scrollbar */
    .ace_scrollbar::-webkit-scrollbar {
        width: 10px;
        height: 10px;
        display: block;
    }

    .ace_scrollbar {
        scrollbar-width: thin;
        opacity: 1;
    }

    .ace_scrollbar::-webkit-scrollbar-track {
        background: ${themeColors.page.background};
    }

    .ace_scrollbar::-webkit-scrollbar-thumb {
        background: ${themeColors.page.secondaryActive};
        border: 2px solid ${themeColors.page.background};
    }

    .ace_scrollbar::-webkit-scrollbar-thumb:hover {
        background: ${themeColors.page.secondaryHover};
    }

    /* ============================================================================
       ACE SEARCH BOX - CLEAN OVERRIDE
       ============================================================================ */
    .ace_search {
        background: ${themeColors.page.secondary};
        padding: 0.75rem 2.5rem 0.75rem 0.75rem;
        border: 1px solid ${themeColors.page.secondaryHover} !important;
        box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.4) !important;
        position: absolute !important;
        top: 12px !important;
        right: 12px !important;
        width: 340px !important;
        max-width: calc(100% - 24px) !important;
        display: flex;
        flex-direction: column !important;
        gap: 10px !important;
        border-radius: 10px !important;
    }

    /* Search/Replace input rows */
    .ace_search_form,
    .ace_replace_form {
        display: grid !important;
        grid-template-columns: minmax(0, 1fr) auto auto !important;
        align-items: center !important;
        gap: 6px !important;
        margin: 0 !important;
        border: none !important;
        padding: 0 !important;
    }

    /* Input fields */
    .ace_search_field {
        background: ${themeColors.page.background};
        color: ${themeColors.page.primary};
        font-size: 0.875rem;
        height: 34px !important;
        padding: 0 8px !important;
        border: 1px solid ${themeColors.page.secondaryHover} !important;
        border-radius: 8px !important;
        margin: 0 !important;
        min-width: 0 !important;
        grid-column: 1 / -1 !important;
    }

    .ace_search_field:focus {
        border-color: ${colors.primary.default} !important;
        outline: none !important;
    }

    /* All buttons - unified style */
    .ace_searchbtn,
    .ace_replacebtn {
        background: ${themeColors.page.secondaryActive};
        color: ${themeColors.page.primary};
        font-size: 0.75rem;
        cursor: pointer;
        height: 30px !important;
        padding: 0 10px !important;
        border: 1px solid ${themeColors.page.secondaryHover} !important;
        border-radius: 8px !important;
        margin: 0 !important;
        white-space: nowrap !important;
        flex-shrink: 0 !important;
        justify-self: end !important;
    }

    .ace_searchbtn:hover,
    .ace_replacebtn:hover {
        background-color: ${colors.primary.default} !important;
        border-color: ${colors.primary.default} !important;
        color: white !important;
    }

    /* Hide the input clear button (the X inside input field) */
    .ace_search_field::-webkit-search-cancel-button,
    .ace_search_field::-webkit-clear-button {
        display: none !important;
    }

    /* Close button - positioned top-right with better styling */
    .ace_searchbtn_close {
        background: ${themeColors.page.secondaryActive};
        color: ${themeColors.page.primary};
        cursor: pointer;
        position: absolute !important;
        top: 10px !important;
        right: 10px !important;
        width: 26px !important;
        height: 26px !important;
        padding: 0 !important;
        margin: 0 !important;
        border: 1px solid ${themeColors.page.secondaryHover} !important;
        border-radius: 8px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 14px !important;
        line-height: 1 !important;
        z-index: 100 !important;
        pointer-events: auto !important;
    }

    .ace_searchbtn_close::before {
        content: '×' !important;
        font-size: 16px !important;
        line-height: 1 !important;
    }

    .ace_searchbtn_close svg,
    .ace_searchbtn_close span {
        display: none !important;
    }

    .ace_searchbtn_close:hover {
        background-color: ${colors.primary.default} !important;
        border-color: ${colors.primary.default} !important;
        color: white !important;
    }

    /* Options row */
    .ace_search_options {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 4px !important;
        margin-top: 2px !important;
        padding: 0 !important;
        align-items: center !important;
    }

    /* Toggle buttons (Regex, Case, etc) */
    .ace_button {
        background: transparent;
        color: ${themeColors.page.primaryHover};
        font-size: 10px;
        cursor: pointer;
        height: 24px !important;
        padding: 0 8px !important;
        border: 1px solid ${themeColors.page.secondaryHover} !important;
        border-radius: 8px !important;
        margin: 0 !important;
    }

    .ace_search_counter {
        font-size: 11px !important;
        color: ${themeColors.page.primaryHover} !important;
        margin-left: 2px !important;
    }

    .ace_button:hover {
        color: ${themeColors.page.primary};
        background: ${themeColors.page.secondaryActive};
    }

    .ace_button.checked {
        border-color: ${colors.primary.default} !important;
        color: ${colors.primary.light} !important;
        background: ${colors.primary.opacity(0.15)} !important;
    }

    /* Hide labels */
    .ace_search_form > label,
    .ace_replace_form > label {
        display: none !important;
    }

    /* Better Fold Widgets (Arrows) */
    .ace_fold-widget {
        text-align: center;
        color: ${themeColors.page.primaryHover};
    }

    .ace_fold-widget.ace_start,
    .ace_fold-widget.ace_end,
    .ace_fold-widget.ace_closed {
        background: none !important;
        border: none !important;
        box-shadow: none !important;
    }

    .ace_fold-widget.ace_start:after {
        content: '▼';
        font-size: 10px;
        line-height: 10px;
        display: block;
        transform: rotate(0deg);
        transition: transform 0.2s;
    }

    .ace_fold-widget.ace_closed:after {
        content: '▶';
        font-size: 10px;
        line-height: 10px;
        display: block;
    }

    .ace_fold-widget.ace_end:after {
        content: '▲';
        font-size: 10px;
        line-height: 10px;
        display: block;
    }

    /* Style the inline folded text (the "..." placeholder) */
    .ace_fold {
        background: ${themeColors.page.secondaryActive};
        border: 1px solid #4b5563;
        color: ${themeColors.page.primaryHover};
        border-radius: 0.25rem;
        display: inline-block;
        padding: 0 0.25rem;
        margin: 0 0.125rem;
        text-align: center;
        font-size: 10px;
        height: auto;
        line-height: 1;
        background-image: none !important;
    }
`;

interface FoldRange {
    startRow: number;
    startColumn: number;
    endRow: number;
    endColumn: number;
    placeholder?: string;
}

export interface SimpleEditorHandle {
    getFolds: () => FoldRange[];
}

interface SimpleEditorProps {
    value: string;
    onChange: (value: string) => void;
    filePath: string;
    readOnly?: boolean;
    onSave?: (currentContent: string) => void;
    onFileDrop?: (filePath: string) => void;
    onFocus?: () => void;
    foldRanges?: FoldRange[];
}

const getAceModeFromFilename = (filename: string): string => {
    const ext = filename.split('.').pop()?.toLowerCase() || '';
    const modeMap: Record<string, string> = {
        js: 'javascript',
        jsx: 'javascript',
        ts: 'typescript',
        tsx: 'typescript',
        html: 'html',
        htm: 'html',
        css: 'css',
        scss: 'scss',
        sass: 'sass',
        less: 'less',
        json: 'json',
        xml: 'xml',
        svg: 'xml',

        yaml: 'yaml',
        yml: 'yaml',
        toml: 'toml',
        ini: 'ini',
        conf: 'ini',
        cfg: 'ini',
        properties: 'properties',
        env: 'properties',

        py: 'python',
        php: 'php',
        rb: 'ruby',
        java: 'java',
        c: 'c_cpp',
        cpp: 'c_cpp',
        cc: 'c_cpp',
        h: 'c_cpp',
        hpp: 'c_cpp',
        cs: 'csharp',
        go: 'golang',
        rs: 'rust',
        swift: 'swift',
        kt: 'kotlin',
        lua: 'lua',
        pl: 'perl',

        sh: 'sh',
        bash: 'sh',
        zsh: 'sh',
        fish: 'sh',
        ps1: 'powershell',
        bat: 'batchfile',
        cmd: 'batchfile',

        sql: 'sql',
        graphql: 'graphqlschema',
        gql: 'graphqlschema',

        md: 'markdown',
        markdown: 'markdown',

        dockerfile: 'dockerfile',

        nginx: 'nginx',
        htaccess: 'apache_conf',

        diff: 'diff',
        patch: 'diff',
        log: 'text',
        txt: 'text',
    };

    const lowerFilename = filename.toLowerCase();
    if (lowerFilename === 'dockerfile' || lowerFilename.startsWith('dockerfile.')) return 'dockerfile';
    if (lowerFilename === 'makefile' || lowerFilename === 'gnumakefile') return 'makefile';
    if (lowerFilename.includes('nginx')) return 'nginx';
    if (lowerFilename === '.env' || lowerFilename.startsWith('.env.')) return 'properties';

    return modeMap[ext] || 'text';
};

const SimpleEditor = React.forwardRef<SimpleEditorHandle, SimpleEditorProps>(({
    value,
    onChange,
    filePath,
    readOnly = false,
    onSave,
    onFileDrop,
    onFocus,
    foldRanges,
}, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const editorRef = useRef<any>(null);
    const [isReady, setIsReady] = useState(false);
    const [isTouchViewport, setIsTouchViewport] = useState(() => {
        if (typeof window === 'undefined') return false;
        const isNarrowViewport = window.innerWidth < 768;
        const hasCoarsePointer =
            typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches;
        return isNarrowViewport || hasCoarsePointer;
    });
    const lastFilePathRef = useRef(filePath);
    const isUpdatingRef = useRef(false);
    const lastEmittedValueRef = useRef(value);

    useImperativeHandle(ref, () => ({
        getFolds: () => {
            if (!editorRef.current) return [];
            return editorRef.current.getSession().getAllFolds().map((fold: any) => ({
                startRow: fold.range.start.row,
                startColumn: fold.range.start.column,
                endRow: fold.range.end.row,
                endColumn: fold.range.end.column,
                placeholder: fold.placeholder,
            }));
        },
    }), []);

    const onChangeRef = useRef(onChange);
    const onSaveRef = useRef(onSave);
    const onFocusRef = useRef(onFocus);

    useEffect(() => {
        onChangeRef.current = onChange;
    }, [onChange]);

    useEffect(() => {
        onSaveRef.current = onSave;
    }, [onSave]);

    useEffect(() => {
        onFocusRef.current = onFocus;
    }, [onFocus]);

    useEffect(() => {
        if (typeof window === 'undefined') return;

        const updateViewportMode = () => {
            const isNarrowViewport = window.innerWidth < 768;
            const hasCoarsePointer =
                typeof window.matchMedia === 'function' && window.matchMedia('(pointer: coarse)').matches;
            setIsTouchViewport(isNarrowViewport || hasCoarsePointer);
        };

        updateViewportMode();
        window.addEventListener('resize', updateViewportMode);
        return () => window.removeEventListener('resize', updateViewportMode);
    }, []);

    useEffect(() => {
        if (!containerRef.current || editorRef.current) return;
        patchAcePreventDefaultForTouchScroll();
        patchAceTouchAxisLock();

        const editor = ace.edit(containerRef.current, {
            mode: `ace/mode/${getAceModeFromFilename(filePath)}`,
            theme: 'ace/theme/one_dark',
            value: value,
            fontSize: 14,
            showPrintMargin: false,
            showGutter: true,
            highlightActiveLine: true,
            readOnly: readOnly,
            tabSize: 4,
            useSoftTabs: true,
            wrap: false,
            enableBasicAutocompletion: true,
            enableLiveAutocompletion: localStorage.getItem('bfm-live-autocomplete') !== 'false',
            enableSnippets: true,
            scrollPastEnd: 0.5,
            animatedScroll: true,
            displayIndentGuides: true,
            highlightSelectedWord: true,
            behavioursEnabled: true,
            wrapBehavioursEnabled: true,
            autoScrollEditorIntoView: true,
            copyWithEmptySelection: true,
            navigateWithinSoftTabs: true,
            dragEnabled: false,
            dragDelay: 0,
        });

        const container = containerRef.current;
        const handleDrop = (e: DragEvent) => {
            const isFileDrag = e.dataTransfer?.types.includes('application/x-filetree-drag');
            const data = e.dataTransfer?.getData('text/plain');

            if (isFileDrag || (data && data.startsWith('/'))) {
                e.preventDefault();
                e.stopPropagation();
            }
        };
        const handleDragOver = (e: DragEvent) => {
            const hasText = e.dataTransfer?.types.includes('text/plain');
            const hasFileTree = e.dataTransfer?.types.includes('application/x-filetree-drag');

            if (hasText || hasFileTree) {
                e.preventDefault();
                if (hasFileTree) {
                    e.stopPropagation();
                }
            }
        };
        const handleTouchStart = (e: TouchEvent) => {
            trackAceTouchStart(e);
        };
        const handleTouchMove = (e: TouchEvent) => {
            trackAceTouchMove(e);
        };
        const handleTouchEnd = (e: TouchEvent) => {
            trackAceTouchEnd(e);
        };
        const handleSearchCloseMouseDown = (e: MouseEvent) => {
            const target = e.target as Element | null;
            if (!target?.closest('.ace_searchbtn_close')) return;
            e.preventDefault();
            e.stopPropagation();
            const searchBox = (editor as any).searchBox;
            if (searchBox && typeof searchBox.hide === 'function') {
                searchBox.hide();
            } else {
                editor.execCommand('hideSearchBox');
            }
            editor.focus();
        };
        container.addEventListener('drop', handleDrop, true);
        container.addEventListener('dragover', handleDragOver, true);
        container.addEventListener('touchstart', handleTouchStart, { passive: true });
        container.addEventListener('touchmove', handleTouchMove, { passive: true });
        container.addEventListener('touchend', handleTouchEnd, { passive: true });
        container.addEventListener('touchcancel', handleTouchEnd, { passive: true });
        container.addEventListener('mousedown', handleSearchCloseMouseDown, true);

        // Recompute renderer metrics after custom CSS line-height adjustments.
        editor.renderer.updateFontSize();

        editor.renderer.setScrollMargin(8, 8, 0, 0);

        const langTools = ace.require('ace/ext/language_tools');
        const customCompleter = {
            getCompletions: (editor: any, session: any, pos: any, prefix: string, callback: any) => {
                if (prefix.length === 0) {
                    callback(null, []);
                    return;
                }

                const modePromise = session.getMode();
                const modeId = modePromise.$id || '';

                if (modeId.includes('javascript') || modeId.includes('typescript')) {
                    const completions = [];

                    if (prefix === 'log' || prefix === 'war' || prefix === 'err' || prefix === 'inf') {
                        completions.push(
                            { name: 'log', value: 'log', meta: 'console', score: 1000 },
                            { name: 'warn', value: 'warn', meta: 'console', score: 1000 },
                            { name: 'error', value: 'error', meta: 'console', score: 1000 },
                            { name: 'info', value: 'info', meta: 'console', score: 1000 }
                        );
                    }

                    const commonKeywords = [
                        'console',
                        'return',
                        'const',
                        'let',
                        'var',
                        'async',
                        'await',
                        'function',
                        'class',
                        'import',
                        'export',
                        'from',
                        'default',
                        'if',
                        'else',
                        'switch',
                        'case',
                        'break',
                        'try',
                        'catch',
                        'Math',
                        'JSON',
                        'Promise',
                        'window',
                        'document',
                    ];

                    commonKeywords.forEach((word) => {
                        if (word.startsWith(prefix)) {
                            completions.push({
                                name: word,
                                value: word,
                                meta: 'keyword',
                                score: 500,
                            });
                        }
                    });

                    callback(null, completions);
                    return;
                }

                callback(null, []);
            },
        };

        if (langTools) {
            langTools.addCompleter(customCompleter);
        }

        editor.session.on('change', () => {
            if (isUpdatingRef.current) return;
            const newValue = editor.getValue();
            lastEmittedValueRef.current = newValue;
            onChangeRef.current(newValue);
        });

        editor.commands.addCommand({
            name: 'save',
            bindKey: { win: 'Ctrl-S', mac: 'Cmd-S' },
            exec: () => {
                if (onSaveRef.current) {
                    onSaveRef.current(editor.getValue());
                }
            },
        });

        editor.on('focus', () => {
            if (onFocusRef.current) {
                onFocusRef.current();
            }
        });

        editorRef.current = editor;
        setIsReady(true);

        return () => {
            container.removeEventListener('drop', handleDrop, true);
            container.removeEventListener('dragover', handleDragOver, true);
            container.removeEventListener('touchstart', handleTouchStart);
            container.removeEventListener('touchmove', handleTouchMove);
            container.removeEventListener('touchend', handleTouchEnd);
            container.removeEventListener('touchcancel', handleTouchEnd);
            container.removeEventListener('mousedown', handleSearchCloseMouseDown, true);
            resetAceTouchAxisState();
            if (editorRef.current) {
                editorRef.current.destroy();
                editorRef.current = null;
            }
        };
    }, []);

    useEffect(() => {
        const handler = (e: Event) => {
            const enabled = (e as CustomEvent).detail?.enabled ?? true;
            editorRef.current?.setOption('enableLiveAutocompletion', enabled);
        };
        window.addEventListener('bfm:autocomplete-toggle', handler);
        return () => window.removeEventListener('bfm:autocomplete-toggle', handler);
    }, []);

    useEffect(() => {
        if (!editorRef.current) return;
        editorRef.current.setOption('wrap', false);
        editorRef.current.session.setUseWrapMode(false);
        editorRef.current.setOption('hScrollBarAlwaysVisible', isTouchViewport);
        editorRef.current.setOption('animatedScroll', !isTouchViewport);
        editorRef.current.resize(true);
    }, [isTouchViewport]);

    useEffect(() => {
        if (!editorRef.current || !isReady) return;
        if (value === lastEmittedValueRef.current) return;

        const currentValue = editorRef.current.getValue();
        if (currentValue !== value) {
            isUpdatingRef.current = true;
            const cursorPosition = editorRef.current.getCursorPosition();
            editorRef.current.setValue(value, -1);
            editorRef.current.moveCursorToPosition(cursorPosition);
            editorRef.current.getSession().getUndoManager().reset();
            if (foldRanges && foldRanges.length > 0) {
                const session = editorRef.current.getSession();
                const AceRange = ace.require('ace/range').Range;
                for (const fold of foldRanges) {
                    try {
                        session.addFold(fold.placeholder || '...', new AceRange(fold.startRow, fold.startColumn, fold.endRow, fold.endColumn));
                    } catch {}
                }
            }
            isUpdatingRef.current = false;
        }
        lastEmittedValueRef.current = value;
    }, [value, isReady]);

    useEffect(() => {
        if (editorRef.current && filePath !== lastFilePathRef.current) {
            const mode = getAceModeFromFilename(filePath);
            editorRef.current.session.setMode(`ace/mode/${mode}`);
            lastFilePathRef.current = filePath;
        }
    }, [filePath]);

    useEffect(() => {
        if (editorRef.current) {
            editorRef.current.setReadOnly(readOnly);
        }
    }, [readOnly]);

    useEffect(() => {
        if (!editorRef.current || !containerRef.current) {
            return;
        }

        const resizeObserver = new ResizeObserver(() => {
            editorRef.current?.resize();
        });

        resizeObserver.observe(containerRef.current);

        return () => {
            resizeObserver.disconnect();
        };
    }, [isReady]);

    const [isDragOver, setIsDragOver] = useState(false);

    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (onFileDrop) {
            setIsDragOver(true);
        }
    };

    const handleDragLeave = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (!e.currentTarget.contains(e.relatedTarget as Node)) {
            setIsDragOver(false);
        }
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(false);

        let path = e.dataTransfer.getData('text/plain');

        if (!path) {
            const filetreeData = e.dataTransfer.getData('application/x-filetree-drag');
            if (filetreeData) {
                try {
                    const data = JSON.parse(filetreeData);
                    if (data.multiple && data.files && data.files.length > 0) {
                        path = data.files[0].path;
                    } else if (data.path && data.isFile) {
                        path = data.path;
                    }
                } catch (err) {
                    console.error('Failed to parse filetree drag data', err);
                }
            }
        }

        if (path && onFileDrop) {
            onFileDrop(path);
        }
    };

    const handleClick = () => {
        if (onFocus) {
            onFocus();
        }
    };

    return (
        <EditorWrapper
            onClick={handleClick}
            onDragEnter={handleDragOver}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
        >
            <EditorContainer ref={containerRef} />
            {isDragOver && (
                <div
                    className='absolute inset-0 z-20 flex items-center justify-center pointer-events-none'
                    style={{
                        background: colors.primary.opacity(0.15),
                        border: `2px dashed ${colors.primary.default}`,
                        borderRadius: 'inherit',
                    }}
                >
                    <span className='text-white text-lg font-medium' style={{ color: colors.primary.default }}>
                        Drop to open in split view
                    </span>
                </div>
            )}
        </EditorWrapper>
    );
});

export default SimpleEditor;
