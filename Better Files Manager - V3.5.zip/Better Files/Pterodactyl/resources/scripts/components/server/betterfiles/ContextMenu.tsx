import React, { useEffect, useRef, useState } from 'react';
import { themeColors } from './colorExtractor';

interface ContextMenuProps {
    x: number;
    y: number;
    onClose: () => void;
    items: Array<{
        label?: string;
        icon?: React.ReactNode;
        onClick?: () => void;
        disabled?: boolean;
        divider?: boolean;
    }>;
}

const ContextMenu: React.FC<ContextMenuProps> = ({ x, y, onClose, items }) => {
    const menuRef = useRef<HTMLDivElement>(null);
    const [adjustedY, setAdjustedY] = useState<number | undefined>(undefined);
    const [adjustedX, setAdjustedX] = useState<number>(x);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
                onClose();
            }
        };

        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === 'Escape') {
                onClose();
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        document.addEventListener('keydown', handleEscape);

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleEscape);
        };
    }, [onClose]);

    useEffect(() => {
        if (menuRef.current) {
            const rect = menuRef.current.getBoundingClientRect();
            const viewportHeight = window.innerHeight;
            const viewportWidth = window.innerWidth;

            let newY = y;
            let newX = x;

            if (rect.bottom > viewportHeight) {
                newY = y - rect.height;

                if (newY < 0) {
                    newY = viewportHeight - rect.height - 10;
                }
            }

            if (rect.right > viewportWidth) {
                newX = viewportWidth - rect.width - 10;
            }

            if (newX < 0) {
                newX = 10;
            }

            setAdjustedY(newY);
            setAdjustedX(newX);
        }
    }, [x, y]);

    return (
        <div
            ref={menuRef}
            className="fixed bg-gray-700 border border-gray-600 shadow-2xl py-2 z-50"
            style={{
                borderRadius: themeColors.borderRadius.component,
                minWidth: '12rem',
                maxWidth: '20rem',
                left: adjustedX,
                top: adjustedY !== undefined ? adjustedY : y,
            }}
        >
            {items.map((item, index) => (
                <React.Fragment key={index}>
                    {item.divider ? (
                        <div className="h-px bg-gray-600 my-2" />
                    ) : item.label && item.icon ? (
                        <button
                            className="w-full px-4 py-2 text-left text-sm text-neutral-300 hover:text-white hover:bg-gray-600 transition-colors flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
                            onClick={() => {
                                if (item.onClick) {
                                    item.onClick();
                                    onClose();
                                }
                            }}
                            disabled={item.disabled}
                        >
                            {item.icon}
                            <span>{item.label}</span>
                        </button>
                    ) : null}
                </React.Fragment>
            ))}
        </div>
    );
};

export default ContextMenu;
