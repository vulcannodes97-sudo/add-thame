import React, { useState, useEffect, useCallback, useRef, lazy, Suspense } from 'react';
import { createPortal } from 'react-dom';
import { ServerContext } from '@/state/server';
import FlashMessageRender from '@/components/FlashMessageRender';
import Spinner from '@/components/elements/Spinner';
import useFlash, { useFlashKey } from '../useFlash';
import { themeColors } from '../colorExtractor';
import { colors } from '../colors';
import FileTree from '../FileTree';
import SimpleEditor, { SimpleEditorHandle } from '../SimpleEditor';
import FileToolbar from '../FileToolbar';
import MarkdownPreview, { isMarkdownFile } from '../MarkdownPreview';
import BreadcrumbNav from '../BreadcrumbNav';
import MediaViewer from '../mediaviewer';
import ProgressToast from '../ProgressToast';
import DirectoryPicker from '../DirectoryPicker';
import {
    getDirectoryContents,
    getFileContents,
    saveFileContents,
    deleteFiles,
    compressFiles,
    renameFile,
    decompressFile,
    FileObject,
} from '@/api/server/files';
import { pullFromUrl, moveToTrash, TrashCleanupSettings } from '@/api/server/files/betterFilesApi';
import getFileDownloadUrl from '@/api/server/files/getFileDownloadUrl';
import { Dialog } from '@/components/elements/dialog';
import { Button } from '@/components/elements/button/index';
import Code from '@/components/elements/Code';
import { CodeIcon } from '@heroicons/react/outline';
import FileActionsBar from '../FileActionsBar';
import EditorTabs, { OpenFile } from '../EditorTabs';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import GreyRowBox from '@/components/elements/GreyRowBox';
import tw from 'twin.macro';
import { StyleSheetManager } from 'styled-components';

import {
    PageContainer,
    Container,
    LeftPanel,
    ResizeHandle,
    EditorHeader,
    FilePath,
    EmptyState,
    SplitViewContainer,
    SplitEditorPane,
    SplitDropZone,
    SplitDivider,
    SplitCloseButton,
    SplitPaneHeader,
    SplitPaneHeaderLeft,
    PaneBadge,
    SplitPaneTitle,
    MobileTabBar,
    MobileTab,
} from './styles';

import { useFileManager } from './hooks/useFileManager';
import { usePanelResize } from './hooks/usePanelResize';
import { useSplitView } from './hooks/useSplitView';
import { useFileSelection } from './hooks/useFileSelection';
import { useFileHistory } from './hooks/useFileHistory';
import { SettingsDialog } from './components/SettingsDialog';
import { getMediaType, groupByDirectory, isArchiveFile } from './utils';
import type { ActiveTab, ViewMode, TrashCleanupSettings as TrashSettings, PropertiesEntry } from './types';

const GitPanel = lazy(() => import('../modals/GitPanel'));
const CreateFileModal = lazy(() => import('../modals/CreateFileModal'));
const CreateFolderModal = lazy(() => import('../modals/CreateFolderModal'));
const PullUrlModal = lazy(() => import('../modals/PullUrlModal'));
const PermissionsModal = lazy(() => import('../modals/PermissionsModal'));
const PropertiesModal = lazy(() => import('../modals/PropertiesModal'));

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

interface EditorWithMarkdownPreviewProps {
    showPreview: boolean;
    content: string;
    filePath: string;
    className?: string;
    children: React.ReactNode;
}

const EditorWithMarkdownPreview: React.FC<EditorWithMarkdownPreviewProps> = ({ showPreview, content, filePath, className, children }) => (
    <div className={cx('flex flex-1 min-w-0 min-h-0 gap-2', showPreview ? 'flex-col xl:flex-row' : 'flex-col', className)}>
        <GreyRowBox className={cx('flex flex-col flex-1 min-w-0 min-h-0 w-full items-stretch', showPreview && 'xl:w-1/2')} style={{ padding: 0 }}>
            {children}
        </GreyRowBox>
        {showPreview && (
            <MarkdownPreview
                content={content}
                filePath={filePath}
                className='flex-1 min-h-[220px] min-w-0 xl:w-1/2'
            />
        )}
    </div>
);

const BetterFileManagerContainer: React.FC = () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid) ?? '';
    const { clearFlashes, clearAndAddHttpError, addFlash } = useFlashKey('better-files');

    const [activeTab, setActiveTab] = useState<ActiveTab>('files');
    const [viewMode, setViewMode] = useState<ViewMode>('tree');
    const [showSettingsModal, setShowSettingsModal] = useState(false);
    const [isMobileViewport, setIsMobileViewport] = useState(false);
    const [isMobileEditorModalOpen, setIsMobileEditorModalOpen] = useState(false);
    const [popoutWindow, setPopoutWindow] = useState<Window | null>(null);
    const [popoutContainer, setPopoutContainer] = useState<HTMLDivElement | null>(null);
    const [showMarkdownPreview, setShowMarkdownPreview] = useState(false);
    const [hasNebula, setHasNebula] = useState(false);

    const [showNewFileModal, setShowNewFileModal] = useState(false);
    const [showNewFolderModal, setShowNewFolderModal] = useState(false);
    const [showPullUrlModal, setShowPullUrlModal] = useState(false);
    const [showMoveModal, setShowMoveModal] = useState(false);
    const [showMassDeleteConfirm, setShowMassDeleteConfirm] = useState(false);
    const [showMassMoveToTrashConfirm, setShowMassMoveToTrashConfirm] = useState(false);
    const [showUnarchiveConfirm, setShowUnarchiveConfirm] = useState(false);
    const [showMassPermissionsModal, setShowMassPermissionsModal] = useState(false);
    const [showPropertiesModal, setShowPropertiesModal] = useState(false);
    const [showUnsavedModal, setShowUnsavedModal] = useState(false);

    const [createFileTargetPaths, setCreateFileTargetPaths] = useState<string[]>([]);
    const [createFolderTargetPaths, setCreateFolderTargetPaths] = useState<string[]>([]);
    const [pullUrlTargetPaths, setPullUrlTargetPaths] = useState<string[]>([]);
    const [propertiesTargetPaths, setPropertiesTargetPaths] = useState<string[]>([]);
    const [unarchiveTargetPath, setUnarchiveTargetPath] = useState<string | null>(null);
    const [pendingCloseTabPath, setPendingCloseTabPath] = useState<string | null>(null);
    const [pendingCloseAllTabs, setPendingCloseAllTabs] = useState(false);

    const [trashRefreshNonce, setTrashRefreshNonce] = useState(0);
    const [canOpenTrashSettings, setCanOpenTrashSettings] = useState(false);
    const [canConfigureTrash, setCanConfigureTrash] = useState(false);
    const [trashCleanupSettings, setTrashCleanupSettings] = useState<TrashSettings | null>(null);

    const [showGitPanel, setShowGitPanel] = useState(false);
    const [isFileDragActive, setIsFileDragActive] = useState(false);
    const [isDraggingToSplit, setIsDraggingToSplit] = useState(false);
    const [isDraggingToEdit, setIsDraggingToEdit] = useState(false);

    const uploadTriggerRef = useRef<(() => void) | null>(null);
    const searchFocusRef = useRef<(() => void) | null>(null);
    const trashTriggerRef = useRef<(() => void) | null>(null);
    const trashSettingsTriggerRef = useRef<(() => void) | null>(null);
    const viewModeChangeRef = useRef<((mode: ViewMode) => void) | null>(null);
    const trashCleanupSaveRef = useRef<((settings: TrashSettings) => Promise<void>) | null>(null);
    const isSwitchingTabsRef = useRef(false);
    const historyButtonRef = useRef<HTMLButtonElement>(null);
    const fullscreenContainerRef = useRef<HTMLDivElement>(null);
    const mainEditorRef = useRef<SimpleEditorHandle>(null);
    const splitEditorRef = useRef<SimpleEditorHandle>(null);
    const [isFullscreen, setIsFullscreen] = useState(false);

    const [showHistoryDropdown, setShowHistoryDropdown] = useState(false);
    const [historyDropdownStyle, setHistoryDropdownStyle] = useState<React.CSSProperties>({});

    const updateHistoryDropdownPosition = useCallback((anchor?: HTMLElement | null) => {
        if (isMobileViewport) return;
        const button = anchor || historyButtonRef.current;
        if (!button) return;
        const rect = button.getBoundingClientRect();
        const dropdownWidth = 320;
        const minLeft = 12;
        const maxLeft = window.innerWidth - dropdownWidth - 12;
        const left = Math.min(maxLeft, Math.max(minLeft, rect.right - dropdownWidth));
        const top = Math.min(window.innerHeight - 12, rect.bottom + 8);
        setHistoryDropdownStyle({ top, left });
    }, [isMobileViewport]);

    const fileManager = useFileManager({ uuid, clearAndAddHttpError, clearFlashes, addFlash });
    const panelResize = usePanelResize({ initialWidth: 300, minWidth: 200, maxWidth: 480 });
    const splitView = useSplitView();
    const fileSelection = useFileSelection({ fileTree: fileManager.fileTree, currentPath: fileManager.currentPath });
    const fileHistory = useFileHistory(uuid);

    useEffect(() => {
        const checkMobile = () => setIsMobileViewport(window.innerWidth < 768);
        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    useEffect(() => {
        const cs = getComputedStyle(document.documentElement);
        const nebulaPresent = cs.getPropertyValue('--pageSecondary').trim() !== '' || cs.getPropertyValue('--pagePrimary').trim() !== '';
        if (nebulaPresent) document.documentElement.classList.add('si-nebula');
        else document.documentElement.classList.remove('si-nebula');
        setHasNebula(nebulaPresent);
    }, []);

    useEffect(() => {
        const handleDocumentDragStart = (e: DragEvent) => {
            if (!e.dataTransfer) return;
            const hasPlain = e.dataTransfer.types.includes('text/plain');
            const hasFileTree = e.dataTransfer.types.includes('application/x-filetree-drag');
            if (hasPlain || hasFileTree) setIsFileDragActive(true);
        };
        const handleDocumentDragOver = (e: DragEvent) => {
            if (!e.dataTransfer) return;
            const hasPlain = e.dataTransfer.types.includes('text/plain');
            const hasFileTree = e.dataTransfer.types.includes('application/x-filetree-drag');
            if (hasPlain || hasFileTree) setIsFileDragActive(true);
        };
        const handleDocumentDragEnd = () => {
            setIsFileDragActive(false);
            setIsDraggingToSplit(false);
            setIsDraggingToEdit(false);
        };
        const handleInternalSplitDragStart = () => setIsFileDragActive(true);
        const handleInternalSplitDragEnd = () => {
            setIsFileDragActive(false);
            setIsDraggingToSplit(false);
            setIsDraggingToEdit(false);
        };
        const handleInternalSplitHover = (event: Event) => {
            const detail = (event as CustomEvent).detail as { over?: boolean; pane?: string } | undefined;
            const isOver = !!detail?.over;
            const pane = detail?.pane;
            setIsDraggingToSplit(isOver && pane !== 'empty');
            setIsDraggingToEdit(isOver && pane === 'empty');
        };

        document.addEventListener('dragstart', handleDocumentDragStart);
        document.addEventListener('dragover', handleDocumentDragOver);
        document.addEventListener('dragend', handleDocumentDragEnd);
        window.addEventListener('bfm:split-drag-start', handleInternalSplitDragStart as EventListener);
        window.addEventListener('bfm:split-drag-end', handleInternalSplitDragEnd as EventListener);
        window.addEventListener('bfm:split-hover', handleInternalSplitHover as EventListener);

        return () => {
            document.removeEventListener('dragstart', handleDocumentDragStart);
            document.removeEventListener('dragover', handleDocumentDragOver);
            document.removeEventListener('dragend', handleDocumentDragEnd);
            window.removeEventListener('bfm:split-drag-start', handleInternalSplitDragStart as EventListener);
            window.removeEventListener('bfm:split-drag-end', handleInternalSplitDragEnd as EventListener);
            window.removeEventListener('bfm:split-hover', handleInternalSplitHover as EventListener);
        };
    }, []);

    const handleFileSelectWrapper = useCallback(async (filePath: string, isFile: boolean, paneOverride?: 'main' | 'split') => {
        if (isFile && window.innerWidth < 768) {
            setActiveTab('editor');
        }
        await fileManager.handleFileSelect(filePath, isFile, {
            setActiveTab,
            setSplitView: splitView.setSplitView,
            setSplitFilePath: splitView.setSplitFilePath,
            setActivePaneState: splitView.setActivePaneState,
            splitView: splitView.splitView,
            splitFilePath: splitView.splitFilePath,
            activePane: splitView.activePane,
        }, paneOverride);
    }, [fileManager, splitView, setActiveTab]);

    const handleSaveWrapper = useCallback(async (contentToSave?: string) => {
        const filePathToSave = splitView.activePane === 'split' && splitView.splitView
            ? splitView.splitFilePath
            : fileManager.selectedFile;
        
        await fileManager.handleSave(contentToSave, {
            activePane: splitView.activePane,
            splitView: splitView.splitView,
            splitFilePath: splitView.splitFilePath,
        });

        if (filePathToSave) {
            fileHistory.addToHistory(filePathToSave);
        }
    }, [fileManager, splitView, fileHistory]);

    const handleMainTabClick = useCallback((path: string) => {
        if (fileManager.selectedFile === path) return;
        if (isSwitchingTabsRef.current) return;
        isSwitchingTabsRef.current = true;

        const currentFolds = mainEditorRef.current?.getFolds() ?? [];
        const currentOpenFiles = fileManager.openFilesRef.current;
        const updatedOpenFiles = currentOpenFiles.map((f) =>
            f.path === fileManager.selectedFile
                ? { ...f, content: fileManager.fileContent, foldRanges: currentFolds, hasUnsavedChanges: fileManager.fileContent !== f.originalContent }
                : f
        );
        fileManager.openFilesRef.current = updatedOpenFiles;

        const targetFile = updatedOpenFiles.find((f) => f.path === path);
        if (targetFile) {
            fileManager.setOpenFiles(updatedOpenFiles);
            fileManager.setSelectedFile(path);
            fileManager.setFileContent(targetFile.content);
            fileManager.setOriginalContent(targetFile.originalContent);

            const directory = path.substring(0, path.lastIndexOf('/')) || '/';
            const fileName = path.substring(path.lastIndexOf('/') + 1);
            const fileObj = fileManager.fileTree[directory]?.find((f: FileObject) => f.name === fileName);
            if (fileObj) fileManager.setSelectedFileObject(fileObj);
        }

        setTimeout(() => { isSwitchingTabsRef.current = false; }, 150);
    }, [fileManager]);

    const handleTabClick = useCallback((path: string, targetPane: 'main' | 'split') => {
        const effectivePane = splitView.splitView && targetPane === 'split' ? 'split' : 'main';
        if (effectivePane === 'split') {
            if (splitView.splitFilePath === path) return;
            splitView.setActivePaneState('split');
            handleFileSelectWrapper(path, true, 'split');
            return;
        }
        splitView.setActivePaneState('main');
        handleMainTabClick(path);
    }, [splitView, handleFileSelectWrapper, handleMainTabClick]);

    const handleTabClose = useCallback((path: string) => {
        const openFile = fileManager.openFilesRef.current.find((f) => f.path === path);
        if (openFile?.hasUnsavedChanges) {
            setPendingCloseTabPath(path);
            setPendingCloseAllTabs(false);
            setShowUnsavedModal(true);
            return;
        }
        fileManager.closeFile(path, {
            splitView: splitView.splitView,
            splitFilePath: splitView.splitFilePath,
            setSplitFilePath: splitView.setSplitFilePath,
            setSplitView: splitView.setSplitView,
            setActivePaneState: splitView.setActivePaneState,
            setActiveTab,
        });
    }, [fileManager, splitView]);

    const closeAllTabs = useCallback(() => {
        fileManager.closeAllFiles({
            setSplitFilePath: splitView.setSplitFilePath,
            setSplitView: splitView.setSplitView,
            setActivePaneState: splitView.setActivePaneState,
            setActiveTab,
        });
    }, [fileManager, splitView]);

    const handleCloseAllTabs = useCallback(() => {
        if (fileManager.openFilesRef.current.length === 0) return;
        if (fileManager.openFilesRef.current.some((file) => file.hasUnsavedChanges)) {
            setPendingCloseTabPath(null);
            setPendingCloseAllTabs(true);
            setShowUnsavedModal(true);
            return;
        }
        closeAllTabs();
    }, [fileManager, closeAllTabs]);

    const handleConfirmCloseUnsaved = useCallback(() => {
        if (pendingCloseAllTabs) {
            closeAllTabs();
        } else if (pendingCloseTabPath) {
            fileManager.closeFile(pendingCloseTabPath, {
                splitView: splitView.splitView,
                splitFilePath: splitView.splitFilePath,
                setSplitFilePath: splitView.setSplitFilePath,
                setSplitView: splitView.setSplitView,
                setActivePaneState: splitView.setActivePaneState,
                setActiveTab,
            });
        }
        setShowUnsavedModal(false);
        setPendingCloseTabPath(null);
        setPendingCloseAllTabs(false);
    }, [pendingCloseAllTabs, pendingCloseTabPath, closeAllTabs, fileManager, splitView]);

    const handleCancelCloseUnsaved = useCallback(() => {
        setShowUnsavedModal(false);
        setPendingCloseTabPath(null);
        setPendingCloseAllTabs(false);
    }, []);

    const handleNewFile = useCallback(() => {
        setCreateFileTargetPaths(fileSelection.resolveActionTargetPaths());
        setShowNewFileModal(true);
    }, [fileSelection]);

    const handleNewFolder = useCallback(() => {
        setCreateFolderTargetPaths(fileSelection.resolveActionTargetPaths());
        setShowNewFolderModal(true);
    }, [fileSelection]);

    const handlePullUrl = useCallback(() => {
        setPullUrlTargetPaths(fileSelection.resolveActionTargetPaths());
        setShowPullUrlModal(true);
    }, [fileSelection]);

    const handleUploadFiles = useCallback(() => {
        uploadTriggerRef.current?.();
    }, []);

    const handleDownloadSelected = useCallback(async () => {
        const paths = fileSelection.selectedFiles.filter((path) => fileManager.getFileObjectByPath(path)?.isFile);
        if (paths.length === 0) {
            addFlash({ type: 'warning', message: 'No files selected to download.' });
            return;
        }
        for (const path of paths) {
            try {
                const url = await getFileDownloadUrl(uuid, path);
                const link = document.createElement('a');
                link.href = url;
                link.download = path.split('/').pop() || 'download';
                link.rel = 'noopener';
                document.body.appendChild(link);
                link.click();
                link.remove();
            } catch (error) {
                clearAndAddHttpError(error as Error);
            }
        }
    }, [uuid, fileSelection.selectedFiles, fileManager, addFlash, clearAndAddHttpError]);

    const confirmMassDelete = useCallback(async () => {
        setShowMassDeleteConfirm(false);
        fileManager.setLoading(true);
        await fileManager.handleMassDelete(fileSelection.selectedFiles);
        fileSelection.clearSelection();
        fileManager.setLoading(false);
    }, [fileManager, fileSelection]);

    const confirmMassMoveToTrash = useCallback(async () => {
        setShowMassMoveToTrashConfirm(false);
        fileManager.setLoading(true);
        await fileManager.handleMassMoveToTrash(fileSelection.selectedFiles);
        fileSelection.clearSelection();
        setTrashRefreshNonce((prev) => prev + 1);
        fileManager.setLoading(false);
    }, [fileManager, fileSelection]);

    const handleArchiveAction = useCallback(() => {
        if (fileSelection.selectedArchiveTarget) {
            setUnarchiveTargetPath(fileSelection.selectedArchiveTarget.path);
            setShowUnarchiveConfirm(true);
            return;
        }
        fileManager.handleMassCompress(fileSelection.selectedFiles).then(() => fileSelection.clearSelection());
    }, [fileManager, fileSelection]);

    const confirmUnarchive = useCallback(async () => {
        if (!unarchiveTargetPath) return;
        setShowUnarchiveConfirm(false);
        await fileManager.handleUnarchive(unarchiveTargetPath);
        fileSelection.clearSelection();
        setUnarchiveTargetPath(null);
    }, [unarchiveTargetPath, fileManager, fileSelection]);

    const confirmMassMove = useCallback(async (destinationPath: string) => {
        setShowMoveModal(false);
        fileManager.setLoading(true);
        await fileManager.handleMassMove(fileSelection.selectedFiles, destinationPath);
        fileSelection.clearSelection();
        fileManager.setLoading(false);
    }, [fileManager, fileSelection]);

    const openPropertiesModal = useCallback((paths: string | string[]) => {
        const nextPaths = (Array.isArray(paths) ? paths : [paths]).filter(Boolean);
        if (nextPaths.length === 0) return;
        setPropertiesTargetPaths(nextPaths);
        setShowPropertiesModal(true);
    }, []);

    const handleShowProperties = useCallback(() => {
        if (fileSelection.selectedFiles.length > 0) {
            openPropertiesModal(Array.from(new Set(fileSelection.selectedFiles)));
            return;
        }
        if (fileManager.selectedFile) openPropertiesModal(fileManager.selectedFile);
    }, [fileSelection.selectedFiles, fileManager.selectedFile, openPropertiesModal]);

    const handleMassPermissions = useCallback(() => {
        if (fileSelection.selectedFiles.length > 0) setShowMassPermissionsModal(true);
    }, [fileSelection.selectedFiles]);

    const handleFileClose = useCallback(() => {
        fileManager.setSelectedFile(null);
        fileManager.setSelectedFileObject(null);
        fileManager.setFileContent('');
        fileManager.setOriginalContent('');
        setActiveTab('files');
    }, [fileManager]);

    const handleBreadcrumbDragStart = useCallback((e: React.DragEvent, path: string, name: string) => {
        e.dataTransfer.setData('application/x-filetree-drag', JSON.stringify({ multiple: false, path, name, isFile: true }));
        e.dataTransfer.setData('text/plain', path);
        e.dataTransfer.effectAllowed = 'copy';
        setIsFileDragActive(true);
    }, []);

    const handleTabDragStart = useCallback((path: string, e: React.DragEvent) => {
        const name = path.substring(path.lastIndexOf('/') + 1);
        e.dataTransfer.setData('application/x-filetree-drag', JSON.stringify({ multiple: false, path, name, isFile: true }));
        e.dataTransfer.setData('text/plain', path);
        e.dataTransfer.effectAllowed = 'copy';
    }, []);

    const resolveDropPath = useCallback((e: { dataTransfer?: { getData?: (type: string) => string } }) => {
        const dataTransfer = e?.dataTransfer;
        let path = dataTransfer?.getData?.('text/plain') || '';
        if (!path) {
            const filetreeData = dataTransfer?.getData?.('application/x-filetree-drag');
            if (filetreeData) {
                try {
                    const data = JSON.parse(filetreeData);
                    if (data.multiple && data.files?.length > 0) path = data.files[0].path;
                    else if (data.path && data.isFile) path = data.path;
                } catch {}
            }
        }
        return path ? (path.startsWith('/') ? path : `/${path}`) : '';
    }, []);

    const openFileInMainPane = useCallback(async (path: string) => {
        if (!path || path === fileManager.selectedFile) return;
        const existingFile = fileManager.openFilesRef.current.find((f) => f.path === path);
        if (existingFile) {
            fileManager.setSelectedFile(path);
            fileManager.setFileContent(existingFile.content);
            fileManager.setOriginalContent(existingFile.originalContent);
            splitView.setActivePaneState('main');
            return;
        }
        try {
            const content = await getFileContents(uuid, path);
            const name = path.substring(path.lastIndexOf('/') + 1);
            const newFile: OpenFile = { path, name, content, originalContent: content, hasUnsavedChanges: false };
            const updatedFiles = [...fileManager.openFilesRef.current, newFile];
            fileManager.openFilesRef.current = updatedFiles;
            fileManager.setOpenFiles(updatedFiles);
            fileManager.setFileContent(content);
            fileManager.setOriginalContent(content);
            fileManager.setSelectedFile(path);
            splitView.setActivePaneState('main');
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, fileManager, splitView, clearAndAddHttpError]);

    const handleSplitDrop = useCallback(async (e: React.DragEvent) => {
        e.preventDefault();
        const path = resolveDropPath(e);
        if (!path) return;

        const existingFile = fileManager.openFilesRef.current.find((f) => f.path === path);
        if (existingFile) {
            splitView.setSplitFilePath(path);
            splitView.setSplitView(true);
            splitView.setActivePaneState('split');
        } else {
            try {
                const content = await getFileContents(uuid, path);
                const name = path.substring(path.lastIndexOf('/') + 1);
                const newFile: OpenFile = { path, name, content, originalContent: content, hasUnsavedChanges: false };
                const updatedFiles = [...fileManager.openFilesRef.current, newFile];
                fileManager.openFilesRef.current = updatedFiles;
                fileManager.setOpenFiles(updatedFiles);
                splitView.setSplitFilePath(path);
                splitView.setSplitView(true);
                splitView.setActivePaneState('split');
            } catch (error) {
                clearAndAddHttpError(error as Error);
            }
        }
    }, [uuid, fileManager, splitView, resolveDropPath, clearAndAddHttpError]);

    const handleMainPaneDrop = useCallback(async (e: React.DragEvent) => {
        e.preventDefault();
        const path = resolveDropPath(e);
        if (path) await openFileInMainPane(path);
    }, [resolveDropPath, openFileInMainPane]);

    const activeFile = fileManager.openFiles.find((f) => f.path === fileManager.selectedFile);
    const activeFileContent = activeFile?.content ?? fileManager.fileContent;
    const activeOriginalContent = activeFile?.originalContent ?? fileManager.originalContent;
    const hasUnsavedChanges = activeFile?.hasUnsavedChanges ?? fileManager.fileContent !== fileManager.originalContent;

    const splitFile = fileManager.openFiles.find((f) => f.path === splitView.splitFilePath);
    const splitFileContent = splitFile?.content ?? '';
    const splitHasUnsavedChanges = splitFile?.hasUnsavedChanges ?? false;

    const mediaType = fileManager.selectedFile ? getMediaType(fileManager.selectedFile) : null;
    const splitMediaType = splitView.splitFilePath ? getMediaType(splitView.splitFilePath) : null;

    const activeEditorFile = splitView.activePane === 'split' && splitView.splitView ? splitView.splitFilePath : fileManager.selectedFile;
    const activeEditorContent = splitView.activePane === 'split' && splitView.splitView ? splitFileContent : activeFileContent;
    const activeEditorOriginalContent = splitView.activePane === 'split' && splitView.splitView ? (splitFile?.originalContent ?? '') : activeOriginalContent;
    const activeEditorHasUnsavedChanges = splitView.activePane === 'split' && splitView.splitView ? splitHasUnsavedChanges : hasUnsavedChanges;
    const activeMediaType = splitView.activePane === 'split' && splitView.splitView ? splitMediaType : mediaType;
    const isActiveSplitEditor = splitView.activePane === 'split' && splitView.splitView;
    const canPreviewMarkdown = activeMediaType === 'text' && !!activeEditorFile && isMarkdownFile(activeEditorFile);
    const showActiveMarkdownPreview = showMarkdownPreview && canPreviewMarkdown;
    const showMainMarkdownPreview = showActiveMarkdownPreview && activeEditorFile === fileManager.selectedFile && isMarkdownFile(fileManager.selectedFile);
    const showSplitMarkdownPreview = showActiveMarkdownPreview && activeEditorFile === splitView.splitFilePath && isMarkdownFile(splitView.splitFilePath);
    const canUseMobileEditorModal = isMobileViewport && activeMediaType === 'text' && !!activeEditorFile;
    const canUseFullscreenEditor = activeMediaType === 'text' && !!activeEditorFile;

    const breadcrumbPane = splitView.splitView && splitView.activePane === 'split' ? 'split' : 'main';
    const breadcrumbFilePath = breadcrumbPane === 'split' ? splitView.splitFilePath : fileManager.selectedFile;
    const breadcrumbPath = breadcrumbFilePath || fileManager.currentPath;
    const breadcrumbIsFile = !!breadcrumbFilePath;

    const propertiesEntries: PropertiesEntry[] = propertiesTargetPaths.map((path) => ({
        path,
        file: fileManager.getFileObjectByPath(path),
    }));

    const updateActiveFileContent = useCallback((newContent: string) => {
        fileManager.updateFileContent(fileManager.selectedFile!, newContent);
    }, [fileManager]);

    const resetActiveFileContent = useCallback(() => {
        if (fileManager.selectedFile) fileManager.resetFileContent(fileManager.selectedFile);
    }, [fileManager]);

    const updateSplitFileContent = useCallback((newContent: string) => {
        if (splitView.splitFilePath) fileManager.updateFileContent(splitView.splitFilePath, newContent);
    }, [fileManager, splitView.splitFilePath]);

    const resetSplitFileContent = useCallback(() => {
        if (splitView.splitFilePath) fileManager.resetFileContent(splitView.splitFilePath);
    }, [fileManager, splitView.splitFilePath]);

    const updateCurrentEditorContent = isActiveSplitEditor ? updateSplitFileContent : updateActiveFileContent;
    const resetCurrentEditorContent = isActiveSplitEditor ? resetSplitFileContent : resetActiveFileContent;

    useEffect(() => {
        if (!canPreviewMarkdown) setShowMarkdownPreview(false);
    }, [canPreviewMarkdown]);

    const handleSaveTrashSettings = useCallback(async (settings: TrashSettings) => {
        await trashCleanupSaveRef.current?.(settings);
    }, []);

    useEffect(() => {
        const handleSplitOpen = (event: Event) => {
            const detail = (event as CustomEvent).detail as { path?: string; pane?: 'main' | 'split' | 'empty' } | undefined;
            const path = detail?.path;
            if (!path) return;
            if (detail?.pane === 'empty') {
                handleFileSelectWrapper(path, true, 'main');
                return;
            }
            if (splitView.splitView) {
                handleFileSelectWrapper(path, true, detail?.pane === 'split' ? 'split' : 'main');
            } else {
                handleFileSelectWrapper(path, true, 'split');
            }
        };
        window.addEventListener('bfm:open-split', handleSplitOpen as EventListener);
        return () => window.removeEventListener('bfm:open-split', handleSplitOpen as EventListener);
    }, [handleFileSelectWrapper, splitView.splitView]);

    useEffect(() => {
        if (!showHistoryDropdown || isMobileViewport) return;
        const updatePosition = () => updateHistoryDropdownPosition();
        updatePosition();
        window.addEventListener('resize', updatePosition);
        window.addEventListener('scroll', updatePosition, true);
        return () => {
            window.removeEventListener('resize', updatePosition);
            window.removeEventListener('scroll', updatePosition, true);
        };
    }, [showHistoryDropdown, isMobileViewport, updateHistoryDropdownPosition]);

    useEffect(() => {
        if (canUseFullscreenEditor) return;
        setIsMobileEditorModalOpen(false);
    }, [canUseFullscreenEditor]);

    useEffect(() => {
        if (!isMobileEditorModalOpen) return;
        const originalOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === 'Escape') setIsMobileEditorModalOpen(false);
        };
        window.addEventListener('keydown', handleEscape);
        return () => {
            document.body.style.overflow = originalOverflow;
            window.removeEventListener('keydown', handleEscape);
        };
    }, [isMobileEditorModalOpen]);

    const openPopoutEditor = useCallback(() => {
        if (popoutWindow && !popoutWindow.closed) {
            popoutWindow.focus();
            return;
        }

        const w = Math.min(1200, Math.round(screen.width * 0.7));
        const h = Math.min(800, Math.round(screen.height * 0.75));
        const left = Math.round((screen.width - w) / 2);
        const top = Math.round((screen.height - h) / 2);

        const win = window.open('', '', `width=${w},height=${h},left=${left},top=${top},resizable=yes,scrollbars=no`);
        if (!win) return;

        win.document.title = 'Better Files - Editor';

        const parentStyles = document.querySelectorAll('style, link[rel="stylesheet"]');
        parentStyles.forEach((node) => {
            if (node instanceof HTMLLinkElement) {
                try {
                    const sheet = node.sheet;
                    if (sheet) {
                        const rules = Array.from(sheet.cssRules).map(r => r.cssText).join('\n');
                        const style = win.document.createElement('style');
                        style.textContent = rules;
                        win.document.head.appendChild(style);
                        return;
                    }
                } catch {}
            }
            win.document.head.appendChild(node.cloneNode(true));
        });

        win.document.body.style.margin = '0';
        win.document.body.style.overflow = 'hidden';
        win.document.body.style.height = '100vh';
        win.document.body.className = document.body.className;
        win.document.documentElement.className = document.documentElement.className;

        const container = win.document.createElement('div');
        container.id = 'popout-editor-root';
        container.style.width = '100%';
        container.style.height = '100%';
        win.document.body.appendChild(container);

        setPopoutWindow(win);
        setPopoutContainer(container);

        win.addEventListener('beforeunload', () => {
            setPopoutWindow(null);
            setPopoutContainer(null);
        });

        setTimeout(() => win.dispatchEvent(new Event('resize')), 100);
        setTimeout(() => win.dispatchEvent(new Event('resize')), 500);
    }, [popoutWindow]);

    useEffect(() => {
        if (!popoutWindow || popoutWindow.closed) return;
        const fileName = activeEditorFile?.split('/').pop() || 'Editor';
        popoutWindow.document.title = `${fileName} - Better Files Editor`;
    }, [popoutWindow, activeEditorFile]);

    useEffect(() => {
        return () => {
            if (popoutWindow && !popoutWindow.closed) popoutWindow.close();
        };
    }, []);

    const toggleFullscreen = useCallback(() => {
        const el = fullscreenContainerRef.current;
        if (!el) return;
        if (document.fullscreenElement) {
            document.exitFullscreen();
        } else {
            el.requestFullscreen();
        }
    }, []);

    useEffect(() => {
        const handler = () => setIsFullscreen(!!document.fullscreenElement);
        document.addEventListener('fullscreenchange', handler);
        return () => document.removeEventListener('fullscreenchange', handler);
    }, []);

    if (fileManager.loading && !fileManager.selectedFile) {
        return <Spinner size='large' centered />;
    }

    return (
        <ServerContentBlock
            title='Files'
            className={`${hasNebula ? 'si-nebula' : ''} betterfiles-scope w-full !max-w-none !mx-0 px-4 sm:px-6`}
        >
            <div className='relative w-full'>
                <FlashMessageRender byKey='better-files' className='fixed top-20 left-1/2 transform -translate-x-1/2 z-50 max-w-2xl' />

                {fileManager.operationProgress?.show && <ProgressToast message={fileManager.operationProgress.message} />}

                {showHistoryDropdown && createPortal(
                    <>
                        <div
                            className='fixed inset-0 z-[60]'
                            onClick={() => setShowHistoryDropdown(false)}
                        />
                        <div
                            className='fixed z-[70]'
                            style={{
                                top: isMobileViewport ? 'auto' : historyDropdownStyle.top ?? 0,
                                left: isMobileViewport ? 'auto' : historyDropdownStyle.left ?? 0,
                                right: isMobileViewport ? 16 : 'auto',
                                bottom: isMobileViewport ? 16 : 'auto',
                            }}
                        >
                            <GreyRowBox
                                className='shadow-xl overflow-hidden !p-0 flex-col !items-stretch'
                                $hoverable={false}
                                style={{
                                    maxHeight: isMobileViewport ? 'calc(100vh - 80px)' : '400px',
                                    maxWidth: isMobileViewport ? undefined : '400px',
                                    minWidth: isMobileViewport ? undefined : '280px',
                                }}
                            >
                            <div className='flex items-center justify-between px-3 py-2 border-b border-gray-600 bg-gray-800/50'>
                                <span className='text-xs font-semibold text-neutral-300 uppercase tracking-wide'>Recently Edited</span>
                                {fileHistory.history.length > 0 && (
                                    <button
                                        type='button'
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            fileHistory.clearHistory();
                                        }}
                                        className='text-xs text-gray-400 hover:text-red-400 transition-colors'
                                    >
                                        Clear
                                    </button>
                                )}
                            </div>
                            <div className='overflow-y-auto' style={{ maxHeight: isMobileViewport ? 'calc(100vh - 140px)' : '350px' }}>
                                {fileHistory.history.length === 0 ? (
                                    <div className='px-3 py-4 text-center text-gray-400 text-sm'>
                                        No recently edited files
                                    </div>
                                ) : (
                                    fileHistory.history.map((entry) => (
                                        <div
                                            key={entry.path}
                                            className='group flex items-center gap-2 px-3 py-2 hover:bg-gray-600/50 cursor-pointer transition-colors'
                                            onClick={() => {
                                                handleFileSelectWrapper(entry.path, true, splitView.activePaneRef.current);
                                                setShowHistoryDropdown(false);
                                            }}
                                        >
                                            <svg className='w-4 h-4 flex-shrink-0 text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' />
                                            </svg>
                                            <div className='flex-1 min-w-0'>
                                                <div className='text-sm text-neutral-200 truncate'>{entry.filename}</div>
                                                <div className='text-xs text-gray-400 truncate'>{entry.path}</div>
                                            </div>
                                            <div className='text-xs text-gray-500 flex-shrink-0 hidden sm:block'>
                                                {new Date(entry.timestamp).toLocaleString(undefined, {
                                                    month: 'short',
                                                    day: 'numeric',
                                                    hour: '2-digit',
                                                    minute: '2-digit',
                                                })}
                                            </div>
                                            <button
                                                type='button'
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    fileHistory.removeFromHistory(entry.path);
                                                }}
                                                className='p-1 text-gray-400 hover:text-red-400 transition-all sm:opacity-0 sm:group-hover:opacity-100'
                                                title='Remove from history'
                                            >
                                                <svg className='w-3.5 h-3.5' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M6 18L18 6M6 6l12 12' />
                                                </svg>
                                            </button>
                                        </div>
                                    ))
                                )}
                            </div>
                            </GreyRowBox>
                        </div>
                    </>,
                    document.body
                )}

                {isMobileEditorModalOpen && canUseFullscreenEditor && createPortal(
                    <div className='fixed inset-0 z-[90] bg-black/75 backdrop-blur-[1px]' onClick={() => setIsMobileEditorModalOpen(false)}>
                        <div
                            className='h-full w-full'
                            onClick={(e) => e.stopPropagation()}
                            style={{
                                paddingTop: isMobileViewport ? 'calc(env(safe-area-inset-top) + 8px)' : 16,
                                paddingRight: isMobileViewport ? 8 : 16,
                                paddingBottom: isMobileViewport ? 'calc(env(safe-area-inset-bottom) + 8px)' : 16,
                                paddingLeft: isMobileViewport ? 8 : 16,
                            }}
                        >
                            <GreyRowBox className='h-full flex flex-col !items-stretch !p-2 md:!p-3 overflow-hidden' $hoverable={false}>
                                <div className='flex items-center gap-2 border-b border-neutral-600 pb-2'>
                                    <Button.Text
                                        type='button'
                                        onClick={() => setIsMobileEditorModalOpen(false)}
                                        title='Exit fullscreen (Esc)'
                                        size={Button.Sizes.Small}
                                        shape={Button.Shapes.IconSquare}
                                        className='bg-transparent text-neutral-300 hover:bg-neutral-600/60 active:bg-neutral-600/60 border-0 flex-shrink-0'
                                    >
                                        {isMobileViewport ? (
                                            <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 19l-7-7 7-7' />
                                            </svg>
                                        ) : (
                                            <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4' />
                                            </svg>
                                        )}
                                    </Button.Text>
                                    <div className='min-w-0 flex-1'>
                                        <div className='text-[10px] uppercase tracking-widest text-neutral-500'>Fullscreen Editor</div>
                                        <div className='text-sm text-neutral-200 truncate'>{activeEditorFile?.split('/').pop() || 'Editor'}</div>
                                    </div>
                                    {activeEditorHasUnsavedChanges && (
                                        <span className='text-[11px] font-semibold text-yellow-400 flex items-center gap-1'>
                                            <span className='w-2 h-2 bg-yellow-400 rounded-full' />
                                            Modified
                                        </span>
                                    )}
                                    {!isMobileViewport && activeEditorFile && (
                                        <FileToolbar
                                            selectedFile={activeEditorFile}
                                            content={activeEditorContent}
                                            originalContent={activeEditorOriginalContent}
                                            hasUnsavedChanges={activeEditorHasUnsavedChanges}
                                            isSaving={fileManager.isSaving}
                                            onSave={handleSaveWrapper}
                                            onReset={resetCurrentEditorContent}
                                            onContentUpdate={updateCurrentEditorContent}
                                            canPreviewMarkdown={canPreviewMarkdown}
                                            markdownPreviewVisible={showActiveMarkdownPreview}
                                            onToggleMarkdownPreview={() => setShowMarkdownPreview((visible) => !visible)}
                                            compact
                                        />
                                    )}
                                </div>

                                <EditorHeader className='mt-2'>
                                    <EditorTabs
                                        openFiles={fileManager.openFiles}
                                        activeMainFilePath={fileManager.selectedFile}
                                        activeSplitFilePath={splitView.splitFilePath}
                                        activePane={splitView.activePane}
                                        splitView={splitView.splitView}
                                        onTabClick={handleTabClick}
                                        onTabClose={handleTabClose}
                                        onCloseAll={handleCloseAllTabs}
                                        onTabDragStart={handleTabDragStart}
                                        disableDrag={isMobileViewport}
                                        chrome={false}
                                        connected
                                        className='flex-1 min-w-0'
                                    />
                                </EditorHeader>

                                {isMobileViewport && activeEditorFile && (
                                    <div className='mt-2'>
                                        <FileToolbar
                                            selectedFile={activeEditorFile}
                                            content={activeEditorContent}
                                            originalContent={activeEditorOriginalContent}
                                            hasUnsavedChanges={activeEditorHasUnsavedChanges}
                                            isSaving={fileManager.isSaving}
                                            onSave={handleSaveWrapper}
                                            onReset={resetCurrentEditorContent}
                                            onContentUpdate={updateCurrentEditorContent}
                                            canPreviewMarkdown={canPreviewMarkdown}
                                            markdownPreviewVisible={showActiveMarkdownPreview}
                                            onToggleMarkdownPreview={() => setShowMarkdownPreview((visible) => !visible)}
                                            compact
                                        />
                                    </div>
                                )}

                                <div className='mt-2 flex-1 min-h-0'>
                                    {activeEditorFile ? (
                                        <EditorWithMarkdownPreview
                                            showPreview={showActiveMarkdownPreview}
                                            content={activeEditorContent}
                                            filePath={activeEditorFile}
                                            className='h-full'
                                        >
                                            <SimpleEditor
                                                value={activeEditorContent}
                                                onChange={updateCurrentEditorContent}
                                                filePath={activeEditorFile}
                                                readOnly={fileManager.isSaving}
                                                onSave={handleSaveWrapper}
                                                onFileDrop={(path: string) => {
                                                    void handleFileSelectWrapper(path, true, splitView.activePaneRef.current);
                                                }}
                                                onFocus={() => splitView.setActivePaneState(isActiveSplitEditor ? 'split' : 'main')}
                                            />
                                        </EditorWithMarkdownPreview>
                                    ) : (
                                        <EmptyState>
                                            <p className='text-sm text-neutral-300'>No file selected</p>
                                        </EmptyState>
                                    )}
                                </div>
                            </GreyRowBox>
                        </div>
                    </div>,
                    document.body
                )}

                {popoutContainer && popoutWindow && !popoutWindow.closed && canUseFullscreenEditor && createPortal(
                    <StyleSheetManager target={popoutWindow.document.head}>
                        <div className='flex flex-col h-screen bg-neutral-800 p-3'>
                        <div className='flex items-center gap-2 border-b border-neutral-600 pb-2 mb-2'>
                            <div className='min-w-0 flex-1'>
                                <div className='text-sm text-neutral-200 truncate font-medium'>{activeEditorFile?.split('/').pop() || 'Editor'}</div>
                                <div className='text-[10px] text-neutral-500 truncate'>{activeEditorFile}</div>
                            </div>
                            {activeEditorHasUnsavedChanges && (
                                <span className='text-[11px] font-semibold text-yellow-400 flex items-center gap-1'>
                                    <span className='w-2 h-2 bg-yellow-400 rounded-full' />
                                    Modified
                                </span>
                            )}
                            <FileToolbar
                                selectedFile={activeEditorFile!}
                                content={activeEditorContent}
                                originalContent={activeEditorOriginalContent}
                                hasUnsavedChanges={activeEditorHasUnsavedChanges}
                                isSaving={fileManager.isSaving}
                                onSave={handleSaveWrapper}
                                onReset={resetCurrentEditorContent}
                                onContentUpdate={updateCurrentEditorContent}
                                canPreviewMarkdown={canPreviewMarkdown}
                                markdownPreviewVisible={showActiveMarkdownPreview}
                                onToggleMarkdownPreview={() => setShowMarkdownPreview((visible) => !visible)}
                                compact
                            />
                        </div>

                        <EditorHeader>
                            <EditorTabs
                                openFiles={fileManager.openFiles}
                                activeMainFilePath={fileManager.selectedFile}
                                activeSplitFilePath={splitView.splitFilePath}
                                activePane={splitView.activePane}
                                splitView={splitView.splitView}
                                onTabClick={handleTabClick}
                                onTabClose={handleTabClose}
                                onCloseAll={handleCloseAllTabs}
                                onTabDragStart={handleTabDragStart}
                                chrome={false}
                                connected
                                className='flex-1 min-w-0'
                            />
                        </EditorHeader>

                        <div className='mt-2 flex-1 min-h-0'>
                            {activeEditorFile ? (
                                <EditorWithMarkdownPreview
                                    showPreview={showActiveMarkdownPreview}
                                    content={activeEditorContent}
                                    filePath={activeEditorFile}
                                    className='h-full'
                                >
                                    <SimpleEditor
                                        value={activeEditorContent}
                                        onChange={updateCurrentEditorContent}
                                        filePath={activeEditorFile}
                                        readOnly={fileManager.isSaving}
                                        onSave={handleSaveWrapper}
                                        onFileDrop={(path: string) => {
                                            void handleFileSelectWrapper(path, true, splitView.activePaneRef.current);
                                        }}
                                        onFocus={() => splitView.setActivePaneState(isActiveSplitEditor ? 'split' : 'main')}
                                    />
                                </EditorWithMarkdownPreview>
                            ) : (
                                <EmptyState>
                                    <p className='text-sm text-neutral-300'>No file selected</p>
                                </EmptyState>
                            )}
                        </div>
                        </div>
                    </StyleSheetManager>,
                    popoutContainer
                )}

                {fileSelection.selectedFiles.length > 0 && (
                    <div className='fixed bottom-44 sm:bottom-16 left-0 right-0 z-50 flex justify-center px-4 pointer-events-none'>
                        <div className='pointer-events-auto w-[min(92vw,380px)] sm:w-auto'>
                            <div className='w-full max-w-7xl overflow-hidden shadow-2xl'>
                                <FileActionsBar
                                    selectedCount={fileSelection.selectedFiles.length}
                                    sortBy={fileSelection.sortBy}
                                    sortDirection={fileSelection.sortDirection}
                                    onSortChange={fileSelection.handleSortChange}
                                    onNewFile={handleNewFile}
                                    onNewFolder={handleNewFolder}
                                    onUploadFiles={handleUploadFiles}
                                    onPullUrl={handlePullUrl}
                                    onDownload={handleDownloadSelected}
                                    onMoveToTrash={() => setShowMassMoveToTrashConfirm(true)}
                                    onDeletePermanently={() => setShowMassDeleteConfirm(true)}
                                    onCompress={handleArchiveAction}
                                    archiveLabel={fileSelection.selectedArchiveTarget ? 'Unarchive' : 'Archive'}
                                    onMove={() => setShowMoveModal(true)}
                                    onPermissions={handleMassPermissions}
                                    onProperties={handleShowProperties}
                                    onClearSelection={fileSelection.clearSelection}
                                />
                            </div>
                        </div>
                    </div>
                )}

                <PageContainer ref={fullscreenContainerRef} className={cx('betterfiles-scope', isFullscreen && 'bg-neutral-800 !p-2 !mb-0')}>
                    <Container ref={panelResize.containerRef} isResizing={panelResize.isResizing} className={isFullscreen ? '!h-[calc(100vh-1rem)]' : undefined}>
                        <MobileTabBar>
                            <MobileTab active={activeTab === 'files'} onClick={() => setActiveTab('files')}>Files</MobileTab>
                            <MobileTab active={activeTab === 'editor'} onClick={() => setActiveTab('editor')} className='truncate'>
                                <span className='truncate block px-2'>{fileManager.selectedFile ? fileManager.selectedFile.split('/').pop() : 'Editor'}</span>
                            </MobileTab>
                        </MobileTabBar>

                        <LeftPanel
                            ref={panelResize.panelRef}
                            width={panelResize.width}
                            isResizing={panelResize.isResizing}
                            className={activeTab === 'files' ? 'md:flex' : '!hidden md:!flex'}
                            css={tw`p-2 pt-2 mt-2 md:mt-0`}
                        >
                            <div className='flex-1 min-h-0 w-full overflow-x-auto overflow-y-auto'>
                                <FileTree
                                    fileTree={fileManager.fileTree}
                                    currentPath={fileManager.currentPath}
                                    selectedFile={activeEditorFile || fileManager.selectedFile}
                                    selectedFiles={fileSelection.selectedFiles}
                                    sortBy={fileSelection.sortBy}
                                    sortDirection={fileSelection.sortDirection}
                                    onFileSelect={(path, isFile) => handleFileSelectWrapper(path, isFile, splitView.activePaneRef.current)}
                                    onPathChange={fileManager.setCurrentPath}
                                    onDirectoryLoad={fileManager.loadDirectory}
                                    onToggleFileSelection={fileSelection.toggleFileSelection}
                                    onSetSelectedFiles={fileSelection.setSelectedFiles}
                                    onSortChange={fileSelection.handleSortChange}
                                    onSelectAll={fileSelection.selectAll}
                                    onClearSelection={fileSelection.clearSelection}
                                    onNewFile={handleNewFile}
                                    onNewFolder={handleNewFolder}
                                    onPullUrl={handlePullUrl}
                                    onFileClose={handleFileClose}
                                    onShowProperties={openPropertiesModal}
                                    trashRefreshNonce={trashRefreshNonce}
                                    onRegisterUploadTrigger={(trigger) => { uploadTriggerRef.current = trigger; }}
                                    onRegisterSearchFocus={(trigger) => { searchFocusRef.current = trigger; }}
                                    onRegisterTrashTrigger={(trigger) => { trashTriggerRef.current = trigger; }}
                                    onRegisterTrashSettingsTrigger={(trigger) => { trashSettingsTriggerRef.current = trigger; setCanOpenTrashSettings(!!trigger); }}
                                    showTrashIcons={isMobileViewport}
                                    onOpenSettings={() => setShowSettingsModal(true)}
                                    onOpenHistory={() => setShowHistoryDropdown(!showHistoryDropdown)}
                                    onRegisterViewModeChange={(trigger, currentMode) => { viewModeChangeRef.current = trigger; setViewMode(currentMode); }}
                                    onRegisterTrashCleanupState={(settings, onSave, canConfigure) => {
                                        setTrashCleanupSettings(settings);
                                        trashCleanupSaveRef.current = onSave;
                                        setCanConfigureTrash(canConfigure);
                                    }}
                                    embedded
                                />
                            </div>
                        </LeftPanel>

                        <ResizeHandle onMouseDown={panelResize.handleMouseDown} />

                        <GreyRowBox
                            css={tw`flex-col items-stretch items-start w-full flex-1 min-w-0 p-2 mt-2 md:mt-0`}
                            className={activeTab === 'editor' ? 'md:flex' : '!hidden md:!flex'}
                        >
                            <div className='flex-1 flex flex-col overflow-hidden min-w-0 max-w-full w-full'>
                                <div className={cx('flex items-start md:items-center gap-2 px-2', isMobileViewport && 'flex-wrap')} style={{ minHeight: 40 }}>
                                    <FilePath className='flex-1 min-w-0'>
                                        <div className='md:hidden flex items-center gap-1 mr-2'>
                                            <button onClick={() => setActiveTab('files')} className='p-2 hover:bg-gray-500'>
                                                <svg className='w-5 h-5' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M10 19l-7-7m0 0l7-7m-7 7h18' />
                                                </svg>
                                            </button>
                                            {canUseMobileEditorModal && (
                                                <Button.Text
                                                    type='button'
                                                    onClick={() => setIsMobileEditorModalOpen(true)}
                                                    title='Expand editor'
                                                    size={Button.Sizes.Small}
                                                    shape={Button.Shapes.IconSquare}
                                                    className='bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0 flex-shrink-0'
                                                >
                                                    <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3m-18 0v3a2 2 0 002 2h3' />
                                                    </svg>
                                                </Button.Text>
                                            )}
                                        </div>
                                        <div className="flex flex-col gap-1 w-full min-w-0 md:flex-row md:items-center md:gap-2">
                                            <BreadcrumbNav
                                                currentPath={breadcrumbPath}
                                                hasUnsavedChanges={activeEditorHasUnsavedChanges}
                                                isFile={breadcrumbIsFile}
                                                onNavigate={(path) => { fileManager.setCurrentPath(path); setActiveTab('files'); }}
                                                onFileSelect={(path) => handleFileSelectWrapper(path, true, splitView.activePaneRef.current)}
                                                onDragStart={handleBreadcrumbDragStart}
                                            />
                                            {activeEditorHasUnsavedChanges && activeMediaType === 'text' && (
                                                <span className='text-yellow-400 text-xs font-semibold flex items-center gap-1'>
                                                    <span className='w-2 h-2 bg-yellow-400 rounded-full'></span>Modified
                                                </span>
                                            )}
                                            {splitView.splitView && (
                                                <span
                                                    className={cx('text-xs px-2 py-0.5 md:ml-2', splitView.activePane === 'main' ? '' : 'bg-gray-500 text-gray-500')}
                                                    style={splitView.activePane === 'main' ? { background: colors.primary.opacity(0.2), color: colors.primary.default } : {}}
                                                >
                                                    {splitView.activePane === 'main' ? 'Main' : 'Split'}
                                                </span>
                                            )}
                                        </div>
                                    </FilePath>
                                    {activeMediaType === 'text' && activeEditorFile && (
                                        <div className={cx('flex-shrink-0 min-w-0', isMobileViewport && 'w-full mt-2')}>
                                            {isMobileViewport ? (
                                                <div className='w-full'>
                                                    <FileToolbar
                                                        selectedFile={activeEditorFile}
                                                        content={activeEditorContent}
                                                        originalContent={activeEditorOriginalContent}
                                                        hasUnsavedChanges={activeEditorHasUnsavedChanges}
                                                        isSaving={fileManager.isSaving}
                                                        onSave={handleSaveWrapper}
                                                        onReset={resetCurrentEditorContent}
                                                        onContentUpdate={updateCurrentEditorContent}
                                                        canPreviewMarkdown={canPreviewMarkdown}
                                                        markdownPreviewVisible={showActiveMarkdownPreview}
                                                        onToggleMarkdownPreview={() => setShowMarkdownPreview((visible) => !visible)}
                                                        compact
                                                    />
                                                </div>
                                            ) : (
                                                <FileToolbar
                                                    selectedFile={activeEditorFile}
                                                    content={activeEditorContent}
                                                    originalContent={activeEditorOriginalContent}
                                                    hasUnsavedChanges={activeEditorHasUnsavedChanges}
                                                    isSaving={fileManager.isSaving}
                                                    onSave={handleSaveWrapper}
                                                    onReset={resetCurrentEditorContent}
                                                    onContentUpdate={updateCurrentEditorContent}
                                                    canPreviewMarkdown={canPreviewMarkdown}
                                                    markdownPreviewVisible={showActiveMarkdownPreview}
                                                    onToggleMarkdownPreview={() => setShowMarkdownPreview((visible) => !visible)}
                                                />
                                            )}
                                        </div>
                                    )}
                                    {!isMobileViewport && (
                                        <div className='flex items-center gap-2 flex-shrink-0'>
                                            <Button.Text
                                                type='button'
                                                onClick={toggleFullscreen}
                                                title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
                                                size={Button.Sizes.Small}
                                                shape={Button.Shapes.IconSquare}
                                                className='bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0'
                                            >
                                                <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                    {isFullscreen ? (
                                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9h4.5M15 9V4.5M15 9l5.25-5.25M15 15h4.5M15 15v4.5m0-4.5l5.25 5.25' />
                                                    ) : (
                                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4' />
                                                    )}
                                                </svg>
                                            </Button.Text>
                                            {canUseFullscreenEditor && (
                                                <Button.Text
                                                    type='button'
                                                    onClick={openPopoutEditor}
                                                    title='Pop Out Editor'
                                                    size={Button.Sizes.Small}
                                                    shape={Button.Shapes.IconSquare}
                                                    className='bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0'
                                                >
                                                    <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14' />
                                                    </svg>
                                                </Button.Text>
                                            )}
                                            {trashCleanupSettings?.git_enabled && (
                                                <Button.Text
                                                    type='button'
                                                    onClick={() => setShowGitPanel(true)}
                                                    title='Git'
                                                    size={Button.Sizes.Small}
                                                    shape={Button.Shapes.IconSquare}
                                                    className='bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0'
                                                >
                                                    <CodeIcon className='w-4 h-4' />
                                                </Button.Text>
                                            )}
                                            <Button.Text
                                                type='button'
                                                onClick={() => trashTriggerRef.current?.()}
                                                title='Trash Bin'
                                                size={Button.Sizes.Small}
                                                shape={Button.Shapes.IconSquare}
                                                className='bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0'
                                            >
                                                <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16' />
                                                </svg>
                                            </Button.Text>
                                            <Button.Text
                                                ref={historyButtonRef}
                                                type='button'
                                                onClick={(e) => {
                                                    const next = !showHistoryDropdown;
                                                    if (next) {
                                                        updateHistoryDropdownPosition(e.currentTarget as HTMLElement);
                                                    }
                                                    setShowHistoryDropdown(next);
                                                }}
                                                title='Recently Edited Files'
                                                size={Button.Sizes.Small}
                                                shape={Button.Shapes.IconSquare}
                                                className={cx(
                                                    'bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0',
                                                    showHistoryDropdown && 'bg-gray-600/60'
                                                )}
                                            >
                                                <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' />
                                                </svg>
                                            </Button.Text>
                                            <Button.Text
                                                type='button'
                                                onClick={() => setShowSettingsModal(true)}
                                                title='File Manager Settings'
                                                size={Button.Sizes.Small}
                                                shape={Button.Shapes.IconSquare}
                                                className='bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60 border-0'
                                            >
                                                <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' />
                                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 12a3 3 0 11-6 0 3 3 0 016 0z' />
                                                </svg>
                                            </Button.Text>
                                        </div>
                                    )}
                                </div>

                                {fileManager.fileLoading ? (
                                    <EmptyState data-split-drop-zone data-pane='empty'>
                                        <Spinner size='large' />
                                        <p className='text-sm text-neutral-300 mt-4'>Loading file...</p>
                                    </EmptyState>
                                ) : fileManager.selectedFile ? (
                                    <>
                                        <EditorHeader className={cx('overflow-x-auto overflow-y-hidden', isMobileViewport && 'mt-2')}>
                                            <EditorTabs
                                                openFiles={fileManager.openFiles}
                                                activeMainFilePath={fileManager.selectedFile}
                                                activeSplitFilePath={splitView.splitFilePath}
                                                activePane={splitView.activePane}
                                                splitView={splitView.splitView}
                                                onTabClick={handleTabClick}
                                                onTabClose={handleTabClose}
                                                onCloseAll={handleCloseAllTabs}
                                                onTabDragStart={handleTabDragStart}
                                                disableDrag={isMobileViewport}
                                                chrome={false}
                                                connected
                                                className='flex-1 min-w-0'
                                            />
                                        </EditorHeader>

                                        <SplitViewContainer ref={splitView.splitContainerRef} className='mt-2'>
                                            <SplitEditorPane
                                                ref={splitView.mainPaneRef}
                                                data-split-drop-zone
                                                data-pane='main'
                                                style={{
                                                    flex: splitView.splitView ? `0 0 ${splitView.leftPaneWidth}%` : '1 1 auto',
                                                    maxWidth: splitView.splitView ? `${splitView.leftPaneWidth}%` : '100%',
                                                    willChange: splitView.isSplitResizing ? 'flex-basis, width' : undefined,
                                                }}
                                                isDragOver={isDraggingToSplit}
                                                onMouseDownCapture={() => splitView.setActivePaneState('main')}
                                                onFocusCapture={() => splitView.setActivePaneState('main')}
                                                onDragEnter={(e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); if (!splitView.splitView && isFileDragActive && !isDraggingToSplit) setIsDraggingToSplit(true); }}
                                                onDragOver={(e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); if (!splitView.splitView && isFileDragActive && !isDraggingToSplit) setIsDraggingToSplit(true); }}
                                                onDragLeave={(e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); if (isFileDragActive) return; if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsDraggingToSplit(false); }}
                                                onDrop={(e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setIsDraggingToSplit(false); if (!splitView.splitView) handleSplitDrop(e); }}
                                            >
                                                {splitView.splitView && (
                                                    <div className='px-2 pt-1.5 pb-2'>
                                                        <SplitPaneHeader active={splitView.activePane === 'main'} onClick={() => splitView.setActivePaneState('main')}>
                                                            <SplitPaneHeaderLeft>
                                                                <PaneBadge active={splitView.activePane === 'main'}>Main</PaneBadge>
                                                                <SplitPaneTitle active={splitView.activePane === 'main'}>{fileManager.selectedFile?.split('/').pop() || 'No file'}</SplitPaneTitle>
                                                            </SplitPaneHeaderLeft>
                                                            {hasUnsavedChanges && <PaneBadge active>Modified</PaneBadge>}
                                                        </SplitPaneHeader>
                                                    </div>
                                                )}
                                                {mediaType === 'text' ? (
                                                    <>
                                                        <EditorWithMarkdownPreview
                                                            showPreview={showMainMarkdownPreview}
                                                            content={activeFileContent}
                                                            filePath={fileManager.selectedFile!}
                                                        >
                                                            <SimpleEditor
                                                                ref={mainEditorRef}
                                                                value={activeFileContent}
                                                                onChange={updateActiveFileContent}
                                                                filePath={fileManager.selectedFile}
                                                                readOnly={fileManager.isSaving}
                                                                onSave={handleSaveWrapper}
                                                                foldRanges={activeFile?.foldRanges}
                                                                onFileDrop={(path: string) => {
                                                                    if (!splitView.splitView && path !== fileManager.selectedFile) handleSplitDrop({ preventDefault: () => {}, dataTransfer: { getData: () => path } } as any);
                                                                    else if (splitView.splitView) handleMainPaneDrop({ preventDefault: () => {}, dataTransfer: { getData: () => path } } as any);
                                                                }}
                                                                onFocus={() => splitView.setActivePaneState('main')}
                                                            />
                                                        </EditorWithMarkdownPreview>
                                                        {isFileDragActive && (
                                                            <div
                                                                className='absolute inset-0 z-10'
                                                                style={{ background: 'transparent' }}
                                                                onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); if (!splitView.splitView && !isDraggingToSplit) setIsDraggingToSplit(true); }}
                                                                onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); if (!splitView.splitView && !isDraggingToSplit) setIsDraggingToSplit(true); }}
                                                                onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); if (isFileDragActive) return; if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsDraggingToSplit(false); }}
                                                                onDrop={(e) => { e.preventDefault(); e.stopPropagation(); setIsDraggingToSplit(false); setIsFileDragActive(false); if (splitView.splitView) handleMainPaneDrop(e); else handleSplitDrop(e); }}
                                                            />
                                                        )}
                                                    </>
                                                ) : (
                                                    <div className='flex-1 flex flex-col min-h-0 overflow-y-auto'>
                                                        <MediaViewer uuid={uuid} filePath={fileManager.selectedFile} fileType={mediaType as 'image' | 'video' | 'audio'} />
                                                    </div>
                                                )}
                                                {!splitView.splitView && isDraggingToSplit && (
                                                    <SplitDropZone isDragOver onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); e.dataTransfer.dropEffect = 'copy'; }} onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); if (isFileDragActive) return; if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsDraggingToSplit(false); }} onDrop={(e) => { e.preventDefault(); e.stopPropagation(); setIsDraggingToSplit(false); handleSplitDrop(e); }}>
                                                        <div className='text-center p-6 border-2 border-dashed bg-gray-700 pointer-events-none' style={{ borderColor: colors.primary.default }}>
                                                            <svg className='w-12 h-12 mx-auto mb-3' style={{ color: colors.primary.default }} fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 00-2-2h-2a2 2 0 00-2 2' />
                                                            </svg>
                                                            <p className='font-medium' style={{ color: colors.primary.default }}>Drop here to open in split view</p>
                                                        </div>
                                                    </SplitDropZone>
                                                )}
                                            </SplitEditorPane>

                                            {splitView.splitView && splitView.splitFilePath && (
                                                <>
                                                    <SplitDivider onMouseDown={splitView.handleSplitResizeStart} />
                                                    <SplitEditorPane
                                                        ref={splitView.splitPaneRef}
                                                        data-split-drop-zone
                                                        data-pane='split'
                                                        style={{ flex: `0 0 ${100 - splitView.leftPaneWidth}%`, maxWidth: `${100 - splitView.leftPaneWidth}%`, willChange: splitView.isSplitResizing ? 'flex-basis, width' : undefined }}
                                                        onMouseDownCapture={() => splitView.setActivePaneState('split')}
                                                        onFocusCapture={() => splitView.setActivePaneState('split')}
                                                    >
                                                        <SplitCloseButton onClick={splitView.closeSplitView} title='Close split view'>
                                                            <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M6 18L18 6M6 6l12 12' />
                                                            </svg>
                                                        </SplitCloseButton>
                                                        <div className='px-2 pt-1.5 pb-2'>
                                                            <SplitPaneHeader active={splitView.activePane === 'split'} onClick={() => splitView.setActivePaneState('split')}>
                                                                <SplitPaneHeaderLeft>
                                                                    <PaneBadge active={splitView.activePane === 'split'}>Split</PaneBadge>
                                                                    <SplitPaneTitle active={splitView.activePane === 'split'}>{splitView.splitFilePath.split('/').pop()}</SplitPaneTitle>
                                                                </SplitPaneHeaderLeft>
                                                                {splitHasUnsavedChanges && <PaneBadge active>Modified</PaneBadge>}
                                                            </SplitPaneHeader>
                                                        </div>
                                                        {splitMediaType === 'text' ? (
                                                            <>
                                                                <EditorWithMarkdownPreview
                                                                    showPreview={showSplitMarkdownPreview}
                                                                    content={splitFileContent}
                                                                    filePath={splitView.splitFilePath!}
                                                                >
                                                                    <SimpleEditor
                                                                        ref={splitEditorRef}
                                                                        value={splitFileContent}
                                                                        onChange={updateSplitFileContent}
                                                                        filePath={splitView.splitFilePath}
                                                                        readOnly={fileManager.isSaving}
                                                                        onSave={handleSaveWrapper}
                                                                        foldRanges={splitFile?.foldRanges}
                                                                        onFileDrop={(path: string) => {
                                                                            if (path && path !== splitView.splitFilePath) {
                                                                                const existingFile = fileManager.openFilesRef.current.find((f) => f.path === path);
                                                                                if (existingFile) splitView.setSplitFilePath(path);
                                                                                else getFileContents(uuid, path).then((content) => {
                                                                                    const name = path.substring(path.lastIndexOf('/') + 1);
                                                                                    const newFile: OpenFile = { path, name, content, originalContent: content, hasUnsavedChanges: false };
                                                                                    const updatedFiles = [...fileManager.openFilesRef.current, newFile];
                                                                                    fileManager.openFilesRef.current = updatedFiles;
                                                                                    fileManager.setOpenFiles(updatedFiles);
                                                                                    splitView.setSplitFilePath(path);
                                                                                }).catch((error) => clearAndAddHttpError(error as Error));
                                                                            }
                                                                        }}
                                                                        onFocus={() => splitView.setActivePaneState('split')}
                                                                    />
                                                                </EditorWithMarkdownPreview>
                                                                {isFileDragActive && (
                                                                    <div
                                                                        className='absolute inset-0 z-10'
                                                                        style={{ background: 'transparent', top: '40px' }}
                                                                        onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                                                        onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                                                        onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                                                        onDrop={(e) => {
                                                                            e.preventDefault();
                                                                            e.stopPropagation();
                                                                            setIsFileDragActive(false);
                                                                            const path = e.dataTransfer.getData('text/plain');
                                                                            if (path && path !== splitView.splitFilePath) {
                                                                                const existingFile = fileManager.openFilesRef.current.find((f) => f.path === path);
                                                                                if (existingFile) splitView.setSplitFilePath(path);
                                                                                else getFileContents(uuid, path).then((content) => {
                                                                                    const name = path.substring(path.lastIndexOf('/') + 1);
                                                                                    const newFile: OpenFile = { path, name, content, originalContent: content, hasUnsavedChanges: false };
                                                                                    const updatedFiles = [...fileManager.openFilesRef.current, newFile];
                                                                                    fileManager.openFilesRef.current = updatedFiles;
                                                                                    fileManager.setOpenFiles(updatedFiles);
                                                                                    splitView.setSplitFilePath(path);
                                                                                }).catch((error) => clearAndAddHttpError(error as Error));
                                                                            }
                                                                        }}
                                                                    />
                                                                )}
                                                            </>
                                                        ) : (
                                                            <div className='flex-1 flex flex-col min-h-0 overflow-y-auto'>
                                                                <MediaViewer uuid={uuid} filePath={splitView.splitFilePath} fileType={splitMediaType as 'image' | 'video' | 'audio'} />
                                                            </div>
                                                        )}
                                                    </SplitEditorPane>
                                                </>
                                            )}
                                        </SplitViewContainer>
                                    </>
                                ) : (
                                    <div
                                        className='flex-1 flex items-center justify-center relative'
                                        data-split-drop-zone
                                        data-pane='empty'
                                        onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                        onDrop={(e) => { const path = resolveDropPath(e); if (path) openFileInMainPane(path); }}
                                    >
                                        {isDraggingToEdit && (
                                            <SplitDropZone isDragOver>
                                                <div className='text-center p-6 border-2 border-dashed bg-gray-700 pointer-events-none' style={{ borderColor: colors.primary.default }}>
                                                    <svg className='w-12 h-12 mx-auto mb-3' style={{ color: colors.primary.default }} fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 00-2-2h-2a2 2 0 00-2 2' />
                                                    </svg>
                                                    <p className='font-medium' style={{ color: colors.primary.default }}>Drop file to edit</p>
                                                </div>
                                            </SplitDropZone>
                                        )}
                                        <EmptyState>
                                            <svg className='w-20 h-20 mb-6 text-neutral-300' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={1.5} d='M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z' />
                                            </svg>
                                            <p className='text-xl font-semibold mb-2 text-neutral-300'>No File Selected</p>
                                            <p className='text-sm text-neutral-300 text-center'>Choose a file from the tree to begin editing</p>
                                            <button onClick={() => setActiveTab('files')} className='mt-4 md:hidden px-4 py-2 text-neutral-300 transition-opacity hover:opacity-90' style={{ backgroundColor: colors.primary.default }}>Browse Files</button>
                                        </EmptyState>
                                    </div>
                                )}
                            </div>
                        </GreyRowBox>
                    </Container>
                </PageContainer>

                <CreateFileModal visible={showNewFileModal} onDismiss={() => setShowNewFileModal(false)} directories={createFileTargetPaths} onFileCreated={async () => { await fileManager.refreshDirectories(createFileTargetPaths); fileManager.setSelectedFile(null); fileManager.setFileContent(''); fileManager.setOriginalContent(''); clearFlashes(); }} />
                <CreateFolderModal visible={showNewFolderModal} onDismiss={() => setShowNewFolderModal(false)} directories={createFolderTargetPaths} onFolderCreated={async () => { await fileManager.refreshDirectories(createFolderTargetPaths); clearFlashes(); }} />
                <PullUrlModal visible={showPullUrlModal} onDismiss={() => setShowPullUrlModal(false)} directories={pullUrlTargetPaths} onPullComplete={async () => { await fileManager.refreshDirectories(pullUrlTargetPaths); clearFlashes(); }} />
                <PropertiesModal visible={showPropertiesModal} onDismiss={() => { setShowPropertiesModal(false); setPropertiesTargetPaths([]); }} entries={propertiesEntries} />

                <Dialog.Confirm open={showMassDeleteConfirm} onClose={() => setShowMassDeleteConfirm(false)} title='Delete Files Permanently' confirm='Delete Forever' onConfirmed={confirmMassDelete}>
                    Are you sure you want to <strong>permanently delete</strong> {fileSelection.selectedFiles.length} file{fileSelection.selectedFiles.length > 1 ? 's' : ''}? This action cannot be undone.
                </Dialog.Confirm>

                <Dialog.Confirm open={showMassMoveToTrashConfirm} onClose={() => setShowMassMoveToTrashConfirm(false)} title='Move to Trash' confirm='Move to Trash' onConfirmed={confirmMassMoveToTrash}>
                    Move {fileSelection.selectedFiles.length} file{fileSelection.selectedFiles.length > 1 ? 's' : ''} to trash? You can restore them later from the trash bin.
                </Dialog.Confirm>

                <Dialog.Confirm open={showUnarchiveConfirm} onClose={() => setShowUnarchiveConfirm(false)} title='Extract Archive' confirm='Extract' onConfirmed={confirmUnarchive}>
                    Extract <Code>{unarchiveTargetPath?.split('/').pop() || 'archive'}</Code> to the current directory? This may overwrite existing files.
                </Dialog.Confirm>

                <DirectoryPicker open={showMoveModal} onClose={() => setShowMoveModal(false)} onConfirm={confirmMassMove} fileTree={fileManager.fileTree} currentPath={fileManager.currentPath} defaultPath={fileSelection.getActionFallbackPath()} title={`Move ${fileSelection.selectedFiles.length} file${fileSelection.selectedFiles.length > 1 ? 's' : ''}`} onLoadDirectory={fileManager.loadDirectory} />

                {showMassPermissionsModal && fileSelection.selectedFiles.length > 0 && (
                    <PermissionsModal
                        visible={showMassPermissionsModal}
                        onDismiss={() => setShowMassPermissionsModal(false)}
                        files={fileSelection.selectedFiles}
                        onPermissionsChanged={async () => {
                            const grouped = groupByDirectory(fileSelection.selectedFiles);
                            const directoriesToRefresh = Array.from(new Set([fileManager.currentPath, ...grouped.keys()]));
                            await Promise.all(directoriesToRefresh.map((dir) => fileManager.loadDirectory(dir)));
                            setShowMassPermissionsModal(false);
                            fileSelection.clearSelection();
                            addFlash({ type: 'success', message: `Permissions updated for ${fileSelection.selectedFiles.length} item${fileSelection.selectedFiles.length > 1 ? 's' : ''}` });
                        }}
                    />
                )}

                <Dialog.Confirm open={showUnsavedModal} onClose={handleCancelCloseUnsaved} title='Unsaved Changes' confirm='Discard Changes' onConfirmed={handleConfirmCloseUnsaved}>
                    {pendingCloseAllTabs ? (
                        <>
                            <p className='text-neutral-300'>
                                Some open tabs have unsaved changes.
                            </p>
                            <p className='text-neutral-300 mt-2'>
                                Are you sure you want to close all tabs? All unsaved changes will be lost.
                            </p>
                        </>
                    ) : (
                        <>
                            <p className='text-neutral-300'>The file <Code>{pendingCloseTabPath?.split('/').pop() || 'file'}</Code> has unsaved changes.</p>
                            <p className='text-neutral-300 mt-2'>Are you sure you want to close it? All unsaved changes will be lost.</p>
                        </>
                    )}
                </Dialog.Confirm>

                <SettingsDialog
                    open={showSettingsModal}
                    onClose={() => setShowSettingsModal(false)}
                    viewMode={viewMode}
                    onViewModeChange={(mode) => viewModeChangeRef.current?.(mode)}
                    canConfigureTrash={canConfigureTrash}
                    trashCleanupSettings={trashCleanupSettings}
                    onSaveTrashSettings={handleSaveTrashSettings}
                />

                {trashCleanupSettings?.git_enabled && (
                    <Suspense fallback={null}>
                        <GitPanel
                            open={showGitPanel}
                            onClose={() => setShowGitPanel(false)}
                            uuid={uuid}
                            workDir={fileManager.currentPath}
                            onFilesChanged={() => fileManager.loadDirectory(fileManager.currentPath)}
                        />
                    </Suspense>
                )}
            </div>
        </ServerContentBlock>
    );
};

export default BetterFileManagerContainer;
