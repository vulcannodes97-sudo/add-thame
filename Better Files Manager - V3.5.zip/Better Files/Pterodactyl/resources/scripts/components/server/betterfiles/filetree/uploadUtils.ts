import type React from 'react';
import { createFolder } from '@/api/server/files';
import { type FolderFile } from './dragUtils';

export interface UploadProgress {
    name: string;
    loaded: number;
    total: number;
    controller: AbortController;
    targetPath: string;
}

interface UploadHandlersParams {
    uuid: string;
    setUploads: React.Dispatch<React.SetStateAction<Map<string, UploadProgress>>>;
    setShowUploadModal: React.Dispatch<React.SetStateAction<boolean>>;
    onDirectoryLoad: (path: string) => Promise<unknown>;
    addFlash: (payload: { key: string; type: 'success' | 'warning' | 'error' | 'info'; message: string }) => void;
    onError: (error: Error) => void;
}

export const createUploadHandlers = ({
    uuid,
    setUploads,
    setShowUploadModal,
    onDirectoryLoad,
    addFlash,
    onError,
}: UploadHandlersParams) => {
    const uploadFilesWithPaths = async (folderFiles: FolderFile[], targetPath: string) => {
        const foldersToCreate = new Set<string>();
        folderFiles.forEach((ff) => {
            const parts = ff.relativePath.split('/');
            let current = '';
            for (let i = 0; i < parts.length - 1; i++) {
                current = current ? `${current}/${parts[i]}` : parts[i];
                foldersToCreate.add(current);
            }
        });

        try {
            const getFileUploadUrl = (await import('@/api/server/files/getFileUploadUrl')).default;
            const axios = (await import('axios')).default;

            setShowUploadModal(true);

            const sortedFolders = Array.from(foldersToCreate).sort((a, b) => a.split('/').length - b.split('/').length);
            for (const folder of sortedFolders) {
                const folderPath = targetPath === '/' ? `/${folder}` : `${targetPath}/${folder}`;
                const parentDir = folderPath.substring(0, folderPath.lastIndexOf('/')) || '/';
                const folderName = folderPath.substring(folderPath.lastIndexOf('/') + 1);
                try {
                    await createFolder(uuid, parentDir, folderName);
                } catch {
                }
            }

            const uploadPromises = folderFiles.map((ff) => {
                const controller = new AbortController();
                const uploadDir = ff.relativePath.includes('/')
                    ? (targetPath === '/'
                        ? '/' + ff.relativePath.substring(0, ff.relativePath.lastIndexOf('/'))
                        : `${targetPath}/${ff.relativePath.substring(0, ff.relativePath.lastIndexOf('/'))}`)
                    : targetPath;
                const uploadKey = `${targetPath}/${ff.relativePath}`;

                setUploads((prev) => {
                    const updated = new Map(prev);
                    updated.set(uploadKey, {
                        name: ff.relativePath,
                        loaded: 0,
                        total: ff.file.size,
                        controller,
                        targetPath: uploadDir,
                    });
                    return updated;
                });

                return () =>
                    getFileUploadUrl(uuid).then((uploadUrl) => {
                        const formData = new FormData();
                        formData.append('files', ff.file, ff.file.name);
                        return axios
                            .post(uploadUrl, formData, {
                                headers: { 'Content-Type': 'multipart/form-data' },
                                params: { directory: uploadDir },
                                signal: controller.signal,
                                onUploadProgress: (progressEvent) => {
                                    setUploads((prev) => {
                                        const updated = new Map(prev);
                                        const upload = updated.get(uploadKey);
                                        if (upload) {
                                            upload.loaded = progressEvent.loaded || 0;
                                            updated.set(uploadKey, upload);
                                        }
                                        return updated;
                                    });
                                },
                            })
                            .then(() => {
                                setTimeout(() => {
                                    setUploads((prev) => {
                                        const updated = new Map(prev);
                                        updated.delete(uploadKey);
                                        return updated;
                                    });
                                }, 1000);
                            })
                            .catch((error: any) => {
                                if (error.name !== 'CanceledError') {
                                    onError(error as Error);
                                }
                                setUploads((prev) => {
                                    const updated = new Map(prev);
                                    updated.delete(uploadKey);
                                    return updated;
                                });
                            });
                    });
            });

            await Promise.all(uploadPromises.map((fn) => fn()));
            await onDirectoryLoad(targetPath);

            for (const folder of sortedFolders) {
                const folderPath = targetPath === '/' ? `/${folder.split('/')[0]}` : `${targetPath}/${folder.split('/')[0]}`;
                if (folderPath !== targetPath) {
                    await onDirectoryLoad(folderPath);
                }
            }
        } catch (error) {
            onError(error as Error);
        }
    };

    const uploadFiles = async (files: File[], targetPath: string) => {
        const folderFiles: FolderFile[] = files.map((f) => ({ file: f, relativePath: f.name }));
        await uploadFilesWithPaths(folderFiles, targetPath);
    };

    const uploadFoldersWithNotice = async (folderFiles: FolderFile[], targetPath: string, hasFolders: boolean) => {
        if (hasFolders) {
            addFlash({
                key: 'folder-upload',
                type: 'info',
                message: `Uploading folder with ${folderFiles.length} file(s)...`,
            });
        }
        await uploadFilesWithPaths(folderFiles, targetPath);
    };

    return {
        uploadFilesWithPaths,
        uploadFiles,
        uploadFoldersWithNotice,
    };
};
