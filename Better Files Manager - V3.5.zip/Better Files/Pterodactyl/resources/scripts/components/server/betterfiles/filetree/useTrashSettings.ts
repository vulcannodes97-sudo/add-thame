import { useCallback, useEffect, useRef, useState } from 'react';
import { getTrashCleanupSettings, getTrashContents, updateTrashCleanupSettings, type TrashCleanupSettings } from '@/api/server/files/betterFilesApi';

interface Options {
    uuid: string;
    trashRefreshNonce?: number;
    clearAndAddHttpError: (error: Error) => void;
    addFlash: (args: { key: string; type: 'success' | 'error'; message: string }) => void;
    onRegisterTrashTrigger?: (fn: (() => void) | null) => void;
    onRegisterTrashSettingsTrigger?: (fn: (() => void) | null) => void;
    onRegisterTrashCleanupState?: (settings: TrashCleanupSettings | null, onSave: (values: { trash_cleanup_enabled: boolean; trash_retention_days: number; trash_retention_unit: 'days' | 'hours' }) => Promise<void>, canConfigure: boolean) => void;
    setShowTrashBinModal: (value: boolean) => void;
    setShowTrashCleanupModal: (value: boolean) => void;
}

export const useTrashSettings = ({
    uuid,
    trashRefreshNonce,
    clearAndAddHttpError,
    addFlash,
    onRegisterTrashTrigger,
    onRegisterTrashSettingsTrigger,
    onRegisterTrashCleanupState,
    setShowTrashBinModal,
    setShowTrashCleanupModal,
}: Options) => {
    const [trashCleanupSettings, setTrashCleanupSettings] = useState<TrashCleanupSettings | null>(null);
    const [, setTrashCount] = useState(0);
    const errorHandlerRef = useRef(clearAndAddHttpError);

    useEffect(() => {
        errorHandlerRef.current = clearAndAddHttpError;
    }, [clearAndAddHttpError]);

    const loadTrashCleanupSettings = useCallback(async () => {
        try {
            const settings = await getTrashCleanupSettings(uuid);
            setTrashCleanupSettings(settings);
        } catch (error) {
            errorHandlerRef.current(error as Error);
        }
    }, [uuid]);

    useEffect(() => {
        loadTrashCleanupSettings();
    }, [loadTrashCleanupSettings]);

    const refreshTrashCount = useCallback(async () => {
        try {
            const files = await getTrashContents(uuid);
            setTrashCount(files.length);
        } catch (error) {
            errorHandlerRef.current(error as Error);
        }
    }, [uuid]);

    useEffect(() => {
        refreshTrashCount();
    }, [refreshTrashCount]);

    useEffect(() => {
        if (typeof trashRefreshNonce === 'number') {
            refreshTrashCount();
        }
    }, [trashRefreshNonce, refreshTrashCount]);

    const canConfigureTrashCleanup = !!trashCleanupSettings?.allow_user_override && !!trashCleanupSettings?.global_enabled;
    const canSearchContents = !!trashCleanupSettings?.content_search_enabled;

    const handleTrashCleanupSave = async (values: { trash_cleanup_enabled: boolean; trash_retention_days: number; trash_retention_unit: 'days' | 'hours' }) => {
        try {
            const updated = await updateTrashCleanupSettings(uuid, values);
            setTrashCleanupSettings(updated);
            addFlash({
                key: 'better-files',
                type: 'success',
                message: 'Trash cleanup settings updated.',
            });
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    };

    useEffect(() => {
        if (!onRegisterTrashTrigger) return;
        onRegisterTrashTrigger(() => {
            setShowTrashBinModal(true);
        });
        return () => {
            onRegisterTrashTrigger(null);
        };
    }, [onRegisterTrashTrigger, setShowTrashBinModal]);

    useEffect(() => {
        if (!onRegisterTrashSettingsTrigger) return;
        if (canConfigureTrashCleanup) {
            onRegisterTrashSettingsTrigger(() => {
                setShowTrashCleanupModal(true);
            });
        } else {
            onRegisterTrashSettingsTrigger(null);
        }
        return () => {
            onRegisterTrashSettingsTrigger(null);
        };
    }, [canConfigureTrashCleanup, onRegisterTrashSettingsTrigger, setShowTrashCleanupModal]);

    useEffect(() => {
        if (!onRegisterTrashCleanupState) return;
        onRegisterTrashCleanupState(trashCleanupSettings, handleTrashCleanupSave, canConfigureTrashCleanup);
    }, [onRegisterTrashCleanupState, trashCleanupSettings, canConfigureTrashCleanup]);

    return {
        trashCleanupSettings,
        setTrashCleanupSettings,
        canConfigureTrashCleanup,
        canSearchContents,
        refreshTrashCount,
        handleTrashCleanupSave,
    };
};
