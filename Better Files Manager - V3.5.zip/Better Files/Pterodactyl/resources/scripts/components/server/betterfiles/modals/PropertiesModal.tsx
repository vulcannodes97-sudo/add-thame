import React from 'react';
import { Dialog } from '@/components/elements/dialog';
import { Button } from '@/components/elements/button';
import Code from '@/components/elements/Code';
import FileTypeBadge from '../FileTypeBadge';
import { FileObject } from '@/api/server/files';
import GreyRowBox from '@/components/elements/GreyRowBox';

interface Props {
    visible: boolean;
    onDismiss: () => void;
    entries: Array<{
        path: string;
        file?: FileObject;
    }>;
}

const formatSize = (bytes?: number, isFile?: boolean): string => {
    if (!isFile || bytes === undefined || bytes === null) return '-';
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${Math.round(bytes / Math.pow(k, i) * 100) / 100} ${sizes[i]}`;
};

const formatDate = (value?: Date | string | null): string => {
    if (!value) return '—';
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime())) return '—';
    return date.toLocaleString();
};

const Row: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
    <div className="grid grid-cols-[120px_1fr] gap-3 items-start">
        <div className="text-[11px] uppercase tracking-widest text-neutral-400">{label}</div>
        <div className="text-sm text-neutral-200 break-all">{value}</div>
    </div>
);

const PropertiesModal: React.FC<Props> = ({ visible, onDismiss, entries }) => {
    const safeEntries = entries.filter(entry => entry.path);
    const titleSuffix = safeEntries.length > 1 ? ` (${safeEntries.length})` : '';

    return (
        <Dialog open={visible} onClose={onDismiss} title={`Properties${titleSuffix}`}>
            <GreyRowBox
                className="betterfiles-scope w-full flex flex-col items-start"
                $hoverable={false}
                onMouseDown={(e) => e.stopPropagation()}
                onClick={(e) => e.stopPropagation()}
            >
                {safeEntries.length === 0 ? (
                    <div className="text-sm text-neutral-300">No items selected.</div>
                ) : (
                    <div className="max-h-[60vh] overflow-y-auto pr-1 -mr-1">
                        <div className="grid gap-4">
                            {safeEntries.map((entry) => {
                                const file = entry.file;
                                const names = (file?.name ?? entry.path.split('/').pop()) || entry.path;
                                const isFile = file?.isFile ?? false;
                                const typeLabel = file ? (file.isFile ? 'File' : 'Folder') : 'Item';
                                const modeLabel = file?.mode ? `${file.mode}${file.modeBits ? ` (${file.modeBits})` : ''}` : '-';
                                return (
                                    <div
                                        key={entry.path}
                                        className="border border-gray-600 bg-gray-700 p-4 shadow-sm"
                                        
                                    >
                                        <div className="flex items-center justify-between gap-3 mb-4">
                                            <div className="flex items-center gap-3 min-w-0">
                                                <FileTypeBadge filename={names} isFolder={!isFile} />
                                                <div className="min-w-0">
                                                    <div className="text-base font-semibold text-neutral-200 truncate">{names}</div>
                                                    <div className="text-xs text-neutral-400">{typeLabel}</div>
                                                </div>
                                            </div>
                                            <span
                                                className="text-[11px] uppercase tracking-widest text-neutral-400 border border-gray-600 px-2 py-0.5"
                                                
                                            >
                                                {isFile ? 'File' : 'Folder'}
                                            </span>
                                        </div>

                                        <div className="grid gap-3">
                                            <Row label="Path" value={entry.path ? <Code>{entry.path}</Code> : '-'} />
                                            <Row label="Size" value={formatSize(file?.size, file?.isFile)} />
                                            <Row label="Permissions" value={modeLabel} />
                                            <Row label="MIME Type" value={file?.mimetype || '-'} />
                                            <Row label="Symlink" value={file?.isSymlink ? 'Yes' : 'No'} />
                                            <Row label="Created" value={formatDate(file?.createdAt)} />
                                            <Row label="Modified" value={formatDate(file?.modifiedAt)} />
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                <Dialog.Footer>
                    <Button.Text onClick={onDismiss}>Close</Button.Text>
                </Dialog.Footer>
            </GreyRowBox>
        </Dialog>
    );
};

export default PropertiesModal;
