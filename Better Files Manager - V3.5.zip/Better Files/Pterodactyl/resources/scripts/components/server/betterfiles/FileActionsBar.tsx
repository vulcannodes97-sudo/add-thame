import React from 'react';
import { colors } from './colors';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { Button } from '@/components/elements/button';

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement>;
type DivProps = React.HTMLAttributes<HTMLDivElement>;
type SpanProps = React.HTMLAttributes<HTMLSpanElement>;
type SelectProps = React.SelectHTMLAttributes<HTMLSelectElement>;

const ActionsBar: React.FC<DivProps> = ({ className, ...props }) => (
    <GreyRowBox
        className={cx(
            'bg-gray-600 p-1 sm:p-2 relative z-30',
            className
        )}
        $hoverable={false}
        {...props}
    />
);

const Group: React.FC<DivProps> = ({ className, ...props }) => (
    <div className={cx('flex items-center gap-1 flex-wrap justify-center sm:justify-start sm:gap-1.5', className)} {...props} />
);

const GridGroup: React.FC<DivProps> = ({ className, ...props }) => (
    <div
        className={cx(
            'grid grid-cols-4 gap-1',
            'sm:flex sm:flex-wrap sm:items-center sm:gap-1.5 sm:justify-start',
            className
        )}
        {...props}
    />
);

const ActionButton: React.FC<ButtonProps & { label: string }> = ({
    label,
    className,
    children,
    style,
    type = 'button',
    onClick,
    ...props
}) => (
    <Button.Text
        type={type}
        size={Button.Sizes.Small}
        className={cx(
            'px-1 py-0.5 text-[0.65rem] min-h-[22px] min-w-[24px] w-full justify-center',
            'bg-transparent text-neutral-300 hover:bg-gray-600/60 active:bg-gray-600/60',
            'transition-all font-medium',
            'flex items-center gap-1 whitespace-nowrap [&>span]:sr-only',
            'border-0',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            'sm:px-2 sm:py-1 sm:min-h-[26px] sm:text-[0.7rem] sm:w-auto sm:justify-start',
            className
        )}
        style={style}
        onClick={(e) => {
            e.preventDefault();
            onClick?.(e);
        }}
        title={props.title ?? label}
        aria-label={props['aria-label'] ?? label}
        {...props}
    >
        {children}
        <span>{label}</span>
    </Button.Text>
);

const SelectInfo: React.FC<SpanProps> = ({ className, children, style, ...props }) => (
    <GreyRowBox
        className={cx(
            'text-[0.68rem] font-semibold px-1.5 py-0.5 min-h-[22px]',
            'bg-gray-600/60 text-neutral-300',
            'border-0',
            'flex items-center whitespace-nowrap',
            'sm:px-2.5 sm:py-1.5 sm:min-h-[32px] sm:text-xs',
            className
        )}
        $hoverable={false}
        style={style}
        {...props}
    >
        {children}
    </GreyRowBox>
);

const SortSelect: React.FC<SelectProps> = ({ className, style, ...props }) => (
    <select
        className={cx(
            'px-2.5 py-1.5 text-xs min-h-[32px]',
            'bg-gray-500 hover:bg-gray-600 text-neutral-300',
            'transition-colors border border-gray-500 hover:border-gray-300',
            'cursor-pointer appearance-none bg-no-repeat bg-right',
            'focus:outline-none focus:ring-2 focus:ring-primary-500',
            'sm:px-2 sm:py-1 sm:min-h-[28px] sm:text-[0.7rem]',
            className
        )}
        style={{
            backgroundImage:
                "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%239CA3AF'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E\")",
            backgroundPosition: 'right 0.4rem center',
            backgroundSize: '1em 1em',
            paddingRight: '2rem',
            ...style,
        }}
        {...props}
    />
);

interface FileActionsBarProps {
    selectedCount: number;
    sortBy: 'name' | 'size' | 'date' | 'type';
    sortDirection: 'asc' | 'desc';
    onSortChange: (sortBy: 'name' | 'size' | 'date' | 'type') => void;
    onNewFile: () => void;
    onNewFolder: () => void;
    onUploadFiles: () => void;
    onPullUrl: () => void;
    onDownload: () => void;
    onMoveToTrash: () => void;
    onDeletePermanently: () => void;
    onCompress: () => void;
    onMove: () => void;
    onPermissions: () => void;
    onProperties: () => void;
    onClearSelection: () => void;
    archiveLabel?: string;
}

const FileActionsBar: React.FC<FileActionsBarProps> = ({
    selectedCount,
    sortBy,
    sortDirection,
    onSortChange,
    onNewFile,
    onNewFolder,
    onUploadFiles,
    onPullUrl,
    onDownload,
    onMoveToTrash,
    onDeletePermanently,
    onCompress,
    onMove,
    onPermissions,
    onProperties,
    onClearSelection,
    archiveLabel = 'Archive',
}) => {
    return (
        <ActionsBar className='betterfiles-scope'>
            <div className={cx('flex flex-col gap-1 sm:hidden', selectedCount > 0 && 'hidden')}>
                <GridGroup>
                    <ActionButton label="New File" onClick={onNewFile}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </ActionButton>
                    <ActionButton label="New Folder" onClick={onNewFolder}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                        </svg>
                    </ActionButton>
                    <ActionButton label="Upload" onClick={onUploadFiles}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                    </ActionButton>
                    <ActionButton label="Pull from URL" onClick={onPullUrl}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                        </svg>
                    </ActionButton>
                </GridGroup>
            </div>

            {selectedCount > 0 && (
                <div className="flex flex-col gap-1 sm:hidden">
                    <div className="flex items-center justify-between gap-1">
                        <SelectInfo>{selectedCount} selected</SelectInfo>
                        <ActionButton label="Clear selection" onClick={onClearSelection} className="w-auto">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </ActionButton>
                    </div>
                    <GridGroup>
                        <ActionButton label="Move" onClick={onMove}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Download" onClick={onDownload}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5m0 0l5-5m-5 5V4" />
                            </svg>
                        </ActionButton>
                        <ActionButton label={archiveLabel} onClick={onCompress}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Permissions" onClick={onPermissions}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Properties" onClick={onProperties} disabled={selectedCount === 0}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6M9 8h6M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Trash" onClick={onMoveToTrash}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Delete" onClick={onDeletePermanently}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </ActionButton>
                    </GridGroup>
                </div>
            )}

            <div className="hidden sm:flex sm:flex-row sm:flex-wrap sm:items-center sm:justify-center sm:gap-1.5">
                <Group>
                    <ActionButton label="New File" onClick={onNewFile}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </ActionButton>
                    <ActionButton label="New Folder" onClick={onNewFolder}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                        </svg>
                    </ActionButton>
                    <ActionButton label="Upload" onClick={onUploadFiles}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                    </ActionButton>
                    <ActionButton label="Pull from URL" onClick={onPullUrl}>
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                        </svg>
                    </ActionButton>
                </Group>

                {selectedCount > 0 && (
                    <Group>
                        <ActionButton label="Move" onClick={onMove}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Download" onClick={onDownload}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v2a2 2 0 002 2h12a2 2 0 002-2v-2M7 10l5 5m0 0l5-5m-5 5V4" />
                            </svg>
                        </ActionButton>
                        <ActionButton label={archiveLabel} onClick={onCompress}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Permissions" onClick={onPermissions}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Properties" onClick={onProperties} disabled={selectedCount === 0}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6M9 8h6M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Trash" onClick={onMoveToTrash}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </ActionButton>
                        <ActionButton label="Delete" onClick={onDeletePermanently}>
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" className="w-3.5 h-3.5 flex-shrink-0">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </ActionButton>
                        <SelectInfo>{selectedCount} selected</SelectInfo>
                        <ActionButton label="Clear selection" onClick={onClearSelection} className="hidden sm:flex">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </ActionButton>
                    </Group>
                )}
            </div>
        </ActionsBar>
    );
};

export default FileActionsBar;
