import React from 'react';
import styled from 'styled-components/macro';
import { themeColors } from './colorExtractor';
import { colors } from './colors';
import FileIcon from './FileIcon';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { Button } from '@/components/elements/button/index';
import { XIcon } from '@heroicons/react/outline';

export interface OpenFile {
    path: string;
    name: string;
    content: string;
    originalContent: string;
    hasUnsavedChanges: boolean;
    foldRanges?: { startRow: number; startColumn: number; endRow: number; endColumn: number; placeholder?: string }[];
}

interface EditorTabsProps {
    openFiles: OpenFile[];
    activeMainFilePath: string | null;
    activeSplitFilePath?: string | null;
    activePane?: 'main' | 'split';
    splitView?: boolean;
    onTabClick: (path: string, targetPane: 'main' | 'split') => void;
    onTabClose: (path: string) => void;
    onCloseAll?: () => void;
    onTabDragStart?: (path: string, e: React.DragEvent) => void;
    disableDrag?: boolean;
    chrome?: boolean;
    connected?: boolean;
    className?: string;
    style?: React.CSSProperties;
}

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

const TabsScroller = styled.div`
    overflow-x: auto;
    overflow-y: hidden;
    scrollbar-width: auto;
`;

const EditorTabs: React.FC<EditorTabsProps> = ({
    openFiles,
    activeMainFilePath,
    activeSplitFilePath,
    activePane = 'main',
    splitView = false,
    onTabClick,
    onTabClose,
    onCloseAll,
    onTabDragStart,
    disableDrag = false,
    chrome = true,
    connected = false,
    className,
    style,
}) => {
    if (openFiles.length === 0) {
        return (
            <TabsScroller
                className={cx(
                    'flex items-end px-0 justify-start',
                    chrome && 'bg-gray-600 border-b border-gray-500',
                    className
                )}
                style={{
                    minHeight: 32,
                    paddingLeft: 23,
                    paddingRight: 23,
                    borderBottom: connected ? `1px solid ${themeColors.page.secondaryHover}` : undefined,
                    paddingBottom: connected ? 0 : undefined,
                    ...style,
                }}
            >
                <div className="flex-1 flex items-center justify-center text-sm text-neutral-300 h-10">
                    No files open
                </div>
            </TabsScroller>
        );
    }

    const effectivePane: 'main' | 'split' =
        splitView && activePane === 'split' && activeSplitFilePath ? 'split' : 'main';

    return (
        <TabsScroller
            className={cx(
                'flex items-end px-0 justify-start',
                chrome && 'bg-gray-600 border-b border-gray-500',
                className
            )}
            style={{
                minHeight: 32,
                paddingLeft: 23,
                paddingRight: 23,
                borderBottom: connected ? `1px solid ${themeColors.page.secondaryHover}` : undefined,
                paddingBottom: connected ? 0 : undefined,
                ...style,
            }}
        >
            {openFiles.map((file) => {
                const isMainActive = file.path === activeMainFilePath;
                const isSplitActive = splitView && !!activeSplitFilePath && file.path === activeSplitFilePath;
                const isFocused = effectivePane === 'split' ? isSplitActive : isMainActive;
                const isSecondary = !isFocused && (isMainActive || isSplitActive);

                const baseClasses = cx(
                    'flex items-center gap-1 text-xs cursor-pointer transition-all duration-150 relative select-none flex-shrink-0',
                    'text-neutral-300'
                );

                const activeClasses = isFocused ? 'text-neutral-200' : '';
                const secondaryClasses = isSecondary ? 'text-neutral-300' : '';

                const tabStyle: React.CSSProperties = {
                    padding: '8px 11px',
                    margin: '0 2px',
                    minWidth: 90,
                    maxWidth: 170,
                    border: `1px solid ${themeColors.page.secondaryHover}`,
                };
                const tabMarginBottom = connected ? 2 : 0;

                return (
                    <GreyRowBox
                        key={file.path}
                        className={cx(
                            baseClasses,
                            activeClasses,
                            secondaryClasses,
                            isFocused ? 'shadow-inner' : isSecondary ? 'shadow-sm' : 'shadow-inner'
                        )}
                        onClick={() => onTabClick(file.path, effectivePane)}
                        draggable={!disableDrag}
                        onDragStart={(e) => {
                            if (disableDrag) return;
                            onTabDragStart?.(file.path, e);
                        }}
                        style={{
                            ...tabStyle,
                            marginBottom: tabMarginBottom,
                            backgroundColor: isFocused
                                ? themeColors.page.secondary
                                : themeColors.page.secondary,
                            borderColor: isFocused
                                ? themeColors.page.secondarySelected
                                : isSecondary
                                    ? themeColors.page.secondaryHover
                                    : themeColors.page.secondaryHover,
                        }}
                    >
                        {file.hasUnsavedChanges && (
                            <span
                                className="absolute"
                                style={{
                                    top: 4,
                                    right: 4,
                                    width: 6,
                                    height: 6,
                                    borderRadius: '50%',
                                    background: colors.primary.default,
                                    boxShadow: `0 0 6px ${colors.primary.default}`,
                                }}
                            />
                        )}
                        <span className="flex-shrink-0 flex items-center justify-center" style={{ width: 16, height: 16 }}>
                            <FileIcon filename={file.name} />
                        </span>
                        <span className="truncate flex-1 text-xs font-medium leading-none" title={file.path}>
                            {file.name}
                        </span>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                onTabClose(file.path);
                            }}
                            title="Close"
                            className="p-0.5 transition-colors flex-shrink-0 flex items-center justify-center text-neutral-300 hover:bg-red-500 hover:text-red-300 leading-none"
                            style={{ width: 16, height: 16, borderRadius: 4 }}
                        >
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </GreyRowBox>
                );
            })}
            {onCloseAll && (
                <div className='sticky right-0 z-10 ml-auto flex h-10 shrink-0 items-center border-l border-gray-500 bg-gray-600 pl-2 pr-1'>
                    <Button.Text
                        type='button'
                        title={`Close ${openFiles.length} open tab${openFiles.length === 1 ? '' : 's'}`}
                        size={Button.Sizes.Small}
                        shape={Button.Shapes.IconSquare}
                        onClick={onCloseAll}
                        className='bg-transparent text-neutral-300 hover:bg-gray-500 active:bg-gray-500 border-0'
                    >
                        <XIcon className='h-4 w-4' />
                    </Button.Text>
                </div>
            )}
        </TabsScroller>
    );
};

export default EditorTabs;
