import { colors } from '../colors';
import { drawRoundRect } from './utils';
import { WaveformConfig, DEFAULT_WAVEFORM_CONFIG } from './types';

const resolveClassColor = (className: string, property: 'backgroundColor' | 'color'): string => {
    if (typeof window === 'undefined' || !document?.body) return '';
    const temp = document.createElement('div');
    temp.className = className;
    temp.style.position = 'absolute';
    temp.style.visibility = 'hidden';
    temp.style.pointerEvents = 'none';
    document.body.appendChild(temp);
    const value = window.getComputedStyle(temp)[property];
    document.body.removeChild(temp);
    return value;
};

const getTimelineColors = () => ({
    base: resolveClassColor('bg-gray-800', 'backgroundColor'),
    buffered: resolveClassColor('bg-gray-700', 'backgroundColor'),
});

export interface WaveformState {
    bars: Float32Array | null;
    frequencyData: Uint8Array | null;
    peakLevel: number;
    beatZoom: number;
    lastBeatTime: number;
    bassAverage: number;
    bassEnergy: number;
    bassPunch: number;
    lastBassLevel: number;
}

export const createWaveformState = (): WaveformState => ({
    bars: null,
    frequencyData: null,
    peakLevel: 1,
    beatZoom: 1,
    lastBeatTime: 0,
    bassAverage: 0,
    bassEnergy: 0,
    bassPunch: 0,
    lastBassLevel: 0,
});

export interface DrawVisualizerOptions {
    canvas: HTMLCanvasElement;
    analyser: AnalyserNode;
    state: WaveformState;
    config?: Partial<WaveformConfig>;
    intensity?: number;
    palette?: WaveformPalette;
    onBeat?: (strength: number) => void;
    onBeatZoomChange?: (zoom: number) => void;
}

export interface WaveformPalette {
    dark: string;
    default: string;
    light: string;
}

export const drawVisualizer = (options: DrawVisualizerOptions): void => {
    const { canvas, analyser, state, config: userConfig, intensity = 1, palette, onBeat, onBeatZoomChange } = options;
    if (!canvas || !analyser) return;
    
    const config = { ...DEFAULT_WAVEFORM_CONFIG, ...userConfig };
    const waveformColors = palette || {
        dark: colors.primary.dark,
        default: colors.primary.default,
        light: colors.primary.light,
    };

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    const dpr = window.devicePixelRatio || 1;

    if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
    }

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);

    const bufferLength = analyser.frequencyBinCount;
    if (!state.frequencyData || state.frequencyData.length !== bufferLength) {
        state.frequencyData = new Uint8Array(bufferLength);
    }
    const dataArray = state.frequencyData;
    analyser.getByteFrequencyData(dataArray);

    let currentPeak = 0;
    let currentAverage = 0;
    for (let i = 0; i < bufferLength; i++) {
        const value = dataArray[i];
        if (value > currentPeak) currentPeak = value;
        currentAverage += value;
    }
    currentAverage /= Math.max(1, bufferLength);

    const volumeScale = Math.min(1, Math.max(0, intensity));
    const visualScale = volumeScale === 0 ? 0 : 0.55 + Math.sqrt(volumeScale) * 0.45;

    state.peakLevel = state.peakLevel * 0.96 + Math.max(currentPeak, currentAverage * 1.8) * 0.04;
    const gain = state.peakLevel > 12 ? Math.min(1.45, 190 / state.peakLevel) : 1.05;

    const barCount = config.barCount;
    const gap = config.barGap;
    const totalWidth = width;
    const barWidth = Math.max(2, (totalWidth - (barCount - 1) * gap) / barCount);
    const actualTotalWidth = barCount * barWidth + (barCount - 1) * gap;
    const offsetX = (totalWidth - actualTotalWidth) / 2;
    const maxHeight = height * config.maxBarHeightRatio;
    const radius = Math.max(1, barWidth / 4);

    if (!state.bars || state.bars.length !== barCount) {
        state.bars = new Float32Array(barCount);
    }

    const bassBinEnd = Math.max(4, Math.floor(bufferLength * 0.08));
    const subBassBinEnd = Math.max(2, Math.floor(bufferLength * 0.025));
    let bassSum = 0;
    let subBassSum = 0;

    for (let i = 0; i < bassBinEnd; i++) {
        const value = dataArray[i];
        bassSum += value;
        if (i < subBassBinEnd) subBassSum += value;
    }

    const bassLevel = Math.min(1, ((bassSum / Math.max(1, bassBinEnd) / 255) * 0.62 + (subBassSum / Math.max(1, subBassBinEnd) / 255) * 0.28) * visualScale);
    const previousBassAverage = state.bassAverage || bassLevel;
    const averageRate = bassLevel > previousBassAverage ? 0.035 : 0.012;
    state.bassAverage = previousBassAverage * (1 - averageRate) + bassLevel * averageRate;

    const bassImpact = Math.max(0, bassLevel - previousBassAverage);
    const previousBassLevel = state.lastBassLevel || bassLevel;
    const bassRise = Math.max(0, bassLevel - previousBassLevel);
    state.lastBassLevel = bassLevel;
    const bassRatio = bassLevel / Math.max(0.065, previousBassAverage);
    const bassSurge = Math.max(0, bassRatio - 1);
    state.bassEnergy = state.bassEnergy * 0.78 + bassLevel * 0.22;

    for (let i = 0; i < barCount; i++) {
        let sum = 0;
        let max = 0;
        const startRatio = i / barCount;
        const endRatio = (i + 1) / barCount;
        const start = Math.floor(Math.pow(startRatio, 1.65) * (bufferLength - 1));
        const end = Math.max(start + 1, Math.floor(Math.pow(endRatio, 1.65) * (bufferLength - 1)));
        const count = Math.max(1, end - start);

        for (let j = start; j < end && j < bufferLength; j++) {
            const value = dataArray[j];
            sum += value;
            if (value > max) max = value;
        }
        const avg = sum / count;
        const lowBoost = 1 + (1 - i / barCount) * 0.18;
        const normalized = Math.min(1, Math.pow(((avg * 0.78 + max * 0.22) * gain * lowBoost * visualScale) / 255, 0.82));

        const current = state.bars[i];
        const isBassBar = i < Math.max(4, Math.floor(barCount * 0.18));
        const rate = normalized > current ? (isBassBar ? 0.34 : 0.28) : (isBassBar ? 0.12 : 0.08);
        state.bars[i] = current + (normalized - current) * rate;
    }

    const now = performance.now();
    const isHeavyBass = bassLevel > Math.max(0.065, previousBassAverage * 1.12);
    const isBassTransient = bassImpact > Math.max(0.016, previousBassAverage * 0.11);
    const isFastBassRise = bassRise > Math.max(0.012, previousBassAverage * 0.08);
    const isBassDrop = bassLevel > Math.max(0.12, previousBassAverage * 1.28) && (bassSurge > 0.18 || bassRise > 0.018);
    const beatStrength = Math.min(1, bassLevel * 0.95 + bassImpact * 3.3 + bassRise * 5.2 + bassSurge * 0.22);
    const bassHit = volumeScale > 0.05
        && (isBassDrop || (isHeavyBass && (isBassTransient || isFastBassRise)))
        && now - state.lastBeatTime > 125;

    if (bassHit) {
        const punchStrength = Math.min(1, Math.max(beatStrength, isBassDrop ? 0.62 : 0.46));
        state.bassPunch = Math.max(state.bassPunch, punchStrength);
        state.lastBeatTime = now;
        onBeat?.(punchStrength);
    }

    state.bassPunch *= 0.88;
    const targetZoom = 1 + Math.min(0.24, state.bassPunch * 0.36);
    state.beatZoom += (targetZoom - state.beatZoom) * (targetZoom > state.beatZoom ? 0.32 : 0.16);
    onBeatZoomChange?.(state.beatZoom);

    const gradient = ctx.createLinearGradient(0, height, 0, 0);
    gradient.addColorStop(0, waveformColors.dark);
    gradient.addColorStop(0.5, waveformColors.default);
    gradient.addColorStop(1, waveformColors.light);

    ctx.fillStyle = gradient;
    ctx.shadowColor = waveformColors.default;
    ctx.shadowBlur = 2 + Math.max(0, state.beatZoom - 1) * 26;

    const beatPulse = Math.max(0, state.beatZoom - 1);
    const smoothedPunch = Math.min(1, beatPulse / 0.24);
    const bassBarCount = Math.max(6, Math.floor(barCount * 0.28));
    const waveformScaleX = 1 + Math.min(0.08, beatPulse * 0.34 + smoothedPunch * 0.018);
    const waveformScaleY = 1 + Math.min(0.26, beatPulse * 0.95 + smoothedPunch * 0.08);

    ctx.save();
    ctx.translate(width / 2, height);
    ctx.scale(waveformScaleX, waveformScaleY);
    ctx.translate(-width / 2, -height);

    for (let i = 0; i < barCount; i++) {
        const value = state.bars[i];
        const bassWeight = Math.max(0, 1 - i / bassBarCount);
        const beatLift = 1 + beatPulse * 0.72 + smoothedPunch * 0.08;
        const bassKickLift = maxHeight * smoothedPunch * bassWeight * 0.045;
        const barHeight = Math.max(2, value * maxHeight * beatLift * (1 + state.bassEnergy * 0.02) + bassKickLift);
        const x = offsetX + i * (barWidth + gap);
        const y = height - barHeight;

        ctx.beginPath();
        drawRoundRect(ctx, x, y, barWidth, barHeight, [radius, radius, 0, 0]);
        ctx.fill();
    }

    ctx.restore();
};

export interface DrawTimelineOptions {
    canvas: HTMLCanvasElement;
    analyser: AnalyserNode;
    currentTime: number;
    duration: number;
    buffered: TimeRanges | null;
    config?: Partial<WaveformConfig>;
}

export const drawTimeline = (options: DrawTimelineOptions): void => {
    const { canvas, analyser, currentTime, duration, buffered, config: userConfig } = options;
    if (!canvas || !analyser) return;
    
    const config = { ...DEFAULT_WAVEFORM_CONFIG, ...userConfig };

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    const dpr = window.devicePixelRatio || 1;

    if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
    }

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);

    const { base, buffered: bufferedColor } = getTimelineColors();
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, width, height);

    if (buffered && duration > 0) {
        ctx.fillStyle = bufferedColor;
        for (let i = 0; i < buffered.length; i++) {
            const startX = (buffered.start(i) / duration) * width;
            const endX = (buffered.end(i) / duration) * width;
            ctx.fillRect(startX, 0, endX - startX, height);
        }
    }

    if (duration > 0) {
        const progress = currentTime / duration;
        ctx.fillStyle = colors.primary.default;
        ctx.fillRect(0, 0, progress * width, height);
    }

    const bufferLength = analyser.frequencyBinCount;
    const timeData = new Uint8Array(bufferLength);
    analyser.getByteTimeDomainData(timeData);

    ctx.strokeStyle = colors.primary.light;
    ctx.lineWidth = 1.5;
    ctx.beginPath();

    const sliceWidth = width / bufferLength;
    let x = 0;

    for (let i = 0; i < bufferLength; i++) {
        const v = timeData[i] / 128.0;
        const y = (v * height) / 2;

        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }

        x += sliceWidth;
    }

    ctx.stroke();
};

export const emitBeatNote = (
    container: HTMLElement,
    strength: number,
    primaryColor: string
): void => {
    const note = document.createElement('div');
    note.style.cssText = `
        position: absolute;
        left: 50%;
        top: 50%;
        width: 12px;
        height: 12px;
        margin: -6px 0 0 -6px;
        background: ${primaryColor};
        border-radius: 50%;
        opacity: ${0.4 + strength * 0.4};
        pointer-events: none;
        animation: beatPulse 0.6s ease-out forwards;
    `;

    container.appendChild(note);
    setTimeout(() => note.remove(), 600);
};
