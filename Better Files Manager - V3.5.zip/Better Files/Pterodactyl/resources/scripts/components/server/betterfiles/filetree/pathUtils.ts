export const normalizePath = (path: string): string => (path.startsWith('/') ? path : `/${path}`);

export const getParentPath = (path: string): string => {
    if (!path || path === '/') return '/';
    const normalized = path.replace(/\/+$/, '');
    const lastSlash = normalized.lastIndexOf('/');
    if (lastSlash <= 0) return '/';
    return normalized.slice(0, lastSlash);
};

export const safeNormalizePath = (rawPath: string): string => {
    const cleaned = rawPath.replace(/\\/g, '/');
    const parts = cleaned.split('/');
    const normalizedParts: string[] = [];
    for (const part of parts) {
        if (!part || part === '.') continue;
        if (part === '..') {
            normalizedParts.pop();
            continue;
        }
        normalizedParts.push(part);
    }
    return '/' + normalizedParts.join('/');
};

export const normalizeDirectory = (value: string): string => {
    const trimmed = value?.trim() || '/';
    if (!trimmed || trimmed === '/') return '/';
    const withSlash = trimmed.startsWith('/') ? trimmed : `/${trimmed}`;
    return withSlash.replace(/\/+$/, '') || '/';
};

export const joinDirectoryAndName = (directory: string, name: string): string => {
    const normalized = normalizeDirectory(directory);
    if (!name) return normalized;
    return normalized === '/' ? `/${name}` : `${normalized}/${name}`;
};
