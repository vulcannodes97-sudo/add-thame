import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { type FileObject } from '@/api/server/files';
import { searchFiles, SearchError, type FileSearchResult } from '@/api/server/files/betterFilesApi';

interface Options {
    uuid: string;
    viewFileTree: Record<string, FileObject[]>;
    canSearchContents: boolean;
    onFileSelect: (path: string, isFile: boolean) => void;
    onPathChange: (path: string) => void;
    viewMode: 'tree' | 'browse' | 'grid';
    safeNormalizePath: (path: string) => string;
    getParentPath: (path: string) => string;
    ensureDirectoryLoaded: (path: string) => Promise<void>;
    expandToPath: (path: string) => Promise<void>;
    getSearchResultDirectory: (result: FileSearchResult) => string;
}

export const useFileSearch = ({
    uuid,
    viewFileTree,
    canSearchContents,
    onFileSelect,
    onPathChange,
    viewMode,
    safeNormalizePath,
    getParentPath,
    ensureDirectoryLoaded,
    expandToPath,
    getSearchResultDirectory,
}: Options) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState<FileSearchResult[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [searchError, setSearchError] = useState<string | null>(null);
    const [isLocalSearch, setIsLocalSearch] = useState(false);
    const [searchIncludeContent, setSearchIncludeContent] = useState(false);
    const searchAbortRef = useRef<AbortController | null>(null);
    const lastSearchQueryRef = useRef<string>('');

    const clearSearchState = useCallback(() => {
        setSearchResults([]);
        setSearchError(null);
        setIsLocalSearch(false);
    }, []);

    const openSearchResult = useCallback(async (result: FileSearchResult) => {
        if (result.is_file) {
            onFileSelect(result.path, true);
            return;
        }

        const directory = getSearchResultDirectory(result);
        setSearchQuery('');
        clearSearchState();

        if (viewMode === 'tree') {
            await expandToPath(directory);
        } else {
            await ensureDirectoryLoaded(directory);
        }

        onPathChange(directory);
    }, [clearSearchState, ensureDirectoryLoaded, expandToPath, getSearchResultDirectory, onFileSelect, onPathChange, viewMode]);

    const revealSearchPath = useCallback(async (path: string, isFile: boolean) => {
        if (!isFile) return;
        const matched = searchResults.find(result => result.path === path);
        const directory = matched ? getSearchResultDirectory(matched) : safeNormalizePath(getParentPath(path));

        setSearchQuery('');
        clearSearchState();

        if (viewMode === 'tree') {
            await expandToPath(directory);
        } else {
            await ensureDirectoryLoaded(directory);
        }

        onPathChange(directory);
    }, [clearSearchState, ensureDirectoryLoaded, expandToPath, getParentPath, getSearchResultDirectory, onPathChange, safeNormalizePath, searchResults, viewMode]);

    const performLocalSearch = useCallback((query: string): FileSearchResult[] => {
        const results: FileSearchResult[] = [];
        const queryLower = query.toLowerCase();
        const maxResults = 100;

        (Object.entries(viewFileTree) as [string, FileObject[]][]).forEach(([dirPath, files]) => {
            if (results.length >= maxResults) return;

            files.forEach((file: FileObject) => {
                if (results.length >= maxResults) return;
                if (file.name === '.trash-bin') return;

                if (file.name.toLowerCase().includes(queryLower)) {
                    const fullPath = dirPath === '/' ? `/${file.name}` : `${dirPath}/${file.name}`;
                    if (!results.some(r => r.path === fullPath)) {
                        results.push({
                            name: file.name,
                            path: fullPath,
                            directory: dirPath,
                            is_file: file.isFile,
                            size: file.size || 0,
                            modified_at: file.modifiedAt?.toString() || '',
                        });
                    }
                }
            });
        });

        return results;
    }, [viewFileTree]);

    useEffect(() => {
        const trimmedQuery = searchQuery?.trim() || '';

        if (trimmedQuery.length === 0) {
            if (searchAbortRef.current) {
                searchAbortRef.current.abort();
                searchAbortRef.current = null;
            }
            lastSearchQueryRef.current = '';
            clearSearchState();
            setIsSearching(false);
            return;
        }

        const searchKey = `${trimmedQuery}::${searchIncludeContent ? 'content' : 'name'}`;

        if (searchKey === lastSearchQueryRef.current) {
            return;
        }

        const timeoutId = setTimeout(async () => {
            if (searchAbortRef.current) {
                searchAbortRef.current.abort();
            }

            const abortController = new AbortController();
            searchAbortRef.current = abortController;
            lastSearchQueryRef.current = searchKey;

            setIsSearching(true);
            setSearchError(null);
            setIsLocalSearch(false);

            try {
                const response = await searchFiles(uuid, trimmedQuery, {
                    maxDepth: 0,
                    timeout: 30,
                    includeContent: searchIncludeContent && canSearchContents,
                });

                if (abortController.signal.aborted) return;

                setSearchResults(response.data);
                setIsLocalSearch(false);
            } catch (error: any) {
                if (abortController.signal.aborted) return;

                if (error instanceof SearchError && error.code === 'CONTENT_SEARCH_DISABLED') {
                    setSearchIncludeContent(false);
                    setSearchError('Content search is disabled by the administrator.');
                    setSearchResults([]);
                    setIsLocalSearch(false);
                    return;
                }
                if (error instanceof SearchError && error.code === 'INSUFFICIENT_PERMISSIONS') {
                    setSearchIncludeContent(false);
                    setSearchError('You do not have permission to search file contents.');
                    setSearchResults([]);
                    setIsLocalSearch(false);
                    return;
                }
                let wingsErrorMessage: string | null = null;
                if (error instanceof SearchError && error.code === 'ENDPOINT_UNAVAILABLE') {
                    wingsErrorMessage = 'Wings search endpoint is not available. Update Wings and restart it.';
                } else if (error instanceof SearchError && error.code === 'WINGS_UNREACHABLE') {
                    wingsErrorMessage = 'Wings is unreachable. Check the node connection.';
                } else if (error instanceof SearchError && error.code === 'TIMEOUT') {
                    wingsErrorMessage = 'Search timed out. Try a shorter query or reduce depth.';
                } else if (error instanceof SearchError) {
                    wingsErrorMessage = error.message;
                }

                if (searchIncludeContent) {
                    setSearchError(wingsErrorMessage ?? 'Search failed. Content search requires Wings.');
                    setSearchResults([]);
                    setIsLocalSearch(false);
                    return;
                }

                const localResults = performLocalSearch(trimmedQuery);
                if (localResults.length > 0) {
                    setSearchResults(localResults);
                    setIsLocalSearch(true);
                    setSearchError(wingsErrorMessage ?? null);
                } else {
                    setSearchError(wingsErrorMessage ?? 'No results found.');
                    setSearchResults([]);
                    setIsLocalSearch(true);
                }
            } finally {
                if (!abortController.signal.aborted) {
                    setIsSearching(false);
                }
            }
        }, 250);

        return () => {
            clearTimeout(timeoutId);
        };
    }, [searchQuery, uuid, performLocalSearch, searchIncludeContent, canSearchContents, clearSearchState]);

    return {
        searchQuery,
        setSearchQuery,
        searchResults,
        isSearching,
        searchError,
        isLocalSearch,
        searchIncludeContent,
        setSearchIncludeContent,
        openSearchResult,
        revealSearchPath,
    };
};
