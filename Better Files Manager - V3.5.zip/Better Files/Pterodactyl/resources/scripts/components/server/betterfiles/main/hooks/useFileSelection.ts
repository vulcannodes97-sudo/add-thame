import { useState, useCallback, useMemo } from 'react';
import type { FileTree, SortBy, SortDirection } from '../types';

interface UseFileSelectionOptions {
    fileTree: FileTree;
    currentPath: string;
}

export const useFileSelection = ({ fileTree, currentPath }: UseFileSelectionOptions) => {
    const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
    const [sortBy, setSortBy] = useState<SortBy>('name');
    const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

    const toggleFileSelection = useCallback((filePath: string) => {
        setSelectedFiles((prev) =>
            prev.includes(filePath) ? prev.filter((f) => f !== filePath) : [...prev, filePath]
        );
    }, []);

    const clearSelection = useCallback(() => setSelectedFiles([]), []);

    const selectAll = useCallback(() => {
        const allFiles = fileTree[currentPath] || [];
        const allFilePaths = allFiles.map((f) => (currentPath === '/' ? `/${f.name}` : `${currentPath}/${f.name}`));
        setSelectedFiles(allFilePaths);
    }, [fileTree, currentPath]);

    const handleSortChange = useCallback((newSortBy: SortBy) => {
        if (sortBy === newSortBy) {
            setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
        } else {
            setSortBy(newSortBy);
            setSortDirection('asc');
        }
    }, [sortBy]);

    const isDirectoryPath = useCallback((path: string) => {
        const normalized = path.startsWith('/') ? path : `/${path}`;
        if (normalized === '/') return true;
        if (fileTree[normalized]) return true;
        const lastSlash = normalized.lastIndexOf('/');
        const directory = lastSlash <= 0 ? '/' : normalized.slice(0, lastSlash);
        const name = normalized.slice(lastSlash + 1);
        const entry = fileTree[directory]?.find((f) => f.name === name);
        return entry ? !entry.isFile : false;
    }, [fileTree]);

    const getActionFallbackPath = useCallback(() => {
        if (typeof window === 'undefined') return currentPath;
        const stored = window.localStorage.getItem('bfm-file-view-mode');
        if (stored === 'tree') return '/';
        return currentPath;
    }, [currentPath]);

    const resolveActionTargetPaths = useCallback(() => {
        const directoryTargets = selectedFiles
            .map((path) => (path.startsWith('/') ? path : `/${path}`))
            .filter((path) => isDirectoryPath(path));
        if (directoryTargets.length > 0) {
            return Array.from(new Set(directoryTargets));
        }
        return [getActionFallbackPath()];
    }, [getActionFallbackPath, isDirectoryPath, selectedFiles]);

    const selectedArchiveTarget = useMemo(() => {
        if (selectedFiles.length !== 1) return null;
        const path = selectedFiles[0];
        const filename = path.substring(path.lastIndexOf('/') + 1);
        const ext = filename.split('.').pop()?.toLowerCase();
        const isArchive = ['zip', 'tar', 'gz', 'rar', '7z', 'bz2', 'xz', 'tgz'].includes(ext || '') || filename.includes('.tar.');
        if (!filename || !isArchive) return null;
        const directory = path.substring(0, path.lastIndexOf('/')) || '/';
        return { path, filename, directory };
    }, [selectedFiles]);

    return {
        selectedFiles,
        setSelectedFiles,
        sortBy,
        setSortBy,
        sortDirection,
        setSortDirection,
        toggleFileSelection,
        clearSelection,
        selectAll,
        handleSortChange,
        isDirectoryPath,
        getActionFallbackPath,
        resolveActionTargetPaths,
        selectedArchiveTarget,
    };
};
