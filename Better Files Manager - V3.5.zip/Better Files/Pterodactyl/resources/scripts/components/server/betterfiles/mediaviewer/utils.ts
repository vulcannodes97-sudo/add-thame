export const VOLUME_STORAGE_KEY = 'betterfiles.media.volume';

export const clampVolume = (value: number): number => Math.min(1, Math.max(0, value));

export const readStoredVolume = (): number => {
    if (typeof window === 'undefined') return 1;
    try {
        const raw = window.localStorage.getItem(VOLUME_STORAGE_KEY);
        if (!raw) return 1;
        const parsed = parseFloat(raw);
        if (Number.isNaN(parsed)) return 1;
        return clampVolume(parsed);
    } catch {
        return 1;
    }
};

export const writeStoredVolume = (value: number): void => {
    if (typeof window === 'undefined') return;
    try {
        window.localStorage.setItem(VOLUME_STORAGE_KEY, clampVolume(value).toString());
    } catch {

    }
};

export const formatTime = (seconds: number): string => {
    if (!Number.isFinite(seconds)) return '--:--';
    if (seconds <= 0) return '0:00';
    const totalSeconds = Math.floor(seconds);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
};

export const cx = (...parts: Array<string | false | null | undefined>): string =>
    parts.filter(Boolean).join(' ');

export const toArrayBuffer = (data: Uint8Array): ArrayBuffer => {
    if (data.buffer instanceof ArrayBuffer) {
        return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
    }
    const copy = new Uint8Array(data);
    return copy.buffer;
};

export const drawRoundRect = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    radii: number | number[]
): void => {
    // @ts-ignore - Check if browser supports it natively
    if (typeof ctx.roundRect === 'function') {
        // @ts-ignore
        ctx.roundRect(x, y, width, height, radii);
        return;
    }

    const [tl, tr, br, bl] = Array.isArray(radii)
        ? radii
        : [radii, radii, radii, radii];

    ctx.moveTo(x + tl, y);
    ctx.lineTo(x + width - tr, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + tr);
    ctx.lineTo(x + width, y + height - br);
    ctx.quadraticCurveTo(x + width, y + height, x + width - br, y + height);
    ctx.lineTo(x + bl, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - bl);
    ctx.lineTo(x, y + tl);
    ctx.quadraticCurveTo(x, y, x + tl, y);
};

export const isFormatSupported = (path: string): boolean => {
    const ext = path.split('.').pop()?.toLowerCase() || '';
    return ['mp4', 'webm', 'ogg', 'mp3', 'wav', 'flac', 'm4a'].includes(ext);
};

export const getMimeType = (filePath: string, defaultType: string): string => {
    const ext = filePath.split('.').pop()?.toLowerCase();
    switch (ext) {
        case 'mp4':
            return 'video/mp4';
        case 'webm':
            return 'video/webm';
        case 'ogg':
            return 'video/ogg';
        case 'mp3':
            return 'audio/mpeg';
        case 'wav':
            return 'audio/wav';
        case 'flac':
            return 'audio/flac';
        case 'm4a':
            return 'audio/mp4';
        default:
            return defaultType;
    }
};

interface AudioPlayerRegistry {
    play: () => void;
    pause: () => void;
    seek: (time: number) => void;
    skip: (delta: number) => void;
    isPlaying: () => boolean;
    getCurrentTime: () => number;
}

export const globalAudioRegistry: Map<string, AudioPlayerRegistry> = new Map();

export const syncAllAudio = (action: 'play' | 'pause' | 'toggle'): void => {
    const players = Array.from(globalAudioRegistry.values());
    if (action === 'toggle') {
        const anyPlaying = players.some(p => p.isPlaying());
        action = anyPlaying ? 'pause' : 'play';
    }
    players.forEach(p => action === 'play' ? p.play() : p.pause());
};

export const syncSeekAll = (time: number): void => {
    globalAudioRegistry.forEach(p => p.seek(time));
};

export const syncSkipAll = (delta: number): void => {
    globalAudioRegistry.forEach(p => p.skip(delta));
};

export const applyMediaSettings = (
    element: HTMLAudioElement | HTMLVideoElement,
    volume: number,
    muted: boolean,
    playbackRate: number
): void => {
    element.volume = Math.min(1, Math.max(0, volume));
    element.muted = muted;
    element.playbackRate = playbackRate;
    (element as any).preservesPitch = false;
    (element as any).mozPreservesPitch = false;
    (element as any).webkitPreservesPitch = false;
};
