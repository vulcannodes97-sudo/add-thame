
self.addEventListener('message', (event: MessageEvent) => {
    const { content, filePath } = event.data;

    try {
        let parsed: any = null;
        const extension = filePath.split('.').pop()?.toLowerCase();

        switch (extension) {
            case 'json':
                parsed = JSON.parse(content);
                break;
            case 'yaml':
            case 'yml':
                parsed = parseBasicYAML(content);
                break;
            case 'properties':
            case 'conf':
                parsed = parsePropertiesFile(content);
                break;
            default:
                parsed = { raw: content };
        }

        self.postMessage({ success: true, parsed, filePath });
    } catch (error) {
        self.postMessage({ 
            success: false, 
            error: error instanceof Error ? error.message : 'Parse error',
            filePath 
        });
    }
});

function parseBasicYAML(content: string): Record<string, any> {
    const result: Record<string, any> = {};
    const lines = content.split('\n');
    let currentKey = '';

    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;

        const colonIndex = trimmed.indexOf(':');
        if (colonIndex > 0) {
            const key = trimmed.substring(0, colonIndex).trim();
            const value = trimmed.substring(colonIndex + 1).trim();
            
            if (value) {
                result[key] = parseValue(value);
            } else {
                currentKey = key;
                result[key] = {};
            }
        }
    }

    return result;
}

function parsePropertiesFile(content: string): Record<string, string> {
    const result: Record<string, string> = {};
    const lines = content.split('\n');

    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('!')) continue;

        const equalIndex = trimmed.indexOf('=');
        if (equalIndex > 0) {
            const key = trimmed.substring(0, equalIndex).trim();
            const value = trimmed.substring(equalIndex + 1).trim();
            result[key] = value;
        }
    }

    return result;
}

function parseValue(value: string): any {
    if (value === 'true') return true;
    if (value === 'false') return false;
    if (value === 'null') return null;
    if (!isNaN(Number(value))) return Number(value);
    
    if ((value.startsWith('"') && value.endsWith('"')) || 
        (value.startsWith("'") && value.endsWith("'"))) {
        return value.slice(1, -1);
    }
    
    return value;
}

export {};
