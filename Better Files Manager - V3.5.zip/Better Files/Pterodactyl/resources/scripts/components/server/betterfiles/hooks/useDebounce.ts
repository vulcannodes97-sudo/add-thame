import { useCallback, useRef } from 'react';

export function useDebouncedCallback<T extends (...args: any[]) => any>(
    callback: T,
    delay: number
): (...args: Parameters<T>) => void {
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);
    const callbackRef = useRef(callback);

    callbackRef.current = callback;

    return useCallback(
        (...args: Parameters<T>) => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }

            timeoutRef.current = setTimeout(() => {
                callbackRef.current(...args);
            }, delay);
        },
        [delay]
    );
}

export function useThrottledCallback<T extends (...args: any[]) => any>(
    callback: T,
    delay: number
): (...args: Parameters<T>) => void {
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);
    const lastRunRef = useRef<number>(0);
    const callbackRef = useRef(callback);

    callbackRef.current = callback;

    return useCallback(
        (...args: Parameters<T>) => {
            const now = Date.now();

            if (now - lastRunRef.current >= delay) {
                lastRunRef.current = now;
                callbackRef.current(...args);
            } else {
                if (timeoutRef.current) {
                    clearTimeout(timeoutRef.current);
                }

                timeoutRef.current = setTimeout(() => {
                    lastRunRef.current = Date.now();
                    callbackRef.current(...args);
                }, delay - (now - lastRunRef.current));
            }
        },
        [delay]
    );
}
