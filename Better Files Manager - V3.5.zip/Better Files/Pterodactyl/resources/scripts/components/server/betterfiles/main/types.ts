import type { FileObject } from '@/api/server/files';

export interface FoldRange {
    startRow: number;
    startColumn: number;
    endRow: number;
    endColumn: number;
    placeholder?: string;
}

export interface OpenFile {
    path: string;
    name: string;
    content: string;
    originalContent: string;
    hasUnsavedChanges: boolean;
    foldRanges?: FoldRange[];
}

export interface FileTree {
    [path: string]: FileObject[];
}

export interface OperationProgress {
    message: string;
    show: boolean;
}

export interface TrashCleanupSettings {
    trash_cleanup_enabled: boolean;
    trash_retention_days: number;
    trash_retention_unit: 'days' | 'hours';
}

export interface PropertiesEntry {
    path: string;
    file: FileObject | undefined;
}

export type MediaType = 'image' | 'video' | 'audio' | 'text' | 'binary';
export type SortBy = 'name' | 'size' | 'date' | 'type';
export type SortDirection = 'asc' | 'desc';
export type ActivePane = 'main' | 'split';
export type ActiveTab = 'files' | 'editor';
export type ViewMode = 'tree' | 'browse' | 'grid';
