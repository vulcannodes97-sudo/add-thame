import React from 'react';
import GreyRowBox from '@/components/elements/GreyRowBox';
import SimpleEditor from '../../SimpleEditor';
import MediaViewer from '../../mediaviewer';
import { SplitEditorPane, SplitPaneHeader, SplitPaneHeaderLeft, PaneBadge, SplitPaneTitle, SplitDropZone, SplitCloseButton, SplitDivider } from '../styles';
import { colors } from '../../colors';
import type { MediaType } from '../types';

interface EditorPaneProps {
    pane: 'main' | 'split';
    uuid: string;
    filePath: string | null;
    fileContent: string;
    mediaType: MediaType | null;
    isActive: boolean;
    hasUnsavedChanges: boolean;
    isSaving: boolean;
    splitView: boolean;
    isFileDragActive: boolean;
    isDraggingToSplit: boolean;
    leftPaneWidth: number;
    isSplitResizing: boolean;
    paneRef: React.RefObject<HTMLDivElement>;
    onFocus: () => void;
    onChange: (content: string) => void;
    onSave: () => void;
    onFileDrop: (path: string) => void;
    onDragEnter?: (e: React.DragEvent) => void;
    onDragOver?: (e: React.DragEvent) => void;
    onDragLeave?: (e: React.DragEvent) => void;
    onDrop?: (e: React.DragEvent) => void;
    onSplitResizeStart?: (e: React.MouseEvent) => void;
    onCloseSplit?: () => void;
}

const EditorPaneComponent: React.FC<EditorPaneProps> = ({
    pane,
    uuid,
    filePath,
    fileContent,
    mediaType,
    isActive,
    hasUnsavedChanges,
    isSaving,
    splitView,
    isFileDragActive,
    isDraggingToSplit,
    leftPaneWidth,
    isSplitResizing,
    paneRef,
    onFocus,
    onChange,
    onSave,
    onFileDrop,
    onDragEnter,
    onDragOver,
    onDragLeave,
    onDrop,
    onSplitResizeStart,
    onCloseSplit,
}) => {
    if (!filePath) return null;

    const isMain = pane === 'main';
    const paneStyle = splitView
        ? {
            flex: isMain ? `0 0 ${leftPaneWidth}%` : `0 0 ${100 - leftPaneWidth}%`,
            maxWidth: isMain ? `${leftPaneWidth}%` : `${100 - leftPaneWidth}%`,
            willChange: isSplitResizing ? 'flex-basis, width' : undefined,
        }
        : { flex: '1 1 auto', maxWidth: '100%' };

    return (
        <>
            {!isMain && splitView && <SplitDivider onMouseDown={onSplitResizeStart} />}
            <SplitEditorPane
                ref={paneRef}
                data-split-drop-zone
                data-pane={pane}
                style={paneStyle}
                isDragOver={isMain && isDraggingToSplit}
                onMouseDownCapture={onFocus}
                onFocusCapture={onFocus}
                onDragEnter={onDragEnter}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
            >
                {!isMain && onCloseSplit && (
                    <SplitCloseButton onClick={onCloseSplit} title='Close split view'>
                        <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M6 18L18 6M6 6l12 12' />
                        </svg>
                    </SplitCloseButton>
                )}

                {splitView && (
                    <div className="px-2 pt-1.5 pb-2">
                        <SplitPaneHeader active={isActive} onClick={onFocus}>
                            <SplitPaneHeaderLeft>
                                <PaneBadge active={isActive}>{isMain ? 'Main' : 'Split'}</PaneBadge>
                                <SplitPaneTitle active={isActive}>
                                    {filePath.split('/').pop() || 'No file'}
                                </SplitPaneTitle>
                            </SplitPaneHeaderLeft>
                            {hasUnsavedChanges && <PaneBadge active={true}>Modified</PaneBadge>}
                        </SplitPaneHeader>
                    </div>
                )}

                {mediaType === 'text' ? (
                    <>
                        <GreyRowBox
                            className='flex flex-col flex-1 min-w-0 min-h-0 w-full items-stretch'
                            style={{ padding: 0 }}
                        >
                            <SimpleEditor
                                value={fileContent}
                                onChange={onChange}
                                filePath={filePath}
                                readOnly={isSaving}
                                onSave={onSave}
                                onFileDrop={onFileDrop}
                                onFocus={onFocus}
                            />
                        </GreyRowBox>

                        {isFileDragActive && (
                            <div
                                className='absolute inset-0 z-10'
                                style={{ background: 'transparent', top: splitView && !isMain ? '40px' : undefined }}
                                onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); }}
                                onDrop={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    const path = e.dataTransfer.getData('text/plain');
                                    if (path && path !== filePath) {
                                        onFileDrop(path);
                                    }
                                }}
                            />
                        )}
                    </>
                ) : (
                    <MediaViewer
                        uuid={uuid}
                        filePath={filePath}
                        fileType={mediaType as 'image' | 'video' | 'audio'}
                    />
                )}

                {isMain && !splitView && isDraggingToSplit && (
                    <SplitDropZone isDragOver={true}>
                        <div
                            className='text-center p-6 border-2 border-dashed bg-gray-700 pointer-events-none'
                            style={{ borderColor: colors.primary.default }}
                        >
                            <svg
                                className='w-12 h-12 mx-auto mb-3'
                                style={{ color: colors.primary.default }}
                                fill='none'
                                stroke='currentColor'
                                viewBox='0 0 24 24'
                            >
                                <path
                                    strokeLinecap='round'
                                    strokeLinejoin='round'
                                    strokeWidth={2}
                                    d='M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 00-2-2h-2a2 2 0 00-2 2'
                                />
                            </svg>
                            <p className='font-medium' style={{ color: colors.primary.default }}>
                                Drop here to open in split view
                            </p>
                        </div>
                    </SplitDropZone>
                )}
            </SplitEditorPane>
        </>
    );
};

export const EditorPane = React.memo(EditorPaneComponent, (prev, next) => {
    return (
        prev.pane === next.pane &&
        prev.filePath === next.filePath &&
        prev.fileContent === next.fileContent &&
        prev.isActive === next.isActive &&
        prev.hasUnsavedChanges === next.hasUnsavedChanges &&
        prev.isSaving === next.isSaving &&
        prev.splitView === next.splitView &&
        prev.isFileDragActive === next.isFileDragActive &&
        prev.isDraggingToSplit === next.isDraggingToSplit &&
        prev.leftPaneWidth === next.leftPaneWidth &&
        prev.isSplitResizing === next.isSplitResizing &&
        prev.mediaType === next.mediaType
    );
});
