import React, { forwardRef } from 'react';
import { themeColors } from '../colorExtractor';
import { colors } from '../colors';

interface PrimaryButtonProps
    extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    children: React.ReactNode;
    icon?: React.ReactNode;
}

export const PrimaryButton = forwardRef<HTMLButtonElement, PrimaryButtonProps>(
    ({ children, icon, ...props }, ref) => {
        const primaryColor = colors.primary.default;
        const borderRadius = themeColors.borderRadius.component;

        return (
            <button
                ref={ref}
                className="inline-flex items-center justify-center gap-2 px-3 py-1.5 text-sm font-medium text-neutral-300 transition-all duration-150 hover:opacity-90 active:scale-95"
                style={{
                    backgroundColor: primaryColor,
                    borderRadius: borderRadius,
                } as React.CSSProperties}
                {...props}
            >
                {icon}
                {children}
            </button>
        );
    }
);

PrimaryButton.displayName = 'PrimaryButton';

export default PrimaryButton;
