import { useState, useRef, useEffect, useCallback } from 'react';
import type { ActivePane } from '../types';

export const useSplitView = () => {
    const [splitView, setSplitView] = useState(false);
    const [splitFilePath, setSplitFilePath] = useState<string | null>(null);
    const [activePane, setActivePane] = useState<ActivePane>('main');
    const [leftPaneWidth, setLeftPaneWidth] = useState(50);
    const [isSplitResizing, setIsSplitResizing] = useState(false);

    const splitContainerRef = useRef<HTMLDivElement>(null);
    const mainPaneRef = useRef<HTMLDivElement>(null);
    const splitPaneRef = useRef<HTMLDivElement>(null);
    const activePaneRef = useRef<ActivePane>('main');
    const splitFileRef = useRef<string | null>(null);
    const resizeRafRef = useRef<number | null>(null);
    const resizeRectRef = useRef<DOMRect | null>(null);
    const pendingLeftWidthRef = useRef<number | null>(null);

    useEffect(() => {
        activePaneRef.current = activePane;
    }, [activePane]);

    useEffect(() => {
        splitFileRef.current = splitFilePath;
    }, [splitFilePath]);

    const setActivePaneState = useCallback((pane: ActivePane) => {
        activePaneRef.current = pane;
        setActivePane(pane);
    }, []);

    const handleSplitResizeStart = useCallback((e: React.MouseEvent) => {
        e.preventDefault();
        resizeRectRef.current = splitContainerRef.current?.getBoundingClientRect() ?? null;
        setIsSplitResizing(true);
    }, []);

    const handleSplitResizeMove = useCallback((e: MouseEvent) => {
        if (!resizeRectRef.current) return;
        const containerWidth = resizeRectRef.current.width;
        const offsetX = e.clientX - resizeRectRef.current.left;
        const pct = Math.max(20, Math.min(80, (offsetX / containerWidth) * 100));
        pendingLeftWidthRef.current = pct;

        if (resizeRafRef.current !== null) return;
        resizeRafRef.current = requestAnimationFrame(() => {
            resizeRafRef.current = null;
            if (pendingLeftWidthRef.current !== null) {
                if (mainPaneRef.current) {
                    mainPaneRef.current.style.flex = `0 0 ${pendingLeftWidthRef.current}%`;
                    mainPaneRef.current.style.maxWidth = `${pendingLeftWidthRef.current}%`;
                }
                if (splitPaneRef.current) {
                    splitPaneRef.current.style.flex = `0 0 ${100 - pendingLeftWidthRef.current}%`;
                    splitPaneRef.current.style.maxWidth = `${100 - pendingLeftWidthRef.current}%`;
                }
            }
        });
    }, []);

    const handleSplitResizeEnd = useCallback(() => {
        if (resizeRafRef.current !== null) {
            cancelAnimationFrame(resizeRafRef.current);
            resizeRafRef.current = null;
        }
        if (pendingLeftWidthRef.current !== null) {
            setLeftPaneWidth(pendingLeftWidthRef.current);
        }
        pendingLeftWidthRef.current = null;
        resizeRectRef.current = null;
        setIsSplitResizing(false);
    }, []);

    useEffect(() => {
        if (isSplitResizing) {
            window.addEventListener('mousemove', handleSplitResizeMove);
            window.addEventListener('mouseup', handleSplitResizeEnd);
            document.body.style.cursor = 'col-resize';
            document.body.style.userSelect = 'none';
        } else {
            window.removeEventListener('mousemove', handleSplitResizeMove);
            window.removeEventListener('mouseup', handleSplitResizeEnd);
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        }

        return () => {
            window.removeEventListener('mousemove', handleSplitResizeMove);
            window.removeEventListener('mouseup', handleSplitResizeEnd);
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
        };
    }, [isSplitResizing, handleSplitResizeMove, handleSplitResizeEnd]);

    const closeSplitView = useCallback(() => {
        setSplitView(false);
        setSplitFilePath(null);
        setActivePaneState('main');
    }, [setActivePaneState]);

    return {
        splitView,
        setSplitView,
        splitFilePath,
        setSplitFilePath,
        activePane,
        setActivePane,
        setActivePaneState,
        activePaneRef,
        splitFileRef,
        leftPaneWidth,
        setLeftPaneWidth,
        isSplitResizing,
        splitContainerRef,
        mainPaneRef,
        splitPaneRef,
        handleSplitResizeStart,
        closeSplitView,
    };
};
