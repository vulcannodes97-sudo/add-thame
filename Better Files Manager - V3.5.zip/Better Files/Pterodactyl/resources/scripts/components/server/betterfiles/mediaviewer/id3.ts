import { ParsedAudioMetadata } from './types';
import { toArrayBuffer } from './utils';

const decodeTextFrame = (bytes: Uint8Array, encoding: number): string => {
    if (!bytes.length) return '';
    let decoder: TextDecoder;
    try {
        if (encoding === 0) decoder = new TextDecoder('iso-8859-1');
        else if (encoding === 1) decoder = new TextDecoder('utf-16');
        else if (encoding === 2) decoder = new TextDecoder('utf-16be');
        else decoder = new TextDecoder('utf-8');
    } catch {
        decoder = new TextDecoder('utf-8');
    }
    return decoder.decode(bytes).replace(/\0/g, '').trim();
};

const readSynchsafe = (bytes: Uint8Array, offset: number): number => {
    return ((bytes[offset] & 0x7f) << 21)
        | ((bytes[offset + 1] & 0x7f) << 14)
        | ((bytes[offset + 2] & 0x7f) << 7)
        | (bytes[offset + 3] & 0x7f);
};

const writeSynchsafe = (value: number): Uint8Array => {
    const safeValue = Math.max(0, value);
    return new Uint8Array([
        (safeValue >> 21) & 0x7f,
        (safeValue >> 14) & 0x7f,
        (safeValue >> 7) & 0x7f,
        safeValue & 0x7f,
    ]);
};

const readInt32 = (bytes: Uint8Array, offset: number): number => {
    return (bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];
};

const findTerminator = (bytes: Uint8Array, start: number, encoding: number): number => {
    if (encoding === 0 || encoding === 3) {
        for (let i = start; i < bytes.length; i += 1) {
            if (bytes[i] === 0x00) return i;
        }
        return bytes.length;
    }
    for (let i = start; i + 1 < bytes.length; i += 2) {
        if (bytes[i] === 0x00 && bytes[i + 1] === 0x00) return i;
    }
    return bytes.length;
};

export const parseId3Metadata = (buffer: ArrayBuffer): ParsedAudioMetadata | null => {
    const bytes = new Uint8Array(buffer);
    if (bytes.length < 10) return null;
    if (bytes[0] !== 0x49 || bytes[1] !== 0x44 || bytes[2] !== 0x33) return null;

    const version = bytes[3];
    const tagSize = readSynchsafe(bytes, 6);
    const tagEnd = Math.min(bytes.length, 10 + tagSize);
    let offset = 10;

    const metadata: ParsedAudioMetadata = {};

    while (offset + 10 <= tagEnd) {
        const frameId = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]);
        if (!frameId.trim()) break;
        const frameSize = version === 4 ? readSynchsafe(bytes, offset + 4) : readInt32(bytes, offset + 4);
        if (frameSize <= 0) break;
        const frameStart = offset + 10;
        const frameEnd = frameStart + frameSize;
        if (frameEnd > tagEnd) break;

        if (frameId === 'TIT2' || frameId === 'TPE1' || frameId === 'TALB') {
            const encoding = bytes[frameStart];
            const text = decodeTextFrame(bytes.slice(frameStart + 1, frameEnd), encoding);
            if (frameId === 'TIT2' && text) metadata.title = text;
            if (frameId === 'TPE1' && text) metadata.artist = text;
            if (frameId === 'TALB' && text) metadata.album = text;
        } else if (frameId === 'APIC') {
            const encoding = bytes[frameStart];
            let cursor = frameStart + 1;
            const mimeEnd = bytes.indexOf(0x00, cursor);
            const safeMimeEnd = mimeEnd === -1 ? frameEnd : mimeEnd;
            const mime = safeMimeEnd > cursor
                ? new TextDecoder('utf-8').decode(bytes.slice(cursor, safeMimeEnd))
                : 'image/jpeg';
            cursor = safeMimeEnd + 1;
            cursor += 1;
            const descEnd = findTerminator(bytes, cursor, encoding);
            cursor = descEnd + (encoding === 0 || encoding === 3 ? 1 : 2);
            if (cursor < frameEnd) {
                metadata.picture = {
                    mime: mime || 'image/jpeg',
                    data: bytes.slice(cursor, frameEnd),
                };
            }
        }

        offset = frameEnd;
    }

    return metadata;
};

const concatBytes = (...chunks: Uint8Array[]): Uint8Array => {
    const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
    const output = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
        output.set(chunk, offset);
        offset += chunk.length;
    }
    return output;
};

const buildId3Frame = (id: string, payload: Uint8Array): Uint8Array => {
    const header = new Uint8Array(10);
    header[0] = id.charCodeAt(0);
    header[1] = id.charCodeAt(1);
    header[2] = id.charCodeAt(2);
    header[3] = id.charCodeAt(3);
    header.set(writeSynchsafe(payload.length), 4);
    header[8] = 0x00;
    header[9] = 0x00;
    return concatBytes(header, payload);
};

export const buildTextFrame = (id: string, value: string): Uint8Array | null => {
    const trimmed = value.trim();
    if (!trimmed) return null;
    const encoder = new TextEncoder();
    const textBytes = encoder.encode(trimmed);
    const payload = new Uint8Array(1 + textBytes.length);
    payload[0] = 0x03;
    payload.set(textBytes, 1);
    return buildId3Frame(id, payload);
};

export const buildApicFrame = (mime: string, imageBytes: Uint8Array): Uint8Array => {
    const encoder = new TextEncoder();
    const mimeBytes = encoder.encode(mime || 'image/jpeg');
    const payload = new Uint8Array(1 + mimeBytes.length + 1 + 1 + 1 + imageBytes.length);
    let offset = 0;
    payload[offset++] = 0x03;
    payload.set(mimeBytes, offset);
    offset += mimeBytes.length;
    payload[offset++] = 0x00;
    payload[offset++] = 0x03;
    payload[offset++] = 0x00;
    payload.set(imageBytes, offset);
    return buildId3Frame('APIC', payload);
};

export const stripId3Tag = (bytes: Uint8Array): Uint8Array => {
    if (bytes.length < 10) return bytes;
    if (bytes[0] !== 0x49 || bytes[1] !== 0x44 || bytes[2] !== 0x33) return bytes;
    const tagSize = readSynchsafe(bytes, 6);
    const start = Math.min(bytes.length, 10 + tagSize);
    return bytes.slice(start);
};

export const buildId3Tag = (frames: Uint8Array[]): Uint8Array => {
    const tagSize = frames.reduce((sum, frame) => sum + frame.length, 0);
    const header = new Uint8Array(10);
    header[0] = 0x49;
    header[1] = 0x44;
    header[2] = 0x33;
    header[3] = 0x04;
    header[4] = 0x00;
    header[5] = 0x00;
    header.set(writeSynchsafe(tagSize), 6);
    return concatBytes(header, ...frames);
};

export const createArtworkUrl = (picture: { mime: string; data: Uint8Array } | undefined): string | null => {
    if (!picture?.data || picture.data.length === 0) return null;
    const imageBlob = new Blob([toArrayBuffer(picture.data)], { type: picture.mime || 'image/jpeg' });
    return URL.createObjectURL(imageBlob);
};

export const loadMetadataFromBlob = async (blob: Blob): Promise<ParsedAudioMetadata | null> => {
    const maxBytes = 512 * 1024;
    const slice = blob.slice(0, Math.min(maxBytes, blob.size));
    const buffer = await slice.arrayBuffer();
    return parseId3Metadata(buffer);
};

export const loadMetadataFromStream = async (src: string, signal?: AbortSignal): Promise<ParsedAudioMetadata | null> => {
    const res = await fetch(src, {
        headers: { Range: 'bytes=0-524287' },
        signal,
    });
    if (!res.ok) throw new Error('stream metadata fetch failed');
    const buffer = await res.arrayBuffer();
    return parseId3Metadata(buffer);
};
