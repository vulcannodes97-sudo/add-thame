import React, { useState, useEffect, useRef, useCallback } from 'react';
import Input from '@/components/elements/Input';
import { Dialog } from '@/components/elements/dialog';
import { Button } from '@/components/elements/button/index';
import { colors } from '../colors';
import { themeColors } from '../colorExtractor';
import {
    AudioPlayerContainer,
    VisualizerCanvas,
    AudioContent,
    BeatNotesLayer,
    ArtworkStack,
    VinylDisk,
    AudioArtwork,
    AudioIconWrapper,
    WaveformCanvas,
    VolumeSlider,
    RateSlider,
} from './styles';
import { AudioPlayerProps, ParsedAudioMetadata } from './types';
import {
    formatTime,
    readStoredVolume,
    writeStoredVolume,
    applyMediaSettings,
    globalAudioRegistry,
    syncAllAudio,
    syncSeekAll,
    syncSkipAll,
    toArrayBuffer,
} from './utils';
import {
    parseId3Metadata,
    buildTextFrame,
    buildApicFrame,
    stripId3Tag,
    buildId3Tag,
    createArtworkUrl,
    loadMetadataFromBlob,
    loadMetadataFromStream,
} from './id3';
import { createWaveformState, drawVisualizer, drawTimeline, emitBeatNote, type WaveformPalette, type WaveformState } from './waveform';

const MAX_METADATA_EDIT_SIZE = 25 * 1024 * 1024;
const ARTWORK_SAMPLE_SIZE = 40;
const MIN_DARK_ACCENT_POPULATION = 0.035;

type RgbColor = [number, number, number];

const clampChannel = (value: number) => Math.max(0, Math.min(255, Math.round(value)));
const toRgb = (color: RgbColor) => `rgb(${clampChannel(color[0])}, ${clampChannel(color[1])}, ${clampChannel(color[2])})`;

const getLuminance = (color: RgbColor) => {
    const [r, g, b] = color.map((channel) => {
        const value = channel / 255;
        return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
    });

    return r * 0.2126 + g * 0.7152 + b * 0.0722;
};

const getSaturation = (color: RgbColor) => {
    const r = color[0] / 255;
    const g = color[1] / 255;
    const b = color[2] / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    if (max === min) return 0;
    const lightness = (max + min) / 2;
    return (max - min) / (1 - Math.abs(2 * lightness - 1));
};

const mixRgb = (color: RgbColor, target: RgbColor, amount: number): RgbColor => [
    color[0] + (target[0] - color[0]) * amount,
    color[1] + (target[1] - color[1]) * amount,
    color[2] + (target[2] - color[2]) * amount,
];

const scaleRgb = (color: RgbColor, amount: number): RgbColor => [
    clampChannel(color[0] * amount),
    clampChannel(color[1] * amount),
    clampChannel(color[2] * amount),
];

const clampAccentVisibility = (color: RgbColor): RgbColor => {
    let next = color;
    for (let i = 0; i < 8 && getLuminance(next) < 0.13; i++) {
        next = mixRgb(next, [255, 255, 255], 0.08);
    }
    for (let i = 0; i < 8 && getLuminance(next) > 0.42; i++) {
        next = mixRgb(next, [0, 0, 0], 0.08);
    }
    return next;
};

const pickArtworkWaveformPalette = (imageData: ImageData): WaveformPalette | null => {
    const buckets = new Map<string, { count: number; sum: RgbColor }>();
    let visiblePixels = 0;

    for (let i = 0; i < imageData.data.length; i += 4) {
        const alpha = imageData.data[i + 3];
        if (alpha < 180) continue;

        visiblePixels++;
        const color: RgbColor = [imageData.data[i], imageData.data[i + 1], imageData.data[i + 2]];
        const luminance = getLuminance(color);
        const saturation = getSaturation(color);

        if (luminance < 0.08 || luminance > 0.48 || saturation < 0.22) continue;

        const keyColor = color.map((channel) => Math.round(channel / 24) * 24) as RgbColor;
        const key = keyColor.join(',');
        const bucket = buckets.get(key) || { count: 0, sum: [0, 0, 0] as RgbColor };
        bucket.count++;
        bucket.sum = [
            bucket.sum[0] + color[0],
            bucket.sum[1] + color[1],
            bucket.sum[2] + color[2],
        ];
        buckets.set(key, bucket);
    }

    if (!visiblePixels) return null;

    let selectedColor: RgbColor | null = null;
    let selectedCount = 0;
    let selectedLuminance = 1;
    buckets.forEach((bucket) => {
        const population = bucket.count / visiblePixels;
        if (population < MIN_DARK_ACCENT_POPULATION) return;

        const color: RgbColor = [
            bucket.sum[0] / bucket.count,
            bucket.sum[1] / bucket.count,
            bucket.sum[2] / bucket.count,
        ];
        const luminance = getLuminance(color);
        if (!selectedColor || luminance < selectedLuminance || (Math.abs(luminance - selectedLuminance) < 0.035 && bucket.count > selectedCount)) {
            selectedColor = color;
            selectedCount = bucket.count;
            selectedLuminance = luminance;
        }
    });

    if (!selectedColor) return null;

    const base = clampAccentVisibility(selectedColor);
    return {
        dark: toRgb(scaleRgb(base, 0.58)),
        default: toRgb(base),
        light: toRgb(mixRgb(base, [255, 255, 255], 0.34)),
    };
};

const AudioPlayer: React.FC<AudioPlayerProps> = ({
    src,
    blobUrl,
    blob,
    blobPartial,
    isStreaming,
    resumeState,
    filePath,
    uuid,
    fileName,
    onRequestFullDownload,
    onError,
    onTimeUpdate,
    onPlayingChange,
}) => {
    const audioRef = useRef<HTMLAudioElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const timelineCanvasRef = useRef<HTMLCanvasElement>(null);
    const iconRef = useRef<HTMLElement | null>(null);
    const audioStageRef = useRef<HTMLDivElement>(null);
    const playerIdRef = useRef<string>(`audio-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`);
    const waveformStateRef = useRef<WaveformState>(createWaveformState());
    const notesLayerRef = useRef<HTMLDivElement>(null);
    const onPlayingChangeRef = useRef<typeof onPlayingChange>();
    const animationRef = useRef<number>();
    const analyserRef = useRef<AnalyserNode>();
    const audioContextRef = useRef<AudioContext | null>(null);
    const sourceRef = useRef<MediaElementAudioSourceNode>();
    const pendingResumeRef = useRef<{ time: number; wasPlaying: boolean } | null>(null);
    const lastSrcRef = useRef<string | null>(null);
    const editCoverPreviewRef = useRef<string | null>(null);
    const coverInputRef = useRef<HTMLInputElement>(null);
    const artworkUrlRef = useRef<string | null>(null);
    const isScrubbingRef = useRef(false);
    const scrubRafRef = useRef<number | null>(null);

    const [playing, setPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [buffered, setBuffered] = useState(0);
    const [volume, setVolume] = useState(() => readStoredVolume());
    const [muted, setMuted] = useState(false);
    const [playbackRate, setPlaybackRate] = useState(1);
    const [syncCount, setSyncCount] = useState(0);
    const [metadata, setMetadata] = useState<ParsedAudioMetadata | null>(null);
    const [artworkUrl, setArtworkUrl] = useState<string | null>(null);
    const [showEditModal, setShowEditModal] = useState(false);
    const [editTitle, setEditTitle] = useState('');
    const [editArtist, setEditArtist] = useState('');
    const [editAlbum, setEditAlbum] = useState('');
    const [editCoverFile, setEditCoverFile] = useState<File | null>(null);
    const [editCoverPreview, setEditCoverPreview] = useState<string | null>(null);
    const [coverMode, setCoverMode] = useState<'none' | 'existing' | 'new'>('none');
    const [editError, setEditError] = useState<string | null>(null);
    const [editSaving, setEditSaving] = useState(false);
    const [editProgress, setEditProgress] = useState(0);
    const [seekPreview, setSeekPreview] = useState<number | null>(null);
    const [artworkColors, setArtworkColors] = useState<{ tl: string; tr: string; bl: string; br: string } | null>(null);
    const [waveformPalette, setWaveformPalette] = useState<WaveformPalette | null>(null);
    const [ambientRotation, setAmbientRotation] = useState(0);

    const lastVolumeRef = useRef(readStoredVolume());
    const lastMutedRef = useRef(false);
    const lastRateRef = useRef(1);
    const rotationRef = useRef(0);

    const isMp3 = (fileName || '').toLowerCase().endsWith('.mp3');
    const canEditMetadata = !!blob && !blobPartial && isMp3 && blob.size <= MAX_METADATA_EDIT_SIZE;
    const needsFullDownload = !canEditMetadata && (isStreaming || blobPartial || !blob);

    useEffect(() => {
        const playerId = playerIdRef.current;
        globalAudioRegistry.set(playerId, {
            play: () => audioRef.current?.play(),
            pause: () => audioRef.current?.pause(),
            seek: (time: number) => { if (audioRef.current) audioRef.current.currentTime = time; },
            skip: (delta: number) => { if (audioRef.current) audioRef.current.currentTime += delta; },
            isPlaying: () => playing,
            getCurrentTime: () => audioRef.current?.currentTime || 0,
        });
        setSyncCount(globalAudioRegistry.size);

        const interval = setInterval(() => setSyncCount(globalAudioRegistry.size), 500);

        return () => {
            globalAudioRegistry.delete(playerId);
            clearInterval(interval);
        };
    }, [playing]);

    useEffect(() => {
        onPlayingChangeRef.current = onPlayingChange;
    }, [onPlayingChange]);

    useEffect(() => {
        let active = true;
        const controller = new AbortController();
        
        const resetArtwork = () => {
            if (artworkUrlRef.current) {
                URL.revokeObjectURL(artworkUrlRef.current);
                artworkUrlRef.current = null;
            }
        };
        
        const setParsedArtwork = (parsed: ParsedAudioMetadata | null) => {
            resetArtwork();
            const url = createArtworkUrl(parsed?.picture);
            if (url) {
                artworkUrlRef.current = url;
                setArtworkUrl(url);
            } else {
                setArtworkUrl(null);
            }
        };

        const loadMetadata = async () => {
            if (blob && !blobPartial) {
                const parsed = await loadMetadataFromBlob(blob);
                if (!active) return;
                setMetadata(parsed);
                setParsedArtwork(parsed);
                return;
            }
            if (isStreaming && src) {
                try {
                    const parsed = await loadMetadataFromStream(src, controller.signal);
                    if (!active) return;
                    setMetadata(parsed);
                    setParsedArtwork(parsed);
                } catch {
                    if (!active) return;
                    setMetadata(null);
                    resetArtwork();
                    setArtworkUrl(null);
                }
                return;
            }
            setMetadata(null);
            resetArtwork();
            setArtworkUrl(null);
        };

        loadMetadata();
        return () => {
            active = false;
            controller.abort();
            resetArtwork();
        };
    }, [blob, blobPartial, fileName, isStreaming, src]);

    useEffect(() => {
        if (!artworkUrl) {
            setArtworkColors(null);
            setWaveformPalette(null);
            return;
        }

        let active = true;
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = artworkUrl;

        const canvas = document.createElement('canvas');
        canvas.width = ARTWORK_SAMPLE_SIZE;
        canvas.height = ARTWORK_SAMPLE_SIZE;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) {
            setArtworkColors(null);
            setWaveformPalette(null);
            return;
        }

        const sample = () => {
            if (!active) return;
            try {
                ctx.drawImage(img, 0, 0, ARTWORK_SAMPLE_SIZE, ARTWORK_SAMPLE_SIZE);
                const getRgb = (x: number, y: number) => {
                    const data = ctx.getImageData(x, y, 1, 1).data;
                    return [data[0], data[1], data[2]];
                };
                const maxPixel = ARTWORK_SAMPLE_SIZE - 1;
                const corners = {
                    tl: getRgb(0, 0),
                    tr: getRgb(maxPixel, 0),
                    bl: getRgb(0, maxPixel),
                    br: getRgb(maxPixel, maxPixel),
                };
                const toRgb = (arr: number[]) => `rgb(${Math.round(arr[0])}, ${Math.round(arr[1])}, ${Math.round(arr[2])})`;
                setArtworkColors({
                    tl: toRgb(corners.tl),
                    tr: toRgb(corners.tr),
                    bl: toRgb(corners.bl),
                    br: toRgb(corners.br),
                });
                setWaveformPalette(pickArtworkWaveformPalette(ctx.getImageData(0, 0, ARTWORK_SAMPLE_SIZE, ARTWORK_SAMPLE_SIZE)));
            } catch {
                setArtworkColors(null);
                setWaveformPalette(null);
            }
        };

        if (img.complete) sample();
        else {
            img.onload = sample;
            img.onerror = () => {
                if (active) {
                    setArtworkColors(null);
                    setWaveformPalette(null);
                }
            };
        }

        return () => {
            active = false;
        };
    }, [artworkUrl]);

    const applySettings = (audio: HTMLAudioElement) => {
        applyMediaSettings(audio, lastVolumeRef.current, lastMutedRef.current, lastRateRef.current);
    };

    const handleBeat = useCallback((strength: number) => {
        const layer = notesLayerRef.current;
        if (layer) {
            emitBeatNote(layer, strength, waveformPalette?.default || colors.primary.default);
        }
        if (artworkColors) {
            const step = 6 + Math.min(12, Math.max(0, strength * 10));
            rotationRef.current = (rotationRef.current + step) % 360;
            setAmbientRotation(rotationRef.current);
        }
    }, [artworkColors, waveformPalette]);

    const handleBeatZoomChange = useCallback((zoom: number) => {
        const beatAmount = Math.max(0, zoom - 1);
        const stageScale = 1 + beatAmount * 0.2;
        const canvasScaleX = 1 + beatAmount * 0.12;
        const canvasScaleY = 1 + beatAmount * 0.22;
        if (audioStageRef.current) {
            audioStageRef.current.style.transform = `scale(${stageScale})`;
        }
        if (canvasRef.current) {
            canvasRef.current.style.transform = `scale3d(${canvasScaleX}, ${canvasScaleY}, 1)`;
        }
    }, []);

    const runVisualizer = useCallback(() => {
        if (!canvasRef.current || !analyserRef.current) return;
        
        const draw = () => {
            if (!canvasRef.current || !analyserRef.current) {
                if (animationRef.current) {
                    cancelAnimationFrame(animationRef.current);
                    animationRef.current = undefined;
                }
                return;
            }
            
            animationRef.current = requestAnimationFrame(draw);
            
            drawVisualizer({
                canvas: canvasRef.current,
                analyser: analyserRef.current,
                state: waveformStateRef.current,
                intensity: audioRef.current?.muted ? 0 : audioRef.current?.volume ?? 1,
                palette: waveformPalette || undefined,
                onBeat: handleBeat,
                onBeatZoomChange: handleBeatZoomChange,
            });

            if (timelineCanvasRef.current && analyserRef.current) {
                const audio = audioRef.current;
                const rawDuration = audio?.duration;
                const timelineDuration = Number.isFinite(rawDuration) && (rawDuration as number) > 0
                    ? (rawDuration as number)
                    : duration;
                    
                drawTimeline({
                    canvas: timelineCanvasRef.current,
                    analyser: analyserRef.current,
                    currentTime: audio?.currentTime || 0,
                    duration: timelineDuration,
                    buffered: audio?.buffered || null,
                });
            }
        };
        draw();
    }, [duration, handleBeat, handleBeatZoomChange, waveformPalette]);

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio) return;

        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContext && !sourceRef.current) {
            const audioCtx = new AudioContext();
            const analyser = audioCtx.createAnalyser();
            analyser.fftSize = 1024;
            analyser.smoothingTimeConstant = 0.65;
            analyser.minDecibels = -85;
            analyser.maxDecibels = -8;

            try {
                const source = audioCtx.createMediaElementSource(audio);
                source.connect(analyser);
                analyser.connect(audioCtx.destination);
                audioContextRef.current = audioCtx;
                sourceRef.current = source;
                analyserRef.current = analyser;
            } catch (e) {
                console.error("Web Audio API setup failed:", e);
            }
        }

        const updateTime = () => setCurrentTime(audio.currentTime);
        const updateDuration = () => {
            setDuration(audio.duration);
            applySettings(audio);
            if (pendingResumeRef.current) {
                const resume = pendingResumeRef.current;
                const target = Math.min(resume.time, Math.max(0, audio.duration - 0.1));
                if (!Number.isNaN(target)) {
                    audio.currentTime = target;
                }
                if (resume.wasPlaying) {
                    const promise = audio.play();
                    if (promise && typeof promise.catch === 'function') {
                        promise.catch(() => {});
                    }
                }
                pendingResumeRef.current = null;
            }
        };
        const updateBuffered = () => {
            if (audio.buffered.length > 0 && audio.duration > 0) {
                const end = audio.buffered.end(audio.buffered.length - 1);
                setBuffered(end);
            }
        };
        const onPlay = () => {
            setPlaying(true);
            if (audioContextRef.current?.state === 'suspended') {
                audioContextRef.current.resume().catch(() => {});
            }
            runVisualizer();
            onPlayingChangeRef.current?.(true);
        };
        const onPause = () => {
            setPlaying(false);
            if (animationRef.current) cancelAnimationFrame(animationRef.current);
            if (audioStageRef.current) {
                audioStageRef.current.style.transform = 'scale(1)';
            }
            if (canvasRef.current) {
                canvasRef.current.style.transform = 'scale(1)';
            }
            onPlayingChangeRef.current?.(false);
        };
        const onVolumeChange = () => {
            setVolume(audio.volume);
            setMuted(audio.muted);
        };
        const onRateChange = () => {
            setPlaybackRate(audio.playbackRate);
        };

        audio.addEventListener('timeupdate', updateTime);
        audio.addEventListener('progress', updateBuffered);
        audio.addEventListener('loadedmetadata', updateDuration);
        audio.addEventListener('durationchange', updateDuration);
        audio.addEventListener('seeked', updateTime);
        audio.addEventListener('play', onPlay);
        audio.addEventListener('pause', onPause);
        audio.addEventListener('volumechange', onVolumeChange);
        audio.addEventListener('ratechange', onRateChange);

        if (!audio.paused) {
            setPlaying(true);
            runVisualizer();
        }

        return () => {
            audio.removeEventListener('timeupdate', updateTime);
            audio.removeEventListener('progress', updateBuffered);
            audio.removeEventListener('loadedmetadata', updateDuration);
            audio.removeEventListener('durationchange', updateDuration);
            audio.removeEventListener('seeked', updateTime);
            audio.removeEventListener('play', onPlay);
            audio.removeEventListener('pause', onPause);
            audio.removeEventListener('volumechange', onVolumeChange);
            audio.removeEventListener('ratechange', onRateChange);
            if (animationRef.current) cancelAnimationFrame(animationRef.current);
        };
    }, [src, runVisualizer]);

    useEffect(() => {
        const audio = audioRef.current;
        if (!audio || !src) return;
        const previousSrc = lastSrcRef.current;
        if (previousSrc && previousSrc !== src && isStreaming && resumeState) {
            pendingResumeRef.current = { time: resumeState.time, wasPlaying: resumeState.wasPlaying };
        }
        if (previousSrc && previousSrc !== src) {
            waveformStateRef.current = createWaveformState();
            setBuffered(0);
            if (audioStageRef.current) audioStageRef.current.style.transform = 'scale(1)';
            if (canvasRef.current) canvasRef.current.style.transform = 'scale(1)';
            try {
                audio.load();
            } catch {}
        }
        applySettings(audio);
        lastSrcRef.current = src;
    }, [isStreaming, resumeState, src]);

    useEffect(() => {
        lastVolumeRef.current = volume;
        writeStoredVolume(volume);
    }, [volume]);

    useEffect(() => {
        lastMutedRef.current = muted;
    }, [muted]);

    useEffect(() => {
        lastRateRef.current = playbackRate;
    }, [playbackRate]);

    useEffect(() => {
        onTimeUpdate?.(currentTime);
    }, [currentTime, onTimeUpdate]);

    useEffect(() => {
        if (playing) {
            runVisualizer();
        }
    }, [playing, runVisualizer]);

    const togglePlay = () => {
        if (audioRef.current) {
            if (playing) audioRef.current.pause();
            else audioRef.current.play();
        }
    };

    const getSafeDuration = () => {
        const audio = audioRef.current;
        if (!audio) return duration;
        const next = audio.duration;
        return Number.isFinite(next) && next > 0 ? next : duration;
    };

    const seekToClientX = (clientX: number, element: HTMLElement) => {
        const audio = audioRef.current;
        if (!audio) return;
        const rect = element.getBoundingClientRect();
        const percent = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
        const nextDuration = getSafeDuration();
        if (!nextDuration || !Number.isFinite(nextDuration)) return;
        const nextTime = percent * nextDuration;
        audio.currentTime = nextTime;
        setCurrentTime(nextTime);
        setSeekPreview(nextTime);
    };

    const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
        seekToClientX(e.clientX, e.currentTarget);
    };

    const skipTime = (delta: number) => {
        const audio = audioRef.current;
        if (!audio) return;
        const nextDuration = getSafeDuration();
        const nextTime = Math.max(0, Math.min(nextDuration || audio.currentTime + delta, audio.currentTime + delta));
        audio.currentTime = nextTime;
        setCurrentTime(nextTime);
    };

    const handleScrubPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
        if (e.button !== 0) return;
        isScrubbingRef.current = true;
        (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
        seekToClientX(e.clientX, e.currentTarget);
    };

    const handleScrubPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
        if (!isScrubbingRef.current) return;
        if (scrubRafRef.current) cancelAnimationFrame(scrubRafRef.current);
        const target = e.currentTarget;
        const x = e.clientX;
        scrubRafRef.current = requestAnimationFrame(() => {
            seekToClientX(x, target);
        });
    };

    const handleScrubPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
        if (!isScrubbingRef.current) return;
        isScrubbingRef.current = false;
        (e.currentTarget as HTMLDivElement).releasePointerCapture(e.pointerId);
        if (scrubRafRef.current) {
            cancelAnimationFrame(scrubRafRef.current);
            scrubRafRef.current = null;
        }
        setSeekPreview(null);
    };

    const handleVolumeChange = (nextVolume: number) => {
        if (!audioRef.current) return;
        audioRef.current.volume = nextVolume;
        audioRef.current.muted = nextVolume === 0;
    };

    const handleRateChange = (nextRate: number) => {
        if (!audioRef.current) return;
        audioRef.current.playbackRate = nextRate;
        (audioRef.current as any).preservesPitch = false;
        (audioRef.current as any).mozPreservesPitch = false;
        (audioRef.current as any).webkitPreservesPitch = false;
    };

    const resetEditPreview = () => {
        if (editCoverPreviewRef.current) {
            URL.revokeObjectURL(editCoverPreviewRef.current);
            editCoverPreviewRef.current = null;
        }
    };

    const openEditModal = () => {
        resetEditPreview();
        setEditTitle(metadata?.title || '');
        setEditArtist(metadata?.artist || '');
        setEditAlbum(metadata?.album || '');
        setEditCoverFile(null);
        setCoverMode(metadata?.picture ? 'existing' : 'none');
        setEditCoverPreview(metadata?.picture ? artworkUrl : null);
        setEditError(null);
        setEditProgress(0);
        setShowEditModal(true);
        if (!canEditMetadata && (isStreaming || blobPartial || !blob)) {
            onRequestFullDownload?.();
        }
    };

    useEffect(() => {
        const maybeOpenFromEvent = (path?: string) => {
            if (!path || path !== filePath) return;
            openEditModal();
            if (typeof window !== 'undefined') {
                (window as any).__bfmEditAudioMetadataPath = null;
            }
        };

        const pending = typeof window !== 'undefined' ? (window as any).__bfmEditAudioMetadataPath : null;
        if (pending) {
            maybeOpenFromEvent(pending);
        }

        const handleEvent = (event: Event) => {
            const detail = (event as CustomEvent).detail as { path?: string } | undefined;
            maybeOpenFromEvent(detail?.path);
        };

        window.addEventListener('bfm:edit-audio-metadata', handleEvent as EventListener);
        return () => {
            window.removeEventListener('bfm:edit-audio-metadata', handleEvent as EventListener);
        };
    }, [filePath, openEditModal]);

    const closeEditModal = () => {
        resetEditPreview();
        setEditCoverFile(null);
        setEditCoverPreview(null);
        setEditError(null);
        setShowEditModal(false);
    };

    const handleCoverSelect = (file?: File) => {
        if (!file) return;
        resetEditPreview();
        const url = URL.createObjectURL(file);
        editCoverPreviewRef.current = url;
        setEditCoverFile(file);
        setEditCoverPreview(url);
        setCoverMode('new');
    };

    const handleRemoveCover = () => {
        resetEditPreview();
        setEditCoverFile(null);
        setEditCoverPreview(null);
        setCoverMode('none');
    };

    const handleSaveMetadata = async () => {
        if (!blob || !filePath || !uuid) return;
        if (!canEditMetadata) {
            setEditError('Metadata edits are only available for MP3 files under 25 MB.');
            return;
        }
        setEditSaving(true);
        setEditError(null);
        setEditProgress(0);
        try {
            const audioBuffer = await blob.arrayBuffer();
            const audioBytes = stripId3Tag(new Uint8Array(audioBuffer));

            const frames: Uint8Array[] = [];
            const titleFrame = buildTextFrame('TIT2', editTitle);
            const artistFrame = buildTextFrame('TPE1', editArtist);
            const albumFrame = buildTextFrame('TALB', editAlbum);
            if (titleFrame) frames.push(titleFrame);
            if (artistFrame) frames.push(artistFrame);
            if (albumFrame) frames.push(albumFrame);

            let picture: ParsedAudioMetadata['picture'] | null = null;
            if (coverMode === 'new' && editCoverFile) {
                const coverBuffer = await editCoverFile.arrayBuffer();
                picture = {
                    mime: editCoverFile.type || 'image/jpeg',
                    data: new Uint8Array(coverBuffer),
                };
            } else if (coverMode === 'existing' && metadata?.picture?.data) {
                picture = metadata.picture;
            }

            if (picture?.data?.length) {
                frames.push(buildApicFrame(picture.mime, picture.data));
            }

            let outputBytes = audioBytes;
            if (frames.length > 0) {
                const tagBytes = buildId3Tag(frames);
                const total = tagBytes.length + audioBytes.length;
                outputBytes = new Uint8Array(total);
                outputBytes.set(tagBytes, 0);
                outputBytes.set(audioBytes, tagBytes.length);
            }

            if (outputBytes.length > MAX_METADATA_EDIT_SIZE) {
                throw new Error('Edited file exceeds the 25 MB limit.');
            }

            const outputBlob = new Blob([toArrayBuffer(outputBytes)], { type: blob.type || 'audio/mpeg' });
            const getFileUploadUrl = (await import('@/api/server/files/getFileUploadUrl')).default;
            const axios = (await import('axios')).default;
            const uploadUrl = await getFileUploadUrl(uuid);
            const directory = filePath.substring(0, filePath.lastIndexOf('/')) || '/';
            const targetName = filePath.split('/').pop() || fileName || 'audio.mp3';
            const formData = new FormData();
            formData.append('files', new File([outputBlob], targetName, { type: outputBlob.type || 'audio/mpeg' }));

            await axios.post(uploadUrl, formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
                params: { directory },
                onUploadProgress: (event: any) => {
                    if (event?.total) {
                        setEditProgress((event.loaded / event.total) * 100);
                    }
                },
            });

            const nextMetadata: ParsedAudioMetadata = {
                title: editTitle.trim() || undefined,
                artist: editArtist.trim() || undefined,
                album: editAlbum.trim() || undefined,
                picture: picture || undefined,
            };
            setMetadata(nextMetadata);
            if (artworkUrlRef.current) {
                URL.revokeObjectURL(artworkUrlRef.current);
                artworkUrlRef.current = null;
            }
            const newArtworkUrl = createArtworkUrl(picture ?? undefined);
            if (newArtworkUrl) {
                artworkUrlRef.current = newArtworkUrl;
                setArtworkUrl(newArtworkUrl);
            } else {
                setArtworkUrl(null);
            }

            closeEditModal();
        } catch (error: any) {
            setEditError(error?.message || 'Failed to update metadata.');
        } finally {
            setEditSaving(false);
        }
    };

    const safeAudioDuration = Number.isFinite(duration) && duration > 0 ? duration : 0;
    const progressPercent = safeAudioDuration ? Math.min(100, Math.max(0, (currentTime / safeAudioDuration) * 100)) : 0;
    const bufferedPercent = safeAudioDuration ? Math.min(100, Math.max(0, (buffered / safeAudioDuration) * 100)) : 0;
    const displayTitle = metadata?.title || fileName?.replace(/\.[^/.]+$/, '') || 'Audio file';

    return (
        <AudioPlayerContainer>
            {artworkColors && (
                <div
                    style={{
                        position: 'absolute',
                        left: '50%',
                        top: '50%',
                        width: '160vmax',
                        height: '160vmax',
                        marginLeft: '-80vmax',
                        marginTop: '-80vmax',
                        zIndex: 0,
                        pointerEvents: 'none',
                        transform: `rotate(${ambientRotation}deg)`,
                        transformOrigin: 'center',
                        transition: 'transform 260ms ease',
                        opacity: 0.85,
                        background: `
                            radial-gradient(circle at 0% 0%, ${artworkColors.tl} 0%, transparent 70%),
                            radial-gradient(circle at 100% 0%, ${artworkColors.tr} 0%, transparent 70%),
                            radial-gradient(circle at 0% 100%, ${artworkColors.bl} 0%, transparent 70%),
                            radial-gradient(circle at 100% 100%, ${artworkColors.br} 0%, transparent 70%)
                        `,
                    }}
                />
            )}
            <VisualizerCanvas ref={canvasRef} width={800} height={400} />
            <audio ref={audioRef} src={src} onError={onError} preload="auto" crossOrigin="anonymous" />

            <AudioContent>
                <BeatNotesLayer ref={notesLayerRef} />

                <div ref={audioStageRef} className='flex flex-1 min-h-0 w-full origin-center transform-gpu items-center justify-center px-2 py-6 transition-transform duration-75 will-change-transform md:py-10'>
                    <div className='flex min-w-0 flex-col items-center gap-5 text-center md:flex-row md:text-left'>
                        <ArtworkStack>
                            <VinylDisk playing={playing} />
                            {artworkUrl ? (
                                <AudioArtwork
                                    ref={iconRef as React.RefObject<HTMLImageElement>}
                                    src={artworkUrl}
                                    alt={metadata?.album || metadata?.title || fileName}
                                />
                            ) : (
                                <AudioIconWrapper ref={iconRef as React.RefObject<HTMLDivElement>} playing={playing}>
                                    <svg className='w-14 h-14 text-white' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={1.6} d='M9 18V7l10-2v11M9 18c0 1.105-1.12 2-2.5 2S4 19.105 4 18s1.12-2 2.5-2 2.5.895 2.5 2zm10-2c0 1.105-1.12 2-2.5 2S14 17.105 14 16s1.12-2 2.5-2 2.5.895 2.5 2zM9 11l10-2' />
                                    </svg>
                                </AudioIconWrapper>
                            )}
                        </ArtworkStack>

                        <div className='min-w-0 max-w-md'>
                            <p className='truncate text-xl font-semibold text-neutral-100'>{displayTitle}</p>
                            {metadata?.artist && <p className='mt-1 truncate text-sm text-neutral-400'>{metadata.artist}</p>}
                            {metadata?.album && <p className='mt-1 truncate text-xs text-neutral-500'>{metadata.album}</p>}
                        </div>
                    </div>
                </div>

                <WaveformCanvas ref={timelineCanvasRef} style={{ display: 'none' }} />
                <div className='w-full rounded bg-neutral-700/95 border border-neutral-600 p-3 shadow-2xl backdrop-blur-md md:p-4'>
                    <div
                        className='relative h-2 w-full cursor-pointer rounded-full bg-neutral-600'
                        onClick={handleSeek}
                        onPointerDown={handleScrubPointerDown}
                        onPointerMove={handleScrubPointerMove}
                        onPointerUp={handleScrubPointerUp}
                        onPointerCancel={handleScrubPointerUp}
                        onMouseMove={(e) => {
                            if (!safeAudioDuration) return;
                            const rect = e.currentTarget.getBoundingClientRect();
                            const percent = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
                            setSeekPreview(percent * safeAudioDuration);
                        }}
                        onMouseLeave={() => {
                            if (!isScrubbingRef.current) setSeekPreview(null);
                        }}
                    >
                        <div
                            className='absolute inset-y-0 left-0 rounded-full bg-neutral-500/50'
                            style={{ width: `${bufferedPercent}%` }}
                        />
                        <div
                            className='absolute inset-y-0 left-0 rounded-full'
                            style={{
                                width: `${progressPercent}%`,
                                backgroundColor: colors.primary.default,
                            }}
                        />
                        <div
                            className='absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full shadow-md'
                            style={{
                                left: `${progressPercent}%`,
                                marginLeft: -7,
                                backgroundColor: colors.primary.default,
                            }}
                        />
                        {seekPreview !== null && (
                            <span
                                className='absolute -top-7 rounded bg-neutral-900 px-2 py-1 text-[10px] text-neutral-200 shadow'
                                style={{ left: `${safeAudioDuration ? (seekPreview / safeAudioDuration) * 100 : 0}%`, transform: 'translateX(-50%)' }}
                            >
                                {formatTime(seekPreview)}
                            </span>
                        )}
                    </div>
                    <div className='flex items-center justify-between text-xs text-neutral-400 mt-2'>
                        <span className='tabular-nums'>{formatTime(currentTime)}</span>
                        <span className='tabular-nums'>{formatTime(duration)}</span>
                    </div>

                    <div className='mt-3 flex flex-wrap items-center justify-center gap-3 md:gap-5'>
                        <div className='flex items-center justify-center gap-5'>
                            <Button.Text
                                type='button'
                                size={Button.Sizes.Small}
                                shape={Button.Shapes.IconSquare}
                                onClick={() => skipTime(-10)}
                                title='Back 10 seconds'
                            >
                                <svg className='w-5 h-5' fill='none' stroke='currentColor' strokeWidth={2} viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' d='M11 19V5l-7 7 7 7zm9 0V5l-7 7 7 7z' />
                                </svg>
                            </Button.Text>

                            <button
                                type='button'
                                onClick={togglePlay}
                                className='w-14 h-14 text-white rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg'
                                style={{ backgroundColor: colors.primary.default }}
                                title={playing ? 'Pause' : 'Play'}
                            >
                                {playing ? (
                                    <svg className='w-7 h-7' fill='none' stroke='currentColor' strokeWidth={2.5} viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' d='M7 5v14M17 5v14' />
                                    </svg>
                                ) : (
                                    <svg className='w-7 h-7 ml-0.5' fill='none' stroke='currentColor' strokeWidth={2.5} viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' d='M8 5l11 7-11 7V5z' />
                                    </svg>
                                )}
                            </button>

                            <Button.Text
                                type='button'
                                size={Button.Sizes.Small}
                                shape={Button.Shapes.IconSquare}
                                onClick={() => skipTime(10)}
                                title='Forward 10 seconds'
                            >
                                <svg className='w-5 h-5' fill='none' stroke='currentColor' strokeWidth={2} viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' d='M13 19V5l7 7-7 7zM4 19V5l7 7-7 7z' />
                                </svg>
                            </Button.Text>
                        </div>

                        <div className='hidden h-8 w-px bg-neutral-600 md:block' />

                        <div className='flex flex-wrap items-center justify-center gap-3'>
                            <div className='flex items-center gap-2'>
                                <span className='hidden text-[10px] uppercase tracking-wider text-neutral-500 sm:inline'>Volume</span>
                                <Button.Text
                                    type='button'
                                    size={Button.Sizes.Small}
                                    shape={Button.Shapes.IconSquare}
                                    onClick={() => { if (audioRef.current) audioRef.current.muted = !muted; }}
                                    title={muted || volume === 0 ? 'Unmute' : 'Mute'}
                                >
                                    <svg className='w-4 h-4' fill='none' stroke='currentColor' strokeWidth={2} viewBox='0 0 24 24' style={{ opacity: muted || volume === 0 ? 0.5 : 1 }}>
                                        <path strokeLinecap='round' strokeLinejoin='round' d='M9 9v6l-4 0v-6h4zm0 0l5-4v14l-5-4M16 8a4 4 0 010 8M18.5 6.5a7 7 0 010 11' />
                                    </svg>
                                </Button.Text>
                                <VolumeSlider
                                    type='range'
                                    min='0'
                                    max='1'
                                    step='0.05'
                                    value={muted ? 0 : volume}
                                    onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                                />
                            </div>

                            <div className='flex items-center gap-2'>
                                <span className='text-[10px] uppercase tracking-wider text-neutral-500'>Speed</span>
                                <span className='w-9 text-xs text-neutral-400 tabular-nums'>{Math.round(playbackRate * 100)}%</span>
                                <RateSlider
                                    type='range'
                                    min='0.5'
                                    max='1.5'
                                    step='0.01'
                                    value={playbackRate}
                                    onChange={(e) => handleRateChange(parseFloat(e.target.value))}
                                />
                            </div>
                        </div>
                    </div>

                    {syncCount > 1 && (
                        <div className='mt-3 flex items-center justify-center gap-2 border-t border-neutral-600 pt-3'>
                            <Button.Text
                                type='button'
                                size={Button.Sizes.Small}
                                onClick={() => syncSkipAll(-10)}
                            >
                                -10s
                            </Button.Text>
                            <Button.Text type='button' size={Button.Sizes.Small} onClick={() => syncSeekAll(0)}>
                                <svg className='w-4 h-4' fill='currentColor' viewBox='0 0 24 24'><path d='M6 6h2v12H6zm3.5 6l8.5 6V6z' /></svg>
                            </Button.Text>
                            <Button type='button' size={Button.Sizes.Small} onClick={() => syncAllAudio('toggle')}>Sync ({syncCount})</Button>
                            <Button.Text type='button' size={Button.Sizes.Small} onClick={() => syncSkipAll(10)}>+10s</Button.Text>
                        </div>
                    )}
                </div>

                <Dialog open={showEditModal} onClose={closeEditModal} title="Edit Audio Metadata">
                    <div className="space-y-4">
                        <p className="text-xs text-neutral-300">
                            Metadata is updated locally and the full file is re-uploaded. Limit: 25 MB.
                        </p>
                        {needsFullDownload && (
                            <p className="text-xs text-yellow-300">
                                Downloading full file to enable metadata edits...
                            </p>
                        )}
                        {editError && (
                            <div
                                className="text-sm text-red-400 bg-gray-700 border border-red-500 p-3"
                                style={{ borderRadius: themeColors.borderRadius.component }}
                            >
                                {editError}
                            </div>
                        )}
                        <div className="grid gap-3">
                            <div>
                                <label className="text-xs uppercase tracking-widest text-gray-400">Title</label>
                                <Input
                                    type="text"
                                    value={editTitle}
                                    onChange={(e) => setEditTitle(e.target.value)}
                                    className="mt-2"
                                    placeholder="Song title"
                                />
                            </div>
                            <div>
                                <label className="text-xs uppercase tracking-widest text-gray-400">Artist</label>
                                <Input
                                    type="text"
                                    value={editArtist}
                                    onChange={(e) => setEditArtist(e.target.value)}
                                    className="mt-2"
                                    placeholder="Artist name"
                                />
                            </div>
                            <div>
                                <label className="text-xs uppercase tracking-widest text-gray-400">Album</label>
                                <Input
                                    type="text"
                                    value={editAlbum}
                                    onChange={(e) => setEditAlbum(e.target.value)}
                                    className="mt-2"
                                    placeholder="Album name"
                                />
                            </div>
                            <div className="flex flex-col gap-3">
                                <label className="text-xs uppercase tracking-widest text-gray-400">Cover Art</label>
                                <div className="flex flex-wrap items-center gap-3">
                                    <div
                                        className="w-20 h-20 overflow-hidden bg-gray-700 border border-gray-600 flex items-center justify-center"
                                        style={{ borderRadius: themeColors.borderRadius.component }}
                                    >
                                        {editCoverPreview ? (
                                            <img src={editCoverPreview} alt="Cover preview" className="w-full h-full object-cover" />
                                        ) : (
                                            <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                                            </svg>
                                        )}
                                    </div>
                                    <div className="flex flex-col gap-2">
                                        <input
                                            ref={coverInputRef}
                                            type="file"
                                            accept="image/*"
                                            className="hidden"
                                            onChange={(e) => handleCoverSelect(e.currentTarget.files?.[0])}
                                        />
                                        <button
                                            type="button"
                                            className="px-3 py-2 text-xs font-semibold text-white bg-gray-600 hover:bg-gray-500"
                                            style={{ borderRadius: themeColors.borderRadius.component }}
                                            onClick={() => coverInputRef.current?.click()}
                                        >
                                            Choose cover
                                        </button>
                                        <button
                                            type="button"
                                            className="px-3 py-2 text-xs font-semibold text-gray-300 bg-gray-700 border border-gray-600 hover:bg-gray-600"
                                            style={{ borderRadius: themeColors.borderRadius.component }}
                                            onClick={handleRemoveCover}
                                            disabled={coverMode === 'none'}
                                        >
                                            Remove cover
                                        </button>
                                    </div>
                                </div>
                            </div>
                            {editSaving && (
                                <div className="mt-2">
                                    <div className="flex justify-between text-xs text-neutral-300 mb-1">
                                        <span>Uploading...</span>
                                        <span>{Math.round(editProgress)}%</span>
                                    </div>
                                    <div
                                        className="w-full bg-gray-700 h-2 overflow-hidden"
                                        style={{ borderRadius: themeColors.borderRadius.component }}
                                    >
                                        <div
                                            className="h-full bg-primary-500 transition-all duration-200"
                                            style={{ width: `${editProgress}%` }}
                                        />
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                    <Dialog.Footer>
                        <Button.Text onClick={closeEditModal} disabled={editSaving}>
                            Cancel
                        </Button.Text>
                        <Button onClick={handleSaveMetadata} disabled={!canEditMetadata || editSaving}>
                            Save Metadata
                        </Button>
                    </Dialog.Footer>
                </Dialog>
            </AudioContent>
        </AudioPlayerContainer>
    );
};

export default AudioPlayer;
