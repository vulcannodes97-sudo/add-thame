import { useState, useCallback, useEffect, useRef } from 'react';
import {
    getDirectoryContents,
    getFileContents,
    saveFileContents,
    deleteFiles,
    compressFiles,
    renameFile,
    decompressFile,
    FileObject,
} from '@/api/server/files';
import { moveToTrash } from '@/api/server/files/betterFilesApi';
import type { FileTree, OpenFile, OperationProgress } from '../types';
import { getMediaType, groupByDirectory, getFileName, getDirectory } from '../utils';
import type { FlashMessage } from '../../useFlash';

const STORAGE_VERSION = 1;
const MAX_RESTORED_OPEN_FILES = 20;

interface StoredFileManagerSession {
    version: number;
    currentPath?: string;
    selectedFile?: string | null;
    openFiles?: Array<{ path: string; name: string }>;
}

interface UseFileManagerOptions {
    uuid: string;
    clearAndAddHttpError: (error?: Error | string | null) => void;
    clearFlashes: () => void;
    addFlash: (flash: Omit<FlashMessage, 'id' | 'key'>) => void;
}

const getStorageKey = (uuid: string) => `bfm-server-session:${uuid}`;

const normalizePath = (path?: string | null) => {
    if (!path || typeof path !== 'string') return '/';
    const cleaned = path.replace(/\\/g, '/').replace(/\/+/g, '/').trim();
    if (!cleaned || cleaned === '.') return '/';
    return cleaned.startsWith('/') ? cleaned : `/${cleaned}`;
};

const loadStoredSession = (uuid: string): StoredFileManagerSession | null => {
    if (!uuid || typeof window === 'undefined') return null;

    try {
        const raw = window.localStorage.getItem(getStorageKey(uuid));
        if (!raw) return null;

        const parsed = JSON.parse(raw) as StoredFileManagerSession;
        if (!parsed || parsed.version !== STORAGE_VERSION) return null;

        return {
            version: STORAGE_VERSION,
            currentPath: normalizePath(parsed.currentPath),
            selectedFile: parsed.selectedFile ? normalizePath(parsed.selectedFile) : null,
            openFiles: Array.isArray(parsed.openFiles)
                ? parsed.openFiles
                    .filter((file) => typeof file?.path === 'string' && file.path.length > 0)
                    .slice(0, MAX_RESTORED_OPEN_FILES)
                    .map((file) => ({
                        path: normalizePath(file.path),
                        name: file.name || getFileName(normalizePath(file.path)),
                    }))
                : [],
        };
    } catch {
        return null;
    }
};

export const useFileManager = ({ uuid, clearAndAddHttpError, clearFlashes, addFlash }: UseFileManagerOptions) => {
    const [initialSession] = useState(() => loadStoredSession(uuid));
    const [loading, setLoading] = useState(true);
    const [fileLoading, setFileLoading] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [fileTree, setFileTree] = useState<FileTree>({});
    const [currentPath, setCurrentPath] = useState(() => initialSession?.currentPath || '/');
    const [selectedFile, setSelectedFile] = useState<string | null>(null);
    const [selectedFileObject, setSelectedFileObject] = useState<FileObject | null>(null);
    const [fileContent, setFileContent] = useState('');
    const [originalContent, setOriginalContent] = useState('');
    const [openFiles, setOpenFiles] = useState<OpenFile[]>([]);
    const [operationProgress, setOperationProgress] = useState<OperationProgress | null>(null);

    const openFilesRef = useRef<OpenFile[]>([]);
    const selectedFileRef = useRef<string | null>(null);
    const hasRestoredSessionRef = useRef(false);

    useEffect(() => {
        openFilesRef.current = openFiles;
    }, [openFiles]);

    useEffect(() => {
        selectedFileRef.current = selectedFile;
    }, [selectedFile]);

    const loadDirectory = useCallback(
        async (path: string): Promise<FileObject[]> => {
            try {
                const files = await getDirectoryContents(uuid, path);
                setFileTree((prev) => ({ ...prev, [path]: files }));
                return files;
            } catch (error) {
                clearAndAddHttpError(error as Error);
                return [];
            }
        },
        [uuid, clearAndAddHttpError]
    );

    useEffect(() => {
        let cancelled = false;

        const restoreSession = async () => {
            if (!uuid) {
                setLoading(false);
                return;
            }

            const storedSession = loadStoredSession(uuid);
            const restoredPath = storedSession?.currentPath || '/';
            const storedOpenFiles = storedSession?.openFiles || [];
            const directoriesToLoad = new Set<string>(['/', restoredPath]);

            storedOpenFiles.forEach((file) => directoriesToLoad.add(getDirectory(file.path)));
            if (storedSession?.selectedFile) directoriesToLoad.add(getDirectory(storedSession.selectedFile));

            hasRestoredSessionRef.current = false;
            setLoading(true);
            setFileTree({});
            setCurrentPath(restoredPath);
            setSelectedFile(null);
            setSelectedFileObject(null);
            setFileContent('');
            setOriginalContent('');
            setOpenFiles([]);
            openFilesRef.current = [];

            const loadedDirectories = new Map<string, FileObject[]>();
            await Promise.all(
                Array.from(directoriesToLoad).map(async (directory) => {
                    const files = await loadDirectory(directory);
                    loadedDirectories.set(directory, files);
                })
            );

            const seen = new Set<string>();
            const restoredOpenFiles: OpenFile[] = [];

            for (const file of storedOpenFiles) {
                const path = normalizePath(file.path);
                if (seen.has(path)) continue;
                seen.add(path);

                const directory = getDirectory(path);
                const fileName = getFileName(path);
                const fileObject = loadedDirectories.get(directory)?.find((entry) => entry.name === fileName);
                if (!fileObject?.isFile) continue;

                if (getMediaType(path) === 'text') {
                    try {
                        const content = await getFileContents(uuid, path);
                        const stringContent = typeof content === 'string' ? content : '';
                        restoredOpenFiles.push({
                            path,
                            name: fileName,
                            content: stringContent,
                            originalContent: stringContent,
                            hasUnsavedChanges: false,
                        });
                    } catch {
                        continue;
                    }
                } else {
                    restoredOpenFiles.push({
                        path,
                        name: fileName,
                        content: '',
                        originalContent: '',
                        hasUnsavedChanges: false,
                    });
                }
            }

            if (cancelled) return;

            const selectedPath = storedSession?.selectedFile
                ? normalizePath(storedSession.selectedFile)
                : restoredOpenFiles[0]?.path;
            const selectedOpenFile = restoredOpenFiles.find((file) => file.path === selectedPath) || null;

            openFilesRef.current = restoredOpenFiles;
            setOpenFiles(restoredOpenFiles);

            if (selectedOpenFile) {
                const directory = getDirectory(selectedOpenFile.path);
                const fileName = getFileName(selectedOpenFile.path);
                const fileObject = loadedDirectories.get(directory)?.find((entry) => entry.name === fileName) || null;

                setSelectedFile(selectedOpenFile.path);
                setSelectedFileObject(fileObject);
                setFileContent(selectedOpenFile.content);
                setOriginalContent(selectedOpenFile.originalContent);
            }

            hasRestoredSessionRef.current = true;
            setLoading(false);
        };

        restoreSession();

        return () => {
            cancelled = true;
        };
    }, [uuid]);

    useEffect(() => {
        if (!uuid || typeof window === 'undefined' || !hasRestoredSessionRef.current) return;

        const payload: StoredFileManagerSession = {
            version: STORAGE_VERSION,
            currentPath,
            selectedFile,
            openFiles: openFiles.slice(-MAX_RESTORED_OPEN_FILES).map((file) => ({
                path: file.path,
                name: file.name,
            })),
        };

        window.localStorage.setItem(getStorageKey(uuid), JSON.stringify(payload));
    }, [uuid, currentPath, selectedFile, openFiles]);

    const getFileObjectByPath = useCallback((path: string): FileObject | undefined => {
        if (!path) return undefined;
        const normalized = path.startsWith('/') ? path : `/${path}`;
        const lastSlash = normalized.lastIndexOf('/');
        const directory = lastSlash <= 0 ? '/' : normalized.slice(0, lastSlash);
        const name = normalized.slice(lastSlash + 1);
        if (!name) return undefined;
        return fileTree[directory]?.find((file) => file.name === name);
    }, [fileTree]);

    const handleFileSelect = useCallback(async (
        filePath: string,
        isFile: boolean,
        callbacks: {
            setActiveTab: (tab: 'files' | 'editor') => void;
            setSplitView: (val: boolean) => void;
            setSplitFilePath: (path: string | null) => void;
            setActivePaneState: (pane: 'main' | 'split') => void;
            splitView: boolean;
            splitFilePath: string | null;
            activePane: 'main' | 'split';
        },
        paneOverride?: 'main' | 'split'
    ) => {
        if (!isFile) {
            if (!fileTree[filePath]) {
                await loadDirectory(filePath);
            }
            setCurrentPath(filePath);
            return;
        }

        const directory = getDirectory(filePath);
        const fileName = getFileName(filePath);
        let directoryFiles = fileTree[directory];
        if (!directoryFiles) {
            directoryFiles = await loadDirectory(directory);
        }
        const fileObj = directoryFiles?.find((f: FileObject) => f.name === fileName);

        if (fileObj) {
            setSelectedFileObject(fileObj);
        }
        callbacks.setActiveTab('editor');

        const useSplitPane = paneOverride === 'split' || (callbacks.splitView && callbacks.activePane === 'split');
        const shouldOpenSplit = useSplitPane && !callbacks.splitView;

        const mediaType = getMediaType(filePath);
        if (mediaType === 'binary') {
            clearAndAddHttpError({
                message: 'Cannot open binary files in the editor. This file type is not editable.',
            } as Error);
            if (shouldOpenSplit) {
                callbacks.setSplitView(false);
                callbacks.setSplitFilePath(null);
            }
            return;
        }

        if (shouldOpenSplit) {
            callbacks.setSplitView(true);
        }

        const existingFile = openFilesRef.current.find((f: OpenFile) => f.path === filePath);
        if (existingFile) {
            if (useSplitPane) {
                callbacks.setSplitFilePath(filePath);
                callbacks.setActivePaneState('split');
            } else {
                setSelectedFile(filePath);
                setFileContent(existingFile.content);
                setOriginalContent(existingFile.originalContent);
                callbacks.setActivePaneState('main');
            }
            return;
        }

        if (mediaType !== 'text') {
            const newFile: OpenFile = {
                path: filePath,
                name: fileName,
                content: '',
                originalContent: '',
                hasUnsavedChanges: false,
            };
            const updatedFiles = [...openFilesRef.current, newFile];
            openFilesRef.current = updatedFiles;
            setOpenFiles(updatedFiles);
            setFileContent('');
            setOriginalContent('');
            if (useSplitPane) {
                callbacks.setSplitFilePath(filePath);
                callbacks.setActivePaneState('split');
            } else {
                setSelectedFile(filePath);
                callbacks.setActivePaneState('main');
            }
            return;
        }

        setFileLoading(true);

        try {
            const content = await getFileContents(uuid, filePath);
            const stringContent = typeof content === 'string' ? content : '';

            const newFile: OpenFile = {
                path: filePath,
                name: fileName,
                content: stringContent,
                originalContent: stringContent,
                hasUnsavedChanges: false,
            };
            const updatedFiles = [...openFilesRef.current, newFile];
            openFilesRef.current = updatedFiles;
            setOpenFiles(updatedFiles);

            if (useSplitPane) {
                callbacks.setSplitFilePath(filePath);
                callbacks.setActivePaneState('split');
            } else {
                setFileContent(stringContent);
                setOriginalContent(stringContent);
                setSelectedFile(filePath);
                callbacks.setActivePaneState('main');
            }
        } catch (error: unknown) {
            clearAndAddHttpError(error as Error);
            setFileContent('');
            setOriginalContent('');
            setSelectedFile(null);
            setSelectedFileObject(null);
        } finally {
            setFileLoading(false);
        }
    }, [uuid, fileTree, openFiles, loadDirectory, clearAndAddHttpError]);

    const handleSave = useCallback(async (
        contentToSave?: string,
        splitContext?: { activePane: 'main' | 'split'; splitView: boolean; splitFilePath: string | null }
    ) => {
        const currentPane = splitContext?.activePane ?? 'main';
        const fileToSave = currentPane === 'split' && splitContext?.splitView
            ? splitContext?.splitFilePath
            : selectedFile;
        if (!fileToSave) return;

        const currentFile = openFilesRef.current.find((f: OpenFile) => f.path === fileToSave);
        const content = contentToSave !== undefined ? contentToSave : currentFile?.content ?? fileContent;

        setIsSaving(true);
        try {
            await saveFileContents(uuid, fileToSave, content);

            if (currentPane === 'main' || !splitContext?.splitView) {
                setOriginalContent(content);
                setFileContent(content);
            }

            const updatedFiles = openFilesRef.current.map((f: OpenFile) =>
                f.path === fileToSave ? { ...f, content, originalContent: content, hasUnsavedChanges: false } : f
            );
            openFilesRef.current = updatedFiles;
            setOpenFiles(updatedFiles);

            clearFlashes();
            const directory = getDirectory(fileToSave);
            await loadDirectory(directory);
        } catch (error: unknown) {
            clearAndAddHttpError(error as Error);
        } finally {
            setIsSaving(false);
        }
    }, [uuid, selectedFile, fileContent, loadDirectory, clearFlashes, clearAndAddHttpError]);

    const removePathsFromTree = useCallback((paths: string[]) => {
        if (paths.length === 0) return;
        const grouped = groupByDirectory(paths);
        setFileTree((prev) => {
            const next = { ...prev };
            for (const [directory, names] of grouped) {
                const current = next[directory];
                if (!current || current.length === 0) continue;
                next[directory] = current.filter((file) => !names.includes(file.name));
            }
            return next;
        });
    }, []);

    const handleMassDelete = useCallback(async (selectedFiles: string[]) => {
        try {
            const grouped = groupByDirectory(selectedFiles);
            for (const [directory, names] of grouped) {
                await deleteFiles(uuid, directory, names);
            }
            removePathsFromTree(selectedFiles);
            const directoriesToRefresh = Array.from(new Set([currentPath, ...grouped.keys()]));
            await Promise.all(directoriesToRefresh.map((dir) => loadDirectory(dir)));
            addFlash({
                type: 'success',
                message: `${selectedFiles.length} item${selectedFiles.length > 1 ? 's' : ''} deleted`,
            });
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, currentPath, loadDirectory, removePathsFromTree, addFlash, clearAndAddHttpError]);

    const handleMassMoveToTrash = useCallback(async (selectedFiles: string[]) => {
        try {
            const grouped = groupByDirectory(selectedFiles);
            for (const [directory, names] of grouped) {
                await moveToTrash(uuid, directory, names);
            }
            removePathsFromTree(selectedFiles);
            const directoriesToRefresh = Array.from(new Set([currentPath, ...grouped.keys()]));
            await Promise.all(directoriesToRefresh.map((dir) => loadDirectory(dir)));
            const total = Array.from(grouped.values()).reduce((sum, names) => sum + names.length, 0);
            addFlash({
                type: 'success',
                message: `${total} item${total > 1 ? 's' : ''} moved to trash`,
            });
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, currentPath, loadDirectory, removePathsFromTree, addFlash, clearAndAddHttpError]);

    const handleMassCompress = useCallback(async (selectedFiles: string[]) => {
        const fileCount = selectedFiles.length;
        const fileText = fileCount === 1 ? 'file' : 'files';
        setOperationProgress({ message: `Compressing ${fileCount} ${fileText}...`, show: true });

        try {
            const dirs = new Set(selectedFiles.map((p) => getDirectory(p)));
            const commonRoot = dirs.size === 1 ? Array.from(dirs)[0] : '/';
            const fileNames = selectedFiles.map((path) => {
                if (commonRoot === '/') {
                    return path.startsWith('/') ? path.substring(1) : path;
                }
                const prefix = commonRoot === '/' ? '/' : `${commonRoot}/`;
                return path.startsWith(prefix) ? path.substring(prefix.length) : path.substring(path.lastIndexOf('/') + 1);
            });
            await compressFiles(uuid, commonRoot, fileNames);
            await loadDirectory(commonRoot);
            if (commonRoot !== currentPath) await loadDirectory(currentPath);
            setOperationProgress(null);
            addFlash({
                type: 'success',
                message: `Archived ${fileCount} ${fileText}`,
            });
        } catch (error) {
            setOperationProgress(null);
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, currentPath, loadDirectory, addFlash, clearAndAddHttpError]);

    const handleUnarchive = useCallback(async (archivePath: string) => {
        const filename = getFileName(archivePath);
        const directory = getDirectory(archivePath);
        setOperationProgress({ message: `Extracting ${filename}...`, show: true });
        try {
            await decompressFile(uuid, directory, filename);
            await loadDirectory(directory);
            setOperationProgress(null);
            addFlash({
                type: 'success',
                message: `Extracted ${filename}`,
            });
        } catch (error) {
            setOperationProgress(null);
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, loadDirectory, addFlash, clearAndAddHttpError]);

    const handleMassMove = useCallback(async (selectedFiles: string[], destinationPath: string) => {
        try {
            const grouped = groupByDirectory(selectedFiles);
            const renameData: { from: string; to: string }[] = [];
            for (const filePath of selectedFiles) {
                const fileName = filePath.substring(filePath.lastIndexOf('/') + 1);
                let fromPath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
                let destPath = (destinationPath === '/' ? fileName : `${destinationPath}/${fileName}`).replace(/^\//, '');
                fromPath = fromPath.replace(/\/+/g, '/');
                destPath = destPath.replace(/\/+/g, '/');
                renameData.push({ from: fromPath, to: destPath });
            }
            if (renameData.length > 0) {
                await renameFile(uuid, '/', renameData);
            }
            removePathsFromTree(selectedFiles);
            await loadDirectory(currentPath);
            const directoriesToRefresh = Array.from(new Set([destinationPath, ...grouped.keys()]));
            await Promise.all(directoriesToRefresh.map((dir) => loadDirectory(dir)));
            addFlash({
                type: 'success',
                message: `Moved ${selectedFiles.length} item${selectedFiles.length > 1 ? 's' : ''}`,
            });
        } catch (error) {
            clearAndAddHttpError(error as Error);
        }
    }, [uuid, currentPath, loadDirectory, removePathsFromTree, addFlash, clearAndAddHttpError]);

    const updateFileContent = useCallback((path: string, newContent: string) => {
        const updatedFiles = openFilesRef.current.map((f) =>
            f.path === path
                ? { ...f, content: newContent, hasUnsavedChanges: newContent !== f.originalContent }
                : f
        );
        openFilesRef.current = updatedFiles;
        setOpenFiles(updatedFiles);
        if (path === selectedFileRef.current) {
            setFileContent(newContent);
        }
    }, []);

    const resetFileContent = useCallback((path: string) => {
        const file = openFilesRef.current.find((f) => f.path === path);
        if (file) {
            updateFileContent(path, file.originalContent);
        }
    }, [updateFileContent]);

    const closeFile = useCallback((path: string, callbacks: {
        splitView: boolean;
        splitFilePath: string | null;
        setSplitFilePath: (path: string | null) => void;
        setSplitView: (val: boolean) => void;
        setActivePaneState: (pane: 'main' | 'split') => void;
        setActiveTab: (tab: 'files' | 'editor') => void;
    }) => {
        const remaining = openFilesRef.current.filter((f) => f.path !== path);
        openFilesRef.current = remaining;
        setOpenFiles(remaining);

        if (callbacks.splitView && callbacks.splitFilePath === path) {
            if (remaining.length > 0) {
                const fallback = remaining.find((f) => f.path !== selectedFile) ?? remaining[remaining.length - 1];
                callbacks.setSplitFilePath(fallback.path);
            } else {
                callbacks.setSplitView(false);
                callbacks.setSplitFilePath(null);
                callbacks.setActivePaneState('main');
            }
        }

        if (selectedFile === path) {
            if (remaining.length > 0) {
                const nextFile = remaining[remaining.length - 1];
                setSelectedFile(nextFile.path);
                setFileContent(nextFile.content);
                setOriginalContent(nextFile.originalContent);
                const directory = getDirectory(nextFile.path);
                const fileName = getFileName(nextFile.path);
                const fileObj = fileTree[directory]?.find((f: FileObject) => f.name === fileName);
                if (fileObj) {
                    setSelectedFileObject(fileObj);
                }
            } else {
                setSelectedFile(null);
                setSelectedFileObject(null);
                setFileContent('');
                setOriginalContent('');
                callbacks.setActiveTab('files');
            }
        }
    }, [selectedFile, fileTree]);

    const closeAllFiles = useCallback((callbacks: {
        setSplitFilePath: (path: string | null) => void;
        setSplitView: (val: boolean) => void;
        setActivePaneState: (pane: 'main' | 'split') => void;
        setActiveTab: (tab: 'files' | 'editor') => void;
    }) => {
        openFilesRef.current = [];
        setOpenFiles([]);
        setSelectedFile(null);
        setSelectedFileObject(null);
        setFileContent('');
        setOriginalContent('');
        callbacks.setSplitFilePath(null);
        callbacks.setSplitView(false);
        callbacks.setActivePaneState('main');
        callbacks.setActiveTab('files');
    }, []);

    const refreshDirectories = useCallback(async (paths: string[]) => {
        const unique = Array.from(new Set(paths.map((path) => (path.startsWith('/') ? path : `/${path}`))));
        await Promise.all(unique.map((path) => loadDirectory(path)));
    }, [loadDirectory]);

    return {
        loading,
        setLoading,
        fileLoading,
        isSaving,
        fileTree,
        currentPath,
        setCurrentPath,
        selectedFile,
        setSelectedFile,
        selectedFileObject,
        setSelectedFileObject,
        fileContent,
        setFileContent,
        originalContent,
        setOriginalContent,
        openFiles,
        setOpenFiles,
        openFilesRef,
        selectedFileRef,
        operationProgress,
        setOperationProgress,
        loadDirectory,
        getFileObjectByPath,
        handleFileSelect,
        handleSave,
        removePathsFromTree,
        handleMassDelete,
        handleMassMoveToTrash,
        handleMassCompress,
        handleUnarchive,
        handleMassMove,
        updateFileContent,
        resetFileContent,
        closeFile,
        closeAllFiles,
        refreshDirectories,
    };
};
