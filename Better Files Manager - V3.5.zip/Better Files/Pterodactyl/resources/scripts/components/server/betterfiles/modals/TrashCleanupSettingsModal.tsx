import React from 'react';
import { Form, Formik } from 'formik';
import { object, number, boolean, string } from 'yup';
import { Dialog } from '@/components/elements/dialog';
import { Button } from '@/components/elements/button';
import Field from '@/components/elements/Field';
import Spinner from '@/components/elements/Spinner';
import { Checkbox } from '../components';
import { TrashCleanupSettings } from '@/api/server/files/betterFilesApi';
import { themeColors } from '../colorExtractor';

interface Props {
    visible: boolean;
    onDismiss: () => void;
    settings: TrashCleanupSettings | null;
    onSave: (values: { trash_cleanup_enabled: boolean; trash_retention_days: number; trash_retention_unit: 'days' | 'hours' }) => Promise<void>;
}

const TrashCleanupSettingsModal: React.FC<Props> = ({ visible, onDismiss, settings, onSave }) => {
    const initialValues = {
        trash_cleanup_enabled: settings?.trash_cleanup_enabled ?? false,
        trash_retention_days: settings?.trash_retention_days ?? 30,
        trash_retention_unit: settings?.trash_retention_unit ?? 'days',
    };

    return (
        <Dialog open={visible} onClose={onDismiss} title="Trash Cleanup">
            <div className="betterfiles-scope" onMouseDown={e => e.stopPropagation()} onClick={e => e.stopPropagation()}>
                {!settings ? (
                    <div className="py-6 flex items-center justify-center text-neutral-300">
                        <Spinner size="small" />
                        <span className="ml-2">Loading settings...</span>
                    </div>
                ) : (
                    <Formik
                        enableReinitialize
                        initialValues={initialValues}
                        validationSchema={object().shape({
                            trash_cleanup_enabled: boolean().required(),
                            trash_retention_days: number().required().min(1),
                            trash_retention_unit: string().required().oneOf(['days', 'hours']),
                        })}
                        onSubmit={async (values, { setSubmitting }) => {
                            try {
                                await onSave({
                                    trash_cleanup_enabled: values.trash_cleanup_enabled,
                                    trash_retention_days: Number(values.trash_retention_days),
                                    trash_retention_unit: values.trash_retention_unit as 'days' | 'hours',
                                });
                                onDismiss();
                            } finally {
                                setSubmitting(false);
                            }
                        }}
                    >
                        {({ submitForm, values, setFieldValue, isSubmitting }) => (
                            <Form>
                                <div className="flex items-center gap-3">
                                    <Checkbox
                                        checked={values.trash_cleanup_enabled}
                                        onChange={() =>
                                            setFieldValue('trash_cleanup_enabled', !values.trash_cleanup_enabled)
                                        }
                                    />
                                    <span className="text-sm text-neutral-300">Enable automatic trash cleanup</span>
                                </div>
                                <div className="mt-4">
                                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                                        <Field
                                            id="trash_retention_days"
                                            name="trash_retention_days"
                                            type="number"
                                            min={1}
                                            label="Delete items older than"
                                            className="bg-gray-600 border-gray-500 text-neutral-300 focus:border-gray-500"
                                        />
                                        <div>
                                            <label className="block text-sm text-neutral-300 mb-1">Unit</label>
                                            <select
                                                name="trash_retention_unit"
                                                value={values.trash_retention_unit}
                                                onChange={(e) => setFieldValue('trash_retention_unit', e.target.value)}
                                                className="w-full bg-gray-600 border border-gray-500 px-3 py-2 text-neutral-300 focus:border-gray-500 focus:outline-none"
                                                style={{ borderRadius: themeColors.borderRadius.component }}
                                            >
                                                <option value="hours">Hours</option>
                                                <option value="days">Days</option>
                                            </select>
                                        </div>
                                    </div>
                                    <p className="mt-2 text-sm text-neutral-300">Set how old items must be before deletion.</p>
                                </div>
                                <Dialog.Footer>
                                    <Button.Text onClick={onDismiss}>
                                        Cancel
                                    </Button.Text>
                                    <Button onClick={submitForm} disabled={isSubmitting}>
                                        {isSubmitting ? 'Saving...' : 'Save Settings'}
                                    </Button>
                                </Dialog.Footer>
                            </Form>
                        )}
                    </Formik>
                )}
            </div>
        </Dialog>
    );
};

export default TrashCleanupSettingsModal;
