import { useReducer, useCallback, useEffect, useRef } from 'react';
import {
    getDirectoryContents,
    getFileContents,
    saveFileContents,
    FileObject,
} from '@/api/server/files';
import type { FileTree, OpenFile, OperationProgress } from '../types';
import { getMediaType, getFileName, getDirectory } from '../utils';
import type { FlashMessage } from '../../useFlash';

interface FileManagerState {
    loading: boolean;
    fileLoading: boolean;
    isSaving: boolean;
    fileTree: FileTree;
    currentPath: string;
    selectedFile: string | null;
    selectedFileObject: FileObject | null;
    fileContent: string;
    originalContent: string;
    openFiles: OpenFile[];
    operationProgress: OperationProgress | null;
}

type FileManagerAction =
    | { type: 'SET_LOADING'; payload: boolean }
    | { type: 'SET_FILE_LOADING'; payload: boolean }
    | { type: 'SET_SAVING'; payload: boolean }
    | { type: 'UPDATE_FILE_TREE'; payload: { path: string; files: FileObject[] } }
    | { type: 'SET_CURRENT_PATH'; payload: string }
    | { type: 'SET_SELECTED_FILE'; payload: string | null }
    | { type: 'SET_SELECTED_FILE_OBJECT'; payload: FileObject | null }
    | { type: 'SET_FILE_CONTENT'; payload: string }
    | { type: 'SET_ORIGINAL_CONTENT'; payload: string }
    | { type: 'SET_OPEN_FILES'; payload: OpenFile[] }
    | { type: 'ADD_OPEN_FILE'; payload: OpenFile }
    | { type: 'UPDATE_OPEN_FILE'; payload: { path: string; updates: Partial<OpenFile> } }
    | { type: 'REMOVE_OPEN_FILE'; payload: string }
    | { type: 'SET_OPERATION_PROGRESS'; payload: OperationProgress | null }
    | { type: 'BATCH_UPDATE'; payload: Partial<FileManagerState> };

const initialState: FileManagerState = {
    loading: true,
    fileLoading: false,
    isSaving: false,
    fileTree: {},
    currentPath: '/',
    selectedFile: null,
    selectedFileObject: null,
    fileContent: '',
    originalContent: '',
    openFiles: [],
    operationProgress: null,
};

function fileManagerReducer(state: FileManagerState, action: FileManagerAction): FileManagerState {
    switch (action.type) {
        case 'SET_LOADING':
            return { ...state, loading: action.payload };
        case 'SET_FILE_LOADING':
            return { ...state, fileLoading: action.payload };
        case 'SET_SAVING':
            return { ...state, isSaving: action.payload };
        case 'UPDATE_FILE_TREE':
            return {
                ...state,
                fileTree: { ...state.fileTree, [action.payload.path]: action.payload.files },
            };
        case 'SET_CURRENT_PATH':
            return { ...state, currentPath: action.payload };
        case 'SET_SELECTED_FILE':
            return { ...state, selectedFile: action.payload };
        case 'SET_SELECTED_FILE_OBJECT':
            return { ...state, selectedFileObject: action.payload };
        case 'SET_FILE_CONTENT':
            return { ...state, fileContent: action.payload };
        case 'SET_ORIGINAL_CONTENT':
            return { ...state, originalContent: action.payload };
        case 'SET_OPEN_FILES':
            return { ...state, openFiles: action.payload };
        case 'ADD_OPEN_FILE':
            return { ...state, openFiles: [...state.openFiles, action.payload] };
        case 'UPDATE_OPEN_FILE':
            return {
                ...state,
                openFiles: state.openFiles.map((f) =>
                    f.path === action.payload.path ? { ...f, ...action.payload.updates } : f
                ),
            };
        case 'REMOVE_OPEN_FILE':
            return {
                ...state,
                openFiles: state.openFiles.filter((f) => f.path !== action.payload),
            };
        case 'SET_OPERATION_PROGRESS':
            return { ...state, operationProgress: action.payload };
        case 'BATCH_UPDATE':
            return { ...state, ...action.payload };
        default:
            return state;
    }
}

interface UseFileManagerOptions {
    uuid: string;
    clearAndAddHttpError: (error?: Error | string | null) => void;
    clearFlashes: () => void;
    addFlash: (flash: Omit<FlashMessage, 'id' | 'key'>) => void;
}

export const useFileManagerReducer = ({ uuid, clearAndAddHttpError, clearFlashes, addFlash }: UseFileManagerOptions) => {
    const [state, dispatch] = useReducer(fileManagerReducer, initialState);
    const openFilesRef = useRef<OpenFile[]>([]);
    const selectedFileRef = useRef<string | null>(null);

    useEffect(() => {
        openFilesRef.current = state.openFiles;
    }, [state.openFiles]);

    useEffect(() => {
        selectedFileRef.current = state.selectedFile;
    }, [state.selectedFile]);

    const loadDirectory = useCallback(
        async (path: string): Promise<FileObject[]> => {
            try {
                const files = await getDirectoryContents(uuid, path);
                dispatch({ type: 'UPDATE_FILE_TREE', payload: { path, files } });
                return files;
            } catch (error) {
                clearAndAddHttpError(error as Error);
                return [];
            }
        },
        [uuid, clearAndAddHttpError]
    );

    useEffect(() => {
        loadDirectory('/').finally(() => dispatch({ type: 'SET_LOADING', payload: false }));
    }, []);

    const getFileObjectByPath = useCallback((path: string): FileObject | undefined => {
        if (!path) return undefined;
        const normalized = path.startsWith('/') ? path : `/${path}`;
        const lastSlash = normalized.lastIndexOf('/');
        const directory = lastSlash <= 0 ? '/' : normalized.slice(0, lastSlash);
        const name = normalized.slice(lastSlash + 1);
        if (!name) return undefined;
        return state.fileTree[directory]?.find((file) => file.name === name);
    }, [state.fileTree]);

    const updateFileContent = useCallback((path: string, content: string) => {
        dispatch({ type: 'UPDATE_OPEN_FILE', payload: { path, updates: { content, hasUnsavedChanges: true } } });
        if (state.selectedFile === path) {
            dispatch({ type: 'SET_FILE_CONTENT', payload: content });
        }
    }, [state.selectedFile]);

    return {
        ...state,
        openFilesRef,
        selectedFileRef,
        dispatch,
        loadDirectory,
        getFileObjectByPath,
        updateFileContent,
        setLoading: (val: boolean) => dispatch({ type: 'SET_LOADING', payload: val }),
        setFileLoading: (val: boolean) => dispatch({ type: 'SET_FILE_LOADING', payload: val }),
        setIsSaving: (val: boolean) => dispatch({ type: 'SET_SAVING', payload: val }),
        setCurrentPath: (val: string) => dispatch({ type: 'SET_CURRENT_PATH', payload: val }),
        setSelectedFile: (val: string | null) => dispatch({ type: 'SET_SELECTED_FILE', payload: val }),
        setSelectedFileObject: (val: FileObject | null) => dispatch({ type: 'SET_SELECTED_FILE_OBJECT', payload: val }),
        setFileContent: (val: string) => dispatch({ type: 'SET_FILE_CONTENT', payload: val }),
        setOriginalContent: (val: string) => dispatch({ type: 'SET_ORIGINAL_CONTENT', payload: val }),
        setOpenFiles: (val: OpenFile[]) => dispatch({ type: 'SET_OPEN_FILES', payload: val }),
        addOpenFile: (file: OpenFile) => dispatch({ type: 'ADD_OPEN_FILE', payload: file }),
        removeOpenFile: (path: string) => dispatch({ type: 'REMOVE_OPEN_FILE', payload: path }),
        setOperationProgress: (val: OperationProgress | null) => dispatch({ type: 'SET_OPERATION_PROGRESS', payload: val }),
    };
};
