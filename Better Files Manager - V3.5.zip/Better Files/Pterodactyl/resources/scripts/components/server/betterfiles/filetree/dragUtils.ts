export interface FolderFile {
    file: File;
    relativePath: string;
}

const readFileEntry = (entry: FileSystemFileEntry): Promise<File> => {
    return new Promise((resolve, reject) => {
        entry.file(resolve, reject);
    });
};

const readDirectoryEntries = (reader: FileSystemDirectoryReader): Promise<FileSystemEntry[]> => {
    return new Promise((resolve, reject) => {
        reader.readEntries(resolve, reject);
    });
};

const getAllFilesFromEntry = async (entry: FileSystemEntry, path: string = ''): Promise<FolderFile[]> => {
    const files: FolderFile[] = [];

    if (entry.isFile) {
        try {
            const file = await readFileEntry(entry as FileSystemFileEntry);
            files.push({
                file,
                relativePath: path ? `${path}/${entry.name}` : entry.name,
            });
        } catch {

        }
    } else if (entry.isDirectory) {
        const dirReader = (entry as FileSystemDirectoryEntry).createReader();
        let entries: FileSystemEntry[] = [];

        let batch: FileSystemEntry[];
        do {
            batch = await readDirectoryEntries(dirReader);
            entries = entries.concat(batch);
        } while (batch.length > 0);

        for (const childEntry of entries) {
            const subPath = path ? `${path}/${entry.name}` : entry.name;
            const subFiles = await getAllFilesFromEntry(childEntry, subPath);
            files.push(...subFiles);
        }
    }

    return files;
};

export const getFilesFromDataTransfer = async (dataTransfer: DataTransfer): Promise<{ files: FolderFile[]; hasFolders: boolean }> => {
    const items = dataTransfer.items;
    const files: FolderFile[] = [];
    let hasFolders = false;

    if (items && items.length > 0) {
        const entries: FileSystemEntry[] = [];

        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            if (item.kind === 'file') {
                const entry = item.webkitGetAsEntry?.();
                if (entry) {
                    entries.push(entry);
                    if (entry.isDirectory) {
                        hasFolders = true;
                    }
                }
            }
        }

        for (const entry of entries) {
            const entryFiles = await getAllFilesFromEntry(entry);
            files.push(...entryFiles);
        }
    }

    if (files.length === 0) {
        const fileList = dataTransfer.files;
        for (let i = 0; i < fileList.length; i++) {
            const file = fileList[i];
            files.push({ file, relativePath: file.name });
        }
    }

    return { files, hasFolders };
};
