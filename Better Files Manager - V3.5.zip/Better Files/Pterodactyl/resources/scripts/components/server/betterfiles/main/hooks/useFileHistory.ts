import { useState, useEffect, useCallback } from 'react';

export interface FileHistoryEntry {
    path: string;
    filename: string;
    timestamp: number;
}

const STORAGE_KEY_PREFIX = 'bfm-file-history-';
const MAX_HISTORY_ITEMS = 15;

export const useFileHistory = (serverUuid: string) => {
    const [history, setHistory] = useState<FileHistoryEntry[]>([]);
    const storageKey = `${STORAGE_KEY_PREFIX}${serverUuid}`;

    useEffect(() => {
        try {
            const stored = localStorage.getItem(storageKey);
            if (stored) {
                const parsed = JSON.parse(stored) as FileHistoryEntry[];
                setHistory(parsed.sort((a, b) => b.timestamp - a.timestamp));
            }
        } catch (e) {
            console.error('Failed to load file history:', e);
        }
    }, [storageKey]);

    const addToHistory = useCallback((path: string) => {
        if (!path) return;
        
        const filename = path.split('/').pop() || path;
        const newEntry: FileHistoryEntry = {
            path,
            filename,
            timestamp: Date.now(),
        };

        setHistory((prev) => {
            const filtered = prev.filter((item) => item.path !== path);
            const updated = [newEntry, ...filtered];
            const trimmed = updated.slice(0, MAX_HISTORY_ITEMS);

            try {
                localStorage.setItem(storageKey, JSON.stringify(trimmed));
            } catch (e) {
                console.error('Failed to save file history:', e);
            }

            return trimmed;
        });
    }, [storageKey]);

    const clearHistory = useCallback(() => {
        setHistory([]);
        try {
            localStorage.removeItem(storageKey);
        } catch (e) {
            console.error('Failed to clear file history:', e);
        }
    }, [storageKey]);

    const removeFromHistory = useCallback((path: string) => {
        setHistory((prev) => {
            const filtered = prev.filter((item) => item.path !== path);
            try {
                localStorage.setItem(storageKey, JSON.stringify(filtered));
            } catch (e) {
                console.error('Failed to save file history:', e);
            }
            return filtered;
        });
    }, [storageKey]);

    return {
        history,
        addToHistory,
        clearHistory,
        removeFromHistory,
    };
};
