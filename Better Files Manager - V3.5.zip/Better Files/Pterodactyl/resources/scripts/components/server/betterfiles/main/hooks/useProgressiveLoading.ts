import { useState, useCallback, useEffect, useRef } from 'react';
import { getFileContents, FileObject } from '@/api/server/files';
import type { FileTree } from '../types';
import { getMediaType } from '../utils';

interface ProgressiveLoadingOptions {
    uuid: string;
    onError: (error: Error) => void;
}

interface FileMetadata {
    path: string;
    name: string;
    size: number;
    modifiedAt: Date | null;
    isFile: boolean;
}

interface LoadedFile extends FileMetadata {
    content: string;
    preview?: string; 
}

export const useProgressiveLoading = ({ uuid, onError }: ProgressiveLoadingOptions) => {
    const [fileMetadata, setFileMetadata] = useState<Map<string, FileMetadata>>(new Map());
    const [filePreviews, setFilePreviews] = useState<Map<string, string>>(new Map());
    const [fullContent, setFullContent] = useState<Map<string, string>>(new Map());
    const [loading, setLoading] = useState<Set<string>>(new Set());
    
    const loadingRef = useRef<Set<string>>(new Set());
    const abortControllersRef = useRef<Map<string, AbortController>>(new Map());

    const registerFileMetadata = useCallback((file: FileObject, directory: string) => {
        const path = directory === '/' ? `/${file.name}` : `${directory}/${file.name}`;
        const metadata: FileMetadata = {
            path,
            name: file.name,
            size: file.size,
            modifiedAt: file.modifiedAt ? new Date(file.modifiedAt) : null,
            isFile: file.isFile,
        };
        
        setFileMetadata(prev => {
            const next = new Map(prev);
            next.set(path, metadata);
            return next;
        });
    }, []);

    const registerFilesMetadata = useCallback((files: FileObject[], directory: string) => {
        setFileMetadata(prev => {
            const next = new Map(prev);
            files.forEach(file => {
                const path = directory === '/' ? `/${file.name}` : `${directory}/${file.name}`;
                next.set(path, {
                    path,
                    name: file.name,
                    size: file.size,
                    modifiedAt: file.modifiedAt ? new Date(file.modifiedAt) : null,
                    isFile: file.isFile,
                });
            });
            return next;
        });
    }, []);

    const loadPreview = useCallback(async (filePath: string): Promise<string | null> => {
        if (filePreviews.has(filePath)) {
            return filePreviews.get(filePath)!;
        }

        const mediaType = getMediaType(filePath);
        if (mediaType !== 'text') {
            return null; 
        }

        if (loadingRef.current.has(filePath)) {
            return null; 
        }

        try {
            loadingRef.current.add(filePath);
            setLoading(prev => new Set([...prev, filePath]));

            const content = await getFileContents(uuid, filePath);
            const preview = content.substring(0, 1024);

            setFilePreviews(prev => {
                const next = new Map(prev);
                next.set(filePath, preview);
                return next;
            });

            setFullContent(prev => {
                const next = new Map(prev);
                next.set(filePath, content);
                return next;
            });

            return preview;
        } catch (error) {
            onError(error as Error);
            return null;
        } finally {
            loadingRef.current.delete(filePath);
            setLoading(prev => {
                const next = new Set(prev);
                next.delete(filePath);
                return next;
            });
        }
    }, [uuid, filePreviews, onError]);

    const loadFullContent = useCallback(async (filePath: string, signal?: AbortSignal): Promise<string | null> => {
        if (fullContent.has(filePath)) {
            return fullContent.get(filePath)!;
        }

        if (loadingRef.current.has(filePath)) {
            return null; 
        }

        try {
            loadingRef.current.add(filePath);
            setLoading(prev => new Set([...prev, filePath]));

            const content = await getFileContents(uuid, filePath);

            if (signal?.aborted) {
                return null;
            }

            setFullContent(prev => {
                const next = new Map(prev);
                next.set(filePath, content);
                return next;
            });

            return content;
        } catch (error) {
            if (!signal?.aborted) {
                onError(error as Error);
            }
            return null;
        } finally {
            loadingRef.current.delete(filePath);
            setLoading(prev => {
                const next = new Set(prev);
                next.delete(filePath);
                return next;
            });
        }
    }, [uuid, fullContent, onError]);

    const loadMultipleFiles = useCallback(async (filePaths: string[]): Promise<Map<string, string>> => {
        const results = await Promise.all(
            filePaths.map((path) =>
                loadFullContent(path)
                    .then((value) => ({ status: 'fulfilled' as const, value }))
                    .catch((error) => ({ status: 'rejected' as const, reason: error }))
            )
        );

        const loadedFiles = new Map<string, string>();
        results.forEach((result, index) => {
            if (result.status === 'fulfilled' && result.value) {
                loadedFiles.set(filePaths[index], result.value);
            }
        });

        return loadedFiles;
    }, [loadFullContent]);

    const cancelLoad = useCallback((filePath: string) => {
        const controller = abortControllersRef.current.get(filePath);
        if (controller) {
            controller.abort();
            abortControllersRef.current.delete(filePath);
        }
    }, []);

    const clearFileCache = useCallback((filePath: string) => {
        setFullContent(prev => {
            const next = new Map(prev);
            next.delete(filePath);
            return next;
        });
        setFilePreviews(prev => {
            const next = new Map(prev);
            next.delete(filePath);
            return next;
        });
    }, []);

    useEffect(() => {
        return () => {
            abortControllersRef.current.forEach(controller => controller.abort());
            abortControllersRef.current.clear();
        };
    }, []);

    return {
        fileMetadata,
        filePreviews,
        fullContent,
        loading,
        isLoading: (path: string) => loading.has(path),
        registerFileMetadata,
        registerFilesMetadata,
        loadPreview,
        loadFullContent,
        loadMultipleFiles,
        cancelLoad,
        clearFileCache,
    };
};
