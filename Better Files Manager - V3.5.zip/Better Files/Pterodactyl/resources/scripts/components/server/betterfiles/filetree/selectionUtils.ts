import { type FileObject } from '@/api/server/files';

export const isDirectoryPath = (fileTree: Record<string, FileObject[]>, path: string): boolean => {
    if (path === '/') return true;
    if (fileTree[path]) return true;
    const parentPath = path.substring(0, path.lastIndexOf('/')) || '/';
    const name = path.substring(path.lastIndexOf('/') + 1);
    const parent = fileTree[parentPath] || [];
    return parent.some((file) => file.name === name && !file.isFile);
};

export const resolveActionTargetPaths = ({
    fileTree,
    selectedFiles,
    currentPath,
    viewMode,
    isDirectory,
}: {
    fileTree: Record<string, FileObject[]>;
    selectedFiles: string[];
    currentPath: string;
    viewMode: 'tree' | 'browse' | 'grid';
    isDirectory: (path: string) => boolean;
}): string[] => {
    if (selectedFiles.length > 0) {
        const directoryTargets = selectedFiles.filter((path) => isDirectory(path));
        if (directoryTargets.length > 0) return directoryTargets;
    }
    return [viewMode === 'tree' ? '/' : currentPath];
};
