import React from 'react';
import { VscJson } from 'react-icons/vsc';
import {
    SiJavascript, SiTypescript, SiPython, SiGo, SiRust, SiPhp, SiRuby,
    SiCplusplus, SiC, SiSharp, SiSwift, SiKotlin, SiDart, SiScala, SiElixir,
    SiHtml5, SiCss, SiSass, SiReact, SiVuedotjs, SiAngular, SiSvelte,
    SiNodedotjs, SiNpm, SiYarn, SiDocker, SiKubernetes, SiTerraform,
    SiGraphql, SiGit, SiGithub, SiGitlab,
    SiWebpack, SiVite, SiRollupdotjs, SiBabel,
    SiJest, SiCypress, SiVitest,
    SiEslint, SiPrettier, SiEditorconfig,
    SiMarkdown, SiLatex, SiAsciidoctor,
    SiApache, SiNginx,
    SiTailwindcss, SiNextdotjs, SiNuxt, SiGatsby, SiRemix,
    SiPrisma
} from 'react-icons/si';
import {
    FaFolder, FaFolderOpen, FaFileAlt, FaFileArchive, FaFileImage,
    FaFileVideo, FaFileAudio, FaFilePdf, FaFileWord, FaFileExcel,
    FaFilePowerpoint, FaFileCode, FaDatabase, FaLock, FaKey,
    FaCog, FaTerminal, FaBook, FaFileContract
} from 'react-icons/fa';
import { AiFillFileText, AiFillFile } from 'react-icons/ai';
import { DiJava } from 'react-icons/di';

interface FileIconProps {
    filename: string;
    isFolder?: boolean;
    isOpen?: boolean;
}

const FileIcon: React.FC<FileIconProps> = ({ filename, isFolder, isOpen }) => {
    const renderIcon = (IconComponent: any, color: string) => {
        return React.createElement(IconComponent, { className: 'w-4 h-4 flex-shrink-0', style: { color } });
    };

    if (isFolder) {
        return isOpen ? renderIcon(FaFolderOpen, '#FCD34D') : renderIcon(FaFolder, '#FBBF24');
    }

    const ext = filename.split('.').pop()?.toLowerCase() || '';
    const lowerFilename = filename.toLowerCase();
    if (['js', 'mjs', 'cjs'].includes(ext)) return renderIcon(SiJavascript, '#F7DF1E');
    if (['jsx'].includes(ext)) return renderIcon(SiReact, '#61DAFB');
    if (['ts', 'mts', 'cts'].includes(ext)) return renderIcon(SiTypescript, '#3178C6');
    if (['tsx'].includes(ext)) return renderIcon(SiReact, '#3178C6');
    if (ext === 'py') return renderIcon(SiPython, '#3776AB');
    if (ext === 'pyc') return renderIcon(SiPython, '#646464');
    if (['pyw', 'pyx', 'pyd'].includes(ext)) return renderIcon(SiPython, '#3776AB');
    if (ext === 'java') return renderIcon(DiJava, '#007396');
    if (ext === 'jar') return renderIcon(FaFileArchive, '#007396');
    if (ext === 'class') return renderIcon(DiJava, '#646464');
    if (ext === 'kt') return renderIcon(SiKotlin, '#7F52FF');
    if (ext === 'scala') return renderIcon(SiScala, '#DC322F');
    if (ext === 'groovy') return renderIcon(FaFileCode, '#4298B8');
    if (['c', 'h'].includes(ext)) return renderIcon(SiC, '#A8B9CC');
    if (['cpp', 'cc', 'cxx', 'hpp', 'hxx', 'h++'].includes(ext)) return renderIcon(SiCplusplus, '#00599C');
    if (['cs', 'csx'].includes(ext)) return renderIcon(SiSharp, '#239120');
    if (ext === 'go') return renderIcon(SiGo, '#00ADD8');
    if (ext === 'rs') return renderIcon(SiRust, '#CE422B');
    if (ext === 'swift') return renderIcon(SiSwift, '#FA7343');
    if (ext === 'php') return renderIcon(SiPhp, '#777BB4');
    if (['phtml', 'php3', 'php4', 'php5'].includes(ext)) return renderIcon(SiPhp, '#777BB4');
    if (ext === 'rb') return renderIcon(SiRuby, '#CC342D');
    if (ext === 'erb') return renderIcon(SiRuby, '#CC342D');
    if (lowerFilename === 'gemfile') return renderIcon(SiRuby, '#CC342D');
    if (ext === 'dart') return renderIcon(SiDart, '#0175C2');
    if (['ex', 'exs'].includes(ext)) return renderIcon(SiElixir, '#4B275F');
    if (['html', 'htm'].includes(ext)) return renderIcon(SiHtml5, '#E34F26');
    if (ext === 'css') return renderIcon(SiCss, '#1572B6');
    if (['scss', 'sass'].includes(ext)) return renderIcon(SiSass, '#CC6699');
    if (ext === 'less') return renderIcon(FaFileCode, '#1D365D');
    if (ext === 'vue') return renderIcon(SiVuedotjs, '#4FC08D');
    if (ext === 'svelte') return renderIcon(SiSvelte, '#FF3E00');
    if (ext === 'ng' || ['component.ts', 'module.ts', 'service.ts'].some((suffix) => lowerFilename.endsWith(suffix))) {
        return renderIcon(SiAngular, '#DD0031');
    }
    if (ext === 'json') return renderIcon(VscJson, '#FFC107');
    if (ext === 'jsonc') return renderIcon(VscJson, '#FFC107');
    if (['yaml', 'yml'].includes(ext)) return renderIcon(FaFileCode, '#CB171E');
    if (ext === 'toml') return renderIcon(FaFileCode, '#9C4121');
    if (ext === 'xml') return renderIcon(FaFileCode, '#E37933');
    if (['md', 'markdown', 'mdown', 'mkd'].includes(ext)) return renderIcon(SiMarkdown, '#083FA1');
    if (ext === 'mdx') return renderIcon(SiMarkdown, '#FCBF24');
    if (ext === 'tex') return renderIcon(SiLatex, '#008080');
    if (['adoc', 'asciidoc'].includes(ext)) return renderIcon(SiAsciidoctor, '#E40046');
    if (ext === 'rst') return renderIcon(FaBook, '#646464');
    if (ext === 'txt') return renderIcon(AiFillFileText, '#9CA3AF');
    if (['sh', 'bash', 'zsh', 'fish'].includes(ext)) return renderIcon(FaTerminal, '#4EAA25');
    if (['bat', 'cmd'].includes(ext)) return renderIcon(FaTerminal, '#0078D6');
    if (ext === 'ps1') return renderIcon(FaTerminal, '#012456');
    if (['properties', 'conf', 'cfg', 'ini', 'config'].includes(ext)) return renderIcon(FaCog, '#9CA3AF');
    if (['.env', '.env.local', '.env.development', '.env.production'].includes(lowerFilename)) return renderIcon(FaCog, '#ECD53F');
    if (ext === 'editorconfig' || lowerFilename === '.editorconfig') return renderIcon(SiEditorconfig, '#FEFEFE');
    if (lowerFilename === 'package.json') return renderIcon(SiNodedotjs, '#339933');
    if (lowerFilename === 'package-lock.json') return renderIcon(SiNpm, '#CB3837');
    if (['yarn.lock', '.yarnrc'].includes(lowerFilename)) return renderIcon(SiYarn, '#2C8EBB');
    if (['composer.json', 'composer.lock'].includes(lowerFilename)) return renderIcon(SiPhp, '#777BB4');
    if (['gemfile', 'gemfile.lock'].includes(lowerFilename)) return renderIcon(SiRuby, '#CC342D');
    if (['requirements.txt', 'pipfile', 'poetry.lock'].includes(lowerFilename)) return renderIcon(SiPython, '#3776AB');
    if (lowerFilename === 'cargo.toml' || lowerFilename === 'cargo.lock') return renderIcon(SiRust, '#CE422B');
    if (lowerFilename === 'go.mod' || lowerFilename === 'go.sum') return renderIcon(SiGo, '#00ADD8');
    if (['webpack.config.js', 'webpack.config.ts'].includes(lowerFilename)) return renderIcon(SiWebpack, '#8DD6F9');
    if (['vite.config.js', 'vite.config.ts'].includes(lowerFilename)) return renderIcon(SiVite, '#646CFF');
    if (['rollup.config.js', 'rollup.config.ts'].includes(lowerFilename)) return renderIcon(SiRollupdotjs, '#EC4A3F');
    if (['.babelrc', 'babel.config.js', 'babel.config.json'].includes(lowerFilename)) return renderIcon(SiBabel, '#F9DC3E');
    if (['tsconfig.json', 'jsconfig.json'].includes(lowerFilename)) return renderIcon(SiTypescript, '#3178C6');
    if (['jest.config.js', 'jest.config.ts'].includes(lowerFilename)) return renderIcon(SiJest, '#C21325');
    if (['cypress.config.js', 'cypress.config.ts'].includes(lowerFilename)) return renderIcon(SiCypress, '#17202C');
    if (['vitest.config.js', 'vitest.config.ts'].includes(lowerFilename)) return renderIcon(SiVitest, '#729B1B');
    if (['test.js', 'test.ts', 'spec.js', 'spec.ts'].some(e => lowerFilename.includes(e))) return renderIcon(FaFileCode, '#C21325');
    if (['.eslintrc', '.eslintrc.js', '.eslintrc.json', 'eslint.config.js'].includes(lowerFilename)) return renderIcon(SiEslint, '#4B32C3');
    if (['.prettierrc', '.prettierrc.js', '.prettierrc.json', 'prettier.config.js'].includes(lowerFilename)) return renderIcon(SiPrettier, '#F7B93E');
    if (['dockerfile', '.dockerignore'].includes(lowerFilename) || ext === 'dockerfile') return renderIcon(SiDocker, '#2496ED');
    if (lowerFilename === 'docker-compose.yml' || lowerFilename === 'docker-compose.yaml') return renderIcon(SiDocker, '#2496ED');
    if (ext === 'tf' || ext === 'tfvars') return renderIcon(SiTerraform, '#7B42BC');
    if (lowerFilename.includes('kubernetes') || ext === 'k8s') return renderIcon(SiKubernetes, '#326CE5');
    if (['.gitignore', '.gitattributes', '.gitmodules'].includes(lowerFilename)) return renderIcon(SiGit, '#F05032');
    if (lowerFilename === '.gitlab-ci.yml') return renderIcon(SiGitlab, '#FC6D26');
    if (lowerFilename === '.github') return renderIcon(SiGithub, '#181717');
    if (ext === 'sql') return renderIcon(FaDatabase, '#F29111');
    if (ext === 'db' || ext === 'sqlite' || ext === 'sqlite3') return renderIcon(FaDatabase, '#003B57');
    if (ext === 'prisma') return renderIcon(SiPrisma, '#2D3748');
    if (ext === 'graphql' || ext === 'gql') return renderIcon(SiGraphql, '#E10098');
    if (['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'tgz', 'tbz2'].includes(ext) || filename.includes('.tar.')) {
        return renderIcon(FaFileArchive, '#A78BFA');
    }
    if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'ico', 'tiff', 'tif'].includes(ext)) {
        return renderIcon(FaFileImage, '#F472B6');
    }
    if (ext === 'svg') return renderIcon(FaFileImage, '#FFB13B');
    if (['mp4', 'webm', 'ogv', 'avi', 'mov', 'mkv', 'flv', 'wmv', 'm4v'].includes(ext)) {
        return renderIcon(FaFileVideo, '#EC4899');
    }

    if (['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'wma', 'aiff'].includes(ext)) {
        return renderIcon(FaFileAudio, '#8B5CF6');
    }
    if (ext === 'pdf') return renderIcon(FaFilePdf, '#F40F02');
    if (['doc', 'docx'].includes(ext)) return renderIcon(FaFileWord, '#2B579A');
    if (['xls', 'xlsx', 'csv'].includes(ext)) return renderIcon(FaFileExcel, '#217346');
    if (['ppt', 'pptx'].includes(ext)) return renderIcon(FaFilePowerpoint, '#D24726');
    if (['pem', 'key', 'pub', 'crt', 'cer', 'p12', 'pfx'].includes(ext)) return renderIcon(FaKey, '#F59E0B');
    if (ext === 'lock') return renderIcon(FaLock, '#6B7280');
    if (ext === 'log') return renderIcon(FaFileAlt, '#6B7280');
    if (['license', 'licence', 'copying'].includes(lowerFilename)) return renderIcon(FaFileContract, '#10B981');
    if (lowerFilename === 'readme.md' || lowerFilename === 'readme') return renderIcon(FaBook, '#3B82F6');
    if (lowerFilename === 'next.config.js' || lowerFilename === 'next.config.mjs') return renderIcon(SiNextdotjs, '#000000');
    if (lowerFilename === 'nuxt.config.js' || lowerFilename === 'nuxt.config.ts') return renderIcon(SiNuxt, '#00DC82');
    if (lowerFilename === 'gatsby-config.js') return renderIcon(SiGatsby, '#663399');
    if (lowerFilename === 'remix.config.js') return renderIcon(SiRemix, '#000000');
    if (lowerFilename === 'tailwind.config.js' || lowerFilename === 'tailwind.config.ts') return renderIcon(SiTailwindcss, '#06B6D4');
    if (['httpd.conf', 'apache2.conf'].includes(lowerFilename) || lowerFilename.includes('apache')) return renderIcon(SiApache, '#D22128');
    if (lowerFilename === 'nginx.conf' || lowerFilename.includes('nginx')) return renderIcon(SiNginx, '#009639');
    return renderIcon(AiFillFile, '#9CA3AF');
};

export default FileIcon;

