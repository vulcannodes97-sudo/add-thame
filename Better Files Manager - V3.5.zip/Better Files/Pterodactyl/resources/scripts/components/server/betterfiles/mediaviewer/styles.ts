import styled, { css } from 'styled-components';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { colors } from '../colors';

export const ViewerWrapper = styled.div`
    flex: 1;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    min-height: 0;
    min-width: 0;
`;

export const ViewerContainer = styled(GreyRowBox).attrs({ className: '!bg-gray-800 !border-gray-800' })`
    width: 100%;
    height: 100%;
    padding: 0;
    overflow: hidden;
    display: flex;
    align-items: stretch;
    justify-content: stretch;
    position: relative;
`;

export const Image = styled.img`
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
`;

export const PlayerContainer = styled.div`
    position: relative;
    width: 100%;
    height: 100%;
    flex: 1;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: transparent;
    border-radius: inherit;
`;

export const VideoElement = styled.video`
    width: 100%;
    height: 100%;
    object-fit: contain;
    position: relative;
    z-index: 1;
`;

export const ControlsOverlay = styled.div<{ visible: boolean }>`
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    transition: opacity 300ms;
    opacity: ${props => props.visible ? 1 : 0};
    background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.35) 55%, rgba(0, 0, 0, 0.65) 100%);
    pointer-events: none;
    z-index: 2;
`;

export const ControlsBar = styled.div`
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    width: 100%;
    user-select: none;
    pointer-events: auto;
`;

export const ControlButton = styled.button.attrs({ className: 'text-white hover:bg-gray-600' })`
    padding: 0.5rem;
    border-radius: 9999px;
    transition: all 200ms;
    outline: none;
    
    svg {
        width: 1.5rem;
        height: 1.5rem;
    }
`;

export const BigPlayButton = styled.button`
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    outline: none;
    
    div {
        width: 5rem;
        height: 5rem;
        border-radius: 9999px;
        display: flex;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(4px);
        transition: all 300ms;
        transform: scale(0.9);
        opacity: 0;
    }

    svg {
        width: 2.5rem;
        height: 2.5rem;
        margin-left: 0.25rem;
    }

    .group:hover & div {
        opacity: 1;
        transform: scale(1);
    }
`;

export const ProgressBarContainer = styled.div.attrs({ className: 'group bg-gray-600 hover:bg-gray-500' })`
    position: relative;
    width: 100%;
    height: 0.5rem;
    border-radius: 9999px;
    cursor: pointer;
    transition: height 150ms ease, background 150ms ease;
    
    &:hover {
        height: 0.625rem;
    }
`;

export const ProgressBarFill = styled.div<{ width: number }>`
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    border-radius: 9999px;
    pointer-events: none;
    background: ${colors.primary.default};
    width: ${props => props.width}%;
`;

export const ProgressBarThumb = styled.div.attrs({ className: 'bg-gray-300' })<{ left: number }>`
    position: absolute;
    top: 50%;
    width: 0.875rem;
    height: 0.875rem;
    border-radius: 9999px;
    pointer-events: none;
    left: ${props => props.left}%;
    transform: translate(-50%, -50%) scale(0);
    transition: transform 150ms ease;
    
    .group:hover & {
        transform: translate(-50%, -50%) scale(1);
    }
`;

export const TimeDisplay = styled.div.attrs({ className: 'text-white' })`
    font-size: 0.75rem;
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    min-width: 80px;
    text-align: center;
`;

export const VolumeContainer = styled.div`
    display: flex;
    align-items: center;
    gap: 0.5rem;
`;

export const VolumeSlider = styled.input.attrs({ className: 'text-gray-500' })`
    width: 5rem;
    transition: background 200ms;
    height: 0.25rem;
    background: currentColor;
    border-radius: 0.5rem;
    appearance: none;
    cursor: pointer;
    &::-webkit-slider-thumb {
        appearance: none;
        width: 0.75rem;
        height: 0.75rem;
        background: currentColor;
        border-radius: 9999px;
        box-shadow: none;
    }
`;

export const RateSlider = styled(VolumeSlider)`
    width: 6rem;
    transition: none;
`;

export const AudioPlayerContainer = styled.div`
    width: 100%;
    height: 100%;
    flex: 1;
    display: flex;
    flex-direction: column;
    position: relative;
    overflow: hidden;

    @media (max-width: 640px) {
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
    }
`;

export const VisualizerCanvas = styled.canvas`
    width: 100%;
    height: 100%;
    position: absolute;
    inset: 0;
    opacity: 0.75;
    transform-origin: center bottom;
    transition: transform 140ms ease-out;
    will-change: transform;
`;

export const AudioContent = styled.div`
    position: relative;
    z-index: 10;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    justify-content: space-between;
    gap: 1.5rem;
    height: 100%;
    width: 100%;
    padding: 1.5rem;
    transform: scale(1);
    transition: transform 220ms ease-out;
    will-change: transform;

    @media (max-width: 640px) {
        padding: 1rem;
        gap: 1rem;
        overflow-y: auto;
    }
`;

export const AudioIconWrapper = styled.div<{ playing: boolean }>`
    width: 7rem;
    height: 7rem;
    border-radius: 9999px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1.5rem;
    background: ${colors.primary.default};
    position: relative;
    z-index: 2;
    transition: transform 0.2s ease;
    
    ${props => props.playing && css`
        animation: pulse 2s ease-in-out infinite;
    `}

    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.02); }
    }

    @media (max-width: 640px) {
        width: 5.5rem;
        height: 5.5rem;
        margin-bottom: 0.75rem;
    }
`;

export const AudioHeader = styled.div`
    display: flex;
    align-items: center;
    gap: 1.5rem;
    width: 100%;
    max-width: 48rem;
    justify-content: center;
    margin-bottom: 1.5rem;

    @media (max-width: 640px) {
        flex-direction: column;
        text-align: center;
        gap: 1rem;
        margin-bottom: 1rem;
    }
`;

export const ArtworkStack = styled.div`
    position: relative;
    width: 7rem;
    height: 7rem;
    flex-shrink: 0;

    @media (max-width: 640px) {
        width: 5.5rem;
        height: 5.5rem;
    }
`;

export const VinylDisk = styled.div<{ playing: boolean }>`
    position: absolute;
    width: 6.2rem;
    height: 6.2rem;
    top: 50%;
    left: -2.2rem;
    transform: translateY(-50%);
    border-radius: 9999px;
    background:
        radial-gradient(circle at center, rgba(255, 255, 255, 0.95) 0 7%, rgba(255, 255, 255, 0.2) 7% 10%, rgba(0, 0, 0, 0.95) 10% 55%, rgba(255, 255, 255, 0.22) 55% 58%, rgba(0, 0, 0, 0.98) 58% 100%),
        conic-gradient(from 110deg, rgba(255, 255, 255, 0.7) 0deg, rgba(255, 255, 255, 0.15) 22deg, rgba(0, 0, 0, 0.4) 60deg, rgba(255, 255, 255, 0.2) 120deg, rgba(0, 0, 0, 0.5) 170deg, rgba(255, 255, 255, 0.35) 230deg, rgba(0, 0, 0, 0.6) 320deg, rgba(255, 255, 255, 0.7) 360deg);
    border: 1px solid rgba(255, 255, 255, 0.35);
    box-shadow: 0 16px 30px rgba(0, 0, 0, 0.45);
    transform-origin: center;
    opacity: 0.9;
    z-index: 1;
    animation: ${props => (props.playing ? 'vinylSpin 3.6s linear infinite' : 'none')};

    @keyframes vinylSpin {
        from { transform: translateY(-50%) rotate(0deg); }
        to { transform: translateY(-50%) rotate(360deg); }
    }

    @media (max-width: 640px) {
        width: 4.8rem;
        height: 4.8rem;
        left: -1.6rem;
    }
`;

export const BeatNotesLayer = styled.div`
    position: absolute;
    inset: 0;
    pointer-events: none;
    overflow: visible;

    .beat-note {
        position: absolute;
        color: ${colors.primary.default};
        font-size: 1.2rem;
        opacity: 0.9;
        text-shadow: 0 6px 12px ${colors.primary.opacity(0.4)};
        transform: translate(0, 0) scale(0.85) rotate(0deg);
        animation: beatNoteFloat 1.1s ease-out forwards;
        will-change: transform, opacity;
    }

    @keyframes beatNoteFloat {
        0% {
            transform: translate(0, 0) scale(0.85) rotate(0deg);
            opacity: 0.95;
        }
        100% {
            transform: translate(var(--dx), var(--dy)) scale(1.25) rotate(18deg);
            opacity: 0;
        }
    }
`;

export const AudioArtwork = styled.img`
    width: 7rem;
    height: 7rem;
    border-radius: 1rem;
    object-fit: cover;
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.35);
    border: 1px solid ${colors.primary.opacity(0.35)};
    position: relative;
    z-index: 2;

    @media (max-width: 640px) {
        width: 5.5rem;
        height: 5.5rem;
        border-radius: 0.9rem;
    }
`;

export const AudioMeta = styled.div`
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
    min-width: 0;
`;

export const AudioTitle = styled.div`
    font-size: 1.35rem;
    font-weight: 700;
    color: white;
    line-height: 1.2;
    max-width: 22rem;
    word-break: break-word;

    @media (max-width: 640px) {
        font-size: 1.1rem;
        max-width: 100%;
    }
`;

export const AudioSubtitle = styled.div.attrs({ className: 'text-gray-400' })`
    font-size: 0.85rem;
    max-width: 22rem;
    word-break: break-word;

    @media (max-width: 640px) {
        max-width: 100%;
    }
`;

export const AudioControls = styled(GreyRowBox).attrs({ className: 'bg-gray-600 border-gray-700' })`
    display: block;
    width: 100%;
    max-width: 44rem;
    padding: 1.5rem;
    align-items: initial;
    justify-content: initial;
    backdrop-filter: blur(12px);

    @media (max-width: 640px) {
        padding: 1rem;
        max-width: 100%;
    }
`;

export const WaveformScrubber = styled.div.attrs({ className: '!bg-gray-800 !border-gray-700' })`
    position: relative;
    width: 100%;
    height: 2.2rem;
    border-radius: 0.9rem;
    overflow: hidden;
    cursor: pointer;
    border-width: 1px;
`;

export const WaveformControls = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    flex-wrap: wrap;
`;

export const ZoomControl = styled.div.attrs({ className: 'bg-gray-800 border-gray-700' })`
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.3rem 0.5rem;
    border-radius: 9999px;
    border-width: 1px;
`;

export const ZoomButton = styled.button.attrs({ className: 'text-white bg-gray-800 hover:bg-gray-700' })`
    width: 1.6rem;
    height: 1.6rem;
    border-radius: 9999px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    transition: background 150ms;
`;

export const ZoomLabel = styled.span.attrs({ className: 'text-gray-400' })`
    font-size: 0.7rem;
    letter-spacing: 0.1em;
    text-transform: uppercase;
`;

export const WaveformCanvas = styled.canvas`
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
`;

export const WaveformPlayhead = styled.div`
    position: absolute;
    top: 0.3rem;
    bottom: 0.3rem;
    width: 2px;
    background: ${colors.primary.default};
    box-shadow: 0 0 10px ${colors.primary.opacity(0.65)};
    border-radius: 9999px;
    pointer-events: none;
`;
