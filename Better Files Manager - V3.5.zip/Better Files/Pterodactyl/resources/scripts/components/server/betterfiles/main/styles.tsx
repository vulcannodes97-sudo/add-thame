import React, { useState } from 'react';
import tw, { TwStyle } from 'twin.macro';
import { colors } from '../colors';
import GreyRowBox from '@/components/elements/GreyRowBox';

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

type DivProps = React.HTMLAttributes<HTMLDivElement> & { css?: TwStyle };

export const PageContainer = React.forwardRef<HTMLDivElement, DivProps>(({ className, style, ...props }, ref) => (
    <div ref={ref} className={cx('mb-0 md:mb-4 bfm-page-container', className)} style={style} {...props} />
));


export const Container = React.forwardRef<HTMLDivElement, DivProps & { isResizing?: boolean }>(
    ({ className, style, isResizing, ...props }, ref) => (
        <div
            ref={ref}
            className={cx(
                'flex overflow-hidden gap-2 mx-auto w-full max-w-full',
                'flex-col md:flex-row',
                'h-[calc(100dvh-4rem)] md:h-[calc(100vh-10rem)]',
                'min-h-0 md:min-h-[600px]',
                className
            )}
            style={{ ...style }}
            {...props}
        />
    )
);
Container.displayName = 'Container';

export const LeftPanel = React.forwardRef<HTMLDivElement, DivProps & { width: number; isResizing?: boolean }>(
    ({ width, isResizing, className, style, css: outerCss, ...props }, ref) => (
        <GreyRowBox
            ref={ref}
            css={[tw`flex-col items-stretch items-start w-full`, outerCss]}
            className={cx(
                'flex-col flex-none overflow-hidden',
                'w-full h-full min-w-0',
                'md:w-[var(--bfm-left-width)] md:basis-[var(--bfm-left-width)] md:shrink-0 md:min-w-[200px] md:max-w-[480px]',
                className
            )}
            style={{
                ['--bfm-left-width' as any]: `${width}px`,
                transition: isResizing ? 'none' : 'width 0.3s ease',
                contain: 'layout paint size',
                willChange: isResizing ? 'width' : undefined,
                ...style,
            }}
            {...props}
        />
    )
);
LeftPanel.displayName = 'LeftPanel';

export const ResizeHandle: React.FC<DivProps> = ({ className, style, onMouseDown, onMouseUp, ...props }) => {
    const [hovered, setHovered] = useState(false);
    const [active, setActive] = useState(false);
    return (
        <div
            className={cx(
                'w-1 transition-colors duration-150 bg-gray-500 hidden md:block cursor-col-resize',
                className
            )}
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => {
                setHovered(false);
                setActive(false);
            }}
            onMouseDown={(e) => {
                setActive(true);
                onMouseDown?.(e);
            }}
            onMouseUp={(e) => {
                setActive(false);
                onMouseUp?.(e);
            }}
            style={{
                backgroundColor: active ? colors.primary.dark : hovered ? colors.primary.default : undefined,
                ...style,
            }}
            {...props}
        />
    );
};

export { GreyRowBox };

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement>;
type SpanProps = React.HTMLAttributes<HTMLSpanElement>;

export const EditorHeader: React.FC<DivProps> = ({ className, ...props }) => (
    <div
        className={cx(
            'px-0 py-0 flex flex-col gap-2',
            'md:flex-row md:items-center md:justify-between md:px-0 md:py-0',
            className
        )}
        {...props}
    />
);

export const FilePath: React.FC<DivProps> = ({ className, ...props }) => (
    <div
        className={cx(
            'font-mono text-sm flex flex-col items-start gap-1 text-neutral-300 w-full min-w-0',
            'md:flex-row md:items-center md:gap-2 md:flex-wrap',
            className
        )}
        {...props}
    />
);

export const EditorActions: React.FC<DivProps> = ({ className, ...props }) => (
    <div className={cx('flex items-center gap-2 flex-wrap ml-auto flex-shrink-0', className)} {...props} />
);

export const EmptyState: React.FC<DivProps> = ({ className, ...props }) => (
    <div
        className={cx('flex-1 flex items-center justify-center flex-col p-4 text-neutral-300', className)}
        {...props}
    />
);

export const SplitViewContainer = React.forwardRef<HTMLDivElement, DivProps>(({ className, ...props }, ref) => (
    <div ref={ref} className={cx('flex flex-1 overflow-y-auto md:overflow-hidden', className)} {...props} />
));
SplitViewContainer.displayName = 'SplitViewContainer';

export const SplitEditorPane = React.forwardRef<HTMLDivElement, DivProps & { isDragOver?: boolean }>(
    ({ isDragOver, className, style, ...props }, ref) => (
        <div
            ref={ref}
            className={cx('flex-1 flex flex-col overflow-y-auto md:overflow-hidden relative min-w-0', className)}
            style={{
                ...(isDragOver ? {} : {}),
                ...style,
            }}
            {...props}
        />
    )
);
SplitEditorPane.displayName = 'SplitEditorPane';

export const SplitDropZone: React.FC<DivProps & { isDragOver?: boolean }> = ({ isDragOver, className, style, children, ...props }) => (
    <div
        className={cx('absolute inset-0 flex items-center justify-center z-10 transition-opacity', className)}
        style={{
            padding: 12,
            background: isDragOver ? colors.primary.opacity(0.08) : 'transparent',
            opacity: isDragOver ? 1 : 0,
            pointerEvents: isDragOver ? 'auto' : 'none',
            ...style,
        }}
        {...props}
    >
        <div
            className='w-full h-full flex items-center justify-center'
            style={{
                border: `2px dashed ${colors.primary.default}`,
                borderSpacing: 10,
                borderCollapse: 'separate',
                boxShadow: `0 0 0 1px ${colors.primary.opacity(0.35)}`,
                background: colors.primary.opacity(0.06),
            }}
        >
            {children}
        </div>
    </div>
);

export const SplitDivider: React.FC<DivProps> = ({ className, style, ...props }) => {
    const [hovered, setHovered] = useState(false);
    const [active, setActive] = useState(false);
    return (
        <div
            className={cx('flex-shrink-0 flex items-center justify-center transition-colors bg-gray-700', className)}
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => {
                setHovered(false);
                setActive(false);
            }}
            onMouseDown={() => setActive(true)}
            onMouseUp={() => setActive(false)}
            style={{
                width: 6,
                cursor: 'col-resize',
                background: active ? colors.primary.opacity(0.25) : hovered ? colors.primary.opacity(0.15) : undefined,
                ...style,
            }}
            {...props}
        >
            <span
                className='transition-all bg-gray-500'
                style={{
                    width: 2,
                    height: hovered ? 60 : 40,
                    background: hovered ? colors.primary.default : undefined,
                    borderRadius: 1,
                    boxShadow: hovered ? `0 0 8px ${colors.primary.default}` : undefined,
                }}
            />
        </div>
    );
};

export const SplitPaneHeader: React.FC<DivProps & { active: boolean }> = ({ active, className, style, ...props }) => (
    <div
        className={cx(
            'px-2 py-1.5 flex items-center justify-between gap-2 cursor-pointer select-none border-b text-neutral-300',
            active ? 'bg-gray-600/70 border-gray-500' : 'bg-gray-700/40 border-gray-600',
            className
        )}
        style={style}
        {...props}
    />
);

export const SplitPaneHeaderLeft: React.FC<DivProps> = ({ className, ...props }) => (
    <div className={cx('flex items-center gap-2 min-w-0', className)} {...props} />
);

export const SplitPaneTitle: React.FC<SpanProps & { active: boolean }> = ({ active, className, style, ...props }) => (
    <span className={cx('text-[11px] font-medium truncate text-neutral-300', className)} style={style} {...props} />
);

export const PaneBadge: React.FC<SpanProps & { active: boolean }> = ({ active, className, style, ...props }) => (
    <span
        className={cx(
            'text-[9px] uppercase tracking-widest px-1.5 py-0 border text-neutral-300',
            active ? '' : 'border-gray-600 bg-gray-700',
            className
        )}
        style={{
            ...(active
                ? {
                      borderColor: colors.primary.opacity(0.5),
                      background: colors.primary.opacity(0.25),
                  }
                : {}),
            ...style,
        }}
        {...props}
    />
);

export const SplitCloseButton: React.FC<ButtonProps> = ({ className, style, ...props }) => (
    <button
        className={cx(
            'absolute top-1 right-1 z-20 p-1 text-neutral-300 transition-all bg-gray-700 backdrop-blur-sm hover:text-neutral-300 hover:bg-red-500 hover:text-red-300',
            className
        )}
        style={{
            ...style,
        }}
        {...props}
    />
);

export const MobileTabBar: React.FC<DivProps> = ({ className, ...props }) => (
    <div className={cx('flex items-center md:hidden bg-gray-600 border-b border-gray-500', className)} {...props} />
);

export const MobileTab: React.FC<ButtonProps & { active: boolean }> = ({ active, className, children, ...props }) => (
    <button
        className={cx(
            'flex-1 py-3 text-sm font-medium transition-colors relative',
            active ? 'text-neutral-300 bg-gray-700' : 'text-gray-500',
            className
        )}
        {...props}
    >
        {children}
        <span
            className='absolute bottom-0 left-0 w-full h-0.5 transition-colors'
            style={{ backgroundColor: active ? colors.primary.default : 'transparent' }}
        />
    </button>
);
