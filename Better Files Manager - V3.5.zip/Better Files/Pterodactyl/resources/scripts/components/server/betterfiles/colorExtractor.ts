import styles from '@/components/elements/button/style.module.css';

interface ExtractedColors {
    bg: string;
    text: string;
}

const extractColorsFromClass = (className: string): ExtractedColors => {
    if (typeof window === 'undefined' || !document?.body) {
        return { bg: '', text: '' };
    }

    const tempElement = document.createElement('div');
    tempElement.className = className;
    tempElement.style.position = 'absolute';
    tempElement.style.visibility = 'hidden';
    tempElement.style.pointerEvents = 'none';
    document.body.appendChild(tempElement);
    const computedStyles = window.getComputedStyle(tempElement);
    const bg = computedStyles.backgroundColor;
    const text = computedStyles.color;
    document.body.removeChild(tempElement);

    return { bg, text };
};

const FALLBACK_COLORS: Record<'primary' | 'text' | 'danger', ExtractedColors> = {
    primary: { bg: '#6366f1', text: '#ffffff' },  
    text: { bg: '#e5e7eb', text: '#111827' },
    danger: { bg: '#ef4444', text: '#ffffff' }
};

const CSS_VAR_MAP: Record<'primary' | 'text' | 'danger', { bg: string; text: string }> = {
    primary: { bg: '--pageButtonDefault', text: '--pagePrimary' },
    text: { bg: '--pageSecondary', text: '--pagePrimary' },
    danger: { bg: '--statusError', text: '--pagePrimary' }
};

let cachedColors: {
    primary: ExtractedColors | null;
    text: ExtractedColors | null;
    danger: ExtractedColors | null;
} = {
    primary: null,
    text: null,
    danger: null
};

const getExtractedColors = (variant: 'primary' | 'text' | 'danger'): ExtractedColors => {
    if (!cachedColors[variant]) {
        try {
            const cssBg = getCssVariable(CSS_VAR_MAP[variant].bg);
            const cssText = getCssVariable(CSS_VAR_MAP[variant].text);
            if (cssBg) {
                cachedColors[variant] = {
                    bg: cssBg,
                    text: cssText || FALLBACK_COLORS[variant].text
                };
                return cachedColors[variant]!;
            }

            const className = variant === 'primary' ? styles.primary :
                variant === 'text' ? styles.text :
                    styles.danger;
            const extracted = extractColorsFromClass(className);
            if (!extracted.bg || extracted.bg === 'rgba(0, 0, 0, 0)') {
                cachedColors[variant] = FALLBACK_COLORS[variant];
            } else {
                cachedColors[variant] = extracted;
            }
        } catch (error) {
            cachedColors[variant] = FALLBACK_COLORS[variant];
        }
    }
    return cachedColors[variant]!;
};

const getCssVariable = (variableName: string): string | null => {
    if (typeof window === 'undefined') return null;
    const value = getComputedStyle(document.documentElement).getPropertyValue(variableName).trim();
    return value || null;
};

const getPageColor = (
    bfmVar: string,
    fallbackVar: string,
    fallbackClass: string,
    fallbackProperty: 'backgroundColor' | 'color',
    fallback: string
): string => {
    return (
        getCssVariable(bfmVar) ||
        getCssVariable(fallbackVar) ||
        resolveClassColor(fallbackClass, fallbackProperty) ||
        fallback
    );
};

const resolveClassColor = (className: string, property: 'backgroundColor' | 'color'): string | null => {
    if (typeof window === 'undefined' || !document?.body) return null;
    const tempElement = document.createElement('div');
    tempElement.className = className;
    tempElement.style.position = 'absolute';
    tempElement.style.visibility = 'hidden';
    tempElement.style.pointerEvents = 'none';
    document.body.appendChild(tempElement);
    const computedStyles = window.getComputedStyle(tempElement);
    const value = property === 'backgroundColor' ? computedStyles.backgroundColor : computedStyles.color;
    document.body.removeChild(tempElement);
    return value && value !== 'rgba(0, 0, 0, 0)' ? value : null;
};

export const initThemeVars = () => {
    if (typeof window === 'undefined') return;

    const root = document.documentElement;
    const mappings: Array<{
        targetVar: string;
        sourceVar: string;
        className: string;
        property: 'backgroundColor' | 'color';
    }> = [
        { targetVar: '--bfm-page-background', sourceVar: '--pageBackground', className: 'bg-gray-900', property: 'backgroundColor' },
        { targetVar: '--bfm-page-secondary', sourceVar: '--pageSecondary', className: 'bg-gray-800', property: 'backgroundColor' },
        { targetVar: '--bfm-page-secondary-hover', sourceVar: '--pageSecondaryHover', className: 'bg-gray-700', property: 'backgroundColor' },
        { targetVar: '--bfm-page-secondary-active', sourceVar: '--pageSecondaryActive', className: 'bg-gray-600', property: 'backgroundColor' },
        { targetVar: '--bfm-page-secondary-selected', sourceVar: '--pageSecondarySelected', className: 'bg-gray-500', property: 'backgroundColor' },
        { targetVar: '--bfm-page-primary', sourceVar: '--pagePrimary', className: 'text-gray-100', property: 'color' },
        { targetVar: '--bfm-page-primary-hover', sourceVar: '--pagePrimaryHover', className: 'text-gray-300', property: 'color' },
    ];

    for (const { targetVar, sourceVar, className, property } of mappings) {
        const existing = getComputedStyle(root).getPropertyValue(targetVar).trim();
        if (existing) continue;

        const fromTheme = getCssVariable(sourceVar);
        if (fromTheme) {
            root.style.setProperty(targetVar, fromTheme);
            continue;
        }

        const fromClass = resolveClassColor(className, property);
        if (fromClass) {
            root.style.setProperty(targetVar, fromClass);
        }
    }
};

export const themeColors = {
    primary: {
        get iconColor() {
            const colors = getExtractedColors('primary');
            return colors.bg; 
        },

        get bg() {
            return styles.primary;
        },

        swap: {
            get asText() {
                const colors = getExtractedColors('primary');
                return colors.bg; 
            },
            get asBg() {
                const colors = getExtractedColors('primary');
                return colors.text;
            }
        }
    },

    text: {
        get iconColor() {
            const colors = getExtractedColors('text');
            return colors.bg;
        },
        get bg() {
            return styles.text;
        },
        swap: {
            get asText() {
                const colors = getExtractedColors('text');
                return colors.bg;
            },
            get asBg() {
                const colors = getExtractedColors('text');
                return colors.text;
            }
        }
    },

    danger: {
        get iconColor() {
            const cssVar = getCssVariable('--dangerBackground');
            if (cssVar) return cssVar;

            const colors = getExtractedColors('danger');
            return colors.bg;
        },
        get bg() {
            return styles.danger;
        },
        swap: {
            get asText() {
                const colors = getExtractedColors('danger');
                return colors.bg;
            },
            get asBg() {
                const colors = getExtractedColors('danger');
                return colors.text;
            }
        }
    },

    success: {
        get iconColor() {
            const cssVar = getCssVariable('--successBackground');
            if (cssVar) return cssVar;
            const statusOnline = getCssVariable('--statusOnline');
            if (statusOnline) return statusOnline;

            return '#10b981'; 
        }
    },

    secondary: {
        get iconColor() {
            const cssVar = getCssVariable('--secondaryBackground');
            if (cssVar) return cssVar;
            const pageSecondarySelected = getCssVariable('--pageSecondarySelected');
            if (pageSecondarySelected) return pageSecondarySelected;

            return '#6b7280'; 
        }
    },

    page: {
        get background() {
            return getPageColor('--bfm-page-background', '--pageBackground', 'bg-gray-900', 'backgroundColor', '#111827');
        },
        get secondary() {
            return getPageColor('--bfm-page-secondary', '--pageSecondary', 'bg-gray-800', 'backgroundColor', '#1f2937');
        },
        get secondaryHover() {
            return getPageColor('--bfm-page-secondary-hover', '--pageSecondaryHover', 'bg-gray-700', 'backgroundColor', '#374151');
        },
        get secondaryActive() {
            return getPageColor('--bfm-page-secondary-active', '--pageSecondaryActive', 'bg-gray-600', 'backgroundColor', '#4b5563');
        },
        get secondarySelected() {
            return getPageColor('--bfm-page-secondary-selected', '--pageSecondarySelected', 'bg-gray-500', 'backgroundColor', '#6b7280');
        },
        get primary() {
            return getPageColor('--bfm-page-primary', '--pagePrimary', 'text-gray-100', 'color', '#f3f4f6');
        },
        get primaryHover() {
            return getPageColor('--bfm-page-primary-hover', '--pagePrimaryHover', 'text-gray-300', 'color', '#d1d5db');
        }
    },

    borderRadius: {
        get box() {
            const cssVar = getCssVariable('--radiusBox');
            if (cssVar) return cssVar;
            return '0.75rem'; 
        },
        get component() {
            const cssVar = getCssVariable('--radiusInput');
            if (cssVar) return cssVar;
            return '0.5rem'; 
        }
    }
};

export const clearColorCache = () => {
    cachedColors = {
        primary: null,
        text: null,
        danger: null
    };
};

export const primaryIcon = themeColors.primary.iconColor;
export const primaryBg = themeColors.primary.bg;
export const primarySwapText = themeColors.primary.swap.asText;
export const primarySwapBg = themeColors.primary.swap.asBg;

export default themeColors;
