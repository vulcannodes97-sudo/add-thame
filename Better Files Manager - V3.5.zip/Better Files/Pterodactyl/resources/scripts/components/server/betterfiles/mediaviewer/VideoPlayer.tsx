import React, { useState, useEffect, useRef } from 'react';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import {
    PlayerContainer,
    VideoElement,
    ControlsOverlay,
    ControlsBar,
    ControlButton,
    BigPlayButton,
    ProgressBarContainer,
    ProgressBarFill,
    ProgressBarThumb,
    TimeDisplay,
    VolumeContainer,
    VolumeSlider,
} from './styles';
import { VideoPlayerProps } from './types';
import { formatTime, readStoredVolume, writeStoredVolume, applyMediaSettings } from './utils';

const resolveClassColor = (className: string, property: 'backgroundColor' | 'color'): string => {
    if (typeof window === 'undefined' || !document?.body) return '';
    const temp = document.createElement('div');
    temp.className = className;
    temp.style.position = 'absolute';
    temp.style.visibility = 'hidden';
    temp.style.pointerEvents = 'none';
    document.body.appendChild(temp);
    const value = window.getComputedStyle(temp)[property];
    document.body.removeChild(temp);
    return value;
};

const getBufferedColor = () => resolveClassColor('bg-gray-500', 'backgroundColor');

const VideoPlayer: React.FC<VideoPlayerProps> = ({
    src,
    blobUrl,
    fileName,
    isStreaming,
    resumeState,
    onError,
    onWaiting,
    onPlaying,
    onTimeUpdate,
    onPlayingChange,
}) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const ambientFrameRef = useRef<number | null>(null);
    const [playing, setPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [buffered, setBuffered] = useState(0);
    const [seekPreview, setSeekPreview] = useState<number | null>(null);
    const [volume, setVolume] = useState(() => readStoredVolume());
    const [muted, setMuted] = useState(false);
    const [playbackRate, setPlaybackRate] = useState(1);
    const [fullscreen, setFullscreen] = useState(false);
    const [showControls, setShowControls] = useState(true);
    const [cornerColors, setCornerColors] = useState<{ tl: string; tr: string; bl: string; br: string } | null>(null);
    const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const pendingResumeRef = useRef<{ time: number; wasPlaying: boolean } | null>(null);
    const lastSrcRef = useRef<string | null>(null);
    const lastVolumeRef = useRef(readStoredVolume());
    const lastMutedRef = useRef(false);
    const lastRateRef = useRef(1);
    const bufferedColor = getBufferedColor();

    const applySettings = (video: HTMLVideoElement) => {
        applyMediaSettings(video, lastVolumeRef.current, lastMutedRef.current, lastRateRef.current);
    };

    useEffect(() => {
        const video = videoRef.current;
        if (!video) return;

        const updateTime = () => setCurrentTime(video.currentTime);
        const updateBuffered = () => {
            if (video.buffered.length > 0 && video.duration > 0) {
                const end = video.buffered.end(video.buffered.length - 1);
                setBuffered((end / video.duration) * 100);
            }
        };
        const updateDuration = () => {
            setDuration(video.duration);
            applySettings(video);
            if (pendingResumeRef.current) {
                const resume = pendingResumeRef.current;
                const target = Math.min(resume.time, Math.max(0, video.duration - 0.1));
                if (!Number.isNaN(target)) {
                    video.currentTime = target;
                }
                if (resume.wasPlaying) {
                    const promise = video.play();
                    if (promise && typeof promise.catch === 'function') {
                        promise.catch(() => {});
                    }
                }
                pendingResumeRef.current = null;
            }
        };
        const onPlay = () => {
            setPlaying(true);
            onPlaying?.();
            onPlayingChange?.(true);
        };
        const onPause = () => {
            setPlaying(false);
            onPlayingChange?.(false);
        };
        const onVolumeChange = () => {
            setVolume(video.volume);
            setMuted(video.muted);
        };
        const onRateChange = () => {
            setPlaybackRate(video.playbackRate);
        };

        video.addEventListener('timeupdate', updateTime);
        video.addEventListener('progress', updateBuffered);
        video.addEventListener('loadedmetadata', updateDuration);
        video.addEventListener('play', onPlay);
        video.addEventListener('pause', onPause);
        video.addEventListener('volumechange', onVolumeChange);
        video.addEventListener('ratechange', onRateChange);
        video.addEventListener('waiting', onWaiting);
        video.addEventListener('canplay', onPlaying);

        return () => {
            video.removeEventListener('timeupdate', updateTime);
            video.removeEventListener('progress', updateBuffered);
            video.removeEventListener('loadedmetadata', updateDuration);
            video.removeEventListener('play', onPlay);
            video.removeEventListener('pause', onPause);
            video.removeEventListener('volumechange', onVolumeChange);
            video.removeEventListener('ratechange', onRateChange);
            video.removeEventListener('waiting', onWaiting);
            video.removeEventListener('canplay', onPlaying);
        };
    }, [onWaiting, onPlaying, onPlayingChange]);

    useEffect(() => {
        const video = videoRef.current;
        if (!video || !src) return;
        const previousSrc = lastSrcRef.current;
        if (previousSrc && previousSrc !== src && isStreaming && resumeState) {
            pendingResumeRef.current = { time: resumeState.time, wasPlaying: resumeState.wasPlaying };
        }
        if (previousSrc && previousSrc !== src) {
            try {
                video.load();
            } catch {}
        }
        applySettings(video);
        lastSrcRef.current = src;
    }, [isStreaming, resumeState, src]);

    useEffect(() => {
        lastVolumeRef.current = volume;
        writeStoredVolume(volume);
    }, [volume]);

    useEffect(() => {
        lastMutedRef.current = muted;
    }, [muted]);

    useEffect(() => {
        lastRateRef.current = playbackRate;
    }, [playbackRate]);

    useEffect(() => {
        onTimeUpdate?.(currentTime);
    }, [currentTime, onTimeUpdate]);

    useEffect(() => {
        if (!canvasRef.current) {
            canvasRef.current = document.createElement('canvas');
            canvasRef.current.width = 8;
            canvasRef.current.height = 8;
        }
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) return;

        const smoothColors = { tl: [0, 0, 0], tr: [0, 0, 0], bl: [0, 0, 0], br: [0, 0, 0] };
        const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
        const smoothFactor = 0.08;

        const sampleColors = () => {
            const video = videoRef.current;
            if (!video || video.paused || video.readyState < 2) {
                ambientFrameRef.current = requestAnimationFrame(sampleColors);
                return;
            }

            try {
                ctx.drawImage(video, 0, 0, 8, 8);
                const getRgb = (x: number, y: number) => {
                    const data = ctx.getImageData(x, y, 1, 1).data;
                    return [data[0], data[1], data[2]];
                };

                const corners = {
                    tl: getRgb(0, 0),
                    tr: getRgb(7, 0),
                    bl: getRgb(0, 7),
                    br: getRgb(7, 7),
                };

                for (const key of ['tl', 'tr', 'bl', 'br'] as const) {
                    for (let i = 0; i < 3; i++) {
                        smoothColors[key][i] = lerp(smoothColors[key][i], corners[key][i], smoothFactor);
                    }
                }

                const toRgb = (arr: number[]) => `rgb(${Math.round(arr[0])}, ${Math.round(arr[1])}, ${Math.round(arr[2])})`;
                setCornerColors({
                    tl: toRgb(smoothColors.tl),
                    tr: toRgb(smoothColors.tr),
                    bl: toRgb(smoothColors.bl),
                    br: toRgb(smoothColors.br),
                });
            } catch {}

            ambientFrameRef.current = requestAnimationFrame(sampleColors);
        };

        ambientFrameRef.current = requestAnimationFrame(sampleColors);

        return () => {
            if (ambientFrameRef.current) {
                cancelAnimationFrame(ambientFrameRef.current);
            }
        };
    }, []);

    const togglePlay = () => {
        if (videoRef.current) {
            if (playing) videoRef.current.pause();
            else videoRef.current.play();
        }
    };

    const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!videoRef.current) return;
        const rect = e.currentTarget.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        videoRef.current.currentTime = percent * duration;
    };

    const handleSeekPreview = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!duration) return;
        const rect = e.currentTarget.getBoundingClientRect();
        const percent = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
        setSeekPreview(percent * duration);
    };

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            videoRef.current?.parentElement?.requestFullscreen();
            setFullscreen(true);
        } else {
            document.exitFullscreen();
            setFullscreen(false);
        }
    };

    const handleMouseMove = () => {
        setShowControls(true);
        if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
        controlsTimeoutRef.current = setTimeout(() => {
            if (playing) setShowControls(false);
        }, 3000);
    };

    return (
        <PlayerContainer onMouseMove={handleMouseMove} onMouseLeave={() => playing && setShowControls(false)}>
            {cornerColors && (
                <div style={{
                    position: 'absolute',
                    inset: 0,
                    zIndex: 0,
                    pointerEvents: 'none',
                    background: `
                        radial-gradient(circle at 0% 0%, ${cornerColors.tl} 0%, transparent 70%),
                        radial-gradient(circle at 100% 0%, ${cornerColors.tr} 0%, transparent 70%),
                        radial-gradient(circle at 0% 100%, ${cornerColors.bl} 0%, transparent 70%),
                        radial-gradient(circle at 100% 100%, ${cornerColors.br} 0%, transparent 70%)
                    `,
                }} />
            )}
            <VideoElement
                ref={videoRef}
                src={src}
                crossOrigin="anonymous"
                onClick={togglePlay}
                onDoubleClick={toggleFullscreen}
                onError={onError}
                preload="auto"
            />

            <BigPlayButton onClick={togglePlay}>
                {!playing && (
                    <div className="bg-black border border-gray-500">
                        <svg className="text-white" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M8 5l11 7-11 7V5z" />
                        </svg>
                    </div>
                )}
            </BigPlayButton>

            <ControlsOverlay visible={showControls || !playing}>
                <ControlsBar>
                    <ControlButton onClick={togglePlay}>
                        {playing ? (
                            <svg fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M7 5v14M17 5v14" />
                            </svg>
                        ) : (
                            <svg fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M8 5l11 7-11 7V5z" />
                            </svg>
                        )}
                    </ControlButton>

                    <VolumeContainer>
                        <ControlButton onClick={() => { if (videoRef.current) videoRef.current.muted = !muted; }}>
                            {muted || volume === 0 ? (
                                <svg fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 9v6l-4 0v-6h4zm0 0l5-4v14l-5-4M19 9l-3 3m0-3l3 3" />
                                </svg>
                            ) : (
                                <svg fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 9v6l-4 0v-6h4zm0 0l5-4v14l-5-4M16 8a4 4 0 010 8M18.5 6.5a7 7 0 010 11" />
                                </svg>
                            )}
                        </ControlButton>
                        <VolumeSlider
                            type="range"
                            min="0"
                            max="1"
                            step="0.1"
                            value={muted ? 0 : volume}
                            onChange={(e) => {
                                if (videoRef.current) {
                                    videoRef.current.volume = parseFloat(e.target.value);
                                    videoRef.current.muted = false;
                                }
                            }}
                        />
                    </VolumeContainer>

                    <TimeDisplay>{formatTime(currentTime)} / {formatTime(duration)}</TimeDisplay>

                    <Tooltip
                        placement="top"
                        content={seekPreview !== null ? formatTime(seekPreview) : formatTime(0)}
                        disabled={seekPreview === null || !duration}
                    >
                        <ProgressBarContainer
                            onClick={handleSeek}
                            onMouseMove={handleSeekPreview}
                            onMouseLeave={() => setSeekPreview(null)}
                        >
                            <div style={{
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                height: '100%',
                                borderRadius: '9999px',
                                width: `${buffered}%`,
                                pointerEvents: 'none',
                            }} />
                            <ProgressBarFill width={(currentTime / duration) * 100 || 0} />
                            <ProgressBarThumb left={(currentTime / duration) * 100 || 0} />
                        </ProgressBarContainer>
                    </Tooltip>

                    {blobUrl && (
                        <a href={blobUrl} download={fileName} className="text-white p-2">
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1M12 4v11m0 0l-4-4m4 4l4-4" />
                            </svg>
                        </a>
                    )}

                    <ControlButton onClick={toggleFullscreen}>
                        {fullscreen ? (
                            <svg fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9 9H5V5m14 4V5h-4M9 15H5v4m14-4v4h-4" />
                            </svg>
                        ) : (
                            <svg fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 9V5h4M15 5h4v4M9 19H5v-4M19 15v4h-4" />
                            </svg>
                        )}
                    </ControlButton>
                </ControlsBar>
            </ControlsOverlay>
        </PlayerContainer>
    );
};

export default VideoPlayer;
