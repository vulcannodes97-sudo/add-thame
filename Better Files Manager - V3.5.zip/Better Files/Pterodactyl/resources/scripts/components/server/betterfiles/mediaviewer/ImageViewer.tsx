import React from 'react';
import { Image } from './styles';
import { ImageViewerProps } from './types';

const ImageViewer: React.FC<ImageViewerProps> = ({ src, alt }) => {
    return (
        <div className="flex-1 flex items-center justify-center">
            <Image src={src} alt={alt} />
        </div>
    );
};

export default ImageViewer;
