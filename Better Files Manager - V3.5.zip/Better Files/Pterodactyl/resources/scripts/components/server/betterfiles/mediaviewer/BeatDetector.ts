import { BeatInfo } from './types';

export class BeatDetector {
    private prevSpectrum: Float32Array | null = null;
    private fluxHistory: number[] = [];
    private energyHistory: number[] = [];
    private prevFlux = 0;
    private prevFlux2 = 0;
    private beatIntervals: number[] = [];
    private lastBeatAt = 0;
    private lastDropAt = 0;
    private energyShort = 0.2;
    private energyLong = 0.25;

    update(spectrum: Float32Array, bassEnergy: number, totalEnergy: number, now: number): BeatInfo {
        if (!this.prevSpectrum || this.prevSpectrum.length !== spectrum.length) {
            this.prevSpectrum = new Float32Array(spectrum.length);
        }

        const len = spectrum.length;
        const lowEnd = Math.max(4, Math.floor(len * 0.12));
        const midEnd = Math.max(lowEnd + 2, Math.floor(len * 0.35));
        let fluxLow = 0;
        let fluxMid = 0;
        let fluxHigh = 0;

        for (let i = 0; i < len; i++) {
            const current = spectrum[i];
            const prev = this.prevSpectrum[i];
            const diff = current - prev;
            if (diff > 0) {
                if (i < lowEnd) fluxLow += diff;
                else if (i < midEnd) fluxMid += diff;
                else fluxHigh += diff;
            }
            this.prevSpectrum[i] = prev + (current - prev) * 0.65;
        }

        const totalFlux = (fluxLow * 1.25 + fluxMid * 0.9 + fluxHigh * 0.6) / (len * 255);
        this.fluxHistory.push(totalFlux);
        if (this.fluxHistory.length > 48) this.fluxHistory.shift();

        const fluxAvg = this.fluxHistory.reduce((sum, v) => sum + v, 0) / this.fluxHistory.length;
        const fluxStd = Math.sqrt(
            this.fluxHistory.reduce((sum, v) => sum + (v - fluxAvg) * (v - fluxAvg), 0) / this.fluxHistory.length
        );
        const fluxThreshold = fluxAvg + fluxStd * 1.1 + 0.008;

        this.energyShort = this.energyShort * 0.55 + totalEnergy * 0.45;
        this.energyLong = this.energyLong * 0.985 + totalEnergy * 0.015;

        const isFluxPeak = this.prevFlux > this.prevFlux2 && this.prevFlux > totalFlux && this.prevFlux > fluxThreshold;
        const isBeatEnergy = bassEnergy > 0.16 && (totalFlux > fluxThreshold * 0.9);
        const isBeat = (isFluxPeak || isBeatEnergy) && totalFlux > 0.01;

        const intervalAvg = this.beatIntervals.length
            ? this.beatIntervals.reduce((sum, v) => sum + v, 0) / this.beatIntervals.length
            : 420;
        const minInterval = Math.max(140, Math.min(420, intervalAvg * 0.55));

        let beat = false;
        let strength = 0;
        if (isBeat && now - this.lastBeatAt > minInterval) {
            beat = true;
            strength = Math.min(1.5, 0.6 + totalFlux * 6 + bassEnergy * 1.2);
            if (this.lastBeatAt > 0) {
                this.beatIntervals.push(now - this.lastBeatAt);
                if (this.beatIntervals.length > 12) this.beatIntervals.shift();
            }
            this.lastBeatAt = now;
        }

        const dropCandidate = this.energyShort < this.energyLong * 0.6 && bassEnergy < 0.14;
        const drop = dropCandidate && now - this.lastDropAt > 1200 && totalEnergy < 0.25;
        if (drop) this.lastDropAt = now;

        this.prevFlux2 = this.prevFlux;
        this.prevFlux = totalFlux;

        return { beat, strength, drop };
    }

    reset(): void {
        this.prevSpectrum = null;
        this.fluxHistory = [];
        this.energyHistory = [];
        this.prevFlux = 0;
        this.prevFlux2 = 0;
        this.beatIntervals = [];
        this.lastBeatAt = 0;
        this.lastDropAt = 0;
        this.energyShort = 0.2;
        this.energyLong = 0.25;
    }
}
