import React, { useState, useEffect } from 'react';
import { FileObject } from '@/api/server/files';
import { Dialog } from '@/components/elements/dialog';
import { Button } from '@/components/elements/button';
import FileIcon from './FileIcon';
import { colors } from './colors';
import { themeColors } from './colorExtractor';

interface DirectoryPickerProps {
    open: boolean;
    onClose: () => void;
    onConfirm: (path: string) => void;
    fileTree: Record<string, FileObject[]>;
    currentPath: string;
    title?: string;
    onLoadDirectory: (path: string) => Promise<FileObject[]>;
    defaultPath?: string;
}

const DirectoryPicker: React.FC<DirectoryPickerProps> = ({
    open,
    onClose,
    onConfirm,
    fileTree,
    currentPath,
    title = "Select Destination",
    onLoadDirectory,
    defaultPath
}) => {
    const [selectedPath, setSelectedPath] = useState(currentPath);
    const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['/']));
    const [loadingFolders, setLoadingFolders] = useState<Set<string>>(new Set());

    useEffect(() => {
        if (open) {
            setSelectedPath(defaultPath ?? currentPath);
        }
    }, [open, currentPath, defaultPath]);

    const toggleFolder = async (path: string) => {
        const newExpanded = new Set(expandedFolders);
        if (newExpanded.has(path)) {
            newExpanded.delete(path);
            setExpandedFolders(newExpanded);
        } else {
            newExpanded.add(path);
            setExpandedFolders(newExpanded);

            if (!fileTree[path]) {
                setLoadingFolders(prev => new Set(prev).add(path));
                try {
                    await onLoadDirectory(path);
                } finally {
                    setLoadingFolders(prev => {
                        const next = new Set(prev);
                        next.delete(path);
                        return next;
                    });
                }
            }
        }
    };

    const renderFolderTree = (path: string, depth = 0): React.ReactNode[] => {
        const files = fileTree[path] || [];
        const folders = files.filter(file => !file.isFile);
        const elements: React.ReactNode[] = [];

        folders.forEach(folder => {
            const fullPath = path === '/' ? `/${folder.name}` : `${path}/${folder.name}`;
            const isExpanded = expandedFolders.has(fullPath);
            const isSelected = selectedPath === fullPath;
            const isLoading = loadingFolders.has(fullPath);

            elements.push(
                <div
                    key={fullPath}
                    className={`flex items-center gap-2 px-3 py-2.5 cursor-pointer text-sm transition-all my-1 ${isSelected
                        ? 'text-neutral-300 shadow-md font-semibold'
                        : 'text-neutral-300 hover:bg-gray-600 hover:text-neutral-300'
                        }`}
                    style={{
                        paddingLeft: depth * 20 + 12,
                        backgroundColor: isSelected ? colors.primary.default : undefined
                    }}
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedPath(fullPath);
                    }}
                >
                    {isLoading ? (
                        <svg className="w-4 h-4 flex-shrink-0 animate-spin" style={{ color: colors.primary.light }} fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    ) : (
                        <svg
                            className={`w-4 h-4 flex-shrink-0 cursor-pointer transition-colors ${isSelected ? 'text-neutral-300' : 'text-gray-500 hover:text-neutral-300'
                                }`}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                toggleFolder(fullPath);
                            }}
                        >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isExpanded ? "M19 9l-7 7-7-7" : "M9 5l7 7-7 7"} />
                        </svg>
                    )}
                    <FileIcon filename={folder.name} isFolder={true} isOpen={isExpanded} />
                    <span className="flex-1 truncate font-medium">{folder.name}</span>
                </div>
            );

            if (isExpanded) {
                elements.push(...renderFolderTree(fullPath, depth + 1));
            }
        });

        return elements;
    };

    return (
        <Dialog open={open} onClose={onClose} title={title}>
            <div
                className="mb-4 p-3 text-sm bg-gray-700 border border-gray-600 text-neutral-300"
                
            >
                Selected: <strong className="font-semibold ml-2" style={{ color: colors.primary.default }}>{selectedPath}</strong>
            </div>
            <div
                className="max-h-96 overflow-y-auto p-4 bg-gray-700 border border-gray-600 shadow-inner"
                
            >
                <div
                    className={`flex items-center gap-2 px-3 py-2.5 cursor-pointer text-sm transition-all my-1 ${selectedPath === '/'
                        ? 'text-neutral-300 shadow-md font-semibold'
                        : 'text-neutral-300 hover:bg-gray-600 hover:text-neutral-300'
                        }`}
                    style={{
                        paddingLeft: 12,
                        backgroundColor: selectedPath === '/' ? colors.primary.default : undefined
                    }}
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedPath('/');
                    }}
                >
                    <svg
                        className={`w-4 h-4 flex-shrink-0 cursor-pointer transition-colors ${selectedPath === '/' ? 'text-neutral-300' : 'text-gray-500 hover:text-neutral-300'
                            }`}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            toggleFolder('/');
                        }}
                    >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={expandedFolders.has('/') ? "M19 9l-7 7-7-7" : "M9 5l7 7-7 7"} />
                    </svg>
                    <FileIcon filename="/" isFolder={true} isOpen={expandedFolders.has('/')} />
                    <span className="flex-1 truncate font-medium">Root Directory</span>
                </div>
                {renderFolderTree('/', 0)}
            </div>
            <Dialog.Footer>
                <Button.Text onClick={(e) => {
                    e.preventDefault();
                    onClose();
                }}>
                    Cancel
                </Button.Text>
                <Button
                    onClick={(e) => {
                        e.preventDefault();
                        onConfirm(selectedPath);
                    }}
                    disabled={selectedPath === currentPath}
                >
                    Move Here
                </Button>
            </Dialog.Footer>
        </Dialog>
    );
};

export default DirectoryPicker;
