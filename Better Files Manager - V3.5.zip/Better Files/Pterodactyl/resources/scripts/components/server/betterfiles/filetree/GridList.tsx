import React, { useMemo } from 'react';
import type { FileObject } from '@/api/server/files';

interface Props {
    currentPath: string;
    files: FileObject[];
    sortBy: 'name' | 'size' | 'date' | 'type';
    sortDirection: 'asc' | 'desc';
    parentPath: string;
    containerRef: React.RefObject<HTMLElement>;
    renderParentRow?: () => React.ReactNode;
    renderGridItem: (file: FileObject, fullPath: string) => React.ReactNode;
    selectedFile?: string | null;
    selectedFiles?: string[];
    draggedPaths?: Set<string>;
    isDragging?: boolean;
}

interface GridItem {
    file: FileObject;
    fullPath: string;
}

const GridList: React.FC<Props> = ({
    currentPath,
    files,
    sortBy,
    sortDirection,
    parentPath,
    containerRef,
    renderParentRow,
    renderGridItem,
    selectedFile,
    selectedFiles,
    draggedPaths,
    isDragging,
}) => {
    const sortedItems = useMemo(() => {
        const items: GridItem[] = [];

        if (renderParentRow && parentPath !== currentPath) {
            items.push({
                file: { name: '..', isFile: false } as FileObject,
                fullPath: '__parent__',
            });
        }

        const sortedFiles = [...files].sort((a, b) => {
            const isADir = a.isFile === false;
            const isBDir = b.isFile === false;

            if (isADir !== isBDir) {
                return isADir ? -1 : 1;
            }

            let comparison = 0;
            switch (sortBy) {
                case 'name':
                    comparison = a.name.localeCompare(b.name);
                    break;
                case 'size':
                    comparison = (a.size || 0) - (b.size || 0);
                    break;
                case 'date': {
                    const dateA = a.modifiedAt ? new Date(a.modifiedAt).getTime() : 0;
                    const dateB = b.modifiedAt ? new Date(b.modifiedAt).getTime() : 0;
                    comparison = dateA - dateB;
                    break;
                }
                case 'type': {
                    const extA = a.name.split('.').pop() || '';
                    const extB = b.name.split('.').pop() || '';
                    comparison = extA.localeCompare(extB);
                    break;
                }
            }

            return sortDirection === 'asc' ? comparison : -comparison;
        });

        sortedFiles.forEach(file => {
            items.push({
                file,
                fullPath: currentPath === '/' ? `/${file.name}` : `${currentPath}/${file.name}`,
            });
        });

        return items;
    }, [files, currentPath, sortBy, sortDirection, parentPath, renderParentRow]);

    const tileMinWidth = 104;

    return (
        <div className="px-4 py-3 min-w-full w-full">
            {renderParentRow && parentPath !== currentPath && (
                <div className="mb-4 w-full">
                    {renderParentRow()}
                </div>
            )}
            <div
                className="w-full"
                style={{
                    display: 'grid',
                    gridTemplateColumns: `repeat(auto-fill, minmax(${tileMinWidth}px, 1fr))`,
                    gap: '12px 10px',
                    justifyContent: 'start',
                    alignContent: 'start',
                }}
            >
                {sortedItems
                    .filter(item => item.fullPath !== '__parent__')
                    .map((item) => (
                        <div key={item.fullPath}>
                            {renderGridItem(item.file, item.fullPath)}
                        </div>
                    ))}
            </div>
        </div>
    );
};

export default GridList;
