import type { MediaType } from './types';

export const getMediaType = (filename: string): MediaType => {
    const ext = filename.split('.').pop()?.toLowerCase();

    if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'ico'].includes(ext || '')) return 'image';
    if (['mp4', 'webm', 'ogv', 'avi', 'mov', 'mkv'].includes(ext || '')) return 'video';
    if (['mp3', 'wav', 'ogg', 'flac', 'm4a'].includes(ext || '')) return 'audio';
    if (
        [
            'jar', 'zip', 'tar', 'gz', 'bz2', 'rar', '7z', 'exe', 'dll', 'so', 'dylib',
            'bin', 'dat', 'pak', 'iso', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt',
            'pptx', 'sqlite', 'sqlite3', 'class', 'war', 'ear',
        ].includes(ext || '')
    ) return 'binary';

    return 'text';
};

export const isArchiveFile = (filename: string): boolean => {
    const ext = filename.split('.').pop()?.toLowerCase();
    return ['zip', 'tar', 'gz', 'rar', '7z', 'bz2', 'xz', 'tgz'].includes(ext || '') || filename.includes('.tar.');
};

export const groupByDirectory = (paths: string[]): Map<string, string[]> => {
    const grouped = new Map<string, string[]>();
    for (const rawPath of paths) {
        if (!rawPath) continue;
        const normalized = rawPath.startsWith('/') ? rawPath : `/${rawPath}`;
        const lastSlash = normalized.lastIndexOf('/');
        const directory = lastSlash <= 0 ? '/' : normalized.slice(0, lastSlash);
        const name = normalized.slice(lastSlash + 1);
        if (!name) continue;
        const list = grouped.get(directory) ?? [];
        list.push(name);
        grouped.set(directory, list);
    }
    return grouped;
};

export const normalizePath = (path: string): string => {
    return path.startsWith('/') ? path : `/${path}`;
};

export const getFileName = (path: string): string => {
    return path.substring(path.lastIndexOf('/') + 1);
};

export const getDirectory = (path: string): string => {
    const lastSlash = path.lastIndexOf('/');
    return lastSlash <= 0 ? '/' : path.substring(0, lastSlash);
};
