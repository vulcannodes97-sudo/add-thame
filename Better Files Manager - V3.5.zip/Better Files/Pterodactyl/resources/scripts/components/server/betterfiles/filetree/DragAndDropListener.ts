import { useCallback, useEffect, useRef, useState } from 'react';
import { unstable_batchedUpdates } from 'react-dom';
import { getFilesFromDataTransfer, type FolderFile } from './dragUtils';

export type InternalDragData =
    | { multiple: true; files: { path: string; name: string; isFile: boolean }[] }
    | { multiple: false; path: string; name: string; isFile: boolean };

interface DragAndDropOptions {
    isMobileViewport: boolean;
    currentPath: string;
    viewMode: 'tree' | 'browse' | 'grid';
    selectedFiles: string[];
    normalizePath: (path: string) => string;
    getParentPath: (path: string) => string;
    onInternalMove: (dragData: InternalDragData, destination: string) => Promise<void>;
    onExternalDrop: (files: FolderFile[], destination: string, hasFolders: boolean) => Promise<void>;
    onError: (error: Error) => void;
    trackDragOverPath?: boolean;
    onDragStartSplit?: () => void;
    onDragEndSplit?: () => void;
    onSplitHover?: (over: boolean, pane?: string | null) => void;
    hideTooltip?: () => void;
    marqueeActiveRef?: React.MutableRefObject<boolean>;
}

export const useDragAndDropListener = ({
    isMobileViewport,
    currentPath,
    viewMode,
    selectedFiles,
    normalizePath,
    getParentPath,
    onInternalMove,
    onExternalDrop,
    onError,
    trackDragOverPath = true,
    onDragStartSplit,
    onDragEndSplit,
    onSplitHover,
    hideTooltip,
    marqueeActiveRef,
}: DragAndDropOptions) => {
    const [isDragging, setIsDragging] = useState(false);
    const [dragOverPath, setDragOverPath] = useState<string | null>(null);
    const [draggingFile, setDraggingFile] = useState<{ path: string; name: string; isFile: boolean; multiple?: boolean } | null>(null);
    const [draggedPaths, setDraggedPaths] = useState<Set<string>>(new Set());
    const [dragGhostInfo, setDragGhostInfo] = useState<{ name: string; filename: string; isFolder: boolean } | null>(null);

    const dragOverPathRef = useRef<string | null>(null);
    const isDraggingRef = useRef(false);
    const dragPointerRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
    const dragRafRef = useRef<number | null>(null);
    const autoScrollRafRef = useRef<number | null>(null);
    const autoScrollVelocityRef = useRef(0);
    const dragStartRef = useRef<{ x: number; y: number; path: string; name: string; isFile: boolean } | null>(null);
    const dragActiveRef = useRef(false);
    const internalDragDataRef = useRef<InternalDragData | null>(null);
    const suppressClickRef = useRef(false);
    const holdTimerRef = useRef<number | null>(null);
    const externalDragActiveRef = useRef(false);
    const splitHoverRef = useRef<string | null>(null);

    const treeContainerRef = useRef<HTMLDivElement>(null);
    const dragGhostRef = useRef<HTMLDivElement>(null);
    const hoverOverlayRef = useRef<HTMLDivElement>(null);
    const lastHoverTargetRef = useRef<HTMLElement | null>(null);

    const userSelectRestoreRef = useRef<{ userSelect: string; webkitUserSelect: string; msUserSelect: string } | null>(null);

    const isDragMoveDisabled = useCallback(() => {
        if (isMobileViewport) return true;
        if (typeof window === 'undefined') return false;
        if (window.innerWidth < 768) return true;
        if (typeof window.matchMedia !== 'function') return false;
        return window.matchMedia('(pointer: coarse)').matches;
    }, [isMobileViewport]);

    const disableTextSelection = useCallback(() => {
        if (userSelectRestoreRef.current) return;
        const element = document.documentElement;
        userSelectRestoreRef.current = {
            userSelect: element.style.userSelect,
            webkitUserSelect: (element.style as any).webkitUserSelect ?? '',
            msUserSelect: (element.style as any).msUserSelect ?? '',
        };
        element.style.userSelect = 'none';
        (element.style as any).webkitUserSelect = 'none';
        (element.style as any).msUserSelect = 'none';
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.removeAllRanges();
        }
    }, []);

    const restoreTextSelection = useCallback(() => {
        const restore = userSelectRestoreRef.current;
        if (!restore) return;
        const element = document.documentElement;
        element.style.userSelect = restore.userSelect;
        (element.style as any).webkitUserSelect = restore.webkitUserSelect;
        (element.style as any).msUserSelect = restore.msUserSelect;
        userSelectRestoreRef.current = null;
    }, []);

    const updateHoverOverlay = useCallback((target: HTMLElement | null) => {
        const overlay = hoverOverlayRef.current;
        const container = treeContainerRef.current;
        if (!overlay || !container) return;
        if (lastHoverTargetRef.current === target && target) {
            return;
        }
        lastHoverTargetRef.current = target;
        if (!target) {
            overlay.style.opacity = '0';
            overlay.style.transform = 'translate3d(-9999px, -9999px, 0)';
            overlay.style.width = '0px';
            overlay.style.height = '0px';
            return;
        }
        const targetRect = target.getBoundingClientRect();
        if (overlay.dataset.overlayMode === 'viewport') {
            const containerRect = container.getBoundingClientRect();
            const left = Math.max(targetRect.left, containerRect.left);
            const right = Math.min(targetRect.right, containerRect.right);
            const width = Math.max(0, right - left);
            overlay.style.width = `${width}px`;
            overlay.style.height = `${targetRect.height}px`;
            overlay.style.transform = `translate3d(${Math.round(left)}px, ${Math.round(targetRect.top)}px, 0)`;
            overlay.style.opacity = width > 0 ? '1' : '0';
            return;
        }
        const containerRect = container.getBoundingClientRect();
        const left = targetRect.left - containerRect.left + container.scrollLeft;
        const top = targetRect.top - containerRect.top + container.scrollTop;
        overlay.style.width = `${targetRect.width}px`;
        overlay.style.height = `${targetRect.height}px`;
        overlay.style.transform = `translate3d(${Math.round(left)}px, ${Math.round(top)}px, 0)`;
        overlay.style.opacity = '1';
    }, []);

    const setDragOverPathSafe = useCallback((path: string | null) => {
        if (dragOverPathRef.current === path) return;
        dragOverPathRef.current = path;
        if (trackDragOverPath) {
            setDragOverPath(path);
        }
    }, [trackDragOverPath]);

    const setIsDraggingSafe = useCallback((next: boolean) => {
        if (isDraggingRef.current === next) return;
        isDraggingRef.current = next;
        setIsDragging(next);
        if (!next) {
            updateHoverOverlay(null);
            lastHoverTargetRef.current = null;
        }
    }, [updateHoverOverlay]);

    const buildInternalDragData = useCallback((path: string, name: string, isFile: boolean): InternalDragData => {
        const isSelected = selectedFiles?.includes(path);
        if (isSelected && selectedFiles && selectedFiles.length > 1) {
            return {
                multiple: true,
                files: selectedFiles.map((filePath) => ({
                    path: filePath,
                    name: filePath.substring(filePath.lastIndexOf('/') + 1),
                    isFile: true,
                })),
            };
        }
        return { multiple: false, path, name, isFile };
    }, [selectedFiles]);

    const isInternalDragEvent = (dataTransfer: DataTransfer): boolean => {
        return dataTransfer.types.includes('application/x-filetree-drag');
    };

    const isExternalFileDragEvent = (dataTransfer: DataTransfer): boolean => {
        return Array.from(dataTransfer.types).includes('Files');
    };

    const startAutoScroll = useCallback(() => {
        if (autoScrollRafRef.current !== null) return;
        const step = () => {
            autoScrollRafRef.current = null;
            const container = treeContainerRef.current;
            if (!container) return;
            if (!draggingFile && !externalDragActiveRef.current) return;
            const { y } = dragPointerRef.current;
            const rect = container.getBoundingClientRect();
            const threshold = 56;
            let targetVelocity = 0;
            if (y < rect.top + threshold) {
                targetVelocity = -Math.min(18, (threshold - (y - rect.top)) / 2);
            } else if (y > rect.bottom - threshold) {
                targetVelocity = Math.min(18, (threshold - (rect.bottom - y)) / 2);
            }
            autoScrollVelocityRef.current += (targetVelocity - autoScrollVelocityRef.current) * 0.2;
            const velocity = autoScrollVelocityRef.current;
            if (Math.abs(velocity) > 0.1) {
                container.scrollTop += velocity;
                autoScrollRafRef.current = requestAnimationFrame(step);
            } else if (targetVelocity !== 0) {
                autoScrollRafRef.current = requestAnimationFrame(step);
            } else {
                autoScrollVelocityRef.current = 0;
            }
        };
        autoScrollRafRef.current = requestAnimationFrame(step);
    }, [draggingFile]);

    const stopAutoScroll = useCallback(() => {
        if (autoScrollRafRef.current !== null) {
            cancelAnimationFrame(autoScrollRafRef.current);
            autoScrollRafRef.current = null;
        }
        autoScrollVelocityRef.current = 0;
    }, []);

    const updateDragHoverFromPoint = useCallback(() => {
        const { x, y } = dragPointerRef.current;
        const el = document.elementFromPoint(x, y) as HTMLElement | null;
        const dropContainerEl = el?.closest('[data-drop-container]') as HTMLElement | null;
        const dropContainerPath = dropContainerEl?.dataset.folderId ?? null;
        const folderEl = el?.closest('[data-folder-id]') as HTMLElement | null;
        const folderId = folderEl?.dataset.folderId ?? null;
        const fileEl = el?.closest('[data-file-path]') as HTMLElement | null;
        const filePath = fileEl?.dataset.filePath ?? null;
        const dropTarget = dropContainerPath
            ? normalizePath(dropContainerPath)
            : folderId
                ? normalizePath(folderId)
                : filePath
                    ? normalizePath(getParentPath(filePath))
                    : null;
        setDragOverPathSafe(dropTarget);
        updateHoverOverlay(folderEl || fileEl);
        if (folderId && !draggingFile) {

        }
    }, [draggingFile, getParentPath, normalizePath, setDragOverPathSafe, updateHoverOverlay]);

    const updateDragGhostPositionImmediate = useCallback((x: number, y: number, includeScroll: boolean = true) => {
        if (!dragGhostRef.current) return;
        const ghostMode = dragGhostRef.current.dataset.ghostMode;
        if (ghostMode === 'viewport') {
            dragGhostRef.current.style.transform = `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
            return;
        }
        const container = treeContainerRef.current;
        if (container) {
            const rect = container.getBoundingClientRect();
            const scrollLeft = includeScroll ? container.scrollLeft : 0;
            const scrollTop = includeScroll ? container.scrollTop : 0;
            const left = x - rect.left + scrollLeft;
            const top = y - rect.top + scrollTop;
            dragGhostRef.current.style.transform = `translate3d(${Math.round(left)}px, ${Math.round(top)}px, 0)`;
            return;
        }
        dragGhostRef.current.style.transform = `translate3d(${Math.round(x)}px, ${Math.round(y)}px, 0)`;
    }, []);

    const scheduleDragHoverUpdate = useCallback((x: number, y: number) => {
        dragPointerRef.current = { x, y };
        if (externalDragActiveRef.current && !draggingFile) {
            startAutoScroll();
            if (dragRafRef.current !== null) return;
            dragRafRef.current = requestAnimationFrame(() => {
                dragRafRef.current = null;
                updateDragHoverFromPoint();
            });
            return;
        }
        if (dragRafRef.current !== null) return;
        dragRafRef.current = requestAnimationFrame(() => {
            dragRafRef.current = null;
            updateDragHoverFromPoint();
            startAutoScroll();
        });
    }, [draggingFile, startAutoScroll, updateDragHoverFromPoint]);

    const clearDragState = useCallback(() => {
        unstable_batchedUpdates(() => {
            setIsDraggingSafe(false);
            setDraggingFile(null);
            setDragOverPath(null);
            setDraggedPaths(new Set());
            setDragGhostInfo(null);
        });
        updateHoverOverlay(null);
        lastHoverTargetRef.current = null;
        dragOverPathRef.current = null;
        externalDragActiveRef.current = false;
        dragStartRef.current = null;
        dragActiveRef.current = false;
        internalDragDataRef.current = null;
        if (dragRafRef.current !== null) {
            cancelAnimationFrame(dragRafRef.current);
            dragRafRef.current = null;
        }
        stopAutoScroll();
        restoreTextSelection();
        if (suppressClickRef.current) {
            setTimeout(() => {
                suppressClickRef.current = false;
            }, 0);
        }
        onDragEndSplit?.();
    }, [onDragEndSplit, restoreTextSelection, stopAutoScroll, updateHoverOverlay]);

    useEffect(() => {
        if (!draggingFile && !externalDragActiveRef.current) {
            updateHoverOverlay(null);
        }
    }, [draggingFile, updateHoverOverlay]);

    useEffect(() => {
        const handleWindowDragEnd = () => {
            clearDragState();
        };

        const handleWindowBlur = () => {

        };
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                clearDragState();
            }
        };
        const handleVisibilityChange = () => {
            if (document.visibilityState !== 'visible') {
                clearDragState();
            }
        };

        window.addEventListener('dragend', handleWindowDragEnd);
        window.addEventListener('blur', handleWindowBlur);
        window.addEventListener('keydown', handleKeyDown);
        document.addEventListener('visibilitychange', handleVisibilityChange);

        return () => {
            window.removeEventListener('dragend', handleWindowDragEnd);
            window.removeEventListener('blur', handleWindowBlur);
            window.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('visibilitychange', handleVisibilityChange);
        };
    }, [clearDragState]);

    const handleItemPointerDown = useCallback((event: React.PointerEvent, path: string, name: string, isFile: boolean) => {
        if (event.button !== 0) return;
        if (isDragMoveDisabled()) return;
        const target = event.target as HTMLElement | null;
        if (target?.closest('input, button, a, label, [data-no-drag]')) return;

        event.preventDefault();
        event.stopPropagation();
        disableTextSelection();
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            selection.removeAllRanges();
        }
        
        dragPointerRef.current = { x: event.clientX, y: event.clientY };
        dragStartRef.current = { x: event.clientX, y: event.clientY, path, name, isFile };

        if (holdTimerRef.current !== null) {
            window.clearTimeout(holdTimerRef.current);
        }
        holdTimerRef.current = window.setTimeout(() => {
            suppressClickRef.current = true;
            holdTimerRef.current = null;
        }, 700);

        const handlePointerMove = (moveEvent: PointerEvent) => {
            const dragStart = dragStartRef.current;
            if (!dragStart) return;
            if (dragActiveRef.current && moveEvent.buttons === 0) {
                handlePointerUp();
                return;
            }
            if (!dragActiveRef.current) {
                if (marqueeActiveRef?.current) {
                    handlePointerUp();
                    return;
                }
                const dx = moveEvent.clientX - dragStart.x;
                const dy = moveEvent.clientY - dragStart.y;
                if (Math.hypot(dx, dy) < 8) return;
                dragActiveRef.current = true;
                if (holdTimerRef.current !== null) {
                    window.clearTimeout(holdTimerRef.current);
                    holdTimerRef.current = null;
                }
                hideTooltip?.();
                onDragStartSplit?.();
                suppressClickRef.current = true;
                externalDragActiveRef.current = false;
                const dragData = buildInternalDragData(dragStart.path, dragStart.name, dragStart.isFile);
                internalDragDataRef.current = dragData;
                unstable_batchedUpdates(() => {
                    setDragOverPathSafe(null);
                    if (dragData.multiple) {
                        const paths = dragData.files.map((file) => normalizePath(file.path));
                        setDraggedPaths(new Set(paths));
                        const ghostFilename = dragData.files[0]?.name || dragData.files[0]?.path.split('/').pop() || 'items';
                        setDragGhostInfo({
                            name: `${dragData.files.length} items`,
                            filename: ghostFilename,
                            isFolder: false,
                        });
                    } else {
                        setDraggedPaths(new Set([normalizePath(dragData.path)]));
                        setDragGhostInfo({
                            name: dragData.name,
                            filename: dragData.name,
                            isFolder: !dragData.isFile,
                        });
                    }
                    if (dragData.multiple) {
                        setDraggingFile({
                            path: dragStart.path,
                            name: `${dragData.files.length} files`,
                            isFile: true,
                            multiple: true,
                        });
                    } else {
                        setDraggingFile({
                            path: dragData.path,
                            name: dragData.name,
                            isFile: dragData.isFile,
                        });
                    }
                    setIsDraggingSafe(true);
                });
            }
            if (dragActiveRef.current) {
                moveEvent.preventDefault();
                updateDragGhostPositionImmediate(moveEvent.clientX, moveEvent.clientY, true);
                const splitEl = document.elementFromPoint(moveEvent.clientX, moveEvent.clientY) as HTMLElement | null;
                const splitZone = splitEl?.closest('[data-split-drop-zone]') as HTMLElement | null;
                const splitPane = splitZone?.dataset.pane ?? null;
                if (splitHoverRef.current !== splitPane) {
                    splitHoverRef.current = splitPane;
                    onSplitHover?.(!!splitPane, splitPane);
                }
            }
            scheduleDragHoverUpdate(moveEvent.clientX, moveEvent.clientY);
        };

        const handlePointerUp = async () => {
            window.removeEventListener('pointermove', handlePointerMove, true);
            window.removeEventListener('pointerup', handlePointerUp, true);
            window.removeEventListener('pointercancel', handlePointerUp, true);
            document.removeEventListener('pointerup', handlePointerUp, true);
            document.removeEventListener('pointercancel', handlePointerUp, true);
            window.removeEventListener('mouseup', handlePointerUp, true);
            if (holdTimerRef.current !== null) {
                window.clearTimeout(holdTimerRef.current);
                holdTimerRef.current = null;
            }
            if (!dragActiveRef.current) {
                restoreTextSelection();
                dragStartRef.current = null;
                return;
            }
            dragActiveRef.current = false;
            Promise.resolve().then(async () => {
                const dragData = internalDragDataRef.current;
                const { x, y } = dragPointerRef.current;
                const dropEl = document.elementFromPoint(x, y) as HTMLElement | null;
                const splitZone = dropEl?.closest('[data-split-drop-zone]') as HTMLElement | null;
                if (splitZone && dragData) {
                    const splitPath = dragData.multiple ? dragData.files[0]?.path : dragData.path;
                    const splitIsFile = dragData.multiple ? dragData.files[0]?.isFile : dragData.isFile;
                    if (splitPath && splitIsFile) {
                        window.dispatchEvent(new CustomEvent('bfm:open-split', {
                            detail: {
                                path: splitPath,
                                pane: splitZone.dataset.pane || 'main',
                            },
                        }));
                        dragStartRef.current = null;
                        internalDragDataRef.current = null;
                        clearDragState();
                        onDragEndSplit?.();
                        return;
                    }
                }
                const dropFolder = dropEl?.closest('[data-folder-id]') as HTMLElement | null;
                const dropTargetPath = dropFolder?.dataset.folderId ?? null;
                const dropFile = dropEl?.closest('[data-file-path]') as HTMLElement | null;
                const dropFilePath = dropFile?.dataset.filePath ?? null;
                if (!dropTargetPath && !dropFilePath) {
                    if (viewMode === 'tree') {
                        const container = treeContainerRef.current;
                        const rect = container?.getBoundingClientRect();
                        if (rect && x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
                            const destination = '/';
                            dragStartRef.current = null;
                            internalDragDataRef.current = null;
                            try {
                                if (dragData) {
                                    await onInternalMove(dragData, destination);
                                }
                            } catch (error) {
                                onError(error as Error);
                            } finally {
                                clearDragState();
                            }
                            return;
                        }
                    }
                    dragStartRef.current = null;
                    internalDragDataRef.current = null;
                    clearDragState();
                    return;
                }
                const rawDestination = dropTargetPath || (dropFilePath ? getParentPath(dropFilePath) : null) || currentPath;
                const destination = normalizePath(rawDestination || '/');
                dragStartRef.current = null;
                internalDragDataRef.current = null;
                try {
                    if (dragData) {
                        await onInternalMove(dragData, destination);
                    }
                } catch (error) {
                    onError(error as Error);
                } finally {
                    clearDragState();
                    onDragEndSplit?.();
                }
            });
        };

        window.addEventListener('pointermove', handlePointerMove, true);
        window.addEventListener('pointerup', handlePointerUp, true);
        window.addEventListener('pointercancel', handlePointerUp, true);
        document.addEventListener('pointerup', handlePointerUp, true);
        document.addEventListener('pointercancel', handlePointerUp, true);
        window.addEventListener('mouseup', handlePointerUp, true);
    }, [
        buildInternalDragData,
        clearDragState,
        currentPath,
        disableTextSelection,
        getParentPath,
        hideTooltip,
        isMobileViewport,
        normalizePath,
        onDragEndSplit,
        onDragStartSplit,
        onError,
        onInternalMove,
        isDragMoveDisabled,
        onSplitHover,
        scheduleDragHoverUpdate,
        setDragOverPathSafe,
        viewMode,
    ]);

    const handleDragOver = useCallback((e: React.DragEvent) => {
        if (isDragMoveDisabled()) return;
        const dataTransfer = e.dataTransfer;
        const internalDrag = draggingFile || isInternalDragEvent(dataTransfer);
        const externalDrag = isExternalFileDragEvent(dataTransfer);
        if (!internalDrag && !externalDrag) return;
        e.preventDefault();
        e.stopPropagation();
        if (externalDrag) {
            if (!externalDragActiveRef.current) setIsDraggingSafe(true);
            externalDragActiveRef.current = true;
        } else {
            if (externalDragActiveRef.current) setIsDraggingSafe(false);
            externalDragActiveRef.current = false;
            setIsDraggingSafe(true);
        }
        scheduleDragHoverUpdate(e.clientX, e.clientY);
    }, [draggingFile, isDragMoveDisabled, scheduleDragHoverUpdate, setIsDraggingSafe]);

    const handleDragLeave = useCallback((e: React.DragEvent) => {
        if (isDragMoveDisabled()) return;
        e.preventDefault();
        e.stopPropagation();
        const container = treeContainerRef.current;
        if (container && e.currentTarget === container) {
            const rect = container.getBoundingClientRect();
            if (e.clientY < rect.top || e.clientY > rect.bottom || e.clientX < rect.left || e.clientX > rect.right) {
                if (externalDragActiveRef.current) {
                    setIsDraggingSafe(false);
                    externalDragActiveRef.current = false;
                } else if (draggingFile) {
                    setIsDraggingSafe(false);
                }
                setDragOverPathSafe(null);
                stopAutoScroll();
            }
        }
    }, [draggingFile, isDragMoveDisabled, setDragOverPathSafe, stopAutoScroll, setIsDraggingSafe]);

    const allowDrop = useCallback((e: React.DragEvent) => {
        if (isDragMoveDisabled()) return;
        e.preventDefault();
    }, [isDragMoveDisabled]);

    const handleDrop = useCallback(async (e: React.DragEvent, targetPath?: string) => {
        if (isDragMoveDisabled()) return;
        e.preventDefault();
        e.stopPropagation();
        const resolvedTarget = normalizePath(targetPath || currentPath || '/');
        const dropContainerEl = (e.target as HTMLElement | null)?.closest?.('[data-drop-container]') as HTMLElement | null;
        const dropContainerPath = dropContainerEl?.dataset.folderId ?? null;
        const dropTargetEl = (e.target as HTMLElement | null)?.closest?.('[data-folder-id]') as HTMLElement | null;
        const dropTargetPath = dropTargetEl?.dataset.folderId ?? null;
        const dropFileEl = (e.target as HTMLElement | null)?.closest?.('[data-file-path]') as HTMLElement | null;
        const dropFilePath = dropFileEl?.dataset.filePath ?? null;
        const rawDestination =
            dropContainerPath ||
            dropTargetPath ||
            (dropFilePath ? getParentPath(dropFilePath) : null) ||
            resolvedTarget;
        const destination = normalizePath(rawDestination || '/');
        const internalDrag = draggingFile || isInternalDragEvent(e.dataTransfer);
        if (isDraggingRef.current) setIsDraggingSafe(false);
        externalDragActiveRef.current = false;
        setDragOverPathSafe(null);

        if (internalDrag) {
            try {
                const dragDataStr = e.dataTransfer.getData('application/x-filetree-drag');
                if (!dragDataStr) {
                    clearDragState();
                    return;
                }
                const dragData = JSON.parse(dragDataStr) as InternalDragData;
                await onInternalMove(dragData, destination);
            } catch (error) {
                onError(error as Error);
            }
        } else {
            const { files: folderFiles, hasFolders } = await getFilesFromDataTransfer(e.dataTransfer);
            if (folderFiles.length === 0) {
                clearDragState();
                return;
            }
            await onExternalDrop(folderFiles, destination, hasFolders);
        }
        clearDragState();
    }, [
        clearDragState,
        currentPath,
        getParentPath,
        isDragMoveDisabled,
        onError,
        onExternalDrop,
        onInternalMove,
        setDragOverPathSafe,
        draggingFile,
        setIsDraggingSafe,
    ]);

    useEffect(() => {
        if (!draggingFile) return;
        if (!dragGhostRef.current) return;
        const { x, y } = dragPointerRef.current;
        updateDragGhostPositionImmediate(x, y, true);
    }, [draggingFile, updateDragGhostPositionImmediate]);

    useEffect(() => {
        const container = treeContainerRef.current;
        if (!container) return;
        const handleScroll = () => {
            if (!draggingFile) return;
            const { x, y } = dragPointerRef.current;
            updateDragGhostPositionImmediate(x, y, false);
            updateDragHoverFromPoint();
        };
        container.addEventListener('scroll', handleScroll, { passive: true });
        return () => {
            container.removeEventListener('scroll', handleScroll);
        };
    }, [draggingFile, updateDragGhostPositionImmediate, updateDragHoverFromPoint]);

    return {
        isDragging,
        dragOverPath,
        draggingFile,
        draggedPaths,
        dragGhostInfo,
        dragGhostRef,
        hoverOverlayRef,
        treeContainerRef,
        suppressClickRef,
        dragActiveRef,
        handleItemPointerDown,
        handleDragOver,
        handleDragLeave,
        handleDrop,
        allowDrop,
        clearDragState,
    };
};

export default useDragAndDropListener;
