import React, { useMemo } from 'react';
import { createPortal } from 'react-dom';
import GreyRowBox from '@/components/elements/GreyRowBox';

interface UploadProgress {
    name: string;
    loaded: number;
    total: number;
    controller: AbortController;
    targetPath: string;
}

interface Props {
    uploads: Map<string, UploadProgress>;
    showUploadModal: boolean;
    setShowUploadModal: (next: boolean) => void;
    cancelAllUploads: () => void;
    cancelUpload: (key: string) => void;
    formatBytes: (value: number) => string;
}

const cx = (...parts: Array<string | false | null | undefined>) => parts.filter(Boolean).join(' ');

const getUploadPortalRoot = (): HTMLElement | null => {
    if (typeof document === 'undefined') return null;
    let root = document.getElementById('bfm-upload-portal-root');
    if (!root) {
        root = document.createElement('div');
        root.id = 'bfm-upload-portal-root';
        root.style.position = 'fixed';
        root.style.inset = '0';
        root.style.zIndex = '2147483647';
        root.style.display = 'flex';
        root.style.alignItems = 'flex-end';
        root.style.justifyContent = 'flex-end';
        root.style.padding = '24px';
        root.style.boxSizing = 'border-box';
        root.style.pointerEvents = 'none';
        root.style.isolation = 'isolate';
        document.documentElement.appendChild(root);
    }
    return root;
};

const UploadModal: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, style, ...props }) => (
    <GreyRowBox
        className={cx(
            'z-[2147483647] shadow-2xl border border-white/10 overflow-y-auto !flex-col !items-stretch',
            className
        )}
        $hoverable={false}
        style={{
            position: 'relative',
            width: 'min(360px, calc(100vw - 16px))',
            maxHeight: 'min(70vh, calc(100vh - 16px))',
            padding: 16,
            pointerEvents: 'auto',
            ...style,
        }}
        {...props}
    />
);

const UploadItem: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, ...props }) => (
    <div className={cx('mb-3 pb-3 border-b border-gray-600 last:border-b-0 last:mb-0 last:pb-0', className)} {...props} />
);

const UploadHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, ...props }) => (
    <div className={cx('flex items-center justify-between mb-2', className)} {...props} />
);

const UploadFileName: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, ...props }) => (
    <div className={cx('text-sm text-neutral-300 truncate flex-1 font-mono', className)} {...props} />
);

const CancelButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement>> = ({ className, ...props }) => (
    <button className={cx('text-red-400 hover:text-red-300 transition-colors ml-2', className)} {...props} />
);

const ProgressBar: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, style, ...props }) => (
    <GreyRowBox
        className={cx('w-full h-1 overflow-hidden !p-0 !bg-neutral-600 !border-transparent', className)}
        $hoverable={false}
        style={{ display: 'block', ...style }}
        {...props}
    />
);

const ProgressFill: React.FC<React.HTMLAttributes<HTMLDivElement> & { progress: number }> = ({ progress, className, style, ...props }) => (
    <div
        className={cx('h-full transition-all duration-300 bg-primary-500 min-w-[1px]', className)}
        style={{ width: `${progress}%`, ...style }}
        {...props}
    />
);

const UploadStats: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({ className, ...props }) => (
    <div className={cx('text-xs text-neutral-300 mt-1 flex justify-between', className)} {...props} />
);

const UploadProgressPanel: React.FC<Props> = ({
    uploads,
    showUploadModal,
    setShowUploadModal,
    cancelAllUploads,
    cancelUpload,
    formatBytes,
}) => {
    if (uploads.size === 0) return null;

    const portalTarget = useMemo(() => getUploadPortalRoot(), []);

    const content = (
        <>
            {showUploadModal ? (
                <UploadModal>
                    <UploadHeader>
                        <div className="text-sm text-neutral-300 font-semibold">
                            Uploading {uploads.size} file{uploads.size > 1 ? 's' : ''}
                        </div>
                        <div className="flex items-center gap-2">
                            <button
                                className="text-xs text-neutral-300 hover:text-neutral-200"
                                onClick={() => setShowUploadModal(false)}
                            >
                                Hide
                            </button>
                            <CancelButton onClick={cancelAllUploads} title="Cancel all uploads">
                                ✕
                            </CancelButton>
                        </div>
                    </UploadHeader>
                    {Array.from(uploads.entries()).map(([key, upload]) => {
                        const progress = (upload.loaded / upload.total) * 100;
                        return (
                            <UploadItem key={key}>
                                <UploadHeader>
                                    <UploadFileName title={upload.name}>{upload.name}</UploadFileName>
                                    <CancelButton onClick={() => cancelUpload(key)} title="Cancel upload">
                                        ✕
                                    </CancelButton>
                                </UploadHeader>
                                <ProgressBar>
                                    <ProgressFill progress={progress} />
                                </ProgressBar>
                                <UploadStats>
                                    <span>{Math.round(progress)}%</span>
                                    <span>{formatBytes(upload.loaded)} / {formatBytes(upload.total)}</span>
                                </UploadStats>
                                <div className="text-xs text-neutral-400 mt-1">
                                    → {upload.targetPath}
                                </div>
                            </UploadItem>
                        );
                    })}
                </UploadModal>
            ) : (
                <GreyRowBox
                    className="z-[2147483647] cursor-pointer shadow-2xl border border-white/10 px-4 py-2"
                    $hoverable={false}
                    style={{
                        position: 'relative',
                        maxWidth: 'calc(100vw - 16px)',
                        pointerEvents: 'auto',
                    }}
                    onClick={() => setShowUploadModal(true)}
                    title={`${uploads.size} file(s) uploading`}
                >
                    <span className="text-neutral-300 text-sm">Uploading&nbsp;</span>
                    <span className="font-semibold">{uploads.size}</span>
                </GreyRowBox>
            )}
        </>
    );

    return portalTarget ? createPortal(content, portalTarget) : null;
};

export default UploadProgressPanel;
export type { UploadProgress };
