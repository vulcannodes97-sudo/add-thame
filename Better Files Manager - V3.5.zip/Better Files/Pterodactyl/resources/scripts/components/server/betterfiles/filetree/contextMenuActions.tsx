import React from 'react';

type ContextMenuItem = {
    label?: string;
    icon?: React.ReactNode;
    onClick?: () => void;
    disabled?: boolean;
    divider?: boolean;
};

interface Options {
    uuid: string;
    isSearchActive: boolean;
    contextMenu: { path: string; isFile: boolean } | null;
    isArchiveFile: (path: string) => boolean;
    handleCreateFile: (targetPath: string) => void;
    handleCreateFolder: (targetPath: string) => void;
    handleRename: (path: string) => void;
    revealSearchPath: (path: string, isFile: boolean) => void;
    handleUnarchive: (path: string) => void;
    handleArchive: (path: string) => void;
    handlePermissions: (path: string) => void;
    onShowProperties?: (path: string) => void;
    handleEditAudioMetadata?: (path: string) => void;
    handleCopyFile: (path: string) => void;
    handleMoveToTrash: (path: string) => void;
    handleDelete: (path: string) => void;
    clearAndAddHttpError: (error: Error) => void;
}

export const buildContextMenuItems = ({
    uuid,
    isSearchActive,
    contextMenu,
    isArchiveFile,
    handleCreateFile,
    handleCreateFolder,
    handleRename,
    revealSearchPath,
    handleUnarchive,
    handleArchive,
    handlePermissions,
    onShowProperties,
    handleEditAudioMetadata,
    handleCopyFile,
    handleMoveToTrash,
    handleDelete,
    clearAndAddHttpError,
}: Options): ContextMenuItem[] => {
    if (!contextMenu) return [];
    const audioExtensions = new Set([
        'mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'wma', 'aiff', 'aif', 'alac', 'opus', 'midi', 'mid',
    ]);
    const ext = contextMenu.path.split('.').pop()?.toLowerCase() || '';
    const isAudioFile = contextMenu.isFile && audioExtensions.has(ext);
    return [
        {
            label: 'New File',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
            onClick: () => {
                const targetPath = contextMenu.isFile
                    ? contextMenu.path.substring(0, contextMenu.path.lastIndexOf('/')) || '/'
                    : contextMenu.path;
                handleCreateFile(targetPath);
            },
        },
        {
            label: 'New Folder',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" /></svg>,
            onClick: () => handleCreateFolder(contextMenu.isFile ? contextMenu.path.substring(0, contextMenu.path.lastIndexOf('/')) || '/' : contextMenu.path),
        },
        { divider: true },
        {
            label: 'Rename',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>,
            onClick: () => handleRename(contextMenu.path),
        },
        ...(contextMenu.isFile ? [{
            label: 'Duplicate',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2" /></svg>,
            onClick: () => handleCopyFile(contextMenu.path),
        }] : []),
        ...(isSearchActive && contextMenu.isFile ? [{
            label: 'Reveal in Explorer',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h8m-8 4h5m-3 4h3m-9-9a2 2 0 012-2h11a2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm13 3l3 3-3 3" /></svg>,
            onClick: () => revealSearchPath(contextMenu.path, contextMenu.isFile),
        }] : []),
        ...(contextMenu.isFile ? [
            ...(isArchiveFile(contextMenu.path) ? [
                {
                    label: 'Unarchive',
                    icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>,
                    onClick: () => handleUnarchive(contextMenu.path),
                },
            ] : [
                {
                    label: 'Archive',
                    icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" /></svg>,
                    onClick: () => handleArchive(contextMenu.path),
                },
            ]),
            { divider: true },
        ] : []),
        {
            label: 'Permissions',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>,
            onClick: () => handlePermissions(contextMenu.path),
        },
        ...(onShowProperties ? [{
            label: 'Properties',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6M9 8h6M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z" /></svg>,
            onClick: () => onShowProperties(contextMenu.path),
        }] : []),
        ...(isAudioFile && handleEditAudioMetadata ? [{
            label: 'Edit Metadata',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 18V7l10-2v11M9 18c0 1.105-1.12 2-2.5 2S4 19.105 4 18s1.12-2 2.5-2 2.5.895 2.5 2zm10-2c0 1.105-1.12 2-2.5 2S14 17.105 14 16s1.12-2 2.5-2 2.5.895 2.5 2zM9 11l10-2" /></svg>,
            onClick: () => handleEditAudioMetadata(contextMenu.path),
        }] : []),
        ...(contextMenu.isFile ? [{
            label: 'Download',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>,
            onClick: async () => {
                try {
                    const getFileDownloadUrl = (await import('@/api/server/files/getFileDownloadUrl')).default;
                    const url = await getFileDownloadUrl(uuid, contextMenu.path);
                    window.location.href = url;
                } catch (error) {
                    clearAndAddHttpError(error as Error);
                }
            },
        }] : []),
        { divider: true },
        {
            label: 'Move to Trash',
            icon: <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>,
            onClick: () => handleMoveToTrash(contextMenu.path),
        },
        {
            label: 'Force Delete',
            icon: <svg className="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>,
            onClick: () => handleDelete(contextMenu.path),
        },
    ];
};
