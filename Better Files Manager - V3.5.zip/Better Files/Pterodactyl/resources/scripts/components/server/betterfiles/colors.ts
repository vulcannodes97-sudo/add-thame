import { themeColors as extractedColors } from './colorExtractor';

type ParsedColor = { r: number; g: number; b: number; a?: number };

const clamp = (value: number) => Math.max(0, Math.min(255, Math.round(value)));

const parseHex = (hex: string): ParsedColor | null => {
    const normalized = hex.replace('#', '').trim();
    if (![3, 6].includes(normalized.length)) return null;
    const chars = normalized.length === 3
        ? normalized.split('').map((c) => c + c).join('')
        : normalized;
    const r = parseInt(chars.slice(0, 2), 16);
    const g = parseInt(chars.slice(2, 4), 16);
    const b = parseInt(chars.slice(4, 6), 16);
    if ([r, g, b].some((v) => Number.isNaN(v))) return null;
    return { r, g, b };
};

const parseRgb = (color: string): ParsedColor | null => {
    const match = color.match(/rgba?\(([^)]+)\)/);
    if (!match) return null;
    const parts = match[1].split(',').map((p) => p.trim());
    if (parts.length < 3) return null;
    const r = parseFloat(parts[0]);
    const g = parseFloat(parts[1]);
    const b = parseFloat(parts[2]);
    if ([r, g, b].some((v) => Number.isNaN(v))) return null;
    const a = parts[3] !== undefined ? parseFloat(parts[3]) : undefined;
    return { r, g, b, a };
};

const hslToRgb = (h: number, s: number, l: number): ParsedColor => {
    const sat = s / 100;
    const light = l / 100;
    const c = (1 - Math.abs(2 * light - 1)) * sat;
    const hh = (h % 360) / 60;
    const x = c * (1 - Math.abs((hh % 2) - 1));
    let r = 0;
    let g = 0;
    let b = 0;
    if (hh >= 0 && hh < 1) { r = c; g = x; b = 0; }
    else if (hh >= 1 && hh < 2) { r = x; g = c; b = 0; }
    else if (hh >= 2 && hh < 3) { r = 0; g = c; b = x; }
    else if (hh >= 3 && hh < 4) { r = 0; g = x; b = c; }
    else if (hh >= 4 && hh < 5) { r = x; g = 0; b = c; }
    else if (hh >= 5 && hh < 6) { r = c; g = 0; b = x; }
    const m = light - c / 2;
    return { r: clamp((r + m) * 255), g: clamp((g + m) * 255), b: clamp((b + m) * 255) };
};

const parseHsl = (color: string): ParsedColor | null => {
    const match = color.match(/hsla?\(([^)]+)\)/);
    if (!match) return null;
    const parts = match[1].split(',').map((p) => p.trim().replace('%', ''));
    if (parts.length < 3) return null;
    const h = parseFloat(parts[0]);
    const s = parseFloat(parts[1]);
    const l = parseFloat(parts[2]);
    if ([h, s, l].some((v) => Number.isNaN(v))) return null;
    const rgb = hslToRgb(h, s, l);
    const a = parts[3] !== undefined ? parseFloat(parts[3]) : undefined;
    return { ...rgb, a };
};

const parseColor = (color: string): ParsedColor | null => {
    if (color.startsWith('#')) return parseHex(color);
    if (color.startsWith('rgb')) return parseRgb(color);
    if (color.startsWith('hsl')) return parseHsl(color);
    return null;
};

const adjustBrightness = (color: string, percent: number): string => {
    const parsed = parseColor(color);
    if (!parsed) return color;
    const adjust = (val: number) => clamp(val + (val * percent / 100));
    return `rgb(${adjust(parsed.r)}, ${adjust(parsed.g)}, ${adjust(parsed.b)})`;
};

const withOpacity = (color: string, opacity: number): string => {
    const parsed = parseColor(color);
    if (!parsed) return color;
    return `rgba(${parsed.r}, ${parsed.g}, ${parsed.b}, ${opacity})`;
};

export const colors = {
    primary: {
        get default() {
            return extractedColors.primary.iconColor;
        },

        get light() {
            return adjustBrightness(extractedColors.primary.iconColor, 30);
        },
        get lighter() {
            return adjustBrightness(extractedColors.primary.iconColor, 50);
        },

        get dark() {
            return adjustBrightness(extractedColors.primary.iconColor, -40);
        },
        get darker() {
            return adjustBrightness(extractedColors.primary.iconColor, -60);
        },
        opacity: (alpha: number) => withOpacity(extractedColors.primary.iconColor, alpha)
    },

    success: {
        get default() {
            return extractedColors.success.iconColor;
        },
        get light() {
            return adjustBrightness(extractedColors.success.iconColor, 30);
        },
        get lighter() {
            return adjustBrightness(extractedColors.success.iconColor, 50);
        },
        get dark() {
            return adjustBrightness(extractedColors.success.iconColor, -40);
        },
        get darker() {
            return adjustBrightness(extractedColors.success.iconColor, -60);
        },
        opacity: (alpha: number) => withOpacity(extractedColors.success.iconColor, alpha)
    },

    danger: {
        get default() {
            return extractedColors.danger.iconColor;
        },
        get light() {
            return adjustBrightness(extractedColors.danger.iconColor, 30);
        },
        get lighter() {
            return adjustBrightness(extractedColors.danger.iconColor, 50);
        },
        get dark() {
            return adjustBrightness(extractedColors.danger.iconColor, -40);
        },
        get darker() {
            return adjustBrightness(extractedColors.danger.iconColor, -60);
        },
        opacity: (alpha: number) => withOpacity(extractedColors.danger.iconColor, alpha)
    },

    warning: {
        default: '#f59e0b',
        light: '#fbbf24',  
        lighter: '#fcd34d', 
        dark: '#d97706',    
        darker: '#b45309',  
        opacity: (alpha: number) => `rgba(245, 158, 11, ${alpha})`
    },

    secondary: {
        get default() {
            return extractedColors.secondary.iconColor;
        },
        get light() {
            return adjustBrightness(extractedColors.secondary.iconColor, 30);
        },
        get lighter() {
            return adjustBrightness(extractedColors.secondary.iconColor, 50);
        },
        get dark() {
            return adjustBrightness(extractedColors.secondary.iconColor, -40);
        },
        get darker() {
            return adjustBrightness(extractedColors.secondary.iconColor, -60);
        },
        opacity: (alpha: number) => withOpacity(extractedColors.secondary.iconColor, alpha)
    },

    text: {
        get default() {
            return extractedColors.text.iconColor;
        },
        get light() {
            return adjustBrightness(extractedColors.text.iconColor, 30);
        },
        get dark() {
            return adjustBrightness(extractedColors.text.iconColor, -40);
        }
    }
} as const;

export const primaryColor = colors.primary.default;
export const primaryLight = colors.primary.light;
export const primaryDark = colors.primary.dark;
export const primaryDarker = colors.primary.darker;

export const successColor = colors.success.default;
export const successDark = colors.success.dark;
export const successDarker = colors.success.darker;

export const dangerColor = colors.danger.default;
export const dangerDark = colors.danger.dark;

export const warningColor = colors.warning.default;
export const warningDark = colors.warning.dark;

export default colors;
