import { useState, useRef, useEffect, useCallback } from 'react';

interface UsePanelResizeOptions {
    initialWidth: number;
    minWidth: number;
    maxWidth: number;
}

export const usePanelResize = ({ initialWidth, minWidth, maxWidth }: UsePanelResizeOptions) => {
    const [width, setWidth] = useState(initialWidth);
    const [isResizing, setIsResizing] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);
    const panelRef = useRef<HTMLDivElement>(null);
    const containerLeftRef = useRef(0);
    const pendingWidthRef = useRef<number | null>(null);
    const rafRef = useRef<number | null>(null);

    const handleMouseDown = useCallback((e: React.MouseEvent) => {
        e.preventDefault();
        containerLeftRef.current = containerRef.current?.getBoundingClientRect().left ?? 0;
        setIsResizing(true);
    }, []);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!isResizing) return;
            const nextWidth = e.clientX - containerLeftRef.current;
            const clamped = Math.max(minWidth, Math.min(maxWidth, nextWidth));
            pendingWidthRef.current = clamped;
            if (rafRef.current !== null) return;
            rafRef.current = requestAnimationFrame(() => {
                rafRef.current = null;
                if (pendingWidthRef.current !== null && panelRef.current) {
                    panelRef.current.style.setProperty('--bfm-left-width', `${pendingWidthRef.current}px`);
                }
            });
        };

        const handleMouseUp = () => {
            if (rafRef.current !== null) {
                cancelAnimationFrame(rafRef.current);
                rafRef.current = null;
            }
            if (pendingWidthRef.current !== null) {
                setWidth(pendingWidthRef.current);
            }
            pendingWidthRef.current = null;
            setIsResizing(false);
        };

        if (isResizing) {
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
        }

        return () => {
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isResizing, minWidth, maxWidth]);

    return {
        width,
        setWidth,
        isResizing,
        containerRef,
        panelRef,
        handleMouseDown,
    };
};
