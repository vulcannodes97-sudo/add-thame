@extends('layouts.admin')
@include('partials/admin.settings.nav', ['activeTab' => 'better-files'])

@section('title')
    Better Files
@endsection

@section('content-header')
    <h1>Better Files<small>Trash cleanup controls.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.settings') }}">Settings</a></li>
        <li class="active">Better Files</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')
    <style>
        .bf-panel {
            background: #2f3841;
            border: 1px solid #3d4954;
            border-radius: 6px;
            padding: 16px;
            margin-bottom: 16px;
            color: #e5e7eb;
        }
        .bf-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px;
            margin-bottom: 12px;
        }
        @media (max-width: 1200px) {
            .bf-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        @media (max-width: 768px) {
            .bf-grid {
                grid-template-columns: 1fr;
            }
        }
        .bf-two-col {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        @media (max-width: 992px) {
            .bf-two-col {
                grid-template-columns: 1fr;
            }
        }
        .bf-form-group {
            margin-bottom: 12px;
        }
        .bf-form-row {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .bf-label {
            min-width: 160px;
            font-weight: 600;
            color: #e2e8f0;
            text-align: right;
        }
        .bf-control {
            flex: 1;
            min-width: 0;
        }
        .bf-panel h4 {
            margin: 0 0 6px 0;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: #9fb2c8;
        }
        .bf-panel .bf-stat {
            font-size: 18px;
            font-weight: 700;
            color: #ffffff;
        }
        .bf-pill {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .08em;
        }
        .bf-pill-green { background: rgba(34, 197, 94, .15); color: #4ade80; border: 1px solid rgba(34, 197, 94, .35); }
        .bf-pill-blue { background: rgba(59, 130, 246, .15); color: #60a5fa; border: 1px solid rgba(59, 130, 246, .35); }
        .bf-pill-yellow { background: rgba(234, 179, 8, .15); color: #facc15; border: 1px solid rgba(234, 179, 8, .35); }
        .bf-section {
            padding: 14px;
            border-radius: 6px;
            background: #2a323a;
            border: 1px solid #39424c;
            margin-bottom: 16px;
        }
        .bf-muted {
            color: #9aa7b5;
        }
        .bf-divider {
            border-top: 1px solid #3a4652;
            margin: 12px 0;
        }
        .bf-table > thead > tr > th {
            background: #2a323a;
            border-color: #3a4652;
            color: #cbd5e1;
            text-transform: uppercase;
            letter-spacing: .08em;
            font-size: 11px;
        }
        .bf-table > tbody > tr > td {
            border-color: #3a4652;
            color: #e2e8f0;
        }
    </style>
    @php
        $allowOverride = (bool) $settings['allow_override'];
        $globalEnabled = (bool) $settings['enabled'];
        $defaultDays = (int) $settings['default_days'];
        $defaultUnit = (string) ($settings['default_unit'] ?? 'days');
        $contentSearchEnabled = (bool) ($settings['content_search_enabled'] ?? false);
        $gitEnabled = (bool) ($settings['git_enabled'] ?? false);
        $pageServers = collect($servers->items());
        $pageEnabledCount = $pageServers->filter(function ($server) use ($allowOverride, $globalEnabled) {
            return $allowOverride ? (bool) $server->bf_trash_cleanup_enabled : $globalEnabled;
        })->count();
        $pageDisabledCount = max(0, $pageServers->count() - $pageEnabledCount);
    @endphp
    <div class="row">
        <div class="col-lg-8 col-xs-12">
            <div class="box box-primary box-solid" style="background:#27303a;border-color:#3a4652;">
                <div class="box-header with-border" style="border-color:#3a4652;">
                    <h3 class="box-title"><i class="fa fa-shield"></i> Trash Cleanup</h3>
                    <div class="box-tools pull-right">
                        <span class="bf-pill bf-pill-green">{{ $globalEnabled ? 'Enabled' : 'Disabled' }}</span>
                        <span class="bf-pill bf-pill-blue">{{ $allowOverride ? 'Overrides Allowed' : 'Overrides Locked' }}</span>
                    </div>
                </div>
                <form action="{{ route('admin.settings.betterfiles') }}" method="POST" class="form-horizontal">
                    <div class="box-body">
                        <div class="bf-grid">
                            <div class="bf-panel">
                                <h4>Cleanup Schedule</h4>
                                <div class="bf-stat">Daily</div>
                                <div class="bf-muted">Kernel scheduler</div>
                            </div>
                            <div class="bf-panel">
                                <h4>Cleanup Status</h4>
                                <div class="bf-stat">{{ $globalEnabled ? 'Enabled' : 'Disabled' }}</div>
                                <div class="bf-muted">Global setting</div>
                            </div>
                            <div class="bf-panel">
                                <h4>Owner Overrides</h4>
                                <div class="bf-stat">{{ $allowOverride ? 'Allowed' : 'Locked' }}</div>
                                <div class="bf-muted">Default: {{ $defaultDays }} {{ $defaultUnit }}</div>
                            </div>
                        </div>
                        <p class="text-muted" style="margin-top: 0;">
                            Control the daily cleanup job and whether server owners can override retention.
                        </p>
                        <div class="bf-section">
                            @if (!$globalEnabled)
                                <strong>Cleanup is disabled.</strong>
                                <div class="bf-muted">Enable automatic cleanup to purge old trash items.</div>
                            @elseif (!$allowOverride)
                                <strong>Overrides locked.</strong>
                                <div class="bf-muted">All servers inherit the default retention window.</div>
                            @else
                                <strong>How it works</strong>
                                <div class="bf-muted">
                                    The panel runs a daily cleanup task. If enabled, items older than the retention
                                    window are removed from each server trash bin.
                                </div>
                            @endif
                        </div>
                        <div class="bf-two-col">
                            <div class="bf-panel">
                                <div class="bf-form-group">
                                    <div class="bf-form-row">
                                        <div class="bf-label">Automatic Cleanup</div>
                                        <div class="bf-control">
                                            <div class="btn-group" data-toggle="buttons">
                                                @php
                                                    $enabled = old('betterfiles:trash_cleanup_enabled', (int) $globalEnabled);
                                                @endphp
                                                <label class="btn btn-primary @if ($enabled == 1) active @endif">
                                                    <input type="radio" name="betterfiles:trash_cleanup_enabled" value="1" @if ($enabled == 1) checked @endif> Enabled
                                                </label>
                                                <label class="btn btn-primary @if ($enabled == 0) active @endif">
                                                    <input type="radio" name="betterfiles:trash_cleanup_enabled" value="0" @if ($enabled == 0) checked @endif> Disabled
                                                </label>
                                            </div>
                                            <div class="help-block">If disabled, cleanup will not run for any server.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="bf-panel">
                                <div class="bf-form-group">
                                    <div class="bf-form-row">
                                        <div class="bf-label">Allow Owner Overrides</div>
                                        <div class="bf-control">
                                            <div class="btn-group" data-toggle="buttons">
                                                @php
                                                    $allowOverrideValue = old('betterfiles:trash_cleanup_allow_override', (int) $allowOverride);
                                                @endphp
                                                <label class="btn btn-primary @if ($allowOverrideValue == 1) active @endif">
                                                    <input type="radio" name="betterfiles:trash_cleanup_allow_override" value="1" @if ($allowOverrideValue == 1) checked @endif> Enabled
                                                </label>
                                                <label class="btn btn-primary @if ($allowOverrideValue == 0) active @endif">
                                                    <input type="radio" name="betterfiles:trash_cleanup_allow_override" value="0" @if ($allowOverrideValue == 0) checked @endif> Disabled
                                                </label>
                                            </div>
                                            <div class="help-block">When disabled, all servers inherit the default retention days below.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bf-divider"></div>
                        <div class="bf-two-col">
                            <div class="bf-panel">
                                <div class="bf-form-row">
                                    <div class="bf-label">Default Retention</div>
                                    <div class="bf-control">
                                        <div class="input-group">
                                            <input
                                                type="number"
                                                class="form-control"
                                                name="betterfiles:trash_cleanup_default_days"
                                                min="1"
                                                value="{{ old('betterfiles:trash_cleanup_default_days', $defaultDays) }}"
                                            />
                                            <select class="form-control" name="betterfiles:trash_cleanup_default_unit">
                                                <option value="hours" @if (old('betterfiles:trash_cleanup_default_unit', $defaultUnit) === 'hours') selected @endif>Hours</option>
                                                <option value="days" @if (old('betterfiles:trash_cleanup_default_unit', $defaultUnit) === 'days') selected @endif>Days</option>
                                            </select>
                                        </div>
                                        <div class="help-block">Sets how old items must be before deletion.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="bf-panel">
                                <div class="bf-form-row">
                                    <div class="bf-label">Pull URL Max Size</div>
                                    <div class="bf-control">
                                        <div class="input-group">
                                            <input
                                                type="number"
                                                class="form-control"
                                                name="betterfiles:pull_url_max_size_mb"
                                                min="1"
                                                value="{{ old('betterfiles:pull_url_max_size_mb', (int) $settings['pull_url_max_size_mb']) }}"
                                            />
                                            <span class="input-group-addon">MB</span>
                                        </div>
                                        <div class="help-block">Limits Pull from URL downloads (minimum 1 MB).</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bf-two-col" style="margin-top: 12px;">
                            <div class="bf-panel">
                                <div class="bf-form-group">
                                    <div class="bf-form-row">
                                        <div class="bf-label">Content Search</div>
                                        <div class="bf-control">
                                            <div class="btn-group" data-toggle="buttons">
                                                @php
                                                    $contentSearchValue = old('betterfiles:search_content_enabled', (int) $contentSearchEnabled);
                                                @endphp
                                                <label class="btn btn-primary @if ($contentSearchValue == 1) active @endif">
                                                    <input type="radio" name="betterfiles:search_content_enabled" value="1" @if ($contentSearchValue == 1) checked @endif> Enabled
                                                </label>
                                                <label class="btn btn-primary @if ($contentSearchValue == 0) active @endif">
                                                    <input type="radio" name="betterfiles:search_content_enabled" value="0" @if ($contentSearchValue == 0) checked @endif> Disabled
                                                </label>
                                            </div>
                                            <div class="help-block">Allows searching inside file contents (small text files only).</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="bf-panel">
                                <h4>Search Behavior</h4>
                                <div class="bf-muted">
                                    Content search is optional and skips large or binary files. Disable it to reduce node load.
                                </div>
                            </div>
                        </div>
                        <div class="bf-two-col" style="margin-top: 12px;">
                            <div class="bf-panel">
                                <div class="bf-form-group">
                                    <div class="bf-form-row">
                                        <div class="bf-label">Git Integration</div>
                                        <div class="bf-control">
                                            <div class="btn-group" data-toggle="buttons">
                                                @php
                                                    $gitValue = old('betterfiles:git_enabled', (int) $gitEnabled);
                                                @endphp
                                                <label class="btn btn-primary @if ($gitValue == 1) active @endif">
                                                    <input type="radio" name="betterfiles:git_enabled" value="1" @if ($gitValue == 1) checked @endif> Enabled
                                                </label>
                                                <label class="btn btn-primary @if ($gitValue == 0) active @endif">
                                                    <input type="radio" name="betterfiles:git_enabled" value="0" @if ($gitValue == 0) checked @endif> Disabled
                                                </label>
                                            </div>
                                            <div class="help-block">Allow users to run safe Git status, clone, pull, and read-only diff actions from the file manager. Requires the Wings Git mod and Git installed in the container image.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="bf-panel">
                                <h4>Git Requirements</h4>
                                <div class="bf-muted">
                                    Requires the Wings Git route mod (Step 9 in docs). Git must be installed inside the server container image. If unavailable, the UI shows a graceful fallback.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" name="_method" value="PATCH" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-4 col-xs-12">
            <div class="box box-solid" style="background:#27303a;border-color:#3a4652;">
                <div class="box-header with-border" style="border-color:#3a4652;">
                    <h3 class="box-title"><i class="fa fa-eye"></i> Visibility</h3>
                </div>
                <div class="box-body">
                    <p class="text-muted">
                        If owner overrides are enabled, server owners can update their retention window from the
                        Better Files file manager. Otherwise, the default retention applies globally.
                    </p>
                    <div class="bf-section" style="margin-bottom: 0;">
                        <strong>Changes apply immediately.</strong>
                        <div class="bf-muted">Cleanup runs once per day.</div>
                    </div>
                </div>
            </div>
            <div class="box box-solid" style="background:#27303a;border-color:#3a4652;">
                <div class="box-header with-border" style="border-color:#3a4652;">
                    <h3 class="box-title"><i class="fa fa-bolt"></i> Quick Facts</h3>
                </div>
                <div class="box-body">
                    <ul class="list-unstyled" style="margin-bottom: 0;">
                        <li><strong>Default retention:</strong> {{ $defaultDays }} {{ $defaultUnit }}</li>
                        <li><strong>Pull URL limit:</strong> {{ (int) $settings['pull_url_max_size_mb'] }} MB</li>
                        <li><strong>Content search:</strong> {{ $contentSearchEnabled ? 'Enabled' : 'Disabled' }}</li>
                        <li><strong>Git integration:</strong> {{ $gitEnabled ? 'Enabled' : 'Disabled' }}</li>
                        <li><strong>Overrides:</strong> {{ $allowOverride ? 'Enabled' : 'Disabled' }}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-solid" style="background:#27303a;border-color:#3a4652;">
                <div class="box-header with-border" style="border-color:#3a4652;">
                    <h3 class="box-title"><i class="fa fa-server"></i> Server Cleanup Settings</h3>
                    <div class="box-tools pull-right">
                        <span class="bf-pill bf-pill-green">Enabled: {{ $pageEnabledCount }}</span>
                        <span class="bf-pill bf-pill-yellow">Disabled: {{ $pageDisabledCount }}</span>
                        <span class="bf-pill bf-pill-blue">Total: {{ $servers->total() }}</span>
                    </div>
                </div>
                <div class="box-body">
                    @if (!$allowOverride)
                        <div class="bf-section">
                            <strong>Overrides locked.</strong>
                            <div class="bf-muted">All servers use the global defaults.</div>
                        </div>
                    @endif
                    <div class="table-responsive">
                        <table class="table table-hover bf-table">
                            <thead>
                                <tr>
                                    <th>Server</th>
                                    <th>Cleanup</th>
                                    <th>Retention</th>
                                    <th>Source</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($servers as $server)
                                    @php
                                        $serverEnabled = $allowOverride ? (bool) $server->bf_trash_cleanup_enabled : $globalEnabled;
                                        $serverDays = $allowOverride ? (int) $server->bf_trash_retention_days : $defaultDays;
                                        $serverUnit = $allowOverride ? (string) ($server->bf_trash_retention_unit ?? $defaultUnit) : $defaultUnit;
                                    @endphp
                                    <tr>
                                        <td>
                                            <strong>{{ $server->name }}</strong><br />
                                            <small class="text-muted" title="{{ $server->uuid }}">UUID: {{ substr($server->uuid, 0, 8) }}</small>
                                        </td>
                                        <td>
                                            @if ($serverEnabled)
                                                <span class="label label-success">Enabled</span>
                                            @else
                                                <span class="label label-default">Disabled</span>
                                            @endif
                                        </td>
                                        <td>{{ $serverDays }} {{ $serverUnit }}</td>
                                        <td>
                                            @if ($allowOverride)
                                                <span class="label label-primary">Server</span>
                                            @else
                                                <span class="label label-warning">Global</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-muted">No servers found.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if ($servers->hasPages())
                    <div class="box-footer clearfix">
                        <div class="pull-right">
                            {!! $servers->render() !!}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
