<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Files;

use Pterodactyl\Models\Permission;
use Pterodactyl\Contracts\Http\ClientPermissionsRequest;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class TrashCleanupSettingsRequest extends ClientApiRequest implements ClientPermissionsRequest
{
    public function permission(): string
    {
        return Permission::ACTION_FILE_UPDATE;
    }

    public function rules(): array
    {
        return [
            'trash_cleanup_enabled' => 'required|boolean',
            'trash_retention_days' => 'required|integer|min:1',
            'trash_retention_unit' => 'required|in:days,hours',
        ];
    }
}
