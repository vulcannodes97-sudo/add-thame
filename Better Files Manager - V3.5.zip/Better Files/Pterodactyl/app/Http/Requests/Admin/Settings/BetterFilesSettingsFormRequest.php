<?php

namespace Pterodactyl\Http\Requests\Admin\Settings;

use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

class BetterFilesSettingsFormRequest extends AdminFormRequest
{
    public function rules(): array
    {
        return [
            'betterfiles:trash_cleanup_enabled' => 'required|boolean',
            'betterfiles:trash_cleanup_allow_override' => 'required|boolean',
            'betterfiles:trash_cleanup_default_days' => 'required|integer|min:1',
            'betterfiles:trash_cleanup_default_unit' => 'required|in:days,hours',
            'betterfiles:pull_url_max_size_mb' => 'required|integer|min:1',
            'betterfiles:search_content_enabled' => 'required|boolean',
            'betterfiles:git_enabled' => 'required|boolean',
        ];
    }

    public function attributes(): array
    {
        return [
            'betterfiles:trash_cleanup_enabled' => 'Trash cleanup enabled',
            'betterfiles:trash_cleanup_allow_override' => 'Allow server owner overrides',
            'betterfiles:trash_cleanup_default_days' => 'Default retention days',
            'betterfiles:trash_cleanup_default_unit' => 'Default retention unit',
            'betterfiles:pull_url_max_size_mb' => 'Pull URL max size (MB)',
            'betterfiles:search_content_enabled' => 'Allow content search',
            'betterfiles:git_enabled' => 'Git integration enabled',
        ];
    }
}
