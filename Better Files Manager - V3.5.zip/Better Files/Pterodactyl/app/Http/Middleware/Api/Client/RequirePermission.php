<?php

namespace Pterodactyl\Http\Middleware\Api\Client;

use Closure;
use Illuminate\Http\Request;
use Pterodactyl\Exceptions\Http\HttpForbiddenException;

class RequirePermission
{
    public function handle(Request $request, Closure $next, string $permission)
    {
        $server = $request->attributes->get('server');
        $user = $request->user();

        if (!$user || !$user->can($permission, $server)) {
            throw new HttpForbiddenException('You do not have permission to perform this action.');
        }

        return $next($request);
    }
}
