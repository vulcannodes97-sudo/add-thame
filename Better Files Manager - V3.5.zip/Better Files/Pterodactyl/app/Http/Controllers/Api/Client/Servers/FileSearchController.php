<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Services\BetterFilesSettingsService;
use Pterodactyl\Services\FileSearchService;


class FileSearchController extends ClientApiController
{
    public function __construct(
        private FileSearchService $searchService,
        private BetterFilesSettingsService $settingsService
    ) {
        parent::__construct();
    }

    public function search(Request $request, Server $server): JsonResponse
    {
        $validated = $request->validate([
            'query' => 'required|string|min:1|max:255',
            'max_results' => 'sometimes|integer|min:0|max:200',
            'max_depth' => 'nullable|integer|min:0|max:1000',
            'timeout' => 'sometimes|integer|min:1|max:30',
            'content' => 'sometimes|boolean',
        ]);

        $contentRequested = filter_var($request->input('content', false), FILTER_VALIDATE_BOOLEAN);
        $globalSettings = $this->settingsService->getGlobalSettings();
        $contentAllowed = (bool)($globalSettings['content_search_enabled'] ?? false);

        if ($contentRequested && !$contentAllowed) {
            return new JsonResponse([
                'error' => 'Content search is disabled by the administrator.',
                'error_code' => 'CONTENT_SEARCH_DISABLED',
            ], 403);
        }

        if ($contentRequested && !$request->user()?->can(Permission::ACTION_FILE_READ_CONTENT, $server)) {
            return new JsonResponse([
                'error' => 'You do not have permission to search file contents.',
                'error_code' => 'INSUFFICIENT_PERMISSIONS',
            ], 403);
        }

        try {
            $result = $this->searchService->searchFiles(
                $server,
                $validated['query'],
                $validated['max_results'] ?? 0,
                $validated['max_depth'] ?? 0,
                $validated['timeout'] ?? 8,
                $contentRequested && $contentAllowed
            );

            return new JsonResponse([
                'data' => $result['results'],
                'meta' => $result['meta'],
            ]);
        } catch (\InvalidArgumentException $e) {
            return new JsonResponse([
                'error' => $e->getMessage(),
                'error_code' => 'INVALID_PARAMS',
            ], 400);
        } catch (\RuntimeException $e) {
            $statusCode = 500;
            $errorCode = 'SEARCH_FAILED';

            if (str_contains($e->getMessage(), 'not available')) {
                $statusCode = 503;
                $errorCode = 'ENDPOINT_UNAVAILABLE';
            } elseif (str_contains($e->getMessage(), 'timed out')) {
                $statusCode = 504;
                $errorCode = 'TIMEOUT';
            } elseif (str_contains($e->getMessage(), 'connect')) {
                $statusCode = 502;
                $errorCode = 'WINGS_UNREACHABLE';
            }

            return new JsonResponse([
                'error' => $e->getMessage(),
                'error_code' => $errorCode,
            ], $statusCode);
        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => 'An unexpected error occurred',
                'error_code' => 'UNEXPECTED_ERROR',
            ], 500);
        }
    }
}
