<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Http\Request;
use Illuminate\Http\Client\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use GuzzleHttp\Exception\RequestException;
use Pterodactyl\Models\Server;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Exceptions\Http\HttpForbiddenException;
use Pterodactyl\Services\BetterFilesSettingsService;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\Files\PullFromUrlRequest;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;

class FilePullController extends ClientApiController
{
    private const MAX_DOWNLOAD_MB_DEFAULT = 100;

    public function __construct(
        private DaemonFileRepository $fileRepository,
        private BetterFilesSettingsService $settingsService,
    ) {
        parent::__construct();
    }

    private function normalizePath(string $path): string
    {
        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#/+#', '/', $path);

        $parts = explode('/', $path);
        $normalized = [];

        foreach ($parts as $part) {
            if ($part === '..') {
                if (!empty($normalized)) {
                    array_pop($normalized);
                }
            } elseif ($part !== '.' && $part !== '') {
                $normalized[] = $part;
            }
        }

        return '/' . implode('/', $normalized);
    }

    private function isBlockedHost(string $host): bool
    {
        $host = strtolower(trim($host));
        if ($host === 'localhost' || $host === 'localhost.localdomain') {
            return true;
        }
        if (str_ends_with($host, '.local') || str_ends_with($host, '.localhost') || str_ends_with($host, '.internal')) {
            return true;
        }
        return false;
    }

    private function isPrivateOrReservedIp(string $ip): bool
    {
        return filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) === false;
    }

    private function resolveHostIps(string $host): array
    {
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return [$host];
        }

        $ips = [];
        $records = dns_get_record($host, DNS_A + DNS_AAAA);
        if (is_array($records)) {
            foreach ($records as $record) {
                if (!empty($record['ip'])) {
                    $ips[] = $record['ip'];
                }
                if (!empty($record['ipv6'])) {
                    $ips[] = $record['ipv6'];
                }
            }
        }

        if (!$ips) {
            $fallback = gethostbynamel($host);
            if (is_array($fallback)) {
                $ips = array_merge($ips, $fallback);
            }
        }

        return array_values(array_unique($ips));
    }

    private function assertSafeUrl(string $url): void
    {
        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
            throw new HttpForbiddenException('Invalid URL provided.');
        }

        $scheme = strtolower($parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            throw new HttpForbiddenException('Only HTTP and HTTPS URLs are allowed.');
        }

        $host = $parts['host'];
        if ($this->isBlockedHost($host)) {
            throw new HttpForbiddenException('The provided URL is not allowed.');
        }

        $ips = $this->resolveHostIps($host);
        if (!$ips) {
            throw new HttpForbiddenException('Unable to resolve the URL host.');
        }

        foreach ($ips as $ip) {
            if ($this->isPrivateOrReservedIp($ip)) {
                throw new HttpForbiddenException('The provided URL is not allowed.');
            }
        }
    }

    private function resolveRedirectUrl(string $baseUrl, string $location): string
    {
        if (preg_match('/^https?:\/\//i', $location)) {
            return $location;
        }

        $base = parse_url($baseUrl);
        if (!$base || empty($base['scheme']) || empty($base['host'])) {
            return $location;
        }

        $scheme = $base['scheme'];
        $host = $base['host'];
        $port = isset($base['port']) ? ':' . $base['port'] : '';

        if (str_starts_with($location, '/')) {
            return "{$scheme}://{$host}{$port}{$location}";
        }

        $path = $base['path'] ?? '/';
        $dir = rtrim(dirname($path), '/');
        return "{$scheme}://{$host}{$port}{$dir}/{$location}";
    }

    private function getPinnedHttpClient(string $url, int $timeoutSeconds)
    {
        $parts = parse_url($url);
        if (!$parts || empty($parts['host']) || empty($parts['scheme'])) {
            throw new HttpForbiddenException('Invalid URL provided.');
        }

        $this->assertSafeUrl($url);

        $host = $parts['host'];
        $scheme = strtolower($parts['scheme']);
        $port = $parts['port'] ?? ($scheme === 'https' ? 443 : 80);

        $ips = $this->resolveHostIps($host);
        if (!$ips) {
            throw new HttpForbiddenException('Unable to resolve the URL host.');
        }

        foreach ($ips as $ip) {
            if ($this->isPrivateOrReservedIp($ip)) {
                throw new HttpForbiddenException('The provided URL is not allowed.');
            }
        }

        $targetIp = $ips[0];
        $resolveEntry = sprintf('%s:%d:%s', $host, $port, $targetIp);

        return Http::timeout($timeoutSeconds)->withOptions([
            'verify' => true,
            'allow_redirects' => false,
            'curl' => [
                CURLOPT_RESOLVE => [$resolveEntry],
            ],
        ]);
    }

    private function requestWithPinnedRedirects(string $url, int $timeoutSeconds, string $method, array $headers = []): array
    {
        $currentUrl = $url;
        $maxRedirects = 5;

        for ($i = 0; $i <= $maxRedirects; $i++) {
            $client = $this->getPinnedHttpClient($currentUrl, $timeoutSeconds)->withHeaders(array_merge([
                'User-Agent' => 'Pterodactyl Panel (https://pterodactyl.io)',
            ], $headers));
            $response = $client->send($method, $currentUrl);
            $status = $response->status();

            if (in_array($status, [301, 302, 303, 307, 308], true)) {
                $location = $response->header('Location');
                if (!$location) {
                    throw new HttpForbiddenException('Redirect location missing.');
                }
                $currentUrl = $this->resolveRedirectUrl($currentUrl, $location);
                continue;
            }

            return [$response, $currentUrl];
        }

        throw new HttpForbiddenException('Too many redirects.');
    }

    private function requestUrlForMetadata(string $url): array
    {
        try {
            [$response, $finalUrl] = $this->requestWithPinnedRedirects($url, 10, 'HEAD');
            if ($response->status() >= 400 || $response->status() === 405) {
                return $this->requestWithPinnedRedirects($url, 15, 'GET', [
                    'Range' => 'bytes=0-0',
                    'Accept-Encoding' => 'identity',
                ]);
            }
            return [$response, $finalUrl];
        } catch (\Throwable $exception) {
            try {
                return $this->requestWithPinnedRedirects($url, 15, 'GET', [
                    'Range' => 'bytes=0-0',
                    'Accept-Encoding' => 'identity',
                ]);
            } catch (\Throwable $fallbackException) {
                throw new HttpForbiddenException('Failed to query URL: ' . $fallbackException->getMessage());
            }
        }
    }

    private function getResponseSize(Response $response): int
    {
        $contentRange = $response->header('Content-Range');
        if ($contentRange && preg_match('/\/(\d+)$/', $contentRange, $matches)) {
            return (int)$matches[1];
        }

        $contentLength = $response->header('Content-Length');
        if ($contentLength !== null && $contentLength !== '') {
            return (int)$contentLength;
        }

        return 0;
    }

    private function parseFilenameFromDisposition(?string $contentDisposition): ?string
    {
        if (!$contentDisposition) {
            return null;
        }

        if (preg_match('/filename(\*)?=(UTF-8\'\')?"?([^";]+)"?;?/i', $contentDisposition, $matches)) {
            return $matches[3] ?? null;
        }

        return null;
    }

    private function sanitizeFilename(string $filename): string
    {
        $filename = preg_replace('/[\x00-\x1f<>:"\\/\\\\|?*]/', '_', $filename);
        $filename = trim($filename, '. ');
        return $filename ?: 'downloaded_file_' . time();
    }

    private function queryUrl(string $url): array
    {
        return Cache::remember('betterfiles:pull-url:query:' . sha1($url), 60, function () use ($url) {
            [$response, $finalUrl] = $this->requestUrlForMetadata($url);
            $status = $response->status();
            if ($status >= 400) {
                throw new HttpForbiddenException("Remote server returned HTTP {$status}.");
            }

            $size = $this->getResponseSize($response);

            $filename = $this->parseFilenameFromDisposition($response->header('Content-Disposition'));
            if (!$filename) {
                $urlPath = parse_url($finalUrl, PHP_URL_PATH) ?: '';
                $filename = basename($urlPath);
            }

            $contentType = $response->header('Content-Type');
            if ($filename && pathinfo($filename, PATHINFO_EXTENSION) === '' && $contentType) {
                $ext = $this->getExtensionFromContentType($contentType);
                if ($ext) {
                    $filename .= '.' . $ext;
                }
            }

            $filename = $filename ? $this->sanitizeFilename($filename) : null;

            return [
                'url' => $finalUrl,
                'filename' => $filename,
                'size' => $size,
                'content_type' => $contentType,
            ];
        });
    }

    private function getDiskDetails(Server $server): array
    {
        try {
            $response = $this->fileRepository->setServer($server)->getHttpClient()->get(
                sprintf('/api/servers/%s', $server->uuid)
            );
            $data = json_decode((string)$response->getBody(), true) ?? [];
            $diskUsed = (int)($data['utilization']['disk_bytes'] ?? 0);
        } catch (\Throwable $exception) {
            $diskUsed = 0;
        }

        $diskLimit = ((int)($server->disk ?? 0)) * 1024 * 1024;

        return [
            'disk_used' => $diskUsed,
            'disk_limit' => $diskLimit,
        ];
    }

    public function query(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'url' => 'required|string|url|max:2048',
        ]);
        $url = $validated['url'];

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new HttpForbiddenException('Invalid URL provided.');
        }
        $this->assertSafeUrl($url);

        $data = $this->queryUrl($url);

        return new JsonResponse([
            'filename' => $data['filename'],
            'size' => $data['size'],
        ]);
    }

    public function pullFromUrl(PullFromUrlRequest $request, Server $server): JsonResponse
    {
        $url = $request->input('url');
        $directory = $request->input('directory', '/');
        $filename = $request->input('filename');

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new HttpForbiddenException('Invalid URL provided.');
        }
        $this->assertSafeUrl($url);

        $directory = $this->normalizePath((string)$directory);
        if ($directory === '') {
            $directory = '/';
        }

        $maxSizeMb = (int)($this->settingsService->getGlobalSettings()['pull_url_max_size_mb'] ?? self::MAX_DOWNLOAD_MB_DEFAULT);
        $maxSizeMb = max(1, $maxSizeMb);
        $maxBytes = $maxSizeMb * 1024 * 1024;

        $data = $this->queryUrl($url);
        $fileSize = (int)($data['size'] ?? 0);
        if ($fileSize > $maxBytes) {
            throw new HttpForbiddenException("File is too large. Maximum size is {$maxSizeMb}MB.");
        }

        if ($fileSize > 0 && (int)($server->disk ?? 0) > 0) {
            $details = $this->getDiskDetails($server);
            if ($details['disk_limit'] > 0 && ($details['disk_used'] + $fileSize) > $details['disk_limit']) {
                throw new HttpForbiddenException('Insufficient disk space.');
            }
        }

        $resolvedName = $data['filename'] ?: 'downloaded_file';
        $targetName = $filename ?: $resolvedName;
        if ($filename && pathinfo($filename, PATHINFO_EXTENSION) === '' && $resolvedName) {
            $ext = pathinfo($resolvedName, PATHINFO_EXTENSION);
            if ($ext) {
                $targetName .= '.' . $ext;
            }
        }
        $targetName = $this->sanitizeFilename($targetName);

        try {
            $identifier = $this->fileRepository->setServer($server)->pull(
                $data['url'],
                $directory,
                [
                    'filename' => $targetName,
                    'use_header' => false,
                    'foreground' => false,
                ]
            );

            Activity::event('server:file.pull-url')
                ->property('directory', $directory)
                ->property('url', $url)
                ->property('filename', $targetName)
                ->log();

            $payload = json_decode($identifier->getBody(), true);
            $downloadId = $payload['identifier'] ?? null;
            if (!$downloadId) {
                throw new HttpForbiddenException('Failed to start file pull.');
            }

            return new JsonResponse([
                'identifier' => $downloadId,
                'id' => $downloadId,
                'filename' => $targetName,
                'size' => $fileSize,
                'directory' => $directory,
            ], JsonResponse::HTTP_ACCEPTED);
        } catch (RequestException $e) {
            $status = $e->getResponse()?->getStatusCode();
            if ($status === 404) {
                throw new HttpForbiddenException('Wings pull endpoint is not available. Update Wings to enable remote pulls.');
            }
            throw new HttpForbiddenException('Failed to pull file: ' . $e->getMessage());
        }
    }

    public function pull(PullFromUrlRequest $request, Server $server): JsonResponse
    {
        return $this->pullFromUrl($request, $server);
    }

    public function status(Server $server): JsonResponse
    {
        try {
            $response = $this->fileRepository->setServer($server)->getHttpClient()->get(
                sprintf('/api/servers/%s/files/pull', $server->uuid)
            );
            $data = json_decode((string)$response->getBody(), true) ?? [];
            return new JsonResponse($data);
        } catch (RequestException $e) {
            $status = $e->getResponse()?->getStatusCode();
            if ($status === 404) {
                throw new HttpForbiddenException('Wings pull endpoint is not available. Update Wings to enable remote pulls.');
            }
            throw new HttpForbiddenException('Failed to query pull status: ' . $e->getMessage());
        }
    }

    public function cancel(Request $request, Server $server, string $id): JsonResponse
    {
        try {
            $this->fileRepository->setServer($server)->getHttpClient()->delete(
                sprintf('/api/servers/%s/files/pull/%s', $server->uuid, $id)
            );
        } catch (RequestException $e) {
            $status = $e->getResponse()?->getStatusCode();
            if ($status === 404) {
                throw new HttpForbiddenException('Wings pull endpoint is not available. Update Wings to enable remote pulls.');
            }
            throw new HttpForbiddenException('Failed to cancel pull: ' . $e->getMessage());
        }

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }

    private function getExtensionFromContentType(string $contentType): ?string
    {
        $contentType = explode(';', $contentType)[0];
        $contentType = trim($contentType);

        $mimeToExtension = [
            'text/plain' => 'txt',
            'text/html' => 'html',
            'text/css' => 'css',
            'text/javascript' => 'js',
            'text/csv' => 'csv',
            'text/xml' => 'xml',
            'application/javascript' => 'js',
            'application/json' => 'json',
            'application/xml' => 'xml',
            'application/pdf' => 'pdf',
            'application/zip' => 'zip',
            'application/x-zip-compressed' => 'zip',
            'application/x-tar' => 'tar',
            'application/x-gzip' => 'gz',
            'application/gzip' => 'gz',
            'application/x-bzip2' => 'bz2',
            'application/x-7z-compressed' => '7z',
            'application/x-rar-compressed' => 'rar',
            'application/vnd.rar' => 'rar',
            'image/jpeg' => 'jpg',
            'image/jpg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/svg+xml' => 'svg',
            'image/webp' => 'webp',
            'image/bmp' => 'bmp',
            'image/tiff' => 'tiff',
            'image/x-icon' => 'ico',
            'video/mp4' => 'mp4',
            'video/webm' => 'webm',
            'video/avi' => 'avi',
            'video/quicktime' => 'mov',
            'video/x-msvideo' => 'avi',
            'audio/mpeg' => 'mp3',
            'audio/mp3' => 'mp3',
            'audio/ogg' => 'ogg',
            'audio/wav' => 'wav',
            'audio/x-wav' => 'wav',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-excel' => 'xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            'text/x-php' => 'php',
            'text/x-python' => 'py',
            'text/x-java-source' => 'java',
            'text/x-c' => 'c',
            'text/x-c++' => 'cpp',
            'application/octet-stream' => null,
        ];

        return $mimeToExtension[$contentType] ?? null;
    }
}
