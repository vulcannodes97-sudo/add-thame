<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Services\BetterFilesSettingsService;
use Pterodactyl\Http\Requests\Api\Client\Servers\Files\TrashCleanupSettingsRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Files\TrashCleanupSettingsViewRequest;

class FileTrashSettingsController extends ClientApiController
{
    public function __construct(private BetterFilesSettingsService $settingsService)
    {
        parent::__construct();
    }

    public function index(TrashCleanupSettingsViewRequest $request, Server $server): JsonResponse
    {
        $global = $this->settingsService->getGlobalSettings();
        $allowOverride = $global['enabled'] && $global['allow_override'];
        $defaultUnit = $global['default_unit'] ?? 'days';
        $contentSearchEnabled = (bool)($global['content_search_enabled'] ?? false);
        $gitEnabled = (bool)($global['git_enabled'] ?? false);

        if (!$allowOverride) {
            return new JsonResponse([
                'data' => [
                    'allow_user_override' => false,
                    'global_enabled' => (bool)$global['enabled'],
                    'trash_cleanup_enabled' => (bool)$global['enabled'],
                    'trash_retention_days' => (int)$global['default_days'],
                    'trash_retention_unit' => (string)$defaultUnit,
                    'default_days' => (int)$global['default_days'],
                    'default_unit' => (string)$defaultUnit,
                    'content_search_enabled' => $contentSearchEnabled,
                    'git_enabled' => $gitEnabled,
                ],
            ]);
        }

        return new JsonResponse([
            'data' => [
                'allow_user_override' => true,
                'global_enabled' => (bool)$global['enabled'],
                'trash_cleanup_enabled' => (bool)$server->bf_trash_cleanup_enabled,
                'trash_retention_days' => (int)$server->bf_trash_retention_days,
                'trash_retention_unit' => (string)($server->bf_trash_retention_unit ?? $defaultUnit),
                'default_days' => (int)$global['default_days'],
                'default_unit' => (string)$defaultUnit,
                'content_search_enabled' => $contentSearchEnabled,
                    'git_enabled' => $gitEnabled,
            ],
        ]);
    }

    public function update(TrashCleanupSettingsRequest $request, Server $server): JsonResponse
    {
        $global = $this->settingsService->getGlobalSettings();
        $allowOverride = $global['enabled'] && $global['allow_override'];
        $contentSearchEnabled = (bool)($global['content_search_enabled'] ?? false);
        $gitEnabled = (bool)($global['git_enabled'] ?? false);

        if (!$allowOverride) {
            return new JsonResponse(['message' => 'Trash cleanup settings are managed by an administrator.'], 403);
        }

        $enabled = (bool)$request->input('trash_cleanup_enabled', false);
        $days = (int)$request->input('trash_retention_days', $global['default_days']);
        $days = max(1, $days);
        $unit = (string)$request->input('trash_retention_unit', $global['default_unit'] ?? 'days');
        $unit = in_array($unit, ['days', 'hours'], true) ? $unit : 'days';

        $server->update([
            'bf_trash_cleanup_enabled' => $enabled,
            'bf_trash_retention_days' => $days,
            'bf_trash_retention_unit' => $unit,
        ]);

        return new JsonResponse([
            'data' => [
                'allow_user_override' => true,
                'global_enabled' => (bool)$global['enabled'],
                'trash_cleanup_enabled' => $enabled,
                'trash_retention_days' => $days,
                'trash_retention_unit' => $unit,
                'default_days' => (int)$global['default_days'],
                'default_unit' => (string)($global['default_unit'] ?? 'days'),
                'content_search_enabled' => $contentSearchEnabled,
                    'git_enabled' => $gitEnabled,
            ],
        ]);
    }
}
