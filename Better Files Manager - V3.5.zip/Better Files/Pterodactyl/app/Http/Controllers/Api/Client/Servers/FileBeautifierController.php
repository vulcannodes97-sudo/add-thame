<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Server;
use Pterodactyl\Jobs\BeautifyFileJob;
use Pterodactyl\Services\FileBeautifierService;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\Files\GetFileContentsRequest;

class FileBeautifierController extends ClientApiController
{
    public function __construct(
        private FileBeautifierService $beautifier,
        private DaemonFileRepository $fileRepository
    ) {
        parent::__construct();
    }

    
    public function check(GetFileContentsRequest $request, Server $server): JsonResponse
    {
        $filePath = $request->get('file');

        if (!$filePath) {
            return new JsonResponse(['error' => 'File path is required'], 400);
        }

        $supported = $this->beautifier->isSupported($filePath);

        return new JsonResponse([
            'supported' => $supported,
            'file_path' => $filePath,
            'file_type' => pathinfo($filePath, PATHINFO_EXTENSION),
        ]);
    }

    
    public function beautify(GetFileContentsRequest $request, Server $server): JsonResponse
    {
        $filePath = $request->get('file');

        if (!$filePath) {
            return new JsonResponse(['error' => 'File path is required'], 400);
        }

        if (!$this->beautifier->isSupported($filePath)) {
            return new JsonResponse([
                'error' => 'File type not supported for beautification',
                'file_type' => pathinfo($filePath, PATHINFO_EXTENSION),
            ], 400);
        }

        try {
            $content = $request->input('content');
            
            if ($content === null) {
                $content = $this->fileRepository
                    ->setServer($server)
                    ->getContent($filePath, config('pterodactyl.files.max_edit_size'));
            }

            $beautified = $this->beautifier->beautify($content, $filePath);

            $this->fileRepository
                ->setServer($server)
                ->putContent($filePath, $beautified);

            $didChange = $beautified !== $content;
            Activity::event('server:file.beautify')
                ->property('file', $filePath)
                ->property('original_size', strlen($content))
                ->property('beautified_size', strlen($beautified))
                ->log();

            return new JsonResponse([
                'success' => true,
                'message' => $didChange ? 'File beautified successfully' : 'No changes needed',
                'file_path' => $filePath,
                'content' => $beautified,
                'original_size' => strlen($content),
                'beautified_size' => strlen($beautified),
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => $e->getMessage(),
                'file_path' => $filePath,
            ], 500);
        }
    }

    
    public function beautifyAsync(GetFileContentsRequest $request, Server $server): JsonResponse
    {
        $filePath = $request->get('file');

        if (!$filePath) {
            return new JsonResponse(['error' => 'File path is required'], 400);
        }

        if (!$this->beautifier->isSupported($filePath)) {
            return new JsonResponse([
                'error' => 'File type not supported for beautification',
                'file_type' => pathinfo($filePath, PATHINFO_EXTENSION),
            ], 400);
        }

        try {
            BeautifyFileJob::dispatch($server, $filePath, $request->user()->id);

            Activity::event('server:file.beautify.queue')
                ->property('file', $filePath)
                ->log();

            return new JsonResponse([
                'success' => true,
                'message' => 'File beautification queued',
                'file_path' => $filePath,
                'queued' => true,
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => $e->getMessage(),
                'file_path' => $filePath,
            ], 500);
        }
    }

    
    public function preview(GetFileContentsRequest $request, Server $server): JsonResponse
    {
        $filePath = $request->get('file');

        if (!$filePath) {
            return new JsonResponse(['error' => 'File path is required'], 400);
        }

        if (!$this->beautifier->isSupported($filePath)) {
            return new JsonResponse([
                'error' => 'File type not supported for beautification',
                'file_type' => pathinfo($filePath, PATHINFO_EXTENSION),
            ], 400);
        }

        try {
            $content = $this->fileRepository
                ->setServer($server)
                ->getContent($filePath, config('pterodactyl.files.max_edit_size'));
            $beautified = $this->beautifier->beautify($content, $filePath);

            return new JsonResponse([
                'success' => true,
                'file_path' => $filePath,
                'original' => $content,
                'beautified' => $beautified,
                'original_size' => strlen($content),
                'beautified_size' => strlen($beautified),
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'error' => $e->getMessage(),
                'file_path' => $filePath,
            ], 500);
        }
    }
}
