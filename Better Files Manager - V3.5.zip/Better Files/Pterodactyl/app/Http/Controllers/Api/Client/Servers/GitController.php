<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use GuzzleHttp\Exception\TransferException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Models\Permission;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Services\BetterFilesSettingsService;

class GitController extends ClientApiController
{
    public function __construct(
        private DaemonFileRepository $fileRepository,
        private BetterFilesSettingsService $settingsService,
    ) {
        parent::__construct();
    }

    private function ensureGitEnabled(): ?JsonResponse
    {
        $global = $this->settingsService->getGlobalSettings();
        if (empty($global['git_enabled'])) {
            return new JsonResponse(['error' => 'Git integration is disabled by the administrator.'], 403);
        }

        return null;
    }

    private function ensureGitOperationAllowed(Request $request, Server $server): ?JsonResponse
    {
        if ($denied = $this->ensureGitEnabled()) {
            return $denied;
        }

        $user = $request->user();
        if (
            !$user ||
            !$user->can(Permission::ACTION_FILE_UPDATE, $server) ||
            !$user->can(Permission::ACTION_CONTROL_CONSOLE, $server)
        ) {
            return new JsonResponse([
                'error' => 'Git clone and pull require both file write and console permissions.',
            ], 403);
        }

        return null;
    }

    private function ensureGitDiffAllowed(Request $request, Server $server): ?JsonResponse
    {
        if ($denied = $this->ensureGitEnabled()) {
            return $denied;
        }

        $user = $request->user();
        if (
            !$user ||
            !$user->can(Permission::ACTION_FILE_READ, $server) ||
            !$user->can(Permission::ACTION_FILE_READ_CONTENT, $server)
        ) {
            return new JsonResponse([
                'error' => 'Viewing Git diffs requires file content read permission.',
            ], 403);
        }

        return null;
    }

    public function status(Request $request, Server $server): JsonResponse
    {
        if ($denied = $this->ensureGitEnabled()) {
            return $denied;
        }

        $validated = $request->validate([
            'work_dir' => 'nullable|string|max:512',
        ]);

        return $this->proxyDaemon(function () use ($server, $validated) {
            return $this->fileRepository
                ->setServer($server)
                ->getHttpClient()
                ->get(
                    sprintf('/api/servers/%s/git/status', $server->uuid),
                    [
                        'query' => ['work_dir' => $validated['work_dir'] ?? '/'],
                        'timeout' => 15,
                    ]
                );
        });
    }

    public function cloneRepository(Request $request, Server $server): JsonResponse
    {
        if ($denied = $this->ensureGitOperationAllowed($request, $server)) {
            return $denied;
        }

        $validated = $request->validate([
            'repository_url' => 'required|string|max:2048',
            'target_directory' => 'nullable|string|max:128',
            'work_dir' => 'nullable|string|max:512',
        ]);

        $repositoryUrl = trim($validated['repository_url']);
        if (!$this->isSafeHttpsUrl($repositoryUrl)) {
            return new JsonResponse(['error' => 'Only HTTPS repository URLs without embedded credentials are allowed.'], 422);
        }

        $targetDirectory = trim((string)($validated['target_directory'] ?? ''));
        if ($targetDirectory !== '' && !$this->isSafeTargetDirectory($targetDirectory)) {
            return new JsonResponse([
                'error' => 'Target directory can only contain letters, numbers, dots, underscores, and dashes.',
            ], 422);
        }

        return $this->proxyDaemon(function () use ($server, $repositoryUrl, $targetDirectory, $validated) {
            return $this->fileRepository
                ->setServer($server)
                ->getHttpClient()
                ->post(
                    sprintf('/api/servers/%s/git/clone', $server->uuid),
                    [
                        'json' => [
                            'repository_url' => $repositoryUrl,
                            'target_directory' => $targetDirectory,
                            'work_dir' => $validated['work_dir'] ?? '/',
                        ],
                        'timeout' => 130,
                    ]
                );
        });
    }

    public function pull(Request $request, Server $server): JsonResponse
    {
        if ($denied = $this->ensureGitOperationAllowed($request, $server)) {
            return $denied;
        }

        $validated = $request->validate([
            'work_dir' => 'nullable|string|max:512',
        ]);

        return $this->proxyDaemon(function () use ($server, $validated) {
            return $this->fileRepository
                ->setServer($server)
                ->getHttpClient()
                ->post(
                    sprintf('/api/servers/%s/git/pull', $server->uuid),
                    [
                        'json' => [
                            'work_dir' => $validated['work_dir'] ?? '/',
                        ],
                        'timeout' => 70,
                    ]
                );
        });
    }

    public function diff(Request $request, Server $server): JsonResponse
    {
        if ($denied = $this->ensureGitDiffAllowed($request, $server)) {
            return $denied;
        }

        $validated = $request->validate([
            'work_dir' => 'nullable|string|max:512',
            'file' => 'nullable|string|max:4096',
        ]);

        return $this->proxyDaemon(function () use ($server, $validated) {
            return $this->fileRepository
                ->setServer($server)
                ->getHttpClient()
                ->post(
                    sprintf('/api/servers/%s/git/diff', $server->uuid),
                    [
                        'json' => [
                            'work_dir' => $validated['work_dir'] ?? '/',
                            'file' => $validated['file'] ?? '',
                        ],
                        'timeout' => 30,
                    ]
                );
        });
    }

    private function proxyDaemon(callable $request): JsonResponse
    {
        try {
            $response = $request();
            $decoded = json_decode($response->getBody()->getContents(), true);

            return new JsonResponse($decoded ?? [], $response->getStatusCode());
        } catch (TransferException $e) {
            $statusCode = 502;
            $body = ['error' => 'Unable to connect to the daemon.'];

            if (method_exists($e, 'getResponse') && $e->getResponse()) {
                $statusCode = $e->getResponse()->getStatusCode();
                $decoded = json_decode($e->getResponse()->getBody()->getContents(), true);
                if ($decoded) {
                    $body = $decoded;
                }
            }

            return new JsonResponse($body, $statusCode);
        }
    }

    private function isSafeHttpsUrl(string $url): bool
    {
        if (!str_starts_with(strtolower($url), 'https://')) {
            return false;
        }

        $parts = parse_url($url);
        if (!$parts || empty($parts['scheme']) || empty($parts['host']) || empty($parts['path'])) {
            return false;
        }

        return empty($parts['user']) && empty($parts['pass']) && empty($parts['query']) && empty($parts['fragment']);
    }

    private function isSafeTargetDirectory(string $directory): bool
    {
        return !str_contains($directory, '..')
            && !str_starts_with($directory, '.')
            && !str_starts_with($directory, '-')
            && preg_match('/^[A-Za-z0-9._-]{1,128}$/', $directory) === 1;
    }
}
