<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\Server;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Pterodactyl\Services\FileTrashService;
use Pterodactyl\Http\Requests\Api\Client\Servers\Files\MoveToTrashRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Files\RestoreFromTrashRequest;

class FileTrashController extends ClientApiController
{
    public function __construct(
        private DaemonFileRepository $fileRepository,
        private FileTrashService $trashService
    ) {
        parent::__construct();
    }

    /**
     * Get contents of the trash bin
     */
    public function index(Server $server): JsonResponse
    {
        $trashContents = $this->trashService->getTrashContents($server);

        return new JsonResponse([
            'data' => $trashContents,
        ]);
    }

    /**
     * Move files to trash
     */
    public function moveToTrash(MoveToTrashRequest $request, Server $server): JsonResponse
    {
        $root = $request->input('root');
        $files = $request->input('files');

        $movedFiles = $this->trashService->moveToTrash($server, $root, $files);

        Activity::event('server:file.trash.move')
            ->property('directory', $root)
            ->property('files', $files)
            ->property('count', count($movedFiles))
            ->log();

        return new JsonResponse([
            'success' => true,
            'message' => count($movedFiles) . ' file(s) moved to trash',
            'files' => $movedFiles,
        ]);
    }

    /**
     * Restore files from trash
     */
    public function restore(RestoreFromTrashRequest $request, Server $server): JsonResponse
    {
        $files = $request->input('files');

        $restoredFiles = $this->trashService->restoreFromTrash($server, $files);

        Activity::event('server:file.trash.restore')
            ->property('files', $files)
            ->property('count', count($restoredFiles))
            ->log();

        return new JsonResponse([
            'success' => true,
            'message' => count($restoredFiles) . ' file(s) restored from trash',
            'files' => $restoredFiles,
        ]);
    }

    /**
     * Empty the entire trash bin
     */
    public function empty(Server $server): JsonResponse
    {
        $deletedCount = $this->trashService->emptyTrash($server);

        Activity::event('server:file.trash.empty')
            ->property('count', $deletedCount)
            ->log();

        return new JsonResponse([
            'success' => true,
            'message' => "Trash bin emptied ({$deletedCount} items deleted)",
            'count' => $deletedCount,
        ]);
    }
}
