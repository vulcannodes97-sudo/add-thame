<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Illuminate\Contracts\Console\Kernel;
use Pterodactyl\Models\Server;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\BetterFilesSettingsService;
use Pterodactyl\Http\Requests\Admin\Settings\BetterFilesSettingsFormRequest;

class BetterFilesController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private Kernel $kernel,
        private BetterFilesSettingsService $settingsService,
    ) {
    }

    public function index(): View
    {
        return view('admin.settings.betterfiles', [
            'settings' => $this->settingsService->getGlobalSettings(),
            'servers' => Server::query()
                ->select(['id', 'uuid', 'name', 'bf_trash_cleanup_enabled', 'bf_trash_retention_days'])
                ->orderBy('name')
                ->paginate(25),
        ]);
    }

    public function update(BetterFilesSettingsFormRequest $request): RedirectResponse
    {
        $settings = $this->settingsService->updateGlobalSettings($request->validated());

        if (!$settings['allow_override']) {
            Server::query()->update([
                'bf_trash_cleanup_enabled' => $settings['enabled'],
                'bf_trash_retention_days' => $settings['default_days'],
                'bf_trash_retention_unit' => $settings['default_unit'] ?? 'days',
            ]);
        }

        $this->kernel->call('queue:restart');
        $this->alert->success('Better Files settings have been updated.')->flash();

        return redirect()->route('admin.settings.betterfiles');
    }
}
