<?php

namespace Pterodactyl\Services;

use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ConnectException;

class FileSearchService
{
    public function __construct(
        private DaemonFileRepository $fileRepository
    ) {}

    public function searchFiles(
        Server $server,
        string $query,
        int $maxResults = 0,
        int $maxDepth = 10,
        int $timeout = 8,
        bool $content = false
    ): array {
        $this->fileRepository->setServer($server);

        if ($maxResults > 0) {
            $maxResults = min(200, $maxResults);
        } else {
            $maxResults = 0;
        }
        if ($maxDepth > 0) {
            $maxDepth = min(1000, $maxDepth);
        } else {
            $maxDepth = 0;
        }
        $timeout = max(1, min(30, $timeout));

        try {
            $response = $this->fileRepository->getHttpClient()->get(
                sprintf('/api/servers/%s/files/search', $server->uuid),
                [
                    'query' => [
                        'query' => $query,
                        'max_results' => $maxResults,
                        ...($maxDepth > 0 ? ['max_depth' => $maxDepth] : []),
                        'timeout' => $timeout,
                        'content' => $content ? '1' : '0',
                    ],
                    'timeout' => $timeout + 5,
                ]
            );

            $body = $response->getBody()->__toString();
            $data = json_decode($body, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \RuntimeException('Invalid JSON response from Wings: ' . json_last_error_msg());
            }

            $results = [];
            foreach ($data['data'] ?? [] as $item) {
                $results[] = [
                    'name' => $item['name'] ?? '',
                    'path' => $item['path'] ?? '',
                    'directory' => $item['directory'] ?? '/',
                    'is_file' => $item['is_file'] ?? true,
                    'size' => (int)($item['size'] ?? 0),
                    'modified_at' => $item['modified_at'] ?? null,
                ];
            }

            return [
                'results' => $results,
                'meta' => [
                    'search_time_ms' => (int)($data['meta']['search_time_ms'] ?? 0),
                    'truncated' => (bool)($data['meta']['truncated'] ?? false),
                    'query' => $data['meta']['query'] ?? $query,
                    'max_results' => (int)($data['meta']['max_results'] ?? $maxResults),
                    'max_depth' => (int)($data['meta']['max_depth'] ?? $maxDepth),
                    'total_scanned' => (int)($data['meta']['total_scanned'] ?? 0),
                ],
            ];
        } catch (ConnectException $e) {
            throw new \RuntimeException('Unable to connect to Wings daemon: ' . $e->getMessage());
        } catch (RequestException $e) {
            $statusCode = $e->getResponse()?->getStatusCode() ?? 500;
            $errorBody = '';

            if ($e->getResponse()) {
                $errorBody = $e->getResponse()->getBody()->__toString();
                $decoded = json_decode($errorBody, true);
                if (isset($decoded['error'])) {
                    $errorBody = $decoded['error'];
                }
            }

            if ($statusCode === 400) {
                throw new \InvalidArgumentException($errorBody ?: 'Invalid search parameters');
            }

            if ($statusCode === 404) {
                throw new \RuntimeException('Search endpoint not available on Wings');
            }

            if ($statusCode === 504 || $statusCode === 408) {
                throw new \RuntimeException('Search timed out, try reducing max_depth or increasing timeout');
            }

            throw new \RuntimeException(
                sprintf('Wings search failed (HTTP %d): %s', $statusCode, $errorBody ?: $e->getMessage())
            );
        }
    }
}
