<?php

namespace Pterodactyl\Services;

use Carbon\Carbon;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Illuminate\Support\Str;

class FileTrashService
{
    private const TRASH_DIR = '/.trash-bin';
    private const METADATA_FILE = '/.trash-bin/.metadata.json';
    private const MAX_TRASH_FILES = 500;
    private const MAX_FILENAME_LENGTH = 255;
    private const MAX_PATH_LENGTH = 4096;
    private const FORBIDDEN_CHARS = ['\\', "\0", "\n", "\r"];
    private const PROTECTED_PATHS = [
        '/.trash-bin',
        '/.well-known',
        '/.git',
        '/.env',
    ];

    public function __construct(
        private DaemonFileRepository $fileRepository
    ) {}

    private function sanitizeFilename(string $filename): string
    {
        $filename = trim($filename);
        
        foreach (self::FORBIDDEN_CHARS as $char) {
            $filename = str_replace($char, '', $filename);
        }
        
        if (strlen($filename) > self::MAX_FILENAME_LENGTH) {
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            $name = pathinfo($filename, PATHINFO_FILENAME);
            $maxNameLength = self::MAX_FILENAME_LENGTH - strlen($ext) - 1;
            $filename = substr($name, 0, $maxNameLength) . '.' . $ext;
        }
        
        return $filename ?: 'unnamed_' . Str::random(8);
    }

    private function normalizePath(string $path): string
    {
        $path = str_replace('\\', '/', $path);
        $path = preg_replace('#/+#', '/', $path);
        
        $parts = explode('/', $path);
        $normalized = [];
        
        foreach ($parts as $part) {
            if ($part === '..') {
                if (!empty($normalized) && end($normalized) !== '') {
                    array_pop($normalized);
                }
            } elseif ($part !== '.' && $part !== '') {
                $normalized[] = $part;
            }
        }
        
        $result = '/' . implode('/', $normalized);
        return $result === '' ? '/' : $result;
    }

    private function isProtectedPath(string $path): bool
    {
        $normalizedPath = strtolower($this->normalizePath($path));
        foreach (self::PROTECTED_PATHS as $protected) {
            if (strpos($normalizedPath, strtolower($protected)) === 0) {
                return true;
            }
        }
        return false;
    }

    private function isWithinTrashDir(string $path): bool
    {
        $normalized = $this->normalizePath($path);
        return $normalized === self::TRASH_DIR || strpos($normalized, self::TRASH_DIR . '/') === 0;
    }

    private function generateTrashName(string $originalName): array
    {
        $timestamp = time();
        $hash = substr(md5($originalName . $timestamp . Str::random(8)), 0, 8);
        
        $pathInfo = pathinfo($originalName);
        $name = $pathInfo['filename'] ?? $originalName;
        $ext = isset($pathInfo['extension']) ? '.' . $pathInfo['extension'] : '';
        
        $trashName = "{$name}_{$timestamp}_{$hash}{$ext}";
        
        return [
            'trashName' => $this->sanitizeFilename($trashName),
            'timestamp' => $timestamp,
            'hash' => $hash,
        ];
    }

    private function getFileSize(string $path): int
    {
        try {
            $dir = dirname($path);
            $name = basename($path);
            $files = $this->fileRepository->getDirectory($dir);
            
            foreach ($files as $file) {
                $fileData = is_array($file) ? $file : (array)$file;
                if (($fileData['name'] ?? '') === $name) {
                    return (int)($fileData['size'] ?? 0);
                }
            }
        } catch (\Exception $e) {
            // Ignore
        }
        return 0;
    }

    public function getTrashContents(Server $server): array
    {
        $this->fileRepository->setServer($server);
        $this->ensureTrashDirExists($server);

        $metadata = $this->getMetadata($server);
        $trashContents = [];

        foreach ($metadata as $key => $meta) {
            // Skip entries without required fields (old format)
            if (!isset($meta['trashPath']) || !isset($meta['originalPath'])) {
                continue;
            }
            
            // Ensure trashPath is a valid string
            $trashPath = (string)$meta['trashPath'];
            if (empty($trashPath)) {
                continue;
            }
            
            // Get file size from metadata or fetch it
            $size = (int)($meta['size'] ?? 0);
            if ($size === 0) {
                $size = $this->getFileSize($trashPath);
            }
            
            // Determine the display name
            $originalName = $meta['originalName'] ?? null;
            if (empty($originalName)) {
                $originalName = basename($meta['originalPath']);
            }
            if (empty($originalName)) {
                $originalName = basename($trashPath);
            }
            
            $trashContents[] = [
                'key' => (string)$key,
                'path' => $trashPath,  // Frontend expects 'path' - MUST be string
                'trashPath' => $trashPath,
                'originalPath' => (string)$meta['originalPath'],
                'originalName' => $originalName,
                'name' => $originalName,  // Show original name for display
                'deletedAt' => $meta['deletedAt'] ?? Carbon::now()->toIso8601String(),
                'timestamp' => (int)($meta['timestamp'] ?? 0),
                'hash' => (string)($meta['hash'] ?? ''),
                'size' => $size,
                'isFile' => !($meta['isDirectory'] ?? false),
                'isDirectory' => (bool)($meta['isDirectory'] ?? false),
            ];
        }

        usort($trashContents, function ($a, $b) {
            return ($b['timestamp'] ?? 0) - ($a['timestamp'] ?? 0);
        });

        return $trashContents;
    }

    public function moveToTrash(Server $server, string $root, array $files): array
    {
        $this->fileRepository->setServer($server);
        $this->ensureTrashDirExists($server);

        $root = $this->normalizePath($root);
        $metadata = $this->getMetadata($server);
        
        if (count($metadata) >= self::MAX_TRASH_FILES) {
            $this->pruneOldestTrashFiles($server, $metadata, count($files));
            $metadata = $this->getMetadata($server);
        }

        $movedFiles = [];

        foreach ($files as $filename) {
            $filename = $this->sanitizeFilename($filename);
            if (empty($filename)) {
                continue;
            }

            $sourcePath = $root === '/' ? "/{$filename}" : "{$root}/{$filename}";
            
            if ($this->isProtectedPath($sourcePath)) {
                continue;
            }

            $isDirectory = false;
            $fileSize = 0;
            try {
                $parentDir = $root === '' ? '/' : $root;
                $entries = $this->fileRepository->getDirectory($parentDir);
                foreach ($entries as $entry) {
                    $fileData = is_array($entry) ? $entry : (array)$entry;
                    if (($fileData['name'] ?? '') === $filename) {
                        $isDirectory = !($fileData['file'] ?? true);
                        $fileSize = (int)($fileData['size'] ?? 0);
                        break;
                    }
                }
                if (!$isDirectory && $fileSize === 0) {
                    $fileSize = $this->getFileSize($sourcePath);
                }
            } catch (\Exception $e) {
                $fileSize = $this->getFileSize($sourcePath);
            }

            // Generate trash name with timestamp and hash
            $trashInfo = $this->generateTrashName($filename);
            
            // Preserve directory structure: /.trash-bin/original/path/structure/
            $relativePath = ltrim($root, '/');
            $trashDir = $relativePath ? self::TRASH_DIR . '/' . $relativePath : self::TRASH_DIR;
            $trashPath = $trashDir . '/' . $trashInfo['trashName'];

            // Ensure trash subdirectory exists
            $this->ensureDirectoryExists($trashDir);

            try {
                $this->fileRepository->renameFiles('/', [
                    [
                        'from' => ltrim($sourcePath, '/'),
                        'to' => ltrim($trashPath, '/'),
                    ],
                ]);

                $metaKey = $trashInfo['timestamp'] . '_' . $trashInfo['hash'];
                $metadata[$metaKey] = [
                    'trashPath' => $trashPath,
                    'originalPath' => $sourcePath,
                    'originalName' => $filename,
                    'deletedAt' => Carbon::now()->toIso8601String(),
                    'deletedFrom' => $root,
                    'timestamp' => $trashInfo['timestamp'],
                    'hash' => $trashInfo['hash'],
                    'isDirectory' => $isDirectory,
                    'size' => $fileSize,
                ];

                $movedFiles[] = [
                    'original' => $sourcePath,
                    'trash' => $trashPath,
                    'key' => $metaKey,
                ];
            } catch (\Exception $e) {
                continue;
            }
        }

        $this->saveMetadata($server, $metadata);
        return $movedFiles;
    }

    public function restoreFromTrash(Server $server, array $files): array
    {
        $this->fileRepository->setServer($server);
        $metadata = $this->getMetadata($server);
        $restoredFiles = [];

        foreach ($files as $file) {
            // Find metadata by key or by trashPath
            $meta = null;
            $metaKey = null;
            
            // First try as a key (timestamp_hash)
            if (isset($metadata[$file])) {
                $meta = $metadata[$file];
                $metaKey = $file;
            } else {
                // Try to find by trashPath
                foreach ($metadata as $key => $m) {
                    if (isset($m['trashPath']) && $m['trashPath'] === $file) {
                        $meta = $m;
                        $metaKey = $key;
                        break;
                    }
                    // Also check normalized path
                    if (isset($m['trashPath']) && $this->normalizePath($m['trashPath']) === $this->normalizePath($file)) {
                        $meta = $m;
                        $metaKey = $key;
                        break;
                    }
                }
            }
            
            if (!$meta || !$metaKey) {
                continue;
            }

            $trashPath = $meta['trashPath'] ?? '';
            $originalPath = $this->normalizePath($meta['originalPath']);
            $originalName = $meta['originalName'] ?? basename($originalPath);
            $originalDir = dirname($originalPath);
            $originalDir = $originalDir === '.' ? '/' : $originalDir;

            if ($trashPath === '' || !$this->isWithinTrashDir($trashPath)) {
                unset($metadata[$metaKey]);
                continue;
            }

            if ($this->isProtectedPath($originalPath)) {
                continue;
            }

            // Ensure original directory exists
            $this->ensureDirectoryExists($originalDir);

            // Check for name conflicts and resolve
            $restoreName = $originalName;
            try {
                $existingFiles = $this->fileRepository->getDirectory($originalDir);
                $existingNames = array_map(function($f) {
                    $fileData = is_array($f) ? $f : (array)$f;
                    return $fileData['name'] ?? '';
                }, $existingFiles);

                if (in_array($restoreName, $existingNames)) {
                    $pathInfo = pathinfo($restoreName);
                    $name = $pathInfo['filename'] ?? $restoreName;
                    $ext = isset($pathInfo['extension']) ? '.' . $pathInfo['extension'] : '';
                    $counter = 1;
                    
                    do {
                        $restoreName = "{$name}_restored_{$counter}{$ext}";
                        $counter++;
                    } while (in_array($restoreName, $existingNames) && $counter < 100);
                }
            } catch (\Exception $e) {
                // Directory listing failed, try restore anyway
            }

            $restorePath = $originalDir === '/' ? "/{$restoreName}" : "{$originalDir}/{$restoreName}";

            try {
                $this->fileRepository->renameFiles('/', [
                    [
                        'from' => ltrim($trashPath, '/'),
                        'to' => ltrim($restorePath, '/'),
                    ],
                ]);

                unset($metadata[$metaKey]);

                $restoredFiles[] = [
                    'from' => $trashPath,
                    'to' => $restorePath,
                    'originalName' => $originalName,
                ];
            } catch (\Exception $e) {
                continue;
            }
        }

        $this->saveMetadata($server, $metadata);
        return $restoredFiles;
    }

    public function emptyTrash(Server $server): int
    {
        $this->fileRepository->setServer($server);
        $metadata = $this->getMetadata($server);
        $deletedCount = 0;

        foreach ($metadata as $key => $meta) {
            try {
                $trashPath = $meta['trashPath'] ?? '';
                if ($trashPath === '' || !$this->isWithinTrashDir($trashPath)) {
                    continue;
                }
                $dir = dirname($trashPath);
                $name = basename($trashPath);
                
                $this->fileRepository->deleteFiles($dir, [$name]);
                $deletedCount++;
            } catch (\Exception $e) {
                continue;
            }
        }

        // Clear metadata
        $this->saveMetadata($server, []);

        // Try to clean up empty directories in trash
        $this->cleanupEmptyTrashDirs($server);

        return $deletedCount;
    }

    public function purgeExpiredTrash(Server $server, int $retentionValue, string $retentionUnit = 'days'): int
    {
        if ($retentionValue <= 0) {
            return 0;
        }

        $this->fileRepository->setServer($server);
        $this->ensureTrashDirExists($server);

        $metadata = $this->getMetadata($server);
        if (empty($metadata)) {
            return 0;
        }

        $retentionUnit = $retentionUnit === 'hours' ? 'hours' : 'days';
        $cutoff = $retentionUnit === 'hours'
            ? Carbon::now()->subHours($retentionValue)->getTimestamp()
            : Carbon::now()->subDays($retentionValue)->getTimestamp();
        $deletedCount = 0;

        foreach ($metadata as $key => $meta) {
            $timestamp = $this->resolveDeletedTimestamp($meta);
            if ($timestamp === 0 || $timestamp > $cutoff) {
                continue;
            }

            try {
                $trashPath = $meta['trashPath'] ?? null;
                if (!$trashPath || !$this->isWithinTrashDir($trashPath)) {
                    unset($metadata[$key]);
                    continue;
                }

                $dir = dirname($trashPath);
                $name = basename($trashPath);

                $this->fileRepository->deleteFiles($dir, [$name]);
                unset($metadata[$key]);
                $deletedCount++;
            } catch (\Exception $e) {
                continue;
            }
        }

        $this->saveMetadata($server, $metadata);
        $this->cleanupEmptyTrashDirs($server);

        return $deletedCount;
    }

    private function cleanupEmptyTrashDirs(Server $server): void
    {
        try {
            $this->fileRepository->setServer($server);
            $this->recursiveCleanEmptyDirs(self::TRASH_DIR);
        } catch (\Exception $e) {
            // Ignore cleanup errors
        }
    }

    private function recursiveCleanEmptyDirs(string $path): bool
    {
        try {
            $contents = $this->fileRepository->getDirectory($path);
            
            // Filter out metadata file
            $contents = array_filter($contents, function($f) {
                $fileData = is_array($f) ? $f : (array)$f;
                return ($fileData['name'] ?? '') !== '.metadata.json';
            });

            if (empty($contents) && $path !== self::TRASH_DIR) {
                $dir = dirname($path);
                $name = basename($path);
                $this->fileRepository->deleteFiles($dir, [$name]);
                return true;
            }

            foreach ($contents as $item) {
                $fileData = is_array($item) ? $item : (array)$item;
                if (!($fileData['file'] ?? true)) {
                    $subPath = $path . '/' . $fileData['name'];
                    $this->recursiveCleanEmptyDirs($subPath);
                }
            }
        } catch (\Exception $e) {
            // Ignore
        }

        return false;
    }

    private function resolveDeletedTimestamp(array $meta): int
    {
        $timestamp = (int)($meta['timestamp'] ?? 0);
        if ($timestamp > 0) {
            return $timestamp;
        }

        if (!empty($meta['deletedAt'])) {
            try {
                return Carbon::parse($meta['deletedAt'])->getTimestamp();
            } catch (\Exception $e) {
                return 0;
            }
        }

        return 0;
    }

    private function pruneOldestTrashFiles(Server $server, array $metadata, int $spaceNeeded): void
    {
        uasort($metadata, function ($a, $b) {
            return ($a['timestamp'] ?? 0) - ($b['timestamp'] ?? 0);
        });

        $toRemove = min($spaceNeeded + 10, (int)(count($metadata) / 2));
        $removed = 0;

        foreach ($metadata as $key => $meta) {
            if ($removed >= $toRemove) {
                break;
            }

            try {
                $trashPath = $meta['trashPath'] ?? '';
                if ($trashPath === '' || !$this->isWithinTrashDir($trashPath)) {
                    unset($metadata[$key]);
                    continue;
                }
                $dir = dirname($trashPath);
                $name = basename($trashPath);
                
                $this->fileRepository->deleteFiles($dir, [$name]);
                unset($metadata[$key]);
                $removed++;
            } catch (\Exception $e) {
                continue;
            }
        }

        $this->saveMetadata($server, $metadata);
    }

    private function ensureTrashDirExists(Server $server): void
    {
        try {
            $this->fileRepository->setServer($server);
            $entries = $this->fileRepository->getDirectory('/');
            foreach ($entries as $entry) {
                $fileData = is_array($entry) ? $entry : (array)$entry;
                if (($fileData['name'] ?? '') === '.trash-bin' && !($fileData['file'] ?? true)) {
                    return;
                }
            }
        } catch (\Exception $e) {
        }

        try {
            $this->fileRepository->createDirectory('.trash-bin', '/');
        } catch (\Exception $e) {
        }
    }

    private function ensureDirectoryExists(string $path): void
    {
        $path = $this->normalizePath($path);
        if ($path === '/') {
            return;
        }

        $parts = array_filter(explode('/', $path));
        $currentPath = '/';

        foreach ($parts as $part) {
            $nextPath = $currentPath === '/' ? "/{$part}" : "{$currentPath}/{$part}";
            $exists = false;
            $isDir = false;

            try {
                $entries = $this->fileRepository->getDirectory($currentPath);
                foreach ($entries as $entry) {
                    $fileData = is_array($entry) ? $entry : (array)$entry;
                    if (($fileData['name'] ?? '') === $part) {
                        $exists = true;
                        $isDir = !($fileData['file'] ?? true);
                        break;
                    }
                }
            } catch (\Exception $e) {
            }

            if ($exists) {
                if (!$isDir) {
                    return;
                }
                $currentPath = $nextPath;
                continue;
            }

            try {
                $this->fileRepository->createDirectory($part, $currentPath);
            } catch (\Exception $e) {
            }

            $currentPath = $nextPath;
        }
    }

    private function getMetadata(Server $server): array
    {
        try {
            $content = $this->fileRepository->setServer($server)->getContent(self::METADATA_FILE);
            $decoded = json_decode($content, true);
            
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
                return [];
            }
            
            return $decoded;
        } catch (\Exception $e) {
            return [];
        }
    }

    private function saveMetadata(Server $server, array $metadata): void
    {
        try {
            $content = json_encode($metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            
            if ($content === false) {
                return;
            }
            
            $this->fileRepository->setServer($server)->putContent(self::METADATA_FILE, $content);
        } catch (\Exception $e) {
        }
    }
}
