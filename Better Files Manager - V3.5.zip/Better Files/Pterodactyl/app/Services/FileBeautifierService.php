<?php

namespace Pterodactyl\Services;

use Exception;

class FileBeautifierService
{
    
    public function beautify(string $content, string $filePath): string
    {
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        return match ($extension) {
            'json' => $this->finalizeBeautified($content, $this->beautifyJson($content)),
            'xml' => $this->finalizeBeautified($content, $this->beautifyXml($content)),
            'html', 'htm' => $this->finalizeBeautified($content, $this->beautifyHtml($content)),
            'yaml', 'yml' => $this->finalizeBeautified($content, $this->beautifyYaml($content)),
            'css' => $this->finalizeBeautified($content, $this->beautifyCss($content)),
            'js', 'javascript' => $this->finalizeBeautified($content, $this->beautifyJavaScript($content)),
            'sql' => $this->finalizeBeautified($content, $this->beautifySql($content)),
            default => throw new Exception("Unsupported file type: {$extension}"),
        };
    }

    
    public function isSupported(string $filePath): bool
    {
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        return in_array($extension, ['json', 'xml', 'html', 'htm', 'yaml', 'yml', 'css', 'js', 'javascript', 'sql']);
    }

    private function finalizeBeautified(string $original, string $beautified): string
    {
        if (rtrim($original, "\r\n") === rtrim($beautified, "\r\n")) {
            return $original;
        }

        return $beautified;
    }

    
    private function beautifyJson(string $content): string
    {
        $decoded = json_decode($content, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON: ' . json_last_error_msg());
        }

        return json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    
    private function beautifyXml(string $content): string
    {
        $dom = new \DOMDocument('1.0');
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;

        $previousValue = libxml_use_internal_errors(true);
        
        if (!$dom->loadXML($content)) {
            libxml_use_internal_errors($previousValue);
            throw new Exception('Invalid XML content');
        }

        libxml_use_internal_errors($previousValue);

        return $dom->saveXML();
    }

    
    private function beautifyHtml(string $content): string
    {
        $dom = new \DOMDocument('1.0');
        $dom->preserveWhiteSpace = false;
        $dom->formatOutput = true;
        $previousValue = libxml_use_internal_errors(true);
        
        if (!$dom->loadHTML($content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD)) {
            libxml_use_internal_errors($previousValue);
            throw new Exception('Invalid HTML content');
        }

        libxml_use_internal_errors($previousValue);

        $output = $dom->saveHTML();
        $output = preg_replace('/^<!DOCTYPE[^>]*>\s*/i', '', $output);
        
        return trim($output);
    }

    
    private function beautifyYaml(string $content): string
    {
        $content = preg_replace_callback('/^(\\t+)/m', function ($matches) {
            return str_repeat('  ', strlen($matches[1]));
        }, $content);
        $trimmed = trim($content);
        if ($trimmed === '') {
            return $content;
        }

        $content = preg_replace('/^(\\s*[^#\\s][^:\\n]*:)([^\\s#])/m', '$1 $2', $content);

        if (class_exists(\Symfony\Component\Yaml\Yaml::class)) {
            $flags = \Symfony\Component\Yaml\Yaml::PARSE_OBJECT_FOR_MAP;
            try {
                $data = \Symfony\Component\Yaml\Yaml::parse($content, $flags);
            } catch (\Symfony\Component\Yaml\Exception\ParseException $e) {
                $line = method_exists($e, 'getParsedLine') ? $e->getParsedLine() : null;
                $prefix = $line ? "Invalid YAML content (line {$line}): " : 'Invalid YAML content: ';
                throw new Exception($prefix . $e->getMessage());
            }
            if ($data === null && !in_array(strtolower($trimmed), ['null', '~'], true)) {
                throw new Exception('Invalid YAML content: parser returned null.');
            }

            $output = rtrim(\Symfony\Component\Yaml\Yaml::dump(
                $data,
                10,
                2,
                \Symfony\Component\Yaml\Yaml::DUMP_MULTI_LINE_LITERAL_BLOCK
            ));
            $normalizedOutput = strtolower(trim($output));
            if (!in_array(strtolower($trimmed), ['null', '~'], true) && in_array($normalizedOutput, ['null', '~', ''], true)) {
                return $content;
            }

            return $output . "\n";
        }

        if (function_exists('yaml_parse') && function_exists('yaml_emit')) {
            $data = @yaml_parse($content);
            if ($data === false && $trimmed !== 'false') {
                $errorMessage = function_exists('yaml_last_error_msg') ? yaml_last_error_msg() : null;
                if ($errorMessage) {
                    throw new Exception('Invalid YAML content: ' . $errorMessage);
                }
                if (function_exists('yaml_last_error')) {
                    throw new Exception('Invalid YAML content: yaml_parse failed with code ' . yaml_last_error());
                }
                throw new Exception('Invalid YAML content');
            }
            if ($data === null && !in_array(strtolower($trimmed), ['null', '~'], true)) {
                throw new Exception('Invalid YAML content: parser returned null.');
            }

            $output = yaml_emit($data, YAML_UTF8_ENCODING, YAML_LN_BREAK);
            $output = preg_replace('/^---\\s*\\n?/', '', $output ?? '');
            $output = preg_replace('/\\n\\.\\.\\.\\s*$/', '', $output ?? '');
            $normalizedOutput = strtolower(trim($output ?? ''));
            if (!in_array(strtolower($trimmed), ['null', '~'], true) && in_array($normalizedOutput, ['null', '~', ''], true)) {
                return $content;
            }

            return rtrim($output) . "\n";
        }

        throw new Exception('YAML formatter unavailable. Install symfony/yaml or enable the yaml extension.');
    }

    
    private function beautifyCss(string $content): string
    {
        $content = preg_replace('/\s+/', ' ', $content);
        $content = str_replace('{', "{\n    ", $content);
        $content = str_replace('}', "\n}\n\n", $content);
        $content = str_replace(';', ";\n    ", $content);
        $content = preg_replace('/\n\s*\n/', "\n", $content);
        
        return trim($content);
    }

    
    private function beautifyJavaScript(string $content): string
    {
        $content = preg_replace('/\s+/', ' ', $content);
        $content = str_replace('{', "{\n    ", $content);
        $content = str_replace('}', "\n}\n", $content);
        $content = str_replace(';', ";\n", $content);
        $content = preg_replace('/\n\s*\n/', "\n", $content);
        
        return trim($content);
    }

    
    private function beautifySql(string $content): string
    {
        $keywords = [
            'SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT JOIN', 'RIGHT JOIN', 
            'INNER JOIN', 'OUTER JOIN', 'ON', 'AND', 'OR', 'ORDER BY', 
            'GROUP BY', 'HAVING', 'LIMIT', 'INSERT INTO', 'VALUES', 
            'UPDATE', 'SET', 'DELETE FROM', 'CREATE TABLE', 'ALTER TABLE',
            'DROP TABLE', 'TRUNCATE TABLE'
        ];

        foreach ($keywords as $keyword) {
            $content = preg_replace('/\b' . $keyword . '\b/i', "\n" . $keyword, $content);
        }

        $content = preg_replace('/\n\s*\n/', "\n", $content);
        $content = preg_replace('/\s+/', ' ', $content);
        
        return trim($content);
    }
}
