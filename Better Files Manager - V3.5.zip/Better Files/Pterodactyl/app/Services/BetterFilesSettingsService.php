<?php

namespace Pterodactyl\Services;

use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class BetterFilesSettingsService
{
    public const KEY_TRASH_CLEANUP_ENABLED = 'betterfiles:trash_cleanup_enabled';
    public const KEY_TRASH_CLEANUP_ALLOW_OVERRIDE = 'betterfiles:trash_cleanup_allow_override';
    public const KEY_TRASH_CLEANUP_DEFAULT_DAYS = 'betterfiles:trash_cleanup_default_days';
    public const KEY_TRASH_CLEANUP_DEFAULT_UNIT = 'betterfiles:trash_cleanup_default_unit';
    public const KEY_PULL_URL_MAX_SIZE_MB = 'betterfiles:pull_url_max_size_mb';
    public const KEY_SEARCH_CONTENT_ENABLED = 'betterfiles:search_content_enabled';
    public const KEY_GIT_ENABLED = 'betterfiles:git_enabled';

    public function __construct(private SettingsRepositoryInterface $settings)
    {
    }

    public function getGlobalSettings(): array
    {
        return [
            'enabled' => $this->getBool(self::KEY_TRASH_CLEANUP_ENABLED, false),
            'allow_override' => $this->getBool(self::KEY_TRASH_CLEANUP_ALLOW_OVERRIDE, true),
            'default_days' => $this->getInt(self::KEY_TRASH_CLEANUP_DEFAULT_DAYS, 30, 1, null),
            'default_unit' => $this->getEnum(self::KEY_TRASH_CLEANUP_DEFAULT_UNIT, 'days', ['days', 'hours']),
            'pull_url_max_size_mb' => $this->getInt(self::KEY_PULL_URL_MAX_SIZE_MB, 100, 1, null),
            'content_search_enabled' => $this->getBool(self::KEY_SEARCH_CONTENT_ENABLED, false),
            'git_enabled' => $this->getBool(self::KEY_GIT_ENABLED, false),
        ];
    }

    public function updateGlobalSettings(array $data): array
    {
        $enabled = filter_var($data[self::KEY_TRASH_CLEANUP_ENABLED] ?? $data['betterfiles:trash_cleanup_enabled'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $allowOverride = filter_var($data[self::KEY_TRASH_CLEANUP_ALLOW_OVERRIDE] ?? $data['betterfiles:trash_cleanup_allow_override'] ?? true, FILTER_VALIDATE_BOOLEAN);
        $defaultDays = (int)($data[self::KEY_TRASH_CLEANUP_DEFAULT_DAYS] ?? $data['betterfiles:trash_cleanup_default_days'] ?? 30);
        $defaultDays = max(1, $defaultDays);
        $defaultUnit = (string)($data[self::KEY_TRASH_CLEANUP_DEFAULT_UNIT] ?? $data['betterfiles:trash_cleanup_default_unit'] ?? 'days');
        $defaultUnit = in_array($defaultUnit, ['days', 'hours'], true) ? $defaultUnit : 'days';
        $pullUrlMaxSizeMb = (int)($data[self::KEY_PULL_URL_MAX_SIZE_MB] ?? $data['betterfiles:pull_url_max_size_mb'] ?? 100);
        $pullUrlMaxSizeMb = max(1, $pullUrlMaxSizeMb);
        $contentSearchEnabled = filter_var($data[self::KEY_SEARCH_CONTENT_ENABLED] ?? $data['betterfiles:search_content_enabled'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $gitEnabled = filter_var($data[self::KEY_GIT_ENABLED] ?? $data['betterfiles:git_enabled'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $this->settings->set(self::KEY_TRASH_CLEANUP_ENABLED, $enabled ? '1' : '0');
        $this->settings->set(self::KEY_TRASH_CLEANUP_ALLOW_OVERRIDE, $allowOverride ? '1' : '0');
        $this->settings->set(self::KEY_TRASH_CLEANUP_DEFAULT_DAYS, (string)$defaultDays);
        $this->settings->set(self::KEY_TRASH_CLEANUP_DEFAULT_UNIT, $defaultUnit);
        $this->settings->set(self::KEY_PULL_URL_MAX_SIZE_MB, (string)$pullUrlMaxSizeMb);
        $this->settings->set(self::KEY_SEARCH_CONTENT_ENABLED, $contentSearchEnabled ? '1' : '0');
        $this->settings->set(self::KEY_GIT_ENABLED, $gitEnabled ? '1' : '0');

        return [
            'enabled' => $enabled,
            'allow_override' => $allowOverride,
            'default_days' => $defaultDays,
            'default_unit' => $defaultUnit,
            'pull_url_max_size_mb' => $pullUrlMaxSizeMb,
            'content_search_enabled' => $contentSearchEnabled,
            'git_enabled' => $gitEnabled,
        ];
    }

    private function getBool(string $key, bool $default): bool
    {
        $value = $this->settings->get($key, $default ? '1' : '0');
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    private function getInt(string $key, int $default, int $min = 1, ?int $max = 60): int
    {
        $value = $this->settings->get($key, (string)$default);
        $int = (int)$value;
        if ($max === null) {
            return max($min, $int);
        }
        return max($min, min($max, $int));
    }

    private function getEnum(string $key, string $default, array $allowed): string
    {
        $value = (string)$this->settings->get($key, $default);
        return in_array($value, $allowed, true) ? $value : $default;
    }

}
