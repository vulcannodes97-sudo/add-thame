<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Symfony\Component\Process\Process;

class BetterFilesInstaller extends Command
{
    protected $signature = 'c:better-files:install {--panel-path= : Override the panel path (defaults to base_path())}';

    protected $description = 'Applies Better Files routes, API wiring, cache clears, ownership fixes, and front-end build.';

    /**
     * @var array<int, array{task: string, status: string, note: string}>
     */
    private array $summary = [];

    public function handle(): int
    {
        $panelPath = $this->option('panel-path') ?: base_path();
        $panelPath = rtrim($panelPath, '/');

        if (!is_dir($panelPath)) {
            $this->error("Panel path {$panelPath} does not exist.");
            return Command::FAILURE;
        }

        $this->info('Running Better Files installer tasks...');

        try {
            $this->updateFrontendRoutes($panelPath);
            $this->updateApiClientRoutes($panelPath);
            $this->updateAdminRoutes($panelPath);
            $this->updateAdminSettingsNav($panelPath);
            $this->updateScheduler($panelPath);
            $this->runMigrations($panelPath);
            $this->call('optimize:clear');
            $this->logStatus('artisan optimize:clear', 'DONE', 'artisan optimize:clear executed');
            $this->call('optimize');
            $this->logStatus('artisan optimize', 'DONE', 'artisan optimize executed');
            $this->runOwnershipFix($panelPath);
            $this->maybeInstallFrontendDependencies($panelPath);
            $this->displaySummary();
        } catch (\Throwable $th) {
            $this->error('Installation failed: ' . $th->getMessage());
            $this->displaySummary();
            return Command::FAILURE;
        }

        $this->info('Better Files installer tasks completed.');
        return Command::SUCCESS;
    }

    private function updateFrontendRoutes(string $panelPath): void
    {
        $path = "{$panelPath}/resources/scripts/routers/routes.ts";
        if (!File::exists($path)) {
            $this->warn("Frontend routes missing at {$path}, skipping.");
            $this->logStatus('Frontend routes', 'SKIPPED', 'routes.ts missing');
            return;
        }

        $contents = File::get($path);
        $importLine = "import BetterFileManagerContainer from '@/components/server/betterfiles/BetterFileManagerContainer';";
        $importAnchor = "import ServerActivityLogContainer from '@/components/server/ServerActivityLogContainer';";
        $changed = false;

        if (!str_contains($contents, $importLine)) {
            if (!str_contains($contents, $importAnchor)) {
                throw new \RuntimeException("Unable to locate {$importAnchor} in routes.ts to insert Better Files import.");
            }

            $contents = str_replace(
                $importAnchor,
                $importAnchor . PHP_EOL . $importLine,
                $contents
            );
            $this->line(' - Added BetterFileManagerContainer import');
            $this->logStatus('Frontend import', 'ADDED', 'BetterFileManagerContainer import inserted');
            $changed = true;
        } else {
            $this->line(' - BetterFileManagerContainer import already present');
            $this->logStatus('Frontend import', 'EXISTS', 'BetterFileManagerContainer already referenced');
        }

        if (!str_contains($contents, 'component: BetterFileManagerContainer')) {
            $filesPattern = "/\\{[^{]*path:\\s*'\\/files'[\\s\\S]*?component:\\s*FileManagerContainer,[\\s\\S]*?\\},/m";
            if (!preg_match($filesPattern, $contents, $match)) {
                throw new \RuntimeException('Could not find the default files route block in routes.ts.');
            }

            $replacement = <<<'ROUTE'
        {
            path: '/files',
            permission: 'file.*',
            name: 'Files',
            component: BetterFileManagerContainer,
        },
ROUTE;

            $contents = preg_replace($filesPattern, $replacement, $contents, 1, $count);
            if ($count === 0) {
                throw new \RuntimeException('Failed to replace the Files route block.');
            }

            $this->line(' - Replaced Files route with Better Files route');
            $this->logStatus('Frontend route', 'ADDED', 'Better Files route inserted');
            $changed = true;
        } else {
            $this->line(' - Better Files route already configured');
            $this->logStatus('Frontend route', 'EXISTS', 'Better Files route already present');
        }

        if ($changed) {
            File::put($path, $contents);
        }
    }

    private function updateApiClientRoutes(string $panelPath): void
    {
        $path = "{$panelPath}/routes/api-client.php";
        if (!File::exists($path)) {
            $this->warn("api-client.php missing at {$path}, skipping API update.");
            $this->logStatus('API routes', 'SKIPPED', 'api-client.php missing');
            return;
        }

        $includeLine = "require __DIR__ . \"/api-better-files.php\";";
        $contents = File::get($path);

        if (str_contains($contents, $includeLine)) {
            $this->line(' - Better Files API include already present');
            $this->logStatus('API routes', 'EXISTS', 'api-better-files include already added');
            return;
        }

        $filesPattern = "/Route::group\\(\\s*\\['prefix'\\s*=>\\s*'\\/files'\\][\\s\\S]*?\\n\\s*\\}\\);/m";
        if (!preg_match($filesPattern, $contents, $match)) {
            throw new \RuntimeException('Could not locate the /files route group in api-client.php.');
        }

        $replacement = rtrim($match[0]) . PHP_EOL . '    ' . $includeLine;
        $updated = preg_replace($filesPattern, $replacement, $contents, 1, $count);
        if ($count === 0) {
            throw new \RuntimeException('Failed to append api-better-files include.');
        }

        File::put($path, rtrim($updated) . PHP_EOL);
        $this->line(' - Added Better Files API include to api-client.php');
        $this->logStatus('API routes', 'ADDED', 'api-better-files include inserted');
    }

    private function updateAdminRoutes(string $panelPath): void
    {
        $path = "{$panelPath}/routes/admin.php";
        if (!File::exists($path)) {
            $this->warn("admin.php missing at {$path}, skipping admin routes update.");
            $this->logStatus('Admin routes', 'SKIPPED', 'admin.php missing');
            return;
        }

        $contents = File::get($path);
        if (str_contains($contents, 'admin.settings.betterfiles')) {
            $this->line(' - Better Files admin routes already present');
            $this->logStatus('Admin routes', 'EXISTS', 'admin.settings.betterfiles already configured');
            return;
        }

        $pattern = "/Route::group\\(\\s*\\[[^\\]]*'prefix'\\s*=>\\s*'settings'[^\\]]*\\].*?\\n\\s*\\}\\);/s";
        if (!preg_match($pattern, $contents, $match)) {
            $this->warn(' - Unable to locate settings route group in admin.php');
            $this->logStatus('Admin routes', 'SKIPPED', 'settings route group not found');
            return;
        }

        $insert = PHP_EOL .
            "    Route::get('/better-files', [Admin\\Settings\\BetterFilesController::class, 'index'])->name('admin.settings.betterfiles');" . PHP_EOL .
            "    Route::patch('/better-files', [Admin\\Settings\\BetterFilesController::class, 'update']);";

        $block = $match[0];
        $insertAt = strrpos($block, '});');
        if ($insertAt === false) {
            $this->warn(' - Unable to locate the end of the settings route group');
            $this->logStatus('Admin routes', 'SKIPPED', 'settings route group end not found');
            return;
        }

        $updatedBlock = substr($block, 0, $insertAt) . $insert . PHP_EOL . substr($block, $insertAt);
        $updated = preg_replace($pattern, $updatedBlock, $contents, 1, $count);
        if ($count === 0) {
            $this->warn(' - Failed to append Better Files settings routes');
            $this->logStatus('Admin routes', 'SKIPPED', 'unable to append Better Files routes');
            return;
        }

        File::put($path, $updated);
        $this->line(' - Added Better Files admin settings routes');
        $this->logStatus('Admin routes', 'ADDED', 'Better Files admin settings routes inserted');
    }

    private function updateAdminSettingsNav(string $panelPath): void
    {
        $path = "{$panelPath}/resources/views/partials/admin/settings/nav.blade.php";
        if (!File::exists($path)) {
            $this->warn("Admin settings nav missing at {$path}, skipping nav update.");
            $this->logStatus('Admin nav', 'SKIPPED', 'admin settings nav missing');
            return;
        }

        $contents = File::get($path);
        if (str_contains($contents, 'admin.settings.betterfiles')) {
            $this->line(' - Better Files settings tab already present');
            $this->logStatus('Admin nav', 'EXISTS', 'Better Files settings tab already present');
            return;
        }

        $anchor = "<li @if(\$activeTab === 'advanced')class=\"active\"@endif><a href=\"{{ route('admin.settings.advanced') }}\">Advanced</a></li>";
        if (!str_contains($contents, $anchor)) {
            $this->warn(' - Unable to locate Advanced tab in settings nav');
            $this->logStatus('Admin nav', 'SKIPPED', 'settings nav anchor not found');
            return;
        }

        $insert = $anchor . PHP_EOL .
            "                    <li @if(\$activeTab === 'better-files')class=\"active\"@endif><a href=\"{{ route('admin.settings.betterfiles') }}\">Better Files</a></li>";

        $contents = str_replace($anchor, $insert, $contents);
        File::put($path, $contents);
        $this->line(' - Added Better Files tab to admin settings nav');
        $this->logStatus('Admin nav', 'ADDED', 'Better Files settings tab inserted');
    }

    private function updateScheduler(string $panelPath): void
    {
        $path = "{$panelPath}/app/Console/Kernel.php";
        if (!File::exists($path)) {
            $this->warn("Kernel.php missing at {$path}, skipping scheduler update.");
            $this->logStatus('Scheduler', 'SKIPPED', 'Kernel.php missing');
            return;
        }

        $contents = File::get($path);
        $changed = false;
        $missedAnchor = false;

        $scheduleLine = '        $schedule->command(\\Pterodactyl\\Console\\Commands\\BetterFilesTrashCleanupCommand::class)->daily();';
        $legacyScheduleLine = '        $schedule->command(BetterFilesTrashCleanupCommand::class)->daily();';
        if (!str_contains($contents, $scheduleLine) && !str_contains($contents, $legacyScheduleLine)) {
            $scheduleAnchor = '        $schedule->command(CleanServiceBackupFilesCommand::class)->daily();';
            if (str_contains($contents, $scheduleAnchor)) {
                $contents = str_replace($scheduleAnchor, $scheduleAnchor . PHP_EOL . $scheduleLine, $contents);
                $changed = true;
            } else {
                $missedAnchor = true;
            }
        }

        if ($changed) {
            File::put($path, $contents);
            $this->line(' - Added Better Files trash cleanup schedule');
            $this->logStatus('Scheduler', 'ADDED', 'Better Files trash cleanup scheduled');
        } elseif ($missedAnchor) {
            $this->warn(' - Unable to locate Kernel.php anchors for Better Files schedule');
            $this->logStatus('Scheduler', 'SKIPPED', 'Kernel.php anchors not found');
        } else {
            $this->line(' - Better Files trash cleanup schedule already present');
            $this->logStatus('Scheduler', 'EXISTS', 'Better Files trash cleanup schedule already configured');
        }
    }

    private function runMigrations(string $panelPath): void
    {
        $this->runShellCommand('cd ' . escapeshellarg($panelPath) . ' && php artisan migrate --force', $panelPath);
        $this->logStatus('Migrations', 'DONE', 'php artisan migrate --force executed');
    }


    private function runOwnershipFix(string $panelPath): void
    {
        $command = 'cd ' . escapeshellarg($panelPath) . ' && chown -R www-data:www-data ./*';
        $this->runShellCommand($command, $panelPath);
        $this->line(' - Ownership reset to www-data:www-data');
        $this->logStatus('Ownership', 'DONE', 'chown -R www-data:www-data executed');
    }

    private function maybeInstallFrontendDependencies(string $panelPath): void
    {
        if (!$this->confirm('Have you already installed front-end dependencies with "yarn install"?', true)) {
            $this->line(' - Skipping react-icons install and build');
            $this->logStatus('Frontend build', 'SKIPPED', 'user declined yarn steps');
            return;
        }

        $this->runShellCommand('cd ' . escapeshellarg($panelPath) . ' && yarn add react-icons@5.4.0 ace-builds', $panelPath);
        $this->logStatus('react-icons + ace-builds', 'DONE', 'yarn add react-icons@5.4.0 ace-builds executed');

        $buildCommand = 'cd ' . escapeshellarg($panelPath) . ' && NODE_OPTIONS=--openssl-legacy-provider yarn run build:production';
        $this->runShellCommand($buildCommand, $panelPath);
        $this->line(' - Production assets rebuilt');
        $this->logStatus('Frontend build', 'DONE', 'yarn run build:production executed with legacy OpenSSL flag');
    }

    private function runShellCommand(string $command, string $panelPath, int $timeout = 600): void
    {
        $process = Process::fromShellCommandline($command, $panelPath, null, null, $timeout);
        $process->run(function ($type, $buffer) {
            $this->output->write($buffer);
        });

        if (!$process->isSuccessful()) {
            throw new \RuntimeException(sprintf(
                'Command "%s" failed: %s',
                $command,
                $process->getErrorOutput() ?: $process->getOutput()
            ));
        }
    }

    private function logStatus(string $task, string $status, string $note): void
    {
        $this->summary[] = [
            'task' => $task,
            'status' => $status,
            'note' => $note,
        ];
    }

    private function displaySummary(): void
    {
        if (!$this->summary) {
            return;
        }

        $this->line(PHP_EOL . 'Summary:' . PHP_EOL);
        foreach ($this->summary as $entry) {
            $prefix = match ($entry['status']) {
                'DONE', 'ADDED' => '[+]',
                'EXISTS' => '[=]',
                'SKIPPED' => '[-]',
                default => '[ ]',
            };

            $this->line(sprintf(' %s %s: %s', $prefix, $entry['task'], $entry['note']));
        }
        $this->line('');
    }
}
