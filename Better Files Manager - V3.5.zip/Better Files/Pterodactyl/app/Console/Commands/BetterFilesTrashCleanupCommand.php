<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\BetterFilesSettingsService;
use Pterodactyl\Services\FileTrashService;

class BetterFilesTrashCleanupCommand extends Command
{
    protected $signature = 'better-files:trash-cleanup {--dry-run : Report what would be deleted without removing files}';

    protected $description = 'Deletes trash bin items older than the configured retention period.';

    public function handle(
        BetterFilesSettingsService $settingsService,
        FileTrashService $trashService
    ): int {
        $global = $settingsService->getGlobalSettings();
        if (!$global['enabled']) {
            $this->info('Better Files trash cleanup is disabled.');
            return Command::SUCCESS;
        }

        $allowOverride = $global['allow_override'];
        $defaultDays = (int)$global['default_days'];
        $defaultUnit = (string)($global['default_unit'] ?? 'days');
        $dryRun = (bool)$this->option('dry-run');
        $totalDeleted = 0;
        $serverCount = 0;

        Server::query()
            ->with('node')
            ->select(['id', 'uuid', 'name', 'node_id', 'bf_trash_cleanup_enabled', 'bf_trash_retention_days', 'bf_trash_retention_unit'])
            ->chunkById(50, function ($servers) use ($trashService, $allowOverride, $defaultDays, $defaultUnit, $dryRun, &$totalDeleted, &$serverCount) {
                foreach ($servers as $server) {
                    $serverCount++;
                    if (!$server->node) {
                        $this->warn("Skipping server {$server->id} ({$server->name}) - missing node.");
                        continue;
                    }
                    $enabled = $allowOverride ? (bool)$server->bf_trash_cleanup_enabled : true;
                    if (!$enabled) {
                        continue;
                    }

                    $retentionValue = $allowOverride ? (int)$server->bf_trash_retention_days : $defaultDays;
                    $retentionValue = max(1, $retentionValue);
                    $retentionUnit = $allowOverride ? (string)($server->bf_trash_retention_unit ?? $defaultUnit) : $defaultUnit;
                    $retentionUnit = $retentionUnit === 'hours' ? 'hours' : 'days';

                    if ($dryRun) {
                        $this->line("Would clean trash for server {$server->id} ({$server->name}).");
                        continue;
                    }

                    $deleted = $trashService->purgeExpiredTrash($server, $retentionValue, $retentionUnit);
                    $totalDeleted += $deleted;

                    if ($deleted > 0) {
                        $this->line("Cleaned {$deleted} trash item(s) for server {$server->id} ({$server->name}).");
                    }
                }
            });

        if ($dryRun) {
            $this->info("Dry run complete for {$serverCount} server(s).");
            return Command::SUCCESS;
        }

        $this->info("Trash cleanup complete. Deleted {$totalDeleted} item(s) across {$serverCount} server(s).");
        return Command::SUCCESS;
    }
}
