<?php

namespace Pterodactyl\Jobs;

use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\FileBeautifierService;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;

class BeautifyFileJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 300;
    public $tries = 2;

    public function __construct(
        public Server $server,
        public string $filePath,
        public int $userId
    ) {
        $this->onQueue('file-operations');
    }

    public function handle(
        FileBeautifierService $beautifier,
        DaemonFileRepository $fileRepository
    ): void {
        try {
            $content = $fileRepository
                ->setServer($this->server)
                ->getContent($this->filePath, config('pterodactyl.files.max_edit_size'));

            $beautified = $beautifier->beautify($content, $this->filePath);

            $fileRepository
                ->setServer($this->server)
                ->putContent($this->filePath, $beautified);

        } catch (Exception $e) {
            Log::error('File beautification failed', [
                'server_uuid' => $this->server->uuid,
                'file_path' => $this->filePath,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            throw $e;
        }
    }

    public function failed(Exception $exception): void
    {
        Log::error('File beautification job failed permanently', [
            'server_uuid' => $this->server->uuid,
            'file_path' => $this->filePath,
            'error' => $exception->getMessage(),
            'attempts' => $this->attempts(),
        ]);
    }
}
