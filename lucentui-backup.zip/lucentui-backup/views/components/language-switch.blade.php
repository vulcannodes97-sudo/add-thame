<div class="p-3">
    <label for="language-switch" class="block mb-2 text-sm font-bold">
        <x-ri-global-line class="inline-block w-5 h-5 mr-2 text-primary"/>
        Language
    </label>
    <x-select 
        id="language-switch" 
        wire:model.live="currentLocale" 
        :options="collect($locales)->map(fn($locale, $code) => [
            'value' => $code,
            'label' => $locale
        ])->values()->toArray()" 
        placeholder="Select a language" 
        class="w-full border-primary/30 rounded-md shadow-sm focus:ring-primary/80 focus:border-primary/80"
    />
</div>