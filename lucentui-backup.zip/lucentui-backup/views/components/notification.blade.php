<div x-data>
    <template x-for="(notification, index) in $store.notifications.notifications" :key="notification.id">
        <div x-show="notification.show" x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 translate-x-4" x-transition:enter-end="opacity-100 translate-x-0"
            x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100 translate-x-0"
            x-transition:leave-end="opacity-0 translate-x-4" @click="$store.notifications.removeNotification(notification.id)"
            :class="notification.type === 'success' ? 'bg-green-500' : 'bg-red-500'"
            class="fixed z-50 text-white px-6 py-4 rounded-lg shadow-lg mb-4 mt-20 flex items-center space-x-4"
            :style="'top: ' + (20 + index * 80) + 'px; right: 30px;'">
            <div>
                <svg x-show="notification.type === 'success'" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
                <svg x-show="notification.type !== 'success'" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </div>
            <div>
                <p x-text="notification.message" class="font-medium"></p>
            </div>
        </div>
    </template>
</div>
