<div class="p-3">
    <label for="currency-switch" class="block mb-2 text-sm font-bold">
        <x-ri-money-dollar-circle-line class="inline-block w-5 h-5 mr-2 text-primary"/>
        Currency
    </label>
    <x-select 
        id="currency-switch" 
        wire:model.live="currentCurrency" 
        :options="$this->currencies" 
        placeholder="Select a currency" 
        class="w-full border-primary/30 rounded-md shadow-sm focus:ring-primary/80 focus:border-primary/80"
    />
</div>