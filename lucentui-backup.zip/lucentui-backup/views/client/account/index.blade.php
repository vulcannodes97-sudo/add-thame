<div class="mt-18 mx-auto px-8 py-8 rounded-2xl animate-fade-in-up">
    <h1 class="text-3xl lg:text-4xl font-extrabold text-color-base mt-4 mb-8">
        {{ __('account.personal_details') }}
    </h1>

    <div class="bg-background-secondary/70 border border-neutral/50 rounded-xl p-6 shadow-lg mb-8">
        <div class="flex items-center mb-6">
            <div class="bg-primary/10 p-3 rounded-full flex-shrink-0 shadow-sm mr-4">
                <x-ri-user-line class="size-6 text-primary" />
            </div>
            <div>
                <h2 class="text-2xl font-bold text-color-base">{{ __('account.personal_details') }}</h2>
                <p class="text-sm text-color-muted">Update your profile information and preferences</p>
            </div>
        </div>

        <form wire:submit.prevent="submit"> 
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <x-form.input name="first_name" type="text" :label="__('general.input.first_name')"
                    :placeholder="__('general.input.first_name_placeholder')" wire:model="first_name" required dirty 
                    class="bg-background/50 border-neutral/50 focus:ring-primary focus:border-primary" />
                <x-form.input name="last_name" type="text" :label="__('general.input.last_name')"
                    :placeholder="__('general.input.last_name_placeholder')" wire:model="last_name" required dirty 
                    class="bg-background/50 border-neutral/50 focus:ring-primary focus:border-primary" />
                <x-form.input name="email" type="email" :label="__('general.input.email')"
                    :placeholder="__('general.input.email_placeholder')" required wire:model="email" dirty 
                    class="bg-background/50 border-neutral/50 focus:ring-primary focus:border-primary" />
            </div>

            @if($custom_properties || $properties)
                <div class="mt-8 pt-6 border-t border-neutral/50">
                    <div class="flex items-center mb-4">
                        <div class="bg-success/10 p-3 rounded-full flex-shrink-0 shadow-sm mr-4">
                            <x-ri-settings-line class="size-6 text-success" />
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-color-base">Additional Information</h3>
                            <p class="text-sm text-color-muted">Configure your custom properties and preferences</p>
                        </div>
                    </div>
                    <div class="bg-success/5 border border-neutral/50 rounded-xl p-4">
                        <x-form.properties :custom_properties="$custom_properties" :properties="$properties" dirty />
                    </div>
                </div>
            @endif

            <div class="flex flex-col sm:flex-row gap-3 justify-end mt-8">
                <x-button.primary 
                    type="submit" 
                    class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors duration-200"
                >
                    <span class="flex items-center space-x-2">
                        <x-ri-save-line class="size-4" />
                        <span class="align-middle">{{ __('general.update') }}</span>
                    </span>
                </x-button.primary>
            </div>
        </form>
    </div>

    <div class="bg-background-secondary/50 border border-neutral/50 rounded-xl p-6 shadow-lg animate-fade-in-up" style="animation-duration: 1.0s;">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="bg-primary/10 border border-neutral/50 rounded-xl p-4 text-center transition-all duration-300 hover:scale-[1.01] hover:shadow-lg hover:border-primary/50">
                <div class="flex items-center justify-center mb-2">
                    <x-ri-user-fill class="size-6 text-primary mr-2" />
                    <span class="text-2xl font-bold text-primary">
                        {{ ($first_name && $last_name && $email) ? '100' : (($first_name || $last_name) ? '75' : ($email ? '50' : '25')) }}%
                    </span>
                </div>
                <p class="text-sm font-medium text-primary">Profile Complete</p>
            </div>
            
            <div class="bg-success/10 border border-neutral/50 rounded-xl p-4 text-center transition-all duration-300 hover:scale-[1.01] hover:shadow-lg hover:border-success/50">
                <div class="flex items-center justify-center mb-2">
                    <x-ri-shield-check-line class="size-6 text-success mr-2" />
                    <span class="text-2xl font-bold text-success">Active</span>
                </div>
                <p class="text-sm font-medium text-success">Account Status</p>
            </div>
                
            <div class="bg-warning/10 border border-neutral/50 rounded-xl p-4 text-center transition-all duration-300 hover:scale-[1.01] hover:shadow-lg hover:border-warning/50">
                <div class="flex items-center justify-center mb-2">
                    <x-ri-time-line class="size-6 text-warning mr-2" />
                    <span class="text-2xl font-bold text-warning">Today</span>
                </div>
                <p class="text-sm font-medium text-warning">Last Updated</p>
            </div>
            
            <div class="bg-inactive/10 border border-neutral/50 rounded-xl p-4 text-center transition-all duration-300 hover:scale-[1.01] hover:shadow-lg hover:border-inactive/50">
                <div class="flex items-center justify-center mb-2">
                    <x-ri-shield-star-line class="size-6 text-inactive mr-2" />
                    <span class="text-2xl font-bold text-inactive">
                        {{ $email ? ($first_name && $last_name ? 'High' : 'Med') : 'Low' }}
                    </span>
                </div>
                <p class="text-sm font-medium text-inactive">Security Level</p>
            </div>
        </div>
    </div>

    <!-- Help & Tips Section -->
    <div class="bg-background-secondary/50 border border-neutral/50 rounded-xl p-6 shadow-lg mt-8 animate-fade-in-up" style="animation-duration: 1.2s;">
        <div class="flex items-center mb-6">
            <div class="bg-info/10 p-3 rounded-full flex-shrink-0 shadow-sm mr-4">
                <x-ri-information-line class="size-6 text-info" />
            </div>
            <div>
                <h3 class="text-xl font-bold text-color-base">Tips & Information</h3>
                <p class="text-sm text-color-muted">Keep your profile updated for better experience</p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="flex items-center p-4 bg-primary/5 border border-primary/20 rounded-xl">
                <div class="bg-primary/10 p-2 rounded-full mr-3 flex-shrink-0">
                    <x-ri-shield-check-line class="size-4 text-primary" />
                </div>
                <div>
                    <p class="text-sm font-medium text-primary">Keep Information Secure</p>
                    <p class="text-xs text-color-muted mt-1">Your data is encrypted and protected</p>
                </div>
            </div>
            
            <div class="flex items-center p-4 bg-success/5 border border-success/20 rounded-xl">
                <div class="bg-success/10 p-2 rounded-full mr-3 flex-shrink-0">
                    <x-ri-refresh-line class="size-4 text-success" />
                </div>
                <div>
                    <p class="text-sm font-medium text-success">Regular Updates</p>
                    <p class="text-xs text-color-muted mt-1">Keep your profile information current</p>
                </div>
            </div>
            
            <div class="flex items-center p-4 bg-warning/5 border border-warning/20 rounded-xl">
                <div class="bg-warning/10 p-2 rounded-full mr-3 flex-shrink-0">
                    <x-ri-customer-service-line class="size-4 text-warning" />
                </div>
                <div>
                    <p class="text-sm font-medium text-warning">Need Help?</p>
                    <p class="text-xs text-color-muted mt-1">Contact support for assistance</p>
                </div>
            </div>
        </div>
    </div>
</div>