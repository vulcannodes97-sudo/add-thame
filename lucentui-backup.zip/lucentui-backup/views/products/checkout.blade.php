<div class="mt-18 container mx-auto px-8 py-8 rounded-2xl">
    <div class="grid md:grid-cols-4 gap-8 lg:gap-12 items-start">
        <div class="flex flex-col gap-6 w-full col-span-3">

            <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden">
                <div class="p-6 lg:p-8">
                    <div class="flex items-start justify-between mb-6">
                        <div class="flex items-center gap-2">
                            <div class="size-2 bg-green-500 rounded-full animate-pulse"></div>
                            <span class="text-xs font-medium text-green-600 uppercase tracking-wide">Available</span>
                        </div>
                    </div>

                    <div class="flex flex-col sm:flex-row items-center gap-6">
                        @if ($product->image)
                            <div class="flex-shrink-0 relative overflow-hidden rounded-xl w-32 h-32 sm:w-36 sm:h-36 bg-gradient-to-br from-primary/10 to-primary/5 p-4">
                                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" class="w-full h-full object-contain object-center">
                            </div>
                        @endif
                        <div class="flex-grow text-center sm:text-left">
                            <h1 class="text-3xl lg:text-4xl font-bold text-color-base mb-3 leading-tight">
                                {{ $product->name }}
                            </h1>
                            <div>
                                <article class="prose dark:prose-invert text-color-muted text-sm leading-relaxed">
                                    {!! $product->description !!}
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            @if ($product->availablePlans()->count() > 1)
                <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden animate-fade-in-up" style="animation-delay: 0.1s;">
                    <div class="p-6 lg:p-8">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="bg-primary/10 text-primary p-3 rounded-full shadow-md">
                                <x-ri-price-tag-3-fill class="size-6" />
                            </div>
                            <div>
                                <h2 class="text-xl font-bold text-color-base">
                                    {{ __('Select Your Plan') }}
                                </h2>
                                <p class="text-color-muted text-sm">Choose the perfect plan for your needs</p>
                            </div>
                        </div>

                        <div class="w-full">
                            <label for="plan_id" class="block text-sm font-medium text-color-base mb-2">
                                {{ __('Choose a plan') }}
                            </label>
                            <select wire:model.live="plan_id"
                                id="plan_id"
                                name="plan_id"
                                class="w-full text-color-base bg-background-secondary border border-neutral/50 focus:border-primary focus:ring-primary focus:ring-2 focus:ring-primary/20 rounded-xl px-4 py-3 appearance-none [&>option]:bg-background-secondary [&>option]:text-color-base dark:[&>option]:bg-gray-800 dark:[&>option]:text-gray-100">
                                @foreach ($product->availablePlans() as $availablePlan)
                                    <option value="{{ $availablePlan->id }}">
                                        {{ $availablePlan->name }} - {{ $availablePlan->price()->formatted->price }}
                                        @if ($availablePlan->price()->has_setup_fee)
                                            + {{ $availablePlan->price()->formatted->setup_fee }} {{ __('product.setup_fee') }}
                                        @endif
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
            @endif

            @if($product->configOptions->count() > 0 || count($this->getCheckoutConfig()) > 0)
                <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden animate-fade-in-up" style="animation-delay: 0.2s;">
                    <div class="p-6 lg:p-8">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="bg-primary/10 text-primary p-3 rounded-full shadow-md">
                                <x-ri-settings-3-fill class="size-6" />
                            </div>
                            <div>
                                <h2 class="text-xl font-bold text-color-base">
                                    {{ __('Configure Your Product') }}
                                </h2>
                                <p class="text-color-muted text-sm">Customize options to fit your requirements</p>
                            </div>
                        </div>

                        <div class="space-y-6">
                            @foreach ($product->configOptions as $configOption)
                                @php
                                    $showPriceTag = $configOption->children->filter(fn ($value) => !$value->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit)->is_free)->count() > 0;
                                @endphp
                                
                                @if ($configOption->type == 'radio')
                                    {{-- Radio Component Kinda lazy tbh --}}
                                    <div class="flex flex-col relative w-full" x-data="{
                                        getIcon(value, optionText) {
                                            const searchText = (String(value) + ' ' + String(optionText)).toLowerCase();
                                            
                                            const iconMap = {
                                                // === OSes ===
                                                'ubuntu': 'https://cdn-icons-png.flaticon.com/512/888/888879.png',
                                                'debian': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/debian/debian-plain.svg',
                                                'windows': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg',
                                                'centos': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/centos/centos-plain.svg',
                                                'fedora': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/fedora/fedora-plain.svg',
                                                'rhel': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redhat/redhat-plain.svg',
                                                'red hat': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redhat/redhat-plain.svg',
                                                'rocky': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rockylinux/rockylinux-plain.svg',
                                                'alma': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rockylinux/rockylinux-plain.svg',
                                                'arch': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/archlinux/archlinux-plain.svg',
                                                'alpine': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/alpine/alpine-plain.svg',
                                                'linux': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg',
                                                
                                                // === Countries & Cities ===
                                                'usa': 'https://flagcdn.com/us.svg',
                                                'us': 'https://flagcdn.com/us.svg',
                                                'united states': 'https://flagcdn.com/us.svg',
                                                'atlanta': 'https://flagcdn.com/us.svg',
                                                'texas': 'https://flagcdn.com/us.svg',
                                                'dallas': 'https://flagcdn.com/us.svg',
                                                'miami': 'https://flagcdn.com/us.svg',
                                                'new york': 'https://flagcdn.com/us.svg',
                                                'chicago': 'https://flagcdn.com/us.svg',
                                                'los angeles': 'https://flagcdn.com/us.svg',
                                                'seattle': 'https://flagcdn.com/us.svg',
                                                'silicon valley': 'https://flagcdn.com/us.svg',
                                                'canada': 'https://flagcdn.com/ca.svg',
                                                'toronto': 'https://flagcdn.com/ca.svg',
                                                'montreal': 'https://flagcdn.com/ca.svg',
                                                'uk': 'https://flagcdn.com/gb.svg',
                                                'united kingdom': 'https://flagcdn.com/gb.svg',
                                                'london': 'https://flagcdn.com/gb.svg',
                                                'germany': 'https://flagcdn.com/de.svg',
                                                'frankfurt': 'https://flagcdn.com/de.svg',
                                                'berlin': 'https://flagcdn.com/de.svg',
                                                'france': 'https://flagcdn.com/fr.svg',
                                                'paris': 'https://flagcdn.com/fr.svg',
                                                'netherlands': 'https://flagcdn.com/nl.svg',
                                                'amsterdam': 'https://flagcdn.com/nl.svg',
                                                'poland': 'https://flagcdn.com/pl.svg',
                                                'warsaw': 'https://flagcdn.com/pl.svg',
                                                'serbia': 'https://flagcdn.com/rs.svg',
                                                'belgium': 'https://flagcdn.com/be.svg',
                                                'switzerland': 'https://flagcdn.com/ch.svg',
                                                'spain': 'https://flagcdn.com/es.svg',
                                                'madrid': 'https://flagcdn.com/es.svg',
                                                'italy': 'https://flagcdn.com/it.svg',
                                                'milan': 'https://flagcdn.com/it.svg',
                                                'singapore': 'https://flagcdn.com/sg.svg',
                                                'india': 'https://flagcdn.com/in.svg',
                                                'mumbai': 'https://flagcdn.com/in.svg',
                                                'bangalore': 'https://flagcdn.com/in.svg',
                                                'japan': 'https://flagcdn.com/jp.svg',
                                                'tokyo': 'https://flagcdn.com/jp.svg',
                                                'china': 'https://flagcdn.com/cn.svg',
                                                'hong kong': 'https://flagcdn.com/hk.svg',
                                                'australia': 'https://flagcdn.com/au.svg',
                                                'sydney': 'https://flagcdn.com/au.svg',
                                                'south korea': 'https://flagcdn.com/kr.svg',
                                                'seoul': 'https://flagcdn.com/kr.svg',
                                                'indonesia': 'https://flagcdn.com/id.svg',
                                                'jakarta': 'https://flagcdn.com/id.svg',
                                                'malaysia': 'https://flagcdn.com/my.svg',
                                                'thailand': 'https://flagcdn.com/th.svg',
                                                'vietnam': 'https://flagcdn.com/vn.svg',
                                                'dubai': 'https://flagcdn.com/ae.svg',
                                                'uae': 'https://flagcdn.com/ae.svg',
                                                'israel': 'https://flagcdn.com/il.svg',
                                                'saudi': 'https://flagcdn.com/sa.svg',
                                                'brazil': 'https://flagcdn.com/br.svg',
                                                'sao paulo': 'https://flagcdn.com/br.svg',
                                                'argentina': 'https://flagcdn.com/ar.svg',
                                                'chile': 'https://flagcdn.com/cl.svg',
                                                'south africa': 'https://flagcdn.com/za.svg',
                                                'kenya': 'https://flagcdn.com/ke.svg',
                                                'nigeria': 'https://flagcdn.com/ng.svg',

                                                // === Minecraft & Server Software ===
                                                'java': 'https://i.imgur.com/3kksGdD.png',
                                                'bedrock': 'https://i.imgur.com/3kksGdD.png',
                                                'forge': 'https://i.imgur.com/RBFsqRB.png',
                                                'fabric': 'https://i.imgur.com/ibMY1Sk.png',
                                                'quilt': 'https://quiltmc.org/assets/img/logo-square.png',
                                                'paper': 'https://assets.papermc.io/brand/papermc_logo.512.png',
                                                'purpur': 'https://avatars.githubusercontent.com/u/94729614?v=4',
                                                'spigot': 'https://static.spigotmc.org/img/spigot-og.png',
                                                'bukkit': 'https://www.vhv.rs/dpng/d/445-4454243_craft-bukkit-logo-spigot-logo-hd-png-download.png',
                                                'velocity': 'https://avatars.githubusercontent.com/u/41710604?s=200&v=4',
                                                'bungee': 'https://i.imgur.com/RJw4xR0.png',
                                                'waterfall': 'https://i.imgur.com/L1KbaWA.png',
                                                'sponge': 'https://static.wikia.nocookie.net/minecraft_gamepedia/images/f/f7/Sponge_JE3_BE3.png/revision/latest?cb=20240729213346',
                                                'mohist': 'https://mohistmc.com/mohistLogo.png',
                                                'thermos': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'tuinity': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'airplane': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'trident': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'pocketminemp': 'https://pmmp.io/assets/images/favicon.png',
                                                'cauldron': 'https://img.icons8.com/color/48/000000/minecraft.png'
                                            };
                                            
                                            for (const [pattern, iconUrl] of Object.entries(iconMap)) {
                                                if (searchText.includes(pattern)) {
                                                    return iconUrl;
                                                }
                                            }
                                            
                                            return null;
                                        }
                                    }">
                                        <label class="mb-4 text-xl font-bold text-color-base">
                                            {{ $configOption->name }}
                                            @if ($configOption->required)
                                                <span class="text-red-500 ml-1">*</span>
                                            @endif
                                        </label>

                                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                                            @foreach ($configOption->children as $child)
                                                @php
                                                    $inputId = 'config_' . $configOption->id . '_' . $child->id;
                                                    $isSelected = isset($configOptions[$configOption->id]) && $configOptions[$configOption->id] == $child->id;
                                                @endphp
                                                <label 
                                                    for="{{ $inputId }}"
                                                    class="relative flex flex-col items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 group {{ $isSelected ? 'border-primary bg-primary/5 shadow-lg shadow-primary/20' : 'border-neutral/50 hover:border-neutral hover:bg-background-tertiary/30' }}"
                                                >
                                                    <input 
                                                        type="radio" 
                                                        id="{{ $inputId }}"
                                                        name="configOptions.{{ $configOption->id }}"
                                                        value="{{ $child->id }}"
                                                        wire:model.live="configOptions.{{ $configOption->id }}"
                                                        {{ $isSelected ? 'checked' : '' }}
                                                        {{ $configOption->required ? 'required' : '' }}
                                                        class="sr-only peer"
                                                    />
                                                    
                                                    @if($isSelected)
                                                    <div class="absolute top-2 right-2 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                                        <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                    </div>
                                                    @endif
                                                    
                                                    <div class="w-12 h-12 mb-3 flex items-center justify-center">
                                                        <img 
                                                            :src="getIcon('{{ $child->id }}', '{{ $child->name }}')"
                                                            x-show="getIcon('{{ $child->id }}', '{{ $child->name }}')"
                                                            alt="{{ $child->name }}"
                                                            class="w-full h-full object-contain transition-transform duration-300 {{ $isSelected ? 'scale-110' : 'group-hover:scale-110' }}"
                                                        />
                                                        <div 
                                                            x-show="!getIcon('{{ $child->id }}', '{{ $child->name }}')"
                                                            class="w-10 h-10 rounded-full bg-gradient-to-br flex items-center justify-center {{ $isSelected ? 'from-primary/30 to-primary/10' : 'from-primary/20 to-primary/5' }}"
                                                        >
                                                            <span class="text-lg font-bold text-primary">
                                                                {{ strtoupper(substr($child->name, 0, 2)) }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <span class="text-sm font-medium text-center transition-colors {{ $isSelected ? 'text-primary' : 'text-color-base group-hover:text-primary' }}">
                                                        {{ $child->name }}
                                                        @if ($showPriceTag && $child->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit)->available)
                                                            <span class="block text-xs mt-1">
                                                                {{ $child->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit) }}
                                                            </span>
                                                        @endif
                                                    </span>
                                                </label>
                                            @endforeach
                                        </div>

                                        @if ($configOption->description ?? false)
                                            <p class="text-xs text-color-muted mt-3">{{ $configOption->description }}</p>
                                        @endif

                                        @error('configOptions.' . $configOption->id)
                                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                                        @enderror
                                    </div>
                                @else

                                    <div class="bg-background-tertiary/30 rounded-xl p-2">
                                        <x-form.configoption :config="$configOption" :name="'configOptions.' . $configOption->id" :showPriceTag="$showPriceTag" :plan="$plan">
                                            @if ($configOption->type == 'select')
                                                @foreach ($configOption->children as $configOptionValue)
                                                    <option value="{{ $configOptionValue->id }}" class="bg-background-secondary text-color-base dark:bg-gray-800 dark:text-gray-100">
                                                        {{ $configOptionValue->name }}
                                                        {{ ($showPriceTag && $configOptionValue->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit)->available) ? ' - ' . $configOptionValue->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit) : '' }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </x-form.configoption>
                                    </div>
                                @endif
                            @endforeach

                            {{-- Checkout Config Options (Proxmox, etc.) --}}
                            @foreach ($this->getCheckoutConfig() as $configOption)
                                @php $configOption = (object) $configOption; @endphp
                                @if ($configOption->type == 'radio')
                                    <div class="flex flex-col relative w-full" x-data="{
                                        getIcon(value, optionText) {
                                            const searchText = (String(value) + ' ' + String(optionText)).toLowerCase();
                                            
                                            const iconMap = {
                                                // === OSes ===
                                                'ubuntu': 'https://cdn-icons-png.flaticon.com/512/888/888879.png',
                                                'debian': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/debian/debian-plain.svg',
                                                'windows': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg',
                                                'centos': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/centos/centos-plain.svg',
                                                'fedora': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/fedora/fedora-plain.svg',
                                                'rhel': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redhat/redhat-plain.svg',
                                                'red hat': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redhat/redhat-plain.svg',
                                                'rocky': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rockylinux/rockylinux-plain.svg',
                                                'alma': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rockylinux/rockylinux-plain.svg',
                                                'arch': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/archlinux/archlinux-plain.svg',
                                                'alpine': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/alpine/alpine-plain.svg',
                                                'linux': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg',
                                                
                                                // === Countries & Cities ===
                                                'usa': 'https://flagcdn.com/us.svg',
                                                'us': 'https://flagcdn.com/us.svg',
                                                'united states': 'https://flagcdn.com/us.svg',
                                                'atlanta': 'https://flagcdn.com/us.svg',
                                                'texas': 'https://flagcdn.com/us.svg',
                                                'dallas': 'https://flagcdn.com/us.svg',
                                                'miami': 'https://flagcdn.com/us.svg',
                                                'new york': 'https://flagcdn.com/us.svg',
                                                'chicago': 'https://flagcdn.com/us.svg',
                                                'los angeles': 'https://flagcdn.com/us.svg',
                                                'seattle': 'https://flagcdn.com/us.svg',
                                                'silicon valley': 'https://flagcdn.com/us.svg',
                                                'canada': 'https://flagcdn.com/ca.svg',
                                                'toronto': 'https://flagcdn.com/ca.svg',
                                                'montreal': 'https://flagcdn.com/ca.svg',
                                                'uk': 'https://flagcdn.com/gb.svg',
                                                'united kingdom': 'https://flagcdn.com/gb.svg',
                                                'london': 'https://flagcdn.com/gb.svg',
                                                'germany': 'https://flagcdn.com/de.svg',
                                                'frankfurt': 'https://flagcdn.com/de.svg',
                                                'berlin': 'https://flagcdn.com/de.svg',
                                                'france': 'https://flagcdn.com/fr.svg',
                                                'paris': 'https://flagcdn.com/fr.svg',
                                                'netherlands': 'https://flagcdn.com/nl.svg',
                                                'amsterdam': 'https://flagcdn.com/nl.svg',
                                                'poland': 'https://flagcdn.com/pl.svg',
                                                'warsaw': 'https://flagcdn.com/pl.svg',
                                                'serbia': 'https://flagcdn.com/rs.svg',
                                                'belgium': 'https://flagcdn.com/be.svg',
                                                'switzerland': 'https://flagcdn.com/ch.svg',
                                                'spain': 'https://flagcdn.com/es.svg',
                                                'madrid': 'https://flagcdn.com/es.svg',
                                                'italy': 'https://flagcdn.com/it.svg',
                                                'milan': 'https://flagcdn.com/it.svg',
                                                'singapore': 'https://flagcdn.com/sg.svg',
                                                'india': 'https://flagcdn.com/in.svg',
                                                'mumbai': 'https://flagcdn.com/in.svg',
                                                'bangalore': 'https://flagcdn.com/in.svg',
                                                'japan': 'https://flagcdn.com/jp.svg',
                                                'tokyo': 'https://flagcdn.com/jp.svg',
                                                'china': 'https://flagcdn.com/cn.svg',
                                                'hong kong': 'https://flagcdn.com/hk.svg',
                                                'australia': 'https://flagcdn.com/au.svg',
                                                'sydney': 'https://flagcdn.com/au.svg',
                                                'south korea': 'https://flagcdn.com/kr.svg',
                                                'seoul': 'https://flagcdn.com/kr.svg',
                                                'indonesia': 'https://flagcdn.com/id.svg',
                                                'jakarta': 'https://flagcdn.com/id.svg',
                                                'malaysia': 'https://flagcdn.com/my.svg',
                                                'thailand': 'https://flagcdn.com/th.svg',
                                                'vietnam': 'https://flagcdn.com/vn.svg',
                                                'dubai': 'https://flagcdn.com/ae.svg',
                                                'uae': 'https://flagcdn.com/ae.svg',
                                                'israel': 'https://flagcdn.com/il.svg',
                                                'saudi': 'https://flagcdn.com/sa.svg',
                                                'brazil': 'https://flagcdn.com/br.svg',
                                                'sao paulo': 'https://flagcdn.com/br.svg',
                                                'argentina': 'https://flagcdn.com/ar.svg',
                                                'chile': 'https://flagcdn.com/cl.svg',
                                                'south africa': 'https://flagcdn.com/za.svg',
                                                'kenya': 'https://flagcdn.com/ke.svg',
                                                'nigeria': 'https://flagcdn.com/ng.svg',

                                                // === Minecraft & Server Software ===
                                                'java': 'https://i.imgur.com/3kksGdD.png',
                                                'bedrock': 'https://i.imgur.com/3kksGdD.png',
                                                'minecraft': 'https://i.imgur.com/3kksGdD.png',
                                                'forge': 'https://i.imgur.com/RBFsqRB.png',
                                                'fabric': 'https://i.imgur.com/ibMY1Sk.png',
                                                'quilt': 'https://quiltmc.org/assets/img/logo-square.png',
                                                'paper': 'https://assets.papermc.io/brand/papermc_logo.512.png',
                                                'purpur': 'https://avatars.githubusercontent.com/u/94729614?v=4',
                                                'spigot': 'https://static.spigotmc.org/img/spigot-og.png',
                                                'bukkit': 'https://www.vhv.rs/dpng/d/445-4454243_craft-bukkit-logo-spigot-logo-hd-png-download.png',
                                                'velocity': 'https://avatars.githubusercontent.com/u/41710604?s=200&v=4',
                                                'bungee': 'https://i.imgur.com/RJw4xR0.png',
                                                'waterfall': 'https://i.imgur.com/L1KbaWA.png',
                                                'sponge': 'https://static.wikia.nocookie.net/minecraft_gamepedia/images/f/f7/Sponge_JE3_BE3.png/revision/latest?cb=20240729213346',
                                                'mohist': 'https://mohistmc.com/mohistLogo.png',
                                                'pocketminemp': 'https://pmmp.io/assets/images/favicon.png',
                                            };
                                            
                                            for (const [pattern, iconUrl] of Object.entries(iconMap)) {
                                                if (searchText.includes(pattern)) {
                                                    return iconUrl;
                                                }
                                            }
                                            
                                            return null;
                                        }
                                    }">
                                        <label class="mb-4 text-xl font-bold text-color-base">
                                            {{ $configOption->label ?? ucfirst(str_replace('_', ' ', $configOption->name)) }}
                                            @if ($configOption->required ?? false)
                                                <span class="text-red-500 ml-1">*</span>
                                            @endif
                                        </label>

                                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                                            @foreach ($configOption->options as $optionValue => $optionLabel)
                                                @php
                                                    $inputId = 'checkout_config_' . $configOption->name . '_' . $optionValue;
                                                    $isSelected = isset($checkoutConfig[$configOption->name]) && $checkoutConfig[$configOption->name] == $optionValue;
                                                @endphp
                                                <label 
                                                    for="{{ $inputId }}"
                                                    class="relative flex flex-col items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 group {{ $isSelected ? 'border-primary bg-primary/5 shadow-lg shadow-primary/20' : 'border-neutral/50 hover:border-neutral hover:bg-background-tertiary/30' }}"
                                                >
                                                    <input 
                                                        type="radio" 
                                                        id="{{ $inputId }}"
                                                        name="checkoutConfig.{{ $configOption->name }}"
                                                        value="{{ $optionValue }}"
                                                        wire:model.live="checkoutConfig.{{ $configOption->name }}"
                                                        {{ $isSelected ? 'checked' : '' }}
                                                        {{ ($configOption->required ?? false) ? 'required' : '' }}
                                                        class="sr-only peer"
                                                    />
                                                    
                                                    @if($isSelected)
                                                    <div class="absolute top-2 right-2 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                                        <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                    </div>
                                                    @endif
                                                    
                                                    <div class="w-12 h-12 mb-3 flex items-center justify-center">
                                                        <img 
                                                            :src="getIcon('{{ $optionValue }}', '{{ $optionLabel }}')"
                                                            x-show="getIcon('{{ $optionValue }}', '{{ $optionLabel }}')"
                                                            alt="{{ $optionLabel }}"
                                                            class="w-full h-full object-contain transition-transform duration-300 {{ $isSelected ? 'scale-110' : 'group-hover:scale-110' }}"
                                                        />
                                                        <div 
                                                            x-show="!getIcon('{{ $optionValue }}', '{{ $optionLabel }}')"
                                                            class="w-10 h-10 rounded-full bg-gradient-to-br flex items-center justify-center {{ $isSelected ? 'from-primary/30 to-primary/10' : 'from-primary/20 to-primary/5' }}"
                                                        >
                                                            <span class="text-lg font-bold text-primary">
                                                                {{ strtoupper(substr($optionLabel, 0, 2)) }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <span class="text-sm font-medium text-center transition-colors {{ $isSelected ? 'text-primary' : 'text-color-base group-hover:text-primary' }}">
                                                        {{ $optionLabel }}
                                                    </span>
                                                </label>
                                            @endforeach
                                        </div>

                                        @if (isset($configOption->description))
                                            <p class="text-xs text-color-muted mt-3">{{ $configOption->description }}</p>
                                        @endif

                                        @error('checkoutConfig.' . $configOption->name)
                                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                                        @enderror
                                    </div>
                                    
                                @else
                                    {{-- Select and Other Types --}}
                                    <div class="bg-background-tertiary/30 rounded-xl p-2">
                                        <x-form.configoption :config="$configOption" :name="'checkoutConfig.' . $configOption->name">
                                            @if ($configOption->type == 'select')
                                                @foreach ($configOption->options as $configOptionValue => $configOptionValueName)
                                                    <option value="{{ $configOptionValue }}" class="bg-background-secondary text-color-base dark:bg-gray-800 dark:text-gray-100">
                                                        {{ $configOptionValueName }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </x-form.configoption>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif

        </div>

        <div class="flex flex-col gap-6 w-full col-span-3 md:col-span-1 sticky top-8 md:top-20">
            <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden animate-fade-in-up" style="animation-delay: 0.3s;">
                <div class="p-6 lg:p-8">
                    <div class="flex items-center gap-4 mb-6 pb-4 border-b border-neutral/50">
                        <div class="bg-primary/10 text-primary p-3 rounded-full shadow-md">
                            <x-ri-shopping-cart-2-fill class="size-6" />
                        </div>
                        <div>
                            <h2 class="text-xl font-bold text-color-base">
                                {{ __('product.order_summary') }}
                            </h2>
                            <p class="text-color-muted text-xs">Review your order details</p>
                        </div>
                    </div>

                    @if(count($configOptions) > 0 || count($checkoutConfig) > 0)
                    <div class="mb-6 space-y-3">
                        <h3 class="text-xs font-semibold text-color-muted uppercase tracking-wider px-1">
                            Configuration Details
                        </h3>

                        <div class="space-y-2">
                            @foreach ($product->configOptions as $configOption)
                                @if (isset($configOptions[$configOption->id]))
                                    @php
                                        $selectedChildId = $configOptions[$configOption->id];
                                        $selectedOption = $configOption->children->firstWhere('id', $selectedChildId);
                                    @endphp
                                    @if ($selectedOption)
                                    
                                    <div class="group p-3 bg-background-tertiary/30 hover:bg-background-tertiary/50 rounded-lg border border-neutral/20 transition-all duration-200">
                                        <div class="flex justify-between items-start gap-3">
                                            <div class="min-w-0 flex-1">
                                                <div class="text-xs text-color-muted mb-1">
                                                    {{ $configOption->name }}
                                                </div>
                                                <div class="text-sm font-medium text-color-base">
                                                    {{ $selectedOption->name }}
                                                </div>
                                                @if(!empty($selectedOption->description))
                                                    <div class="text-xs text-color-muted/70 mt-1 line-clamp-1">
                                                        {{ $selectedOption->description }}
                                                    </div>
                                                @endif
                                            </div>

                                            @if (!$selectedOption->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit)->is_free)
                                                <div class="flex-shrink-0">
                                                    <span class="text-xs font-semibold text-primary">
                                                        {{ $selectedOption->price(billing_period: $plan->billing_period, billing_unit: $plan->billing_unit) }}
                                                    </span>
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                    @endif
                                @endif
                            @endforeach
                            
                            @foreach ($this->getCheckoutConfig() as $configOption)
                                @php $configOption = (object) $configOption; @endphp
                                @if (isset($checkoutConfig[$configOption->name]))
                                    @php
                                        $selectedValue = $checkoutConfig[$configOption->name];
                                        $configOptionLabel = $configOption->label ?? ucfirst(str_replace('_', ' ', $configOption->name));
                                        $selectedLabel = $configOption->options[$selectedValue] ?? $selectedValue;
                                    @endphp

                                    <div class="group p-3 bg-background-tertiary/30 hover:bg-background-tertiary/50 rounded-lg border border-neutral/20 transition-all duration-200">
                                        <div class="flex justify-between items-start gap-3">
                                            <div class="min-w-0 flex-1">
                                                <div class="text-xs text-color-muted mb-1">
                                                    {{ $configOptionLabel }}
                                                </div>
                                                <div class="text-sm font-medium text-color-base">
                                                    {{ $selectedLabel }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                @endif
                            @endforeach
                        </div>
                    </div>
                    @endif

                    <div class="space-y-3 mb-6">
                        @if ($total->total_tax > 0)
                            <div class="flex justify-between items-center p-3 bg-background-tertiary/30 rounded-xl border border-neutral/30">
                                <div class="flex items-center gap-2">
                                    <x-ri-price-tag-3-line class="size-4 text-color-muted" />
                                    <h4 class="text-sm font-medium text-color-muted">{{ __('invoices.subtotal') }}</h4>
                                </div>
                                <span class="text-base font-semibold text-color-base">{{ $total->format($total->subtotal) }}</span>
                            </div>

                            <div class="flex justify-between items-center p-3 bg-background-tertiary/30 rounded-xl border border-neutral/30">
                                <div class="flex items-center gap-2">
                                    <x-ri-percent-line class="size-4 text-color-muted" />
                                    <h4 class="text-sm font-medium text-color-muted">
                                        {{ \App\Classes\Settings::tax()->name }} ({{ \App\Classes\Settings::tax()->rate }}%)
                                    </h4>
                                </div>
                                <span class="text-base font-semibold text-color-base">{{ $total->formatted->total_tax }}</span>
                            </div>
                        @endif

                        {{-- Total Today --}}
                        <div class="flex flex-col items-start p-4 bg-gradient-to-r from-green-400/20 via-green-500/10 to-green-400/20 rounded-xl border border-green-400/30 shadow-md relative overflow-hidden">
                            <svg class="absolute -top-4 -right-4 w-20 h-20 opacity-25 pointer-events-none z-0" viewBox="0 0 80 80" fill="none">
                                <defs>
                                    <radialGradient id="cornerGradient" cx="0.7" cy="0.3" r="1">
                                        <stop offset="0%" stop-color="#22c55e" stop-opacity="0.7"/>
                                        <stop offset="100%" stop-color="#22c55e" stop-opacity="0"/>
                                    </radialGradient>
                                </defs>
                                <circle cx="70" cy="10" r="40" fill="url(#cornerGradient)" />
                                <circle cx="60" cy="20" r="10" fill="#22c55e" fill-opacity="0.3"/>
                                <rect x="50" y="0" width="20" height="20" rx="6" fill="#22c55e" fill-opacity="0.15"/>
                            </svg>
                            <div class="flex items-center gap-2 z-10">
                                <x-ri-money-dollar-circle-fill class="size-5 text-green-600" />
                                <h4 class="text-lg font-semibold text-green-600">{{ __('product.total_today') }}</h4>
                            </div>
                            <span class="text-2xl font-bold text-green-600 z-10">{{ $total }}</span>
                        </div>

                        {{-- Recurring Price --}}
                        @if ($total->setup_fee && $plan->type == 'recurring')
                            <div class="flex justify-between items-center p-3 bg-background-tertiary/30 rounded-xl border border-neutral/30">
                                <div class="flex items-center gap-2">
                                    <x-ri-time-fill class="size-4 text-color-muted" />
                                    <h4 class="text-sm text-color-muted">
                                        {{ __('product.then_after_x', ['time' => $plan->billing_period . ' ' . trans_choice(__('services.billing_cycles.' . $plan->billing_unit), $plan->billing_period)]) }}
                                    </h4>
                                </div>
                                <span class="text-base font-medium text-color-base">
                                    {{ $total->format($total->price) }}
                                </span>
                            </div>
                        @endif
                    </div>

                    @if (($product->stock > 0 || !$product->stock) && $product->price()->available)
                        <div class="space-y-3">
                            <x-button.primary wire:click="checkout" wire:loading.attr="disabled" 
                                    class="group/btn w-full inline-flex items-center justify-center gap-3 bg-primary hover:bg-primary/90 text-white px-6 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:shadow-lg hover:shadow-primary/30 disabled:opacity-50 disabled:cursor-not-allowed">
                                <span wire:loading.remove>{{ __('product.checkout') }}</span>
                                <span wire:loading>Processing...</span>
                                <x-ri-arrow-right-fill class="size-5 transform transition-transform duration-300 group-hover/btn:translate-x-1" wire:loading.remove />
                                <x-ri-loader-4-fill class="size-5 animate-spin" wire:loading />
                            </x-button.primary>
                            
                            <div class="flex items-center justify-center gap-2 text-xs text-color-muted">
                                <x-ri-shield-check-fill class="size-4 text-green-500" />
                                <span>Secure checkout powered by encryption</span>
                            </div>
                        </div>
                    @else
                        <div class="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl">
                            <div class="flex items-center gap-2 text-red-600 dark:text-red-400">
                                <x-ri-error-warning-fill class="size-5" />
                                <span class="font-medium">Currently Unavailable</span>
                            </div>
                            <p class="text-sm text-red-500 dark:text-red-300 mt-1">
                                This product is currently out of stock or not available for purchase.
                            </p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>