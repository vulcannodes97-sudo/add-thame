<div class="mt-20 mx-auto px-8 py-8 animate-fade-in-up">
    
    <div class="text-center sm:text-left mb-8">
        <h1 class="text-3xl lg:text-4xl font-bold text-color-base leading-tight flex items-center gap-2"> 
            {{ __('services.upgrade_service', ['service' => $service->product->name]) }}
        </h1>
        <h2 class="text-lg font-semibold mt-2">
            @if($step == 1)
                {{ __('services.upgrade_choose_product') }}
            @else
                {{ __('services.upgrade_choose_config') }}
            @endif
        </h2>        
    </div>

    <div class="grid md:grid-cols-4 gap-8 lg:gap-12 items-start">
        
        <div class="flex flex-col gap-6 w-full col-span-3">

            @if($step == 1)
                <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden animate-fade-in-up" style="animation-delay: 0.1s;">
                    <div class="p-6 lg:p-8">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="bg-primary/10 text-primary p-3 rounded-full shadow-md">
                                <x-ri-price-tag-3-fill class="size-6" />
                            </div>
                            <div>
                                <h2 class="text-xl font-bold text-color-base">
                                    {{ __('services.upgrade_choose_product') }}
                                </h2>
                                <p class="text-color-muted text-sm">Select your new plan or keep your current one</p>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <input type="radio" name="upgrade" value="{{ $service->product->id }}" wire:model.live="upgrade"
                                    class="hidden peer" id="product-{{ $service->product->id }}">
                                <label for="product-{{ $service->product->id }}"
                                    class="flex flex-col cursor-pointer bg-background-tertiary/30 hover:bg-background-tertiary/50 border border-neutral/30 peer-checked:border-primary peer-checked:bg-primary/5 peer-checked:ring-2 peer-checked:ring-primary p-6 rounded-xl transition-all duration-300 h-full">
                                    
                                    @if ($service->product->image)
                                        <div class="relative overflow-hidden rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 p-2 mb-4">
                                            <img src="{{ Storage::url($service->product->image) }}" alt="{{ $service->product->name }}" class="rounded-lg w-full object-cover object-center h-auto max-h-48">
                                        </div>
                                    @endif

                                    <div class="rounded-full border border-background inline-flex items-center justify-center gap-2 align-middle bg-primary/60 w-fit px-3 py-1 mb-4">
                                        <p class="text-sm font-medium text-color-base">{{ __('services.current_plan') }}</p>
                                    </div>
                                    
                                    <h3 class="text-lg font-bold text-color-base mb-2">{{ $service->product->name }}</h3>
                                    <div class="max-h-64 overflow-y-auto mb-4 flex-grow">
                                        <article class="prose dark:prose-invert text-color-muted text-sm">
                                            {!! $service->product->description !!}
                                        </article>
                                    </div>
                                    
                                    <div class="mt-auto space-y-3">
                                        <h3 class="text-lg font-semibold text-color-base">
                                            @if($service->plan->type == 'recurring')
                                                {{ __('services.price_every_period', [
                                                    'price' => $service->product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code),
                                                    'period' => $service->plan->billing_period > 1 ? $service->plan->billing_period : '',
                                                    'unit' => strtolower(trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period))
                                                ]) }}
                                            @else
                                                {{ __('services.price_one_time', [
                                                    'price' => $service->product->price(null, null, null, $service->currency_code),
                                                ]) }}
                                            @endif
                                        </h3>
                                        
                                        <div class="flex justify-between items-center p-3 bg-background-tertiary/30 rounded-lg">
                                            <span class="text-sm text-color-muted">Current Price</span>
                                            <span class="text-lg font-semibold text-color-base">
                                                {{ $service->product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                            </span>
                                        </div>
                                    </div>
                                </label>
                            </div>

                            @foreach ($service->productUpgrades() as $product)
                                <div>
                                    <input type="radio" name="upgrade" value="{{ $product->id }}" wire:model.live="upgrade"
                                        class="hidden peer" id="product-{{ $product->id }}">
                                    <label for="product-{{ $product->id }}"
                                        class="flex flex-col cursor-pointer bg-background-tertiary/30 hover:bg-background-tertiary/50 border border-neutral/50 peer-checked:border-secondary peer-checked:bg-secondary/5 peer-checked:ring-2 peer-checked:ring-secondary p-6 rounded-xl transition-all duration-300 h-full">
                                                  
                                        @if ($product->image)
                                            <div class="relative overflow-hidden rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 p-2 mb-4">
                                                <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" class="rounded-lg w-full object-cover object-center h-auto max-h-48">
                                            </div>
                                        @endif

                                        @if($upgrade == $product->id)
                                            <div class="rounded-full border border-background inline-flex items-center justify-center gap-2 align-middle bg-primary w-fit px-3 py-1 mb-4 animate-fade-in-up" style="animation-delay: 0.1s;">
                                                <p class="text-sm font-medium text-color-base">{{ __('services.new_plan') }}</p>
                                            </div>
                                        @endif
                                        
                                        <h3 class="text-lg font-bold text-color-base mb-2">{{ $product->name }}</h3>
                                        <div class="max-h-64 overflow-y-auto mb-4 flex-grow">
                                            <article class="prose dark:prose-invert text-color-muted text-sm">
                                                {!! $product->description !!}
                                            </article>
                                        </div>
                                        
                                        <div class="mt-auto space-y-3">
                                            <h3 class="text-lg font-semibold text-color-base">
                                                @if($service->plan->type == 'recurring')
                                                    {{ __('services.price_every_period', [
                                                        'price' => $product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code),
                                                        'period' => $service->plan->billing_period > 1 ? $service->plan->billing_period : '',
                                                        'unit' => trans_choice(__('services.billing_cycles.' . $service->plan->billing_unit), $service->plan->billing_period)
                                                    ]) }}
                                                @else
                                                    {{ __('services.price_one_time', [
                                                        'price' => $product->price(null, null, null, $service->currency_code),
                                                    ]) }}
                                                @endif
                                            </h3>
                                            
                                            <div class="flex justify-between items-center p-3 bg-background-tertiary/30 rounded-lg">
                                                <span class="text-sm text-color-muted">New Price</span>
                                                <span class="text-lg font-semibold text-color-base">
                                                    {{ $product->price(null, $service->plan->billing_period, $service->plan->billing_unit, $service->currency_code) }}
                                                </span>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @else
                <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden animate-fade-in-up" style="animation-delay: 0.2s;">
                    <div class="p-6 lg:p-8">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="bg-primary/10 text-primary p-3 rounded-full shadow-md">
                                <x-ri-settings-3-fill class="size-6" />
                            </div>
                            <div>
                                <h2 class="text-xl font-bold text-color-base">
                                    {{ __('services.upgrade_choose_config') }}
                                </h2>
                                <p class="text-color-muted text-sm">Customize your upgrade options</p>
                            </div>
                        </div>

                        <div class="space-y-6">
                            @foreach ($upgradeProduct->upgradableConfigOptions as $configOption)
                                @php
                                    $showPriceTag = $configOption->children->filter(fn ($value) => !$value->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->is_free)->count() > 0;
                                @endphp
                                
                                @if ($configOption->type == 'radio')
                                    <div class="flex flex-col relative w-full" x-data="{
                                        getIcon(value, optionText) {
                                            const searchText = (String(value) + ' ' + String(optionText)).toLowerCase();
                                            
                                            const iconMap = {
                                                // === OSes ===
                                                'ubuntu': 'https://cdn-icons-png.flaticon.com/512/888/888879.png',
                                                'debian': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/debian/debian-plain.svg',
                                                'windows': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg',
                                                'centos': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/centos/centos-plain.svg',
                                                'fedora': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/fedora/fedora-plain.svg',
                                                'rhel': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redhat/redhat-plain.svg',
                                                'red hat': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redhat/redhat-plain.svg',
                                                'rocky': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rockylinux/rockylinux-plain.svg',
                                                'alma': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/rockylinux/rockylinux-plain.svg',
                                                'arch': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/archlinux/archlinux-plain.svg',
                                                'alpine': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/alpine/alpine-plain.svg',
                                                'linux': 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg',
                                                
                                                // === Countries & Cities ===
                                                'usa': 'https://flagcdn.com/us.svg',
                                                'us': 'https://flagcdn.com/us.svg',
                                                'united states': 'https://flagcdn.com/us.svg',
                                                'atlanta': 'https://flagcdn.com/us.svg',
                                                'texas': 'https://flagcdn.com/us.svg',
                                                'dallas': 'https://flagcdn.com/us.svg',
                                                'miami': 'https://flagcdn.com/us.svg',
                                                'new york': 'https://flagcdn.com/us.svg',
                                                'chicago': 'https://flagcdn.com/us.svg',
                                                'los angeles': 'https://flagcdn.com/us.svg',
                                                'seattle': 'https://flagcdn.com/us.svg',
                                                'silicon valley': 'https://flagcdn.com/us.svg',
                                                'canada': 'https://flagcdn.com/ca.svg',
                                                'toronto': 'https://flagcdn.com/ca.svg',
                                                'montreal': 'https://flagcdn.com/ca.svg',
                                                'uk': 'https://flagcdn.com/gb.svg',
                                                'united kingdom': 'https://flagcdn.com/gb.svg',
                                                'london': 'https://flagcdn.com/gb.svg',
                                                'germany': 'https://flagcdn.com/de.svg',
                                                'frankfurt': 'https://flagcdn.com/de.svg',
                                                'berlin': 'https://flagcdn.com/de.svg',
                                                'france': 'https://flagcdn.com/fr.svg',
                                                'paris': 'https://flagcdn.com/fr.svg',
                                                'netherlands': 'https://flagcdn.com/nl.svg',
                                                'amsterdam': 'https://flagcdn.com/nl.svg',
                                                'poland': 'https://flagcdn.com/pl.svg',
                                                'warsaw': 'https://flagcdn.com/pl.svg',
                                                'serbia': 'https://flagcdn.com/rs.svg',
                                                'belgium': 'https://flagcdn.com/be.svg',
                                                'switzerland': 'https://flagcdn.com/ch.svg',
                                                'spain': 'https://flagcdn.com/es.svg',
                                                'madrid': 'https://flagcdn.com/es.svg',
                                                'italy': 'https://flagcdn.com/it.svg',
                                                'milan': 'https://flagcdn.com/it.svg',
                                                'singapore': 'https://flagcdn.com/sg.svg',
                                                'india': 'https://flagcdn.com/in.svg',
                                                'mumbai': 'https://flagcdn.com/in.svg',
                                                'bangalore': 'https://flagcdn.com/in.svg',
                                                'japan': 'https://flagcdn.com/jp.svg',
                                                'tokyo': 'https://flagcdn.com/jp.svg',
                                                'china': 'https://flagcdn.com/cn.svg',
                                                'hong kong': 'https://flagcdn.com/hk.svg',
                                                'australia': 'https://flagcdn.com/au.svg',
                                                'sydney': 'https://flagcdn.com/au.svg',
                                                'south korea': 'https://flagcdn.com/kr.svg',
                                                'seoul': 'https://flagcdn.com/kr.svg',
                                                'indonesia': 'https://flagcdn.com/id.svg',
                                                'jakarta': 'https://flagcdn.com/id.svg',
                                                'malaysia': 'https://flagcdn.com/my.svg',
                                                'thailand': 'https://flagcdn.com/th.svg',
                                                'vietnam': 'https://flagcdn.com/vn.svg',
                                                'dubai': 'https://flagcdn.com/ae.svg',
                                                'uae': 'https://flagcdn.com/ae.svg',
                                                'israel': 'https://flagcdn.com/il.svg',
                                                'saudi': 'https://flagcdn.com/sa.svg',
                                                'brazil': 'https://flagcdn.com/br.svg',
                                                'sao paulo': 'https://flagcdn.com/br.svg',
                                                'argentina': 'https://flagcdn.com/ar.svg',
                                                'chile': 'https://flagcdn.com/cl.svg',
                                                'south africa': 'https://flagcdn.com/za.svg',
                                                'kenya': 'https://flagcdn.com/ke.svg',
                                                'nigeria': 'https://flagcdn.com/ng.svg',

                                                // === Minecraft & Server Software ===
                                                'java': 'https://i.imgur.com/3kksGdD.png',
                                                'bedrock': 'https://i.imgur.com/3kksGdD.png',
                                                'forge': 'https://i.imgur.com/RBFsqRB.png',
                                                'fabric': 'https://i.imgur.com/ibMY1Sk.png',
                                                'quilt': 'https://quiltmc.org/assets/img/logo-square.png',
                                                'paper': 'https://assets.papermc.io/brand/papermc_logo.512.png',
                                                'purpur': 'https://avatars.githubusercontent.com/u/94729614?v=4',
                                                'spigot': 'https://static.spigotmc.org/img/spigot-og.png',
                                                'bukkit': 'https://www.vhv.rs/dpng/d/445-4454243_craft-bukkit-logo-spigot-logo-hd-png-download.png',
                                                'velocity': 'https://avatars.githubusercontent.com/u/41710604?s=200&v=4',
                                                'bungee': 'https://i.imgur.com/RJw4xR0.png',
                                                'waterfall': 'https://i.imgur.com/L1KbaWA.png',
                                                'sponge': 'https://static.wikia.nocookie.net/minecraft_gamepedia/images/f/f7/Sponge_JE3_BE3.png/revision/latest?cb=20240729213346',
                                                'mohist': 'https://mohistmc.com/mohistLogo.png',
                                                'thermos': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'tuinity': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'airplane': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'trident': 'https://img.icons8.com/color/48/000000/minecraft.png',
                                                'pocketminemp': 'https://pmmp.io/assets/images/favicon.png',
                                                'cauldron': 'https://img.icons8.com/color/48/000000/minecraft.png'
                                            };
                                            
                                            for (const [pattern, iconUrl] of Object.entries(iconMap)) {
                                                if (searchText.includes(pattern)) {
                                                    return iconUrl;
                                                }
                                            }
                                            
                                            return null;
                                        }
                                    }">
                                        <label class="mb-4 text-xl font-bold text-color-base">
                                            {{ $configOption->name }}
                                            @if ($configOption->required)
                                                <span class="text-red-500 ml-1">*</span>
                                            @endif
                                        </label>

                                        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                                            @foreach ($configOption->children as $child)
                                                @php
                                                    $inputId = 'config_' . $configOption->id . '_' . $child->id;
                                                    $isSelected = isset($configOptions[$configOption->id]) && $configOptions[$configOption->id] == $child->id;
                                                @endphp
                                                <label 
                                                    for="{{ $inputId }}"
                                                    class="relative flex flex-col items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 group {{ $isSelected ? 'border-primary bg-primary/5 shadow-lg shadow-primary/20' : 'border-neutral/50 hover:border-neutral hover:bg-background-tertiary/30' }}"
                                                >
                                                    <input 
                                                        type="radio" 
                                                        id="{{ $inputId }}"
                                                        name="configOptions.{{ $configOption->id }}"
                                                        value="{{ $child->id }}"
                                                        wire:model.live="configOptions.{{ $configOption->id }}"
                                                        {{ $isSelected ? 'checked' : '' }}
                                                        {{ $configOption->required ? 'required' : '' }}
                                                        class="sr-only peer"
                                                    />
                                                    
                                                    @if($isSelected)
                                                    <div class="absolute top-2 right-2 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                                        <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                    </div>
                                                    @endif
                                                    
                                                    <div class="w-12 h-12 mb-3 flex items-center justify-center">
                                                        <img 
                                                            :src="getIcon('{{ $child->id }}', '{{ $child->name }}')"
                                                            x-show="getIcon('{{ $child->id }}', '{{ $child->name }}')"
                                                            alt="{{ $child->name }}"
                                                            class="w-full h-full object-contain transition-transform duration-300 {{ $isSelected ? 'scale-110' : 'group-hover:scale-110' }}"
                                                        />
                                                        <div 
                                                            x-show="!getIcon('{{ $child->id }}', '{{ $child->name }}')"
                                                            class="w-10 h-10 rounded-full bg-gradient-to-br flex items-center justify-center {{ $isSelected ? 'from-primary/30 to-primary/10' : 'from-primary/20 to-primary/5' }}"
                                                        >
                                                            <span class="text-lg font-bold text-primary">
                                                                {{ strtoupper(substr($child->name, 0, 2)) }}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    
                                                    <span class="text-sm font-medium text-center transition-colors {{ $isSelected ? 'text-primary' : 'text-color-base group-hover:text-primary' }}">
                                                        {{ $child->name }}
                                                        @if ($showPriceTag && $child->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->available)
                                                            <span class="block text-xs mt-1">
                                                                {{ $child->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit) }}
                                                            </span>
                                                        @endif
                                                    </span>
                                                </label>
                                            @endforeach
                                        </div>

                                        @if ($configOption->description ?? false)
                                            <p class="text-xs text-color-muted mt-3">{{ $configOption->description }}</p>
                                        @endif

                                        @error('configOptions.' . $configOption->id)
                                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                                        @enderror
                                    </div>
                                @else
                                    <div class="bg-background-tertiary/30 rounded-xl p-2">
                                        <x-form.configoption :config="$configOption" :name="'configOptions.' . $configOption->id" :showPriceTag="$showPriceTag" :plan="$service->plan">
                                            @if ($configOption->type == 'select')
                                                @foreach ($configOption->children as $configOptionValue)
                                                    <option value="{{ $configOptionValue->id }}" class="bg-background-secondary text-color-base dark:bg-gray-800 dark:text-gray-100">
                                                        {{ $configOptionValue->name }}
                                                        {{ ($showPriceTag && $configOptionValue->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->available) ? ' - ' . $configOptionValue->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit) : '' }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </x-form.configoption>
                                    </div>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <div class="flex flex-col gap-6 w-full col-span-3 md:col-span-1 sticky top-8 md:top-20">
            <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 rounded-2xl shadow-lg overflow-hidden animate-fade-in-up" style="animation-delay: 0.3s;">
                <div class="p-6 lg:p-8">
                    <div class="flex items-center gap-4 mb-6 pb-4 border-b border-neutral/50">
                        <div class="bg-primary/10 text-primary p-3 rounded-full shadow-md">
                            <x-ri-arrow-up-circle-fill class="size-6" />
                        </div>
                        <div>
                            <h2 class="text-xl font-bold text-color-base">
                                {{ __('services.upgrade_summary') }}
                            </h2>
                            <p class="text-color-muted text-xs">Review your upgrade details</p>
                        </div>
                    </div>

                    @if(count($configOptions) > 0)
                    <div class="mb-6 space-y-3">
                        <h3 class="text-xs font-semibold text-color-muted uppercase tracking-wider px-1">
                            Configuration Details
                        </h3>

                        <div class="space-y-2">
                            @foreach ($upgradeProduct->upgradableConfigOptions as $configOption)
                                @if (isset($configOptions[$configOption->id]))
                                    @php
                                        $selectedChildId = $configOptions[$configOption->id];
                                        $selectedOption = $configOption->children->firstWhere('id', $selectedChildId);
                                    @endphp
                                    @if ($selectedOption)
                                    
                                    <div class="group p-3 bg-background-tertiary/30 hover:bg-background-tertiary/50 rounded-lg border border-neutral/20 transition-all duration-200">
                                        <div class="flex justify-between items-start gap-3">
                                            <div class="min-w-0 flex-1">
                                                <div class="text-xs text-color-muted mb-1">
                                                    {{ $configOption->name }}
                                                </div>
                                                <div class="text-sm font-medium text-color-base">
                                                    {{ $selectedOption->name }}
                                                </div>
                                                @if(!empty($selectedOption->description))
                                                    <div class="text-xs text-color-muted/70 mt-1 line-clamp-1">
                                                        {{ $selectedOption->description }}
                                                    </div>
                                                @endif
                                            </div>

                                            @if (!$selectedOption->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit)->is_free)
                                                <div class="flex-shrink-0">
                                                    <span class="text-xs font-semibold text-primary">
                                                        {{ $selectedOption->price(billing_period: $service->plan->billing_period, billing_unit: $service->plan->billing_unit) }}
                                                    </span>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    @endif
                                @endif
                            @endforeach
                        </div>
                    </div>
                    @endif

                    <div class="space-y-4 mb-6">
                        <div class="flex justify-between items-center p-3 bg-background-tertiary/30 rounded-lg border border-neutral/30">
                            <div class="flex items-center gap-2">
                                <x-ri-archive-fill class="size-4 text-color-muted" />
                                <span class="text-sm text-color-muted">{{ __('services.current_plan') }}</span>
                            </div>
                            <span class="text-sm font-medium text-color-base">{{ $service->product->name }}</span>
                        </div>

                        @if($upgrade != $service->product->id)
                            <div class="flex justify-between items-center p-3 bg-primary/10 rounded-lg border border-primary/20">
                                <div class="flex items-center gap-2">
                                    <x-ri-star-fill class="size-4 text-primary" />
                                    <span class="text-sm text-primary font-medium">{{ __('services.new_plan') }}</span>
                                </div>
                                <span class="text-sm font-medium text-primary">{{ $upgradeProduct ? $upgradeProduct->name : __('general.select_plan') }}</span>
                            </div>
                        @endif

                        <div class="flex-col justify-between items-center p-4 bg-gradient-to-r from-green-400/20 via-green-500/10 to-green-400/20 rounded-xl border border-green-400/30 shadow-md relative overflow-hidden">
                            <svg class="absolute -top-4 -right-4 w-20 h-20 opacity-25 pointer-events-none z-0" viewBox="0 0 80 80" fill="none">
                                <defs>
                                    <radialGradient id="cornerGradient" cx="0.7" cy="0.3" r="1">
                                        <stop offset="0%" stop-color="#22c55e" stop-opacity="0.7"/>
                                        <stop offset="100%" stop-color="#22c55e" stop-opacity="0"/>
                                    </radialGradient>
                                </defs>
                                <circle cx="70" cy="10" r="40" fill="url(#cornerGradient)" />
                                <circle cx="60" cy="20" r="10" fill="#22c55e" fill-opacity="0.3"/>
                                <rect x="50" y="0" width="20" height="20" rx="6" fill="#22c55e" fill-opacity="0.15"/>
                            </svg>
                            <div class="flex items-center gap-2 z-10">
                                <x-ri-money-dollar-circle-fill class="size-5 text-green-600" />
                                <h4 class="text-lg font-semibold text-green-600">{{ __('services.total_today') }}</h4>
                            </div>
                            <span class="text-2xl font-bold text-green-600 z-10">{{ $this->totalToday() }}</span>
                        </div>
                    </div>

                    <div class="space-y-3">
                        <button wire:click="{{ ($upgradeProduct->upgradableConfigOptions()->count() > 0 && $step == 1) ? 'nextStep' : 'doUpgrade' }}" 
                                wire:loading.attr="disabled"
                                class="group/btn w-full inline-flex items-center justify-center gap-3 bg-primary hover:bg-primary/90 text-white px-6 py-4 rounded-xl font-semibold text-lg transition-all duration-300 hover:shadow-lg hover:shadow-primary/30 disabled:opacity-50 disabled:cursor-not-allowed">
                            <span wire:loading.remove>
                                @if($upgradeProduct && $upgradeProduct->upgradableConfigOptions()->count() > 0 && $step == 1)
                                    {{ __('services.next_step') }}
                                @else
                                    {{ __('services.upgrade') }}
                                @endif
                            </span>
                            <span wire:loading>Processing...</span>
                            <x-ri-arrow-right-fill class="size-5 transform transition-transform duration-300 group-hover/btn:translate-x-1" wire:loading.remove />
                            <x-ri-loader-4-fill class="size-5 animate-spin" wire:loading />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>