<div class="min-h-screen">
    @if(theme('homepage_layout', 'landing') === 'landing')
        <!-- Landing Page Layout -->
        
        <!-- Custom HTML Section -->
        @if(theme('custom_homepage_html'))
            <div class="custom-homepage-content">
                {!! theme('custom_homepage_html') !!}
            </div>
        @endif

        <section class="relative isolate overflow-hidden bg-gradient-to-b from-background-primary via-background to-background-secondary/50 pt-18 pb-32 px-8">
            @if(theme('background_image_url'))
            <div class="background-image-layer"
                 style="position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        min-height: 100%;
                        background-image: url('{{ theme('background_image_url') }}');
                        background-size: cover;
                        background-position: center;
                        background-repeat: no-repeat;
                        background-attachment: scroll;
                        opacity: {{ theme('background_image_opacity', 30) / 100 }};
                        filter: blur({{ theme('background_image_blur', 5) }}px);
                        z-index: -2;
                        pointer-events: none;
                        -webkit-mask-image: linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,0) 75%);
                        mask-image: linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,0) 75%);
                        -webkit-mask-repeat: no-repeat;
                        mask-repeat: no-repeat;
                        -webkit-mask-position: center;
                        mask-position: center;">
            </div>
            @endif

            <svg class="absolute inset-0 -z-10 h-full w-full stroke-primary/15 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]" aria-hidden="true">
                <defs>
                    <pattern id="grid-pattern" width="80" height="80" x="50%" y="-1" patternUnits="userSpaceOnUse">
                        <path d="M.5 80V.5H80" fill="none" />
                    </pattern>
                </defs>
                <rect width="100%" height="100%" strokeWidth="0" fill="url(#grid-pattern)" />
            </svg> 

            <div class="mt-20 container mx-auto px-4 lg:px-8">
                <div class="max-w-7xl lg:grid lg:grid-cols-12 lg:gap-x-8 lg:px-0">
                    <div class="lg:col-span-7 lg:px-0 lg:pt-4">
                        <div class="animate-fade-in-down mb-8">
                            <div class="inline-flex items-center gap-3 rounded-full bg-primary/10 border border-primary/20 px-5 py-2.5 backdrop-blur-sm">
                                <span class="relative flex h-2 w-2">
                                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                                    <span class="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                                </span>
                                <span class="text-sm font-semibold text-primary">{{ theme('homepage_hero_badge', 'Now 50% faster deployment!') }}</span>
                            </div>
                        </div>

                        <!-- Hero Title -->
                        <div class="mb-8">
                            <h1 class="text-5xl font-bold tracking-tight sm:text-6xl lg:text-7xl animate-fade-in-up">
                                {{ theme('homepage_hero_title1', 'The Best') }}
                            </h1>
                            <h1 class="text-5xl font-bold tracking-tight sm:text-6xl lg:text-7xl animate-fade-in-up animation-delay-100">
                                <span class="bg-gradient-to-r from-primary to-primary bg-clip-text text-transparent animate-gradient-x">
                                    {{ theme('homepage_hero_title2', 'Hosting') }}
                                </span>
                            </h1>
                        </div>

                        <!-- Hero Description -->
                        <div class="text-lg text-base/70 max-w-xl animate-fade-in-up animation-delay-200 leading-relaxed mb-10 prose dark:prose-invert">
                            {!! \Illuminate\Support\Str::markdown(theme('homepage_hero_desc', 'Experience next-gen game hosting with blazing-fast SSD performance, enterprise-grade security, and 24/7 expert support.')) !!}
                        </div>

                        <!-- CTA Buttons -->
                        <div class="flex flex-wrap gap-4 animate-fade-in-up animation-delay-300 mb-10">
                            <a href="#services" class="group inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-4 font-semibold text-white shadow-lg hover:bg-primary/90 transition-all duration-300 hover:scale-105">
                                <x-ri-rocket-line class="h-5 w-5" />
                                <span>{{ theme('hero_cta_primary_text', 'Get Started') }}</span>
                                <x-ri-arrow-right-line class="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                            </a>
                            <a href="#features" class="group inline-flex items-center gap-2 rounded-xl bg-secondary px-8 py-4 font-semibold text-white shadow-lg hover:bg-secondary/90 transition-all duration-300 hover:scale-105">
                                <x-ri-flashlight-line class="h-5 w-5" />
                                <span>{{ theme('hero_cta_secondary_text', 'Learn More') }}</span>
                            </a>
                        </div>

                        <div class="flex flex-wrap items-center gap-4 text-sm text-gray-400 animate-fade-in-up animation-delay-400 mb-10">
                            @php
                                $badgeDefaults = ['30-Day Guarantee', 'Instant Setup', 'Secure Payments'];
                            @endphp

                            @for ($i = 1; $i <= 3; $i++)
                                <div class="flex items-center gap-2 bg-success/10 px-3 py-1.5 rounded-full border border-success/30 text-success">
                                    <x-ri-check-line class="h-5 w-5 text-success" />
                                    <span>{{ theme("hero_trust_badge_{$i}", $badgeDefaults[$i - 1]) }}</span>
                                </div>
                            @endfor
                        </div>
                    </div>

                    <!-- Hero Image/Illustration -->
                    <div class="mt-16 sm:mt-24 lg:col-span-5 lg:mt-0">
                        <div class="relative mb-8">
                            @php
                                $heroImg = theme('homepage_hero_illustration_url') ?: 'https://pngimg.com/d/minecraft_PNG40.png';
                                $heroAlt = theme('homepage_hero_illustration_alt', 'Hero Illustration');
                            @endphp

                            <div class="absolute -inset-4 rounded-full bg-gradient-to-r from-primary/20 to-secondary/20 blur-2xl opacity-25 pointer-events-none"></div>
                            <img src="{{ $heroImg }}" alt="{{ $heroAlt }}" class="relative w-full h-auto object-contain animate-float" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="container mx-auto px-4">
                <div class="grid grid-cols-2 gap-6 lg:grid-cols-4">
                    <div class="group text-center p-6 rounded-2xl bg-gradient-to-br from-background-secondary to-background border border-neutral hover:border-success/50 transition-all duration-300 hover:scale-105">
                        <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-success/10 text-success mb-4">
                            <x-ri-time-line class="h-7 w-7" />
                        </div>
                        <div class="text-3xl font-bold text-success mb-2">99.9%</div>
                        <div class="text-sm font-semibold text-color-base">{{ theme('stats_uptime_title', 'Uptime') }}</div>
                        <div class="text-xs text-color-muted mt-1">{{ theme('stats_uptime_subtitle', 'Guaranteed') }}</div>
                    </div>

                    <div class="group text-center p-6 rounded-2xl bg-gradient-to-br from-background-secondary to-background border border-neutral hover:border-primary/50 transition-all duration-300 hover:scale-105">
                        <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 text-primary mb-4">
                            <x-ri-customer-service-line class="h-7 w-7" />
                        </div>
                        <div class="text-3xl font-bold text-primary mb-2">24/7</div>
                        <div class="text-sm font-semibold text-color-base">{{ theme('stats_support_title', 'Support') }}</div>
                        <div class="text-xs text-color-muted mt-1">{{ theme('stats_support_subtitle', 'Always available') }}</div>
                    </div>

                    <div class="group text-center p-6 rounded-2xl bg-gradient-to-br from-background-secondary to-background border border-neutral hover:border-purple-500/50 transition-all duration-300 hover:scale-105">
                        <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-purple-500/10 text-purple-500 mb-4">
                            <x-ri-user-heart-line class="h-7 w-7" />
                        </div>
                        <div class="text-3xl font-bold text-purple-500 mb-2">{{ number_format(\App\Models\User::count()) }}+</div>
                        <div class="text-sm font-semibold text-color-base">{{ theme('stats_users_title', 'Customers') }}</div>
                        <div class="text-xs text-color-muted mt-1">{{ theme('stats_users_subtitle', 'Worldwide') }}</div>
                    </div>

                    <div class="group text-center p-6 rounded-2xl bg-gradient-to-br from-background-secondary to-background border border-neutral hover:border-orange-500/50 transition-all duration-300 hover:scale-105">
                        <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-orange-500/10 text-orange-500 mb-4">
                            <x-ri-server-line class="h-7 w-7" />
                        </div>
                        <div class="text-3xl font-bold text-orange-500 mb-2">{{ number_format(\App\Models\Service::where('status', 'active')->count()) }}+</div>
                        <div class="text-sm font-semibold text-color-base">{{ theme('stats_servers_title', 'Servers') }}</div>
                        <div class="text-xs text-color-muted mt-1">{{ theme('stats_servers_subtitle', 'Active now') }}</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Features Section -->
        <section id="features" class="relative py-20 bg-gradient-to-b from-background-secondary/50 via-background to-background-secondary/30 px-8">
            <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-color-base mb-4">
                {{ theme('features_title', 'Powerful Features') }}
                </h2>
                <p class="text-lg text-color-muted max-w-2xl mx-auto">
                {{ theme('features_subtitle', 'Everything you need to succeed') }}
                </p>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="group p-8 rounded-2xl bg-gradient-to-br from-primary/5 to-transparent border border-primary/20 hover:border-primary/40 transition-all duration-300 hover:translate-y-[-4px]">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 text-primary mb-6">
                    <x-ri-shield-check-line class="h-6 w-6" />
                </div>
                <h3 class="text-xl font-bold text-color-base mb-3">{{ theme('feature_1_title', 'Military-Grade Security') }}</h3>
                <p class="text-color-muted leading-relaxed">{{ theme('feature_1_desc', 'Advanced DDoS protection and encrypted connections keep your servers safe 24/7.') }}</p>
                </div>

                <div class="group p-8 rounded-2xl bg-gradient-to-br from-secondary/5 to-transparent border border-secondary/20 hover:border-secondary/40 transition-all duration-300 hover:translate-y-[-4px]">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-secondary/10 text-secondary mb-6">
                    <x-ri-dashboard-line class="h-6 w-6" />
                </div>
                <h3 class="text-xl font-bold text-color-base mb-3">{{ theme('feature_2_title', 'Smart Analytics') }}</h3>
                <p class="text-color-muted leading-relaxed">{{ theme('feature_2_desc', 'Real-time monitoring and detailed insights help optimize your performance.') }}</p>
                </div>

                <div class="group p-8 rounded-2xl bg-gradient-to-br from-success/5 to-transparent border border-success/20 hover:border-success/40 transition-all duration-300 hover:translate-y-[-4px]">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-success/10 text-success mb-6">
                    <x-ri-flashlight-line class="h-6 w-6" />
                </div>
                <h3 class="text-xl font-bold text-color-base mb-3">{{ theme('feature_3_title', 'Lightning Setup') }}</h3>
                <p class="text-color-muted leading-relaxed">{{ theme('feature_3_desc', 'Deploy servers in under 60 seconds with automated setup system.') }}</p>
                </div>

                <div class="group p-8 rounded-2xl bg-gradient-to-br from-warning/5 to-transparent border border-warning/20 hover:border-warning/40 transition-all duration-300 hover:translate-y-[-4px]">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-warning/10 text-warning mb-6">
                    <x-ri-cpu-line class="h-6 w-6" />
                </div>
                <h3 class="text-xl font-bold text-color-base mb-3">{{ theme('feature_4_title', 'Extreme Performance') }}</h3>
                <p class="text-color-muted leading-relaxed">{{ theme('feature_4_desc', 'Premium NVMe SSD storage and high-frequency CPUs deliver zero-lag experience.') }}</p>
                </div>

                <div class="group p-8 rounded-2xl bg-gradient-to-br from-info/5 to-transparent border border-info/20 hover:border-info/40 transition-all duration-300 hover:translate-y-[-4px]">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-info/10 text-info mb-6">
                    <x-ri-global-line class="h-6 w-6" />
                </div>
                <h3 class="text-xl font-bold text-color-base mb-3">{{ theme('feature_5_title', 'Global Reach') }}</h3>
                <p class="text-color-muted leading-relaxed">{{ theme('feature_5_desc', '15+ datacenter locations ensure ultra-low latency worldwide.') }}</p>
                </div>

                <div class="group p-8 rounded-2xl bg-gradient-to-br from-error/5 to-transparent border border-error/20 hover:border-error/40 transition-all duration-300 hover:translate-y-[-4px]">
                <div class="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-error/10 text-error mb-6">
                    <x-ri-line-chart-line class="h-6 w-6" />
                </div>
                <h3 class="text-xl font-bold text-color-base mb-3">{{ theme('feature_6_title', 'AI-Powered') }}</h3>
                <p class="text-color-muted leading-relaxed">{{ theme('feature_6_desc', 'Machine learning algorithms continuously optimize server performance.') }}</p>
                </div>
            </div>
            </div>
        </section>

        <!-- Services Section -->
        <section id="services" class="relative py-20 bg-gradient-to-b from-background-secondary/30 via-background to-background/50 px-8">
            <div class="container mx-auto px-4">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-bold text-color-base mb-4">
                        {{ theme('services_title', 'Our Services') }}
                    </h2>
                    <p class="text-lg text-color-muted max-w-2xl mx-auto">
                        {{ theme('services_subtitle', 'Choose from our range of hosting solutions') }}
                    </p>
                </div>

                <div class="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    @foreach ($categories as $category)
                    <div class="group relative rounded-2xl bg-background-secondary border border-neutral hover:border-primary/50 overflow-hidden transition-all duration-300 hover:scale-[1.02]">
                        @if ($category->image)
                        <div class="relative h-48 overflow-hidden">
                            <img src="{{ Storage::url($category->image) }}" alt="{{ $category->name }}" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                            <div class="absolute inset-0 bg-gradient-to-t from-background-secondary to-transparent opacity-60"></div>
                        </div>
                        @endif
                        
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-color-base mb-2 group-hover:text-primary transition-colors">
                                {{ $category->name }}
                            </h3>
                            
                            @if(theme('show_category_description', true))
                            <div class="prose dark:prose-invert prose-sm text-color-muted mb-4 line-clamp-2">
                                {!! $category->description !!}
                            </div>
                            @endif
                            
                            <a href="{{ route('category.show', ['category' => $category->slug]) }}" wire:navigate class="inline-flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all">
                                <span>{{ __('common.button.view_all') }}</span>
                                <x-ri-arrow-right-line class="h-4 w-4" />
                            </a>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section class="relative py-20 bg-gradient-to-b from-background/50 via-background-secondary/20 to-background-secondary/40 px-8">
            <div class="container mx-auto px-4">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-bold text-color-base mb-4">
                        {{ theme('testimonials_title', 'What Customers Say') }}
                    </h2>
                    <p class="text-lg text-color-muted max-w-2xl mx-auto">
                        {{ theme('testimonials_subtitle', 'Join thousands of satisfied customers') }}
                    </p>
                </div>

                <div class="grid md:grid-cols-3 gap-8">
                    @for ($i = 1; $i <= 3; $i++)
                    <div class="p-8 rounded-2xl bg-background-secondary/80 border border-neutral hover:border-primary/30 transition-all duration-300">
                        <div class="flex items-center gap-4 mb-6">
                            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-white font-bold">
                                {{ substr(theme("testimonial_{$i}_name", 'Customer'), 0, 1) }}
                            </div>
                            <div>
                                <h4 class="font-bold text-color-base">{{ theme("testimonial_{$i}_name", 'Customer Name') }}</h4>
                                <p class="text-sm text-color-muted">{{ theme("testimonial_{$i}_role", 'Role') }}</p>
                            </div>
                        </div>
                        <p class="text-color-muted italic mb-4">"{{ theme("testimonial_{$i}_quote", 'Great service!') }}"</p>
                        <div class="flex gap-1">
                            @for ($j = 0; $j < 5; $j++)
                            <x-ri-star-fill class="h-4 w-4 text-warning" />
                            @endfor
                        </div>
                    </div>
                    @endfor
                </div>
            </div>
        </section>

        <!-- FAQ Section -->
        <section class="relative py-20 bg-gradient-to-b from-background-secondary/40 via-background to-background-secondary/20 px-8">
            <div class="container mx-auto px-4">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-bold text-color-base mb-4">
                        {{ theme('faq_title', 'Frequently Asked Questions') }}
                    </h2>
                    <p class="text-lg text-color-muted max-w-2xl mx-auto">
                        {{ theme('faq_subtitle', 'Find answers to common questions about our services') }}
                    </p>
                </div>

                <div class="max-w-7xl mx-auto w-full" x-data="{ openFaq: null }">
                    <div class="space-y-4">
                    @php
                        $faqs = [
                        [
                            'question' => 'How quickly can I get my server up and running?',
                            'answer' => 'Your server will be automatically deployed within 60 seconds after payment confirmation. Our automated system ensures instant setup with zero manual intervention required.'
                        ],
                        [
                            'question' => 'What payment methods do you accept?',
                            'answer' => 'We accept all major payment methods including credit/debit cards, PayPal, cryptocurrency, and local payment options. All transactions are secured with industry-standard encryption.'
                        ],
                        [
                            'question' => 'Can I upgrade or downgrade my plan anytime?',
                            'answer' => 'Yes! You can upgrade or downgrade your hosting plan at any time through your dashboard. Changes take effect immediately, and we\'ll pro-rate any pricing differences.'
                        ],
                        [
                            'question' => 'Do you offer refunds if I\'m not satisfied?',
                            'answer' => 'We offer a 30-day money-back guarantee. If you\'re not completely satisfied with our service within the first 30 days, contact our support team for a full refund.'
                        ],
                        [
                            'question' => 'What kind of support do you provide?',
                            'answer' => 'We provide 24/7 customer support through live chat, email, and ticket system. Our expert team is always ready to help you with technical issues, setup assistance, or any questions.'
                        ],
                        [
                            'question' => 'How do you handle DDoS attacks?',
                            'answer' => 'All our servers come with enterprise-grade DDoS protection that automatically detects and mitigates attacks in real-time, ensuring your server stays online even during large-scale attacks.'
                        ]
                        ];
                    @endphp

                    @foreach($faqs as $index => $faq)
                    <div class="group border border-neutral rounded-xl overflow-hidden bg-background-secondary hover:border-primary/30 transition-all duration-300">
                        <button 
                            @click="openFaq = openFaq === {{ $index }} ? null : {{ $index }}"
                            class="w-full flex items-center justify-between p-6 text-left"
                            :aria-expanded="openFaq === {{ $index }}"
                        >
                        <span class="text-lg font-semibold text-color-base pr-8">
                            {{ theme('faq_'.($index + 1).'_question', $faq['question']) }}
                        </span>
                        <span class="flex-shrink-0 transition-transform duration-300" 
                            :class="{ 'rotate-45': openFaq === {{ $index }} }">
                            <x-ri-add-line class="h-6 w-6 text-primary" />
                        </span>
                        </button>
                            <div 
                                x-show="openFaq === {{ $index }}"
                                x-collapse
                                class="overflow-hidden"
                            >
                            <div class="px-6 pb-6 text-color-muted leading-relaxed">
                                {{ theme('faq_'.($index + 1).'_answer', $faq['answer']) }}
                            </div>
                        </div>
                    </div>
                    @endforeach
                    </div>
                </div>
            </div>
        </section>

        <section class="relative bg-gradient-to-b from-background-secondary/20 via-background to-background-primary/30 py-24 overflow-hidden px-8">
            <div class="container mx-auto px-4">
            <div class="mx-auto w-full max-w-7xl bg-gradient-to-br from-primary/10 via-secondary/5 to-background border border-neutral/10 rounded-3xl p-8 sm:p-12 shadow-xl backdrop-blur-md">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                <div class="text-left">
                    <h2 class="text-3xl md:text-4xl font-bold mb-6">
                    <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                        {{ theme('cta_title', 'Ready to Get Started?') }}
                    </span>
                    </h2>
                    <p class="text-xl text-color-muted mb-0">
                    {{ theme('cta_subtitle', 'Join thousands of satisfied customers today') }}
                    </p>
                </div>

                <div class="flex justify-end">
                    <div class="flex flex-col sm:flex-row gap-4">
                    <a href="#services" class="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary to-secondary px-8 py-4 text-base font-semibold text-white shadow-lg hover:shadow-primary/50 transition-all duration-300 hover:scale-105">
                        <x-ri-sparkling-2-line class="h-5 w-5" />
                        <span>{{ theme('cta_primary_text', 'View Pricing') }}</span>
                    </a>
                    <a href="{{ theme('help_link', '#') }}" class="inline-flex items-center gap-2 rounded-xl bg-background border border-primary/30 px-8 py-4 text-base font-semibold text-color-base hover:border-primary/50 transition-all duration-300">
                        <x-ri-chat-3-line class="h-5 w-5" />
                        <span>{{ theme('cta_secondary_text', 'Contact Us') }}</span>
                    </a>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </section>

    @else
        <!-- Portal Page Layout -->
        
        <!-- Custom HTML Section -->
        @if(theme('custom_homepage_html'))
            <div class="custom-homepage-content">
                {!! theme('custom_homepage_html') !!}
            </div>
        @endif

        <!-- Compact Hero Section -->
        <section class="mt-20 relative py-16 border-b border-neutral">
            <div class="container mx-auto px-4">
                <div class="max-w-4xl mx-auto text-center">
                    <div class="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-2 mb-6">
                        <span class="relative flex h-2 w-2">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                        </span>
                        <span class="text-sm font-semibold text-primary">{{ theme('homepage_hero_badge', '🚀 Welcome!') }}</span>
                    </div>
                    
                    <h1 class="text-4xl md:text-5xl font-bold text-color-base mb-4">
                        {{ theme('homepage_hero_title1', 'The Best') }}
                        <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                            {{ theme('homepage_hero_title2', 'Hosting') }}
                        </span>
                    </h1>
                    
                    <p class="text-lg text-color-muted mb-8">
                        {!! \Illuminate\Support\Str::markdown(theme('homepage_hero_desc', 'Experience next-gen game hosting with blazing-fast SSD performance, enterprise-grade security, and 24/7 expert support.')) !!}
                    </p>
                </div>
            </div>
        </section>

        <!-- Quick Actions Portal -->
        <section class="py-12 bg-background">
            <div class="container mx-auto px-4">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <!-- Buy Server -->
                    <a href="{{ theme('buy_server_link', '#services') }}" class="group p-6 rounded-xl bg-gradient-to-br from-primary to-primary/80 text-white hover:shadow-xl hover:scale-105 transition-all duration-300">
                        <div class="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                            <x-ri-server-fill class="h-6 w-6" />
                        </div>
                        <h3 class="font-bold text-lg mb-1">{{ theme('buy_server_title', 'Buy Server') }}</h3>
                        <p class="text-sm text-white/80">{{ theme('buy_server_subtitle', 'Get started') }}</p>
                    </a>

                    <!-- Help/Support -->
                    <a href="{{ theme('help_link', '#') }}" target="_blank" class="group p-6 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 text-white hover:shadow-xl hover:scale-105 transition-all duration-300">
                        <div class="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                            <x-ri-customer-service-line class="h-6 w-6" />
                        </div>
                        <h3 class="font-bold text-lg mb-1">{{ theme('help_title', 'Support') }}</h3>
                        <p class="text-sm text-white/80">{{ theme('help_subtitle', '24/7 Help') }}</p>
                    </a>

                    <!-- Login/Dashboard -->
                    @guest
                    <a href="{{ route('login') }}" class="group p-6 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white hover:shadow-xl hover:scale-105 transition-all duration-300">
                        <div class="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                            <x-ri-login-box-line class="h-6 w-6" />
                        </div>
                        <h3 class="font-bold text-lg mb-1">{{ theme('login_title', 'Login') }}</h3>
                        <p class="text-sm text-white/80">{{ theme('login_subtitle', 'Access Panel') }}</p>
                    </a>
                    @else
                    <a href="{{ route('dashboard') }}" class="group p-6 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 text-white hover:shadow-xl hover:scale-105 transition-all duration-300">
                        <div class="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                            <x-ri-dashboard-fill class="h-6 w-6" />
                        </div>
                        <h3 class="font-bold text-lg mb-1">{{ theme('dashboard_title', 'Dashboard') }}</h3>
                        <p class="text-sm text-white/80">{{ theme('dashboard_subtitle', 'Manage') }}</p>
                    </a>
                    @endguest

                    <!-- Documentation -->
                    <a href="{{ theme('docs_link', '#') }}" target="_blank" class="group p-6 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 text-white hover:shadow-xl hover:scale-105 transition-all duration-300">
                        <div class="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                            <x-ri-book-open-line class="h-6 w-6" />
                        </div>
                        <h3 class="font-bold text-lg mb-1">{{ theme('docs_title', 'Docs') }}</h3>
                        <p class="text-sm text-white/80">{{ theme('docs_subtitle', 'Learn more') }}</p>
                    </a>
                </div>
            </div>
        </section>

        <!-- Stats Compact -->
        <section class="py-12 bg-background-secondary/50">
            <div class="container mx-auto px-4">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div class="text-center">
                        <div class="text-3xl font-bold text-success mb-1">99.9%</div>
                        <div class="text-sm text-color-muted">{{ theme('stats_uptime_title', 'Uptime') }}</div>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-primary mb-1">24/7</div>
                        <div class="text-sm text-color-muted">{{ theme('stats_support_title', 'Support') }}</div>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-purple-500 mb-1">{{ number_format(\App\Models\User::count()) }}+</div>
                        <div class="text-sm text-color-muted">{{ theme('stats_users_title', 'Users') }}</div>
                    </div>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-orange-500 mb-1">{{ number_format(\App\Models\Service::where('status', 'active')->count()) }}+</div>
                        <div class="text-sm text-color-muted">{{ theme('stats_servers_title', 'Servers') }}</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Grid (Portal Style) -->
        <section id="services" class="py-16 bg-background">
            <div class="container mx-auto px-4">
                <div class="mb-12">
                    <h2 class="text-3xl font-bold text-color-base mb-2">
                        {{ theme('services_title', 'Our Services') }}
                    </h2>
                    <p class="text-color-muted">
                        {{ theme('services_subtitle', 'Select a service to get started') }}
                    </p>
                </div>

                <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    @foreach ($categories as $category)
                    <a href="{{ route('category.show', ['category' => $category->slug]) }}" wire:navigate class="group block p-6 rounded-xl bg-background-secondary border border-neutral hover:border-primary/50 hover:shadow-lg transition-all duration-300">
                        @if ($category->image)
                        <div class="w-16 h-16 rounded-lg overflow-hidden mb-4">
                            <img src="{{ Storage::url($category->image) }}" alt="{{ $category->name }}" class="w-full h-full object-cover">
                        </div>
                        @else
                        <div class="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                            <x-ri-server-line class="h-8 w-8 text-primary" />
                        </div>
                        @endif
                        
                        <h3 class="text-lg font-bold text-color-base mb-2 group-hover:text-primary transition-colors">
                            {{ $category->name }}
                        </h3>
                        
                        @if(theme('show_category_description', true))
                        <div class="prose dark:prose-invert prose-sm text-color-muted mb-3 line-clamp-2">
                            {!! $category->description !!}
                        </div>
                        @endif
                        
                        <div class="flex items-center text-primary text-sm font-semibold">
                            <span>{{ __('common.button.view_all') }}</span>
                            <x-ri-arrow-right-line class="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" />
                        </div>
                    </a>
                    @endforeach
                </div>
            </div>
        </section>

        <!-- Features Compact Grid -->
        <section class="py-16 bg-background-secondary/30">
            <div class="container mx-auto px-4">
                <div class="mb-12">
                    <h2 class="text-3xl font-bold text-color-base mb-2">
                        {{ theme('features_title', 'Why Choose Us') }}
                    </h2>
                    <p class="text-color-muted">
                        {{ theme('features_subtitle', 'Premium features included') }}
                    </p>
                </div>

                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="flex gap-4 p-6 rounded-xl bg-background border border-neutral">
                        <div class="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <x-ri-shield-check-line class="h-5 w-5 text-primary" />
                        </div>
                        <div>
                            <h3 class="font-bold text-color-base mb-1">{{ theme('feature_1_title', 'Secure') }}</h3>
                            <p class="text-sm text-color-muted">{{ theme('feature_1_desc', 'Advanced security') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 p-6 rounded-xl bg-background border border-neutral">
                        <div class="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center flex-shrink-0">
                            <x-ri-flashlight-line class="h-5 w-5 text-secondary" />
                        </div>
                        <div>
                            <h3 class="font-bold text-color-base mb-1">{{ theme('feature_3_title', 'Fast Setup') }}</h3>
                            <p class="text-sm text-color-muted">{{ theme('feature_3_desc', 'Quick deployment') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 p-6 rounded-xl bg-background border border-neutral">
                        <div class="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center flex-shrink-0">
                            <x-ri-cpu-line class="h-5 w-5 text-warning" />
                        </div>
                        <div>
                            <h3 class="font-bold text-color-base mb-1">{{ theme('feature_4_title', 'Performance') }}</h3>
                            <p class="text-sm text-color-muted">{{ theme('feature_4_desc', 'High-speed servers') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 p-6 rounded-xl bg-background border border-neutral">
                        <div class="w-10 h-10 rounded-lg bg-info/10 flex items-center justify-center flex-shrink-0">
                            <x-ri-global-line class="h-5 w-5 text-info" />
                        </div>
                        <div>
                            <h3 class="font-bold text-color-base mb-1">{{ theme('feature_5_title', 'Global') }}</h3>
                            <p class="text-sm text-color-muted">{{ theme('feature_5_desc', 'Worldwide coverage') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 p-6 rounded-xl bg-background border border-neutral">
                        <div class="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center flex-shrink-0">
                            <x-ri-customer-service-line class="h-5 w-5 text-success" />
                        </div>
                        <div>
                            <h3 class="font-bold text-color-base mb-1">24/7 Support</h3>
                            <p class="text-sm text-color-muted">Always available</p>
                        </div>
                    </div>

                    <div class="flex gap-4 p-6 rounded-xl bg-background border border-neutral">
                        <div class="w-10 h-10 rounded-lg bg-error/10 flex items-center justify-center flex-shrink-0">
                            <x-ri-line-chart-line class="h-5 w-5 text-error" />
                        </div>
                        <div>
                            <h3 class="font-bold text-color-base mb-1">{{ theme('feature_6_title', 'Smart') }}</h3>
                            <p class="text-sm text-color-muted">{{ theme('feature_6_desc', 'AI optimization') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Testimonials Compact -->
        <section class="py-16 bg-background">
            <div class="container mx-auto px-4">
                <div class="mb-12">
                    <h2 class="text-3xl font-bold text-color-base mb-2">
                        {{ theme('testimonials_title', 'Testimonials') }}
                    </h2>
                    <p class="text-color-muted">
                        {{ theme('testimonials_subtitle', 'What our customers say') }}
                    </p>
                </div>

                <div class="grid md:grid-cols-3 gap-6">
                    @for ($i = 1; $i <= 3; $i++)
                    <div class="p-6 rounded-xl bg-background-secondary border border-neutral">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-white font-bold text-sm">
                                {{ substr(theme("testimonial_{$i}_name", 'User'), 0, 1) }}
                            </div>
                            <div>
                                <h4 class="font-semibold text-color-base text-sm">{{ theme("testimonial_{$i}_name", 'Customer') }}</h4>
                                <p class="text-xs text-color-muted">{{ theme("testimonial_{$i}_role", 'Role') }}</p>
                            </div>
                        </div>
                        <p class="text-sm text-color-muted italic mb-3">"{{ theme("testimonial_{$i}_quote", 'Great service!') }}"</p>
                        <div class="flex gap-1">
                            @for ($j = 0; $j < 5; $j++)
                            <x-ri-star-fill class="h-3 w-3 text-warning" />
                            @endfor
                        </div>
                    </div>
                    @endfor
                </div>
            </div>
        </section>

        <!-- CTA Compact -->
        <section class="py-16 bg-gradient-to-r from-primary/10 to-secondary/10">
            <div class="container mx-auto px-4">
                <div class="max-w-xl mx-auto text-center">
                    <h2 class="text-3xl font-bold mb-4">
                        <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                            {{ theme('cta_title', 'Ready to Start?') }}
                        </span>
                    </h2>
                    <p class="text-color-muted mb-8">
                        {{ theme('cta_subtitle', 'Host your Minecraft server with us today and experience unparalleled performance and support.') }}
                    </p>
                    <div class="flex gap-4 justify-center">
                        <a href="#services" class="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-white hover:bg-primary/90 transition-all">
                            <span>{{ theme('cta_primary_text', 'Get Started') }}</span>
                            <x-ri-arrow-right-line class="h-4 w-4" />
                        </a>
                        <a href="{{ theme('help_link', '#') }}" class="inline-flex items-center gap-2 rounded-xl bg-background-secondary border border-neutral px-6 py-3 text-sm font-semibold text-color-base hover:border-primary/50 transition-all">
                            <span>{{ theme('cta_secondary_text', 'Learn More') }}</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>

    @endif

    <!-- Hook Section -->
    <div class="container mx-auto my-12 px-10">
        {!! hook('pages.dashboard') !!}
    </div>
</div>

