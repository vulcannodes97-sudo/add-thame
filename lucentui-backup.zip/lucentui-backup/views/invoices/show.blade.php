<div class="mt-12 mx-auto px-8 py-8 rounded-2xl animate-fade-in-up">

    <div @if ($checkPayment || $invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Processing)->where('created_at', '>=', now()->subDays(1))->count() > 0) wire:poll.5s="checkPaymentStatus" @endif>
        @if ($this->pay || $showPayModal)
            @include('invoices.partials.payment-modal')
        @endif
    </div>

    <div class="relative overflow-hidden bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/30 rounded-2xl shadow-2xl backdrop-blur-sm mt-4 mb-8">

        <div class="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-primary/10 via-primary/5 to-transparent rounded-full blur-3xl opacity-60"></div>
        <div class="absolute -bottom-24 -left-24 w-72 h-72 bg-gradient-to-tr from-primary/8 via-primary/4 to-transparent rounded-full blur-2xl opacity-40"></div>
        
        <div class="relative z-10 p-8 lg:p-12">
            
            <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-12">
                <div class="mb-6 lg:mb-0">
                    <h1 class="text-4xl lg:text-4xl font-bold text-color-base leading-tight mb-2 bg-gradient-to-r from-color-base via-color-base to-primary bg-clip-text flex items-center">
                        {{ !$invoice->number && config('settings.invoice_proforma', false) ? __('invoices.proforma_invoice', ['id' => $invoice->id]) : __('invoices.invoice', ['id' => $invoice->number]) }}
                    </h1>
                    <div class="w-24 h-1 bg-gradient-to-r from-primary to-primary/60 rounded-full"></div>
                </div>
                <div class="flex items-center gap-4">
                    @if ($invoice->status == 'paid')
                        <div class="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-success/20 to-success/10 border border-success/30 rounded-2xl backdrop-blur-sm">
                            <x-ri-checkbox-circle-fill class="size-6 text-success" />
                            <span class="text-success font-bold text-lg">{{ __('invoices.paid') }}</span>
                        </div>
                    @elseif ($invoice->status == 'pending')
                        @if($checkPayment || $invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Processing)->where('created_at', '>=', now()->subDays(1))->count() > 0)
                            <div class="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-warning/20 to-warning/10 border border-warning/30 rounded-2xl backdrop-blur-sm">
                                <x-ri-loader-5-fill class="size-6 text-warning animate-spin" />
                                <span class="text-warning font-bold text-lg">{{ __('invoices.payment_processing') }}</span>
                            </div>
                        @else
                            <div class="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-warning/20 to-warning/10 border border-warning/30 rounded-2xl backdrop-blur-sm">
                                <x-ri-error-warning-fill class="size-6 text-warning" />
                                <span class="text-warning font-bold text-lg">{{ __('invoices.payment_pending') }}</span>
                            </div>
                        @endif
                    @endif
                    
                    <button wire:click="downloadPDF" class="group flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-primary to-primary/80 text-white font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-xl">
                        <x-ri-download-line class="size-5 transition-transform group-hover:scale-110" />
                        <span wire:loading wire:target="downloadPDF">
                            <x-ri-loader-5-fill class="size-6 animate-spin" />
                        </span>
                        <span wire:loading.remove wire:target="downloadPDF">{{ __('invoices.download_pdf') }}</span>
                    </button>
                </div>
            </div>

            <div class="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-12">
                
                <div class="bg-gradient-to-br from-background/80 to-background/60 border border-neutral/20 rounded-2xl p-6 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                    <div class="flex items-center gap-3 mb-4">
                        <x-ri-user-line class="size-6 text-primary" />
                        <h3 class="uppercase font-black text-color-base text-sm tracking-wider">{{ __('invoices.issued_to') }}</h3>
                    </div>
                    <div class="space-y-2">
                        <p class="text-color-base text-xl font-bold mb-2">{{ $invoice->user_name }}</p>
                        @foreach($invoice->user_properties as $property)
                            <p class="text-color-muted text-sm">{{ $property }}</p>
                        @endforeach
                    </div>
                </div>

                <div class="bg-gradient-to-br from-background/80 to-background/60 border border-neutral/20 rounded-2xl p-6 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                    <div class="flex items-center gap-3 mb-4">
                        <x-ri-building-line class="size-6 text-primary" />
                        <h3 class="uppercase font-black text-color-base text-sm tracking-wider">{{ __('invoices.bill_to') }}</h3>
                    </div>
                    <div class="space-y-2 uppercase font-bold">
                        {!! nl2br(e($invoice->bill_to)) !!}
                    </div>
                </div>

                <div class="bg-gradient-to-br from-background/80 to-background/60 border border-neutral/20 rounded-2xl p-6 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                    <div class="flex items-center gap-3 mb-4">
                        <x-ri-file-list-3-line class="size-6 text-primary" />
                        <h3 class="uppercase font-black text-color-base text-sm tracking-wider">Invoice Details</h3>
                    </div>
                    <div class="space-y-1">
                        <div class="flex items-center justify-between py-2 px-3 bg-background/50 rounded-xl">
                            <span class="text-color-muted text-sm font-medium">
                                {{ !$invoice->number && config('settings.invoice_proforma', false) ? __('invoices.proforma_invoice_date') : __('invoices.invoice_date') }}
                            </span>
                            <span class="font-bold text-color-base">{{ $invoice->created_at->format('d M Y') }}</span>
                        </div>
                        @if($invoice->number)
                            <div class="flex items-center justify-between py-2 px-3 bg-background/50 rounded-xl">
                                <span class="text-color-muted text-sm font-medium">{{ __('invoices.invoice_no')}}</span>
                                <span class="font-bold text-color-base">#{{ $invoice->number }}</span>
                            </div>
                        @endif
                        @if($invoice->due_at)
                            <div class="flex items-center justify-between py-2 px-3 bg-background/50 rounded-xl">
                                <span class="text-color-muted text-sm font-medium">{{ __('invoices.due_date') }}</span>
                                <span class="font-bold text-color-base">{{ $invoice->due_at->format('d M Y') }}</span>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            @if ($invoice->status == 'pending')
                <div class="bg-gradient-to-r from-background/60 to-background/40 border border-neutral/20 rounded-2xl p-8 mb-12 backdrop-blur-sm">
                    <h3 class="text-2xl font-bold text-color-base mb-6 flex items-center gap-3">
                        <x-ri-wallet-3-line class="size-6 text-primary" />
                        Payment Options
                    </h3>
                    
                    @if($invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Processing)->count() > 0)
                        <div class="p-4 bg-warning/10 border border-warning/30 rounded-xl mb-6">
                            <p class="text-warning text-sm font-medium">{{ __('invoices.duplicate_payment') }}</p>
                        </div>
                    @endif

                    <div role="region" aria-label="Payment options" class="p-6 bg-gradient-to-br from-background/70 to-background/50 border border-neutral/20 rounded-2xl shadow-sm">
                        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                            <div class="flex-1">
                                <div class="text-right">
                                    <p class="text-color-muted text-sm mb-1">Amount Due</p>
                                    <p class="text-3xl font-black text-primary">{{ $invoice->formattedRemaining }}</p>
                                    @if($invoice->due_at)
                                        <p class="text-color-muted text-sm mt-2">Due by <span class="font-semibold text-color-base">{{ $invoice->due_at->format('d M Y') }}</span></p>
                                    @endif
                                </div>

                                @if($invoice->note ?? false)
                                    <p class="mt-4 text-sm text-color-muted">{{ $invoice->note }}</p>
                                @endif
                            </div>

                            <div class="w-full sm:w-auto flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
                                <x-button.primary
                                    wire:click="$set('showPayModal', true)"
                                    wire:loading.attr="disabled"
                                    wire:target="$set('showPayModal')"
                                    class="flex-1 sm:flex-none py-2 px-6 text-sm font-bold rounded-lg transition-transform hover:scale-105"
                                    title="Open checkout modal"
                                    aria-label="Open checkout modal">
                                    <span wire:loading wire:target="$set('showPayModal')" class="flex items-center justify-center gap-2">
                                        <x-ri-loader-5-fill class="size-4 animate-spin" />
                                        Processing...
                                    </span>
                                    <span wire:loading.remove wire:target="$set('showPayModal')">{{ __('product.checkout') }}</span>
                                </x-button.primary>

                                @if ($checkPayment || $invoice->transactions->where('status', \App\Enums\InvoiceTransactionStatus::Processing)->count() > 0)
                                    <button
                                        wire:click="checkPaymentStatus"
                                        wire:loading.attr="disabled"
                                        wire:target="checkPaymentStatus"
                                        class="px-4 py-2 bg-background border border-neutral/30 hover:bg-background-secondary text-color-base rounded-lg transition-all duration-300 flex items-center gap-2"
                                        title="Check payment status"
                                        aria-live="polite">
                                        <x-ri-refresh-line class="size-4" wire:loading.remove wire:target="checkPaymentStatus" />
                                        <x-ri-loader-5-fill class="size-4 animate-spin" wire:loading wire:target="checkPaymentStatus" />
                                        <span wire:loading.remove wire:target="checkPaymentStatus" class="font-medium">Check Status</span>
                                        <span wire:loading wire:target="checkPaymentStatus">{{ __('invoices.checking_payment') }}</span>
                                    </button>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            <div class="mb-12">
                <h3 class="text-2xl font-bold text-color-base mb-6 flex items-center gap-3">
                    <x-ri-file-list-3-line class="size-6 text-primary" />
                    Invoice Items
                </h3>
                
                <div class="overflow-hidden border border-neutral/20 rounded-2xl backdrop-blur-sm">
                    <div class="overflow-x-auto">
                        <table class="min-w-full">
                            <thead>
                                <tr class="bg-gradient-to-r from-background to-background/80 border-b border-neutral/20">
                                    <th scope="col" class="px-8 py-6 text-left text-xs font-black text-color-base uppercase tracking-wider">
                                        {{ __('invoices.item') }}
                                    </th>
                                    <th scope="col" class="px-8 py-6 text-left text-xs font-black text-color-base uppercase tracking-wider">
                                        {{ __('invoices.price') }}
                                    </th>
                                    <th scope="col" class="px-8 py-6 text-left text-xs font-black text-color-base uppercase tracking-wider">
                                        {{ __('invoices.quantity') }}
                                    </th>
                                    <th scope="col" class="px-8 py-6 text-right text-xs font-black text-color-base uppercase tracking-wider">
                                        {{ __('invoices.total') }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-neutral/10">
                                @foreach ($invoice->items as $item)
                                    <tr class="bg-background-secondary/40 hover:bg-background-secondary/60 transition-all duration-300 group">
                                        <td class="px-8 py-6">
                                            <div class="flex items-center gap-3">
                                                <div class="w-1 h-8 bg-gradient-to-b from-primary to-primary/40 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                                                @if(in_array($item->reference_type, ['App\Models\Service', 'App\Models\ServiceUpgrade']))
                                                    <a href="{{ route('services.show', $item->reference_type == 'App\Models\Service' ? $item->reference_id : $item->reference->service_id) }}"
                                                        class="text-color-base font-bold hover:text-primary transition-colors duration-200 hover:underline underline-offset-2">
                                                        {{ $item->description }}
                                                    </a>
                                                @else
                                                    <span class="text-color-base font-bold">{{ $item->description }}</span>
                                                @endif
                                            </div>
                                        </td>
                                        <td class="px-8 py-6 text-color-base font-semibold">{{ $item->formattedPrice }}</td>
                                        <td class="px-8 py-6 text-color-base font-semibold">{{ $item->quantity }}</td>
                                        <td class="px-8 py-6 text-right text-color-base font-bold text-lg">{{ $item->formattedTotal }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="flex justify-end mb-12">
                <div class="w-full sm:w-96">
                    <div class="space-y-4">
                        @if ($invoice->formattedTotal->tax > 0)
                            <div class="flex justify-between items-center py-3 px-4 bg-background/40 rounded-xl">
                                <span class="text-color-muted font-bold uppercase text-sm tracking-wider">{{ __('invoices.subtotal') }}</span>
                                <span class="text-color-base font-bold text-lg">
                                    {{ $invoice->formattedTotal->format($invoice->formattedTotal->subtotal) }}
                                </span>
                            </div>
                            <div class="flex justify-between items-center py-3 px-4 bg-background/40 rounded-xl">
                                <span class="text-color-muted font-bold uppercase text-sm tracking-wider">
                                    {{ $invoice->tax->name }} ({{ $invoice->tax->rate }}%)
                                </span>
                                <span class="text-color-base font-bold text-lg">
                                    {{ $invoice->formattedTotal->formatted->tax }}
                                </span>
                            </div>
                        @endif
                        <div class="border-t border-neutral/20 pt-4">
                            <div class="flex justify-between items-center py-4 px-4 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl border border-primary/20">
                                <span class="text-color-base font-black uppercase text-lg tracking-wider">{{ __('invoices.total') }}</span>
                                <span class="text-primary font-black text-3xl">
                                    {{ $invoice->formattedTotal }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            @if ($invoice->transactions->isNotEmpty())
                <div class="mb-8">
                    <h3 class="text-2xl font-bold text-color-base mb-6 flex items-center gap-3">
                        <x-ri-exchange-dollar-line class="size-6 text-primary" />
                        {{ __('invoices.transactions') }}
                    </h3>
                    
                    <div class="overflow-hidden border border-neutral/20 rounded-2xl backdrop-blur-sm">
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead>
                                    <tr class="bg-gradient-to-r from-background to-background/80 border-b border-neutral/20">
                                        <th scope="col" class="px-8 py-6 text-left text-xs font-black text-color-base uppercase tracking-wider">
                                            {{ __('invoices.date') }}
                                        </th>
                                        <th scope="col" class="px-8 py-6 text-left text-xs font-black text-color-base uppercase tracking-wider">
                                            {{ __('invoices.transaction_id') }}
                                        </th>
                                        <th scope="col" class="px-8 py-6 text-left text-xs font-black text-color-base uppercase tracking-wider">
                                            {{ __('invoices.gateway') }}
                                        </th>
                                        <th scope="col" class="px-8 py-6 text-right text-xs font-black text-color-base uppercase tracking-wider">
                                            {{ __('invoices.amount') }}
                                        </th>
                                        <th scope="col" class="px-8 py-6 text-right text-xs font-black text-color-base uppercase tracking-wider">
                                            {{ __('invoices.status') }}
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-neutral/10">
                                    @foreach ($invoice->transactions->sortByDesc('created_at') as $transaction)
                                        <tr class="bg-background-secondary/40 hover:bg-background-secondary/60 transition-all duration-300 group">
                                            <td class="px-8 py-6 flex items-center gap-3">
                                                <div class="w-1 h-8 bg-gradient-to-b from-success to-success/40 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                                                <span class="text-color-base font-bold">{{ $transaction->created_at->format('d M Y H:i') }}</span>
                                            </td>
                                            <td class="px-8 py-6 text-color-base font-semibold">{{ $transaction->transaction_id }}</td>
                                            <td class="px-8 py-6 text-color-base font-semibold">
                                                @if($transaction->is_credit_transaction)
                                                    {{ __('invoices.paid_with_credits') }}
                                                @else
                                                    {{ $transaction->gateway?->name }}
                                                @endif
                                            </td>
                                            <td class="px-8 py-6 text-right text-color-base font-bold text-lg">{{ $transaction->formattedAmount }}</td>
                                            <td class="px-8 py-6 text-right">
                                                @if($transaction->status == \App\Enums\InvoiceTransactionStatus::Succeeded)
                                                    <span class="inline-flex items-center gap-2 px-3 py-1 bg-success/20 border border-success/30 text-success font-semibold rounded-full text-xs">
                                                        <x-ri-checkbox-circle-fill class="size-4" />
                                                        {{ __('invoices.transaction_statuses.succeeded') }}
                                                    </span>
                                                @elseif($transaction->status == \App\Enums\InvoiceTransactionStatus::Processing)
                                                    <span class="inline-flex items-center gap-2 px-3 py-1 bg-warning/20 border border-warning/30 text-warning font-semibold rounded-full text-xs">
                                                        <x-ri-loader-5-fill class="size-4 animate-spin" />
                                                        {{ __('invoices.transaction_statuses.processing') }}
                                                    </span>
                                                @elseif($transaction->status == \App\Enums\InvoiceTransactionStatus::Failed)
                                                    <span class="inline-flex items-center gap-2 px-3 py-1 bg-error/20 border border-error/30 text-error font-semibold rounded-full text-xs">
                                                        <x-ri-close-circle-fill class="size-4" />
                                                        {{ __('invoices.transaction_statuses.failed') }}
                                                    </span>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>