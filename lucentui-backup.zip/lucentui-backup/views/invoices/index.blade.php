<div class="mt-18 mx-auto px-8 py-8 rounded-2xl animate-fade-in-up" x-data="{
    search: '', 
    statusFilter: 'all',
    get filteredInvoices() {
        const searchTerm = this.search.toLowerCase();
        const status = this.statusFilter;
        
        return Array.from(this.$refs.invoicesContainer?.children || [])
            .filter(child => child.tagName === 'A')
            .filter(child => {
                // Status filter
                if (status !== 'all' && child.dataset.status !== status) {
                    return false;
                }
                
                // Search filter
                if (this.search) {
                    const invoiceNumber = child.dataset.invoiceNumber?.toLowerCase() || '';
                    return invoiceNumber.includes(searchTerm);
                }
                
                return true;
            }).length > 0;
    },
    get visibleInvoicesCount() {
        const searchTerm = this.search.toLowerCase();
        const status = this.statusFilter;
        
        return Array.from(this.$refs.invoicesContainer?.children || [])
            .filter(child => child.tagName === 'A')
            .filter(child => {
                // Status filter
                if (status !== 'all' && child.dataset.status !== status) {
                    return false;
                }
                
                // Search filter
                if (this.search) {
                    const invoiceNumber = child.dataset.invoiceNumber?.toLowerCase() || '';
                    return invoiceNumber.includes(searchTerm);
                }
                
                return true;
            }).length;
    }
}">

    <h1 class="text-3xl lg:text-4xl font-extrabold text-color-base mt-4 mb-8">
        {{ __('navigation.invoices') }}
    </h1>

    {{-- Search Input --}}
    <div class="mb-8">
        <div class="relative">
            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <svg class="w-5 h-5 text-gray-400 transition-colors duration-200" 
                     :class="search ? 'text-primary' : 'text-gray-400'"
                     xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                </svg>
            </div>
            <input
                x-model.debounce.300ms="search"
                type="text"
                placeholder="{{ __('Search by invoice number...') }}"
                class="w-full pl-11 pr-4 py-3 bg-background-secondary/40 border border-neutral/50 rounded-xl focus:ring-2 focus:ring-primary focus:border-primary transition-all duration-300 hover:bg-background-secondary/60 focus:bg-background-secondary/70"
            >
            {{-- Clear search button --}}
            <button x-show="search" 
                    x-cloak
                    @click="search = ''"
                    class="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-primary transition-colors duration-200">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
        
        {{-- Filter Status Info --}}
        <div x-show="search || statusFilter !== 'all'" 
             x-cloak 
             class="mt-2 text-sm text-color-muted transition-all duration-300 transform"
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 -translate-y-1"
             x-transition:enter-end="opacity-100 translate-y-0">
            <span x-show="search && statusFilter !== 'all'">
                Showing <span class="font-bold text-primary" x-text="visibleInvoicesCount"></span> results for "<strong class="text-primary" x-text="search"></strong>" in <strong class="text-primary capitalize" x-text="statusFilter"></strong> invoices
            </span>
            <span x-show="search && statusFilter === 'all'">
                Showing <span class="font-bold text-primary" x-text="visibleInvoicesCount"></span> results for "<strong class="text-primary" x-text="search"></strong>"
            </span>
            <span x-show="!search && statusFilter !== 'all'">
                Showing <span class="font-bold text-primary" x-text="visibleInvoicesCount"></span> <strong class="text-primary capitalize" x-text="statusFilter"></strong> invoices
            </span>
        </div>
    </div>

    {{-- Status Filter Cards --}}
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12 bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 p-4 rounded-xl">
        {{-- All Invoices --}}
        <button @click="statusFilter = 'all'" 
                class="bg-primary/10 border border-primary/50 rounded-xl p-4 text-center hover:bg-primary/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'all' ? 'ring-2 ring-primary bg-primary/25 scale-105 shadow-lg shadow-primary/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-apps-line class="size-6 text-primary mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-primary">{{ $invoices->count() }}</span>
            </div>
            <p class="text-sm font-medium text-primary">All Invoices</p>
        </button>

        {{-- Paid Invoices --}}
        <button @click="statusFilter = 'paid'" 
                class="bg-success/10 border border-success/50 rounded-xl p-4 text-center hover:bg-success/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'paid' ? 'ring-2 ring-success bg-success/25 scale-105 shadow-lg shadow-success/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-checkbox-circle-fill class="size-6 text-success mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-success">{{ $invoices->where('status', 'paid')->count() }}</span>
            </div>
            <p class="text-sm font-medium text-success">{{ __('Paid') }}</p>
        </button>

        {{-- Pending Invoices --}}
        <button @click="statusFilter = 'pending'" 
                class="bg-warning/10 border border-warning/50 rounded-xl p-4 text-center hover:bg-warning/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'pending' ? 'ring-2 ring-warning bg-warning/25 scale-105 shadow-lg shadow-warning/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-error-warning-fill class="size-6 text-warning mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-warning">{{ $invoices->where('status', 'pending')->count() }}</span>
            </div>
            <p class="text-sm font-medium text-warning">{{ __('Pending') }}</p>
        </button>

        {{-- Cancelled Invoices --}}
        <button @click="statusFilter = 'cancelled'" 
                class="bg-inactive/10 border border-inactive/50 rounded-xl p-4 text-center hover:bg-inactive/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'cancelled' ? 'ring-2 ring-inactive bg-inactive/25 scale-105 shadow-lg shadow-inactive/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-close-circle-fill class="size-6 text-inactive mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-inactive">{{ $invoices->where('status', 'cancelled')->count() }}</span>
            </div>
            <p class="text-sm font-medium text-inactive">{{ __('Cancelled') }}</p>
        </button>
    </div>

    {{-- Invoices List --}}
    <div class="grid grid-cols-1 gap-3 md:gap-5" x-ref="invoicesContainer">
        @forelse ($invoices as $invoice)
            <a href="{{ route('invoices.show', $invoice) }}"
               wire:navigate
               class="block"
               data-invoice-number="{{ strtolower($invoice->number) }}"
               data-status="{{ $invoice->status }}"
               x-show="(statusFilter === 'all' || '{{ $invoice->status }}' === statusFilter) && (search === '' || '{{ strtolower($invoice->number) }}'.includes(search.toLowerCase()))"
               x-transition:enter="transition ease-out duration-500 delay-75"
               x-transition:enter-start="opacity-0 transform scale-95 -translate-y-4"
               x-transition:enter-end="opacity-100 transform scale-100 translate-y-0"
               x-transition:leave="transition ease-in duration-300"
               x-transition:leave-start="opacity-100 transform scale-100 translate-y-0"
               x-transition:leave-end="opacity-0 transform scale-95 -translate-y-2"
            >
                <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 hover:from-background-secondary/70 hover:to-background-secondary/50 border border-neutral/50 p-6 rounded-xl shadow-lg
                            transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl hover:border-primary/50 hover:shadow-primary/10
                            flex flex-col md:flex-row items-start md:items-center justify-between gap-4 group">

                    <div class="flex items-start md:items-center gap-4 flex-grow">
                        <div class="bg-primary/10 p-3 rounded-full flex-shrink-0 shadow-sm group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300">
                            <x-ri-bill-line class="size-6 text-primary group-hover:text-primary/80 transition-colors duration-300" /> 
                        </div>
                        <div class="flex flex-col">
                            <span class="text-xl font-bold text-color-base leading-tight group-hover:text-primary transition-colors duration-300">{{ !$invoice->number && config('settings.invoice_proforma', false) ? __('invoices.proforma_invoice', ['id' => $invoice->id]) : __('invoices.invoice', ['id' => $invoice->number]) }}</span>
                            <p class="text-color-muted text-sm mt-1 group-hover:text-color-base transition-colors duration-300">
                                {{ __('Total') }}: <span class="font-bold text-primary">{{ $invoice->formattedTotal }}</span>
                                <span class="mx-2 text-color-muted/50">•</span> 
                                {{ __('invoices.invoice_date') }}: {{ $invoice->created_at->format('d M Y') }}
                            </p>
                            @if($invoice->due_date)
                                <p class="text-xs text-warning mt-1 group-hover:text-warning/80 transition-colors duration-300">
                                    <span class="font-extrabold">{{ __('Jatuh Tempo') }}: </span><span class="font-medium">{{ $invoice->due_date->format('d M Y') }}</span>
                                </p>
                            @endif
                        </div>
                    </div>

                    <div class="flex items-center gap-3 flex-shrink-0 mt-3 md:mt-0">
                        <div class="text-sm font-semibold px-3 py-1 rounded-full flex items-center gap-1.5 transition-all duration-300 group-hover:scale-105
                            @if ($invoice->status == 'paid') text-success bg-success/20 group-hover:bg-success/30
                            @elseif($invoice->status == 'cancelled') text-inactive bg-inactive/20 group-hover:bg-inactive/30
                            @else text-warning bg-warning/20 group-hover:bg-warning/30
                            @endif">
                            @if ($invoice->status == 'paid')
                                <x-ri-checkbox-circle-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" />
                                {{ __('Paid') }}
                            @elseif($invoice->status == 'cancelled')
                                <x-ri-close-circle-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" /> 
                                {{ __('Cancelled') }}
                            @elseif($invoice->status == 'pending')
                                <x-ri-error-warning-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" />
                                {{ __('Pending') }}
                            @endif
                        </div>
                        <x-ri-arrow-right-s-line class="size-6 text-color-muted group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                    </div>
                </div>
            </a>
        @empty
            <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 rounded-xl shadow-lg p-6 lg:p-8 border border-neutral/50 text-center">
                <x-ri-file-info-line class="size-16 text-color-muted mx-auto mb-4 opacity-60" />
                <h3 class="text-xl font-bold text-color-base mb-2">No invoices yet.</h3>
            </div>
        @endforelse

        {{-- No Results Found --}}
        @if($invoices->isNotEmpty())
        <div x-show="(search !== '' || statusFilter !== 'all') && !filteredInvoices"
             x-cloak
             class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 rounded-xl shadow-lg p-6 lg:p-8 border border-neutral/50 text-center"
             x-transition:enter="transition ease-out duration-500 delay-200"
             x-transition:enter-start="opacity-0 transform scale-95 -translate-y-4"
             x-transition:enter-end="opacity-100 transform scale-100 translate-y-0"
             x-transition:leave="transition ease-in duration-300"
             x-transition:leave-start="opacity-100 transform scale-100 translate-y-0"
             x-transition:leave-end="opacity-0 transform scale-95 -translate-y-2">
            <x-ri-search-2-line class="size-16 text-color-muted mx-auto mb-4 opacity-60 animate-pulse" />
            <h3 class="text-xl font-bold text-color-base mb-2">No Invoices Found</h3>
            
            {{-- Dynamic messages based on active filters --}}
            <div x-show="search && statusFilter !== 'all'">
                <p class="text-color-muted mb-4">
                    No <strong class="text-primary capitalize" x-text="statusFilter"></strong> invoices match "<strong class="text-primary" x-text="search"></strong>"
                </p>
            </div>
            <div x-show="search && statusFilter === 'all'">
                <p class="text-color-muted mb-4">
                    Your search for "<strong class="text-primary" x-text="search"></strong>" did not match any invoices.
                </p>
            </div>
            <div x-show="!search && statusFilter !== 'all'">
                <p class="text-color-muted mb-4">
                    No <strong class="text-primary capitalize" x-text="statusFilter"></strong> invoices found.
                </p>
            </div>
            
            {{-- Clear filter buttons --}}
            <div class="flex gap-2 justify-center flex-wrap">
                <button x-show="search" 
                        @click="search = ''" 
                        class="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition-all duration-300 hover:scale-105">
                    <x-ri-close-line class="size-4" />
                    Clear Search
                </button>
                <button x-show="statusFilter !== 'all'" 
                        @click="statusFilter = 'all'" 
                        class="inline-flex items-center gap-2 px-4 py-2 bg-secondary/10 hover:bg-secondary/20 text-secondary rounded-lg transition-all duration-300 hover:scale-105">
                    <x-ri-filter-off-line class="size-4" />
                    Show All
                </button>
            </div>
        </div>
        @endif

        {{-- Pagination (only show when no filters active) --}}
        <div x-show="search === '' && statusFilter === 'all'" 
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100">
            {{ $invoices->links() }}
        </div>
    </div>
</div>