<div class="mt-18 mx-auto px-8 py-8 rounded-2xl animate-fade-in-up" x-data="{
    search: '', 
    statusFilter: 'all',
    get filteredTickets() {
        const searchTerm = this.search.toLowerCase();
        const status = this.statusFilter;
        
        return Array.from(this.$refs.ticketsContainer?.children || [])
            .filter(child => child.tagName === 'A')
            .filter(child => {
                // Status filter
                if (status !== 'all' && child.dataset.status !== status) {
                    return false;
                }
                
                // Search filter
                if (this.search) {
                    const ticketSubject = child.dataset.ticketSubject?.toLowerCase() || '';
                    return ticketSubject.includes(searchTerm);
                }
                
                return true;
            }).length > 0;
    },
    get visibleTicketsCount() {
        const searchTerm = this.search.toLowerCase();
        const status = this.statusFilter;
        
        return Array.from(this.$refs.ticketsContainer?.children || [])
            .filter(child => child.tagName === 'A')
            .filter(child => {
                // Status filter
                if (status !== 'all' && child.dataset.status !== status) {
                    return false;
                }
                
                // Search filter
                if (this.search) {
                    const ticketSubject = child.dataset.ticketSubject?.toLowerCase() || '';
                    return ticketSubject.includes(searchTerm);
                }
                
                return true;
            }).length;
    }
}">

    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <h1 class="text-3xl lg:text-4xl font-extrabold text-color-base">
            {{ __('ticket.tickets') }}
        </h1>
        <x-navigation.link :href="route('tickets.create')" class="inline-flex items-center justify-center px-5 py-2 border border-transparent text-base font-medium rounded-full shadow-sm text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors duration-200 order-first md:order-last">
            <x-ri-add-line class="size-5 mr-2" />
            <span>{{ __('ticket.create_ticket') }}</span>
        </x-navigation.link>
    </div>

    {{-- Search Input --}}
    <div class="mb-8">
        <div class="relative">
            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <svg class="w-5 h-5 text-gray-400 transition-colors duration-200" 
                     :class="search ? 'text-primary' : 'text-gray-400'"
                     xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
                </svg>
            </div>
            <input
                x-model.debounce.300ms="search"
                type="text"
                placeholder="{{ __('Search by ticket subject...') }}"
                class="w-full pl-11 pr-4 py-3 bg-background-secondary/40 border border-neutral/50 rounded-xl focus:ring-2 focus:ring-primary focus:border-primary transition-all duration-300 hover:bg-background-secondary/60 focus:bg-background-secondary/70"
            >
            <button x-show="search" 
                    x-cloak
                    @click="search = ''"
                    class="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-primary transition-colors duration-200">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
        
        {{-- Filter Status Info --}}
        <div x-show="search || statusFilter !== 'all'" 
             x-cloak 
             class="mt-2 text-sm text-color-muted transition-all duration-300 transform"
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 -translate-y-1"
             x-transition:enter-end="opacity-100 translate-y-0">
            <span x-show="search && statusFilter !== 'all'">
                Showing <span class="font-bold text-primary" x-text="visibleTicketsCount"></span> results for "<strong class="text-primary" x-text="search"></strong>" in <strong class="text-primary capitalize" x-text="statusFilter"></strong> tickets
            </span>
            <span x-show="search && statusFilter === 'all'">
                Showing <span class="font-bold text-primary" x-text="visibleTicketsCount"></span> results for "<strong class="text-primary" x-text="search"></strong>"
            </span>
            <span x-show="!search && statusFilter !== 'all'">
                Showing <span class="font-bold text-primary" x-text="visibleTicketsCount"></span> <strong class="text-primary capitalize" x-text="statusFilter"></strong> tickets
            </span>
        </div>
    </div>

    {{-- Status Filter Cards --}}
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12 bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 border border-neutral/50 p-4 rounded-xl">
        {{-- All Tickets --}}
        <button @click="statusFilter = 'all'" 
                class="bg-primary/10 border border-primary/50 rounded-xl p-4 text-center hover:bg-primary/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'all' ? 'ring-2 ring-primary bg-primary/25 scale-105 shadow-lg shadow-primary/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-apps-line class="size-6 text-primary mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-primary">{{ $tickets->count() }}</span>
            </div>
            <p class="text-sm font-medium text-primary">All Tickets</p>
        </button>

        {{-- Open Tickets --}}
        <button @click="statusFilter = 'open'" 
                class="bg-success/10 border border-success/50 rounded-xl p-4 text-center hover:bg-success/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'open' ? 'ring-2 ring-success bg-success/25 scale-105 shadow-lg shadow-success/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-add-circle-fill class="size-6 text-success mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-success">{{ $tickets->where('status', 'open')->count() }}</span>
            </div>
            <p class="text-sm font-medium text-success">Open</p>
        </button>

        {{-- Replied Tickets --}}
        <button @click="statusFilter = 'replied'" 
                class="bg-info/10 border border-info/50 rounded-xl p-4 text-center hover:bg-info/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'replied' ? 'ring-2 ring-info bg-info/25 scale-105 shadow-lg shadow-info/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-chat-smile-2-fill class="size-6 text-info mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-info">{{ $tickets->where('status', 'replied')->count() }}</span>
            </div>
            <p class="text-sm font-medium text-info">Replied</p>
        </button>

        {{-- Closed Tickets --}}
        <button @click="statusFilter = 'closed'" 
                class="bg-inactive/10 border border-inactive/50 rounded-xl p-4 text-center hover:bg-inactive/20 transition-all duration-300 cursor-pointer group"
                :class="statusFilter === 'closed' ? 'ring-2 ring-inactive bg-inactive/25 scale-105 shadow-lg shadow-inactive/20' : ''">
            <div class="flex items-center justify-center mb-2">
                <x-ri-forbid-fill class="size-6 text-inactive mr-2 transition-transform duration-300 group-hover:scale-110" />
                <span class="text-2xl font-bold text-inactive">{{ $tickets->where('status', 'closed')->count() }}</span>
            </div>
            <p class="text-sm font-medium text-inactive">Closed</p>
        </button>
    </div>


    <div class="grid grid-cols-1 gap-6 md:gap-8" x-ref="ticketsContainer">
        @forelse ($tickets as $ticket)
        <a href="{{ route('tickets.show', $ticket) }}" 
           wire:navigate 
           class="block group"
           data-ticket-subject="{{ strtolower($ticket->subject) }}"
           data-status="{{ $ticket->status }}"
           x-show="(statusFilter === 'all' || '{{ $ticket->status }}' === statusFilter) && (search === '' || '{{ strtolower($ticket->subject) }}'.includes(search.toLowerCase()))"
           x-transition:enter="transition ease-out duration-500 delay-75"
           x-transition:enter-start="opacity-0 transform scale-95 -translate-y-4"
           x-transition:enter-end="opacity-100 transform scale-100 translate-y-0"
           x-transition:leave="transition ease-in duration-300"
           x-transition:leave-start="opacity-100 transform scale-100 translate-y-0"
           x-transition:leave-end="opacity-0 transform scale-95 -translate-y-2"
        >
            <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 hover:from-background-secondary/70 hover:to-background-secondary/50 border border-neutral/50 p-6 rounded-xl shadow-lg
                        transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl hover:border-primary/50 hover:shadow-primary/10
                        flex flex-col md:flex-row items-start md:items-center justify-between gap-4">

                <div class="flex items-start md:items-center gap-4 flex-grow">
                    <div class="bg-primary/10 p-3 rounded-full flex-shrink-0 shadow-sm group-hover:bg-primary/20 group-hover:scale-110 transition-all duration-300">
                        <x-ri-ticket-line class="size-6 text-primary group-hover:text-primary/80 transition-colors duration-300" />
                    </div>
                    
                    <div class="flex flex-col">
                        <span class="text-xl font-bold text-color-base leading-tight group-hover:text-primary transition-colors duration-200">
                            #{{ $ticket->id }} - {{ $ticket->subject }}
                        </span>
                        <p class="text-color-muted text-sm mt-1 group-hover:text-color-base transition-colors duration-300">
                            {{ __('ticket.last_activity') }}: 
                            {{ $ticket->messages()->orderBy('created_at', 'desc')->first()->created_at->diffForHumans() }}
                            @if($ticket->department)
                                <span class="mx-2 text-color-muted/50">•</span> {{ $ticket->department }}
                            @endif
                        </p>
                    </div>
                </div>

                <div class="flex items-center gap-3 flex-shrink-0 mt-3 md:mt-0">
                    <div class="text-sm font-semibold px-3 py-1 rounded-full flex items-center gap-1.5 transition-all duration-300 group-hover:scale-105
                        @if ($ticket->status == 'open') text-success bg-success/20 group-hover:bg-success/30
                        @elseif($ticket->status == 'closed') text-inactive bg-inactive/20 group-hover:bg-inactive/30
                        @elseif($ticket->status == 'replied') text-info bg-info/20 group-hover:bg-info/30
                        @else text-warning bg-warning/20 group-hover:bg-warning/30
                        @endif">
                        @if ($ticket->status == 'open')
                            <x-ri-add-circle-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" />
                            Open
                        @elseif($ticket->status == 'closed')
                            <x-ri-forbid-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" />
                            Closed
                        @elseif($ticket->status == 'replied')
                            <x-ri-chat-smile-2-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" />
                            Replied
                        @else
                            <x-ri-error-warning-fill class="size-4 transition-transform duration-300 group-hover:rotate-12" />
                            {{ ucfirst($ticket->status) }} 
                        @endif
                    </div>
                    <x-ri-arrow-right-s-line class="size-6 text-color-muted group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                </div>
            </div>
        </a>
        @empty
        <div class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 rounded-xl shadow-lg p-6 lg:p-8 border border-neutral/50 text-center">
            <x-ri-inbox-line class="size-16 text-color-muted mx-auto mb-4 opacity-60" />
            <h3 class="text-xl font-bold text-color-base mb-2">No Tickets yet.</h3>
        </div>
        @endforelse

        {{-- No Results Found --}}
        @if($tickets->isNotEmpty())
        <div x-show="(search !== '' || statusFilter !== 'all') && !filteredTickets"
             x-cloak
             class="bg-gradient-to-br from-background-secondary/50 to-background-secondary/30 rounded-xl shadow-lg p-6 lg:p-8 border border-neutral/50 text-center"
             x-transition:enter="transition ease-out duration-500 delay-200"
             x-transition:enter-start="opacity-0 transform scale-95 -translate-y-4"
             x-transition:enter-end="opacity-100 transform scale-100 translate-y-0"
             x-transition:leave="transition ease-in duration-300"
             x-transition:leave-start="opacity-100 transform scale-100 translate-y-0"
             x-transition:leave-end="opacity-0 transform scale-95 -translate-y-2">
            <x-ri-search-2-line class="size-16 text-color-muted mx-auto mb-4 opacity-60 animate-pulse" />
            <h3 class="text-xl font-bold text-color-base mb-2">{{ __('ticket.no_tickets') }}</h3>
            
            {{-- Dynamic messages --}}
            <div x-show="search && statusFilter !== 'all'">
                <p class="text-color-muted mb-4">
                    No <strong class="text-primary capitalize" x-text="statusFilter"></strong> tickets match "<strong class="text-primary" x-text="search"></strong>"
                </p>
            </div>
            <div x-show="search && statusFilter === 'all'">
                <p class="text-color-muted mb-4">
                    Your search for "<strong class="text-primary" x-text="search"></strong>" did not match any tickets.
                </p>
            </div>
            <div x-show="!search && statusFilter !== 'all'">
                <p class="text-color-muted mb-4">
                    No <strong class="text-primary capitalize" x-text="statusFilter"></strong> tickets found.
                </p>
            </div>
            
            {{-- Clear filter buttons --}}
            <div class="flex gap-2 justify-center flex-wrap">
                <button x-show="search" 
                        @click="search = ''" 
                        class="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition-all duration-300 hover:scale-105">
                    <x-ri-close-line class="size-4" />
                    Clear Search
                </button>
                <button x-show="statusFilter !== 'all'" 
                        @click="statusFilter = 'all'" 
                        class="inline-flex items-center gap-2 px-4 py-2 bg-secondary/10 hover:bg-secondary/20 text-secondary rounded-lg transition-all duration-300 hover:scale-105">
                    <x-ri-filter-off-line class="size-4" />
                    Show All
                </button>
            </div>
        </div>
        @endif

        {{-- Pagination (only show when no filters active) --}}
        <div x-show="search === '' && statusFilter === 'all'" 
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0"
             x-transition:enter-end="opacity-100">
            {{ $tickets->links() }}
        </div>
    </div>
</div>