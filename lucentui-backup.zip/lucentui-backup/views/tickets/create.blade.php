<div class="mt-20 container mx-auto px-8 py-8">
    <h1 class="text-3xl lg:text-4xl font-extrabold text-color-base mt-4 mb-8">
        {{ __('ticket.create_ticket') }}
    </h1>

    <form wire:submit.prevent="create">
        <div class="bg-background-secondary/70 border border-neutral/50 p-6 rounded-2xl shadow-lg">
            <h2 class="text-2xl font-bold text-color-base mb-6">{{ __('ticket.ticket_details') }}</h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                <x-form.input wire:model="subject" label="{{ __('ticket.subject') }}" name="subject" required />

                @if (count($departments) > 0)
                    <x-form.select wire:model="department" label="{{ __('ticket.department') }}" name="department" required>
                        <option value="">{{ __('ticket.select_department') }}</option>
                        @foreach ($departments as $departmentOption) 
                            <option value="{{ $departmentOption }}">{{ $departmentOption }}</option>
                        @endforeach
                    </x-form.select>
                @endif

                <x-form.select wire:model="priority" label="{{ __('ticket.priority') }}" name="priority" required>
                    <option value="">{{ __('ticket.select_priority') }}</option>
                    <option value="low">{{ __('ticket.low') }}</option>
                    <option value="medium">{{ __('ticket.medium') }}</option>
                    <option value="high">{{ __('ticket.high') }}</option>
                </x-form.select>

                <x-form.select wire:model="service" label="{{ __('ticket.service') }}" name="service">
                    <option value="">{{ __('ticket.select_service') }}</option>
                    @foreach ($services as $product)
                        <option value="{{ $product->id }}">{{ $product->product->name }} ({{ ucfirst($product->status) }})
                            @if ($product->expires_at)
                                - {{ $product->expires_at->format('Y-m-d') }}
                            @endif
                        </option>
                    @endforeach
                </x-form.select>

                <div class="col-span-1 md:col-span-2">
                    <div wire:ignore>
                        <textarea id="editor" wire:model="message" placeholder="Your Message Here." class="form-input h-40"></textarea>
                    </div>
                    <x-easymde-editor wire:model="message" target-id="editor" />
                </div>

                {{-- Attachments Section --}}
                <div class="col-span-1 md:col-span-2">
                    <label for="attachments" class="block text-sm font-medium text-color-muted mb-2">
                        {{ __('ticket.attachments') }}
                    </label>
                    <div x-data="{
                            drop: false,
                            selectedFiles: [],
                            handleDrop(event) {
                                this.drop = false;
                                if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
                                    this.selectedFiles = Array.from(event.dataTransfer.files);
                                    this.$refs.fileInput.files = event.dataTransfer.files;
                                    // Trigger the change event to update Livewire
                                    this.$refs.fileInput.dispatchEvent(new Event('change'));
                                }
                            },
                            init() {
                                this.$watch('$wire.attachments', (value) => {
                                    if (value.length == 0) {
                                        this.selectedFiles = [];
                                    }
                                });
                            }                            
                        }">
                        <div class="flex justify-center rounded-lg bg-background-secondary border border-dashed border-neutral px-6 py-6"
                            @dragover.prevent="drop = true" @dragleave.prevent="drop = false"
                            @drop.prevent="handleDrop($event)" :class="{'bg-background-secondary/50': drop}">
                            <div class="text-center">
                                <template x-if="selectedFiles.length === 0">
                                    <div>
                                        <div class="flex text-sm text-color-muted justify-center">
                                            <label for="attachments"
                                                class="relative cursor-pointer rounded-md font-semibold text-primary hover:text-primary/80">
                                                <span>
                                                    {{ __('ticket.upload_attachments') }}
                                                </span>
                                            </label>
                                            <p class="pl-1 text-color-muted">{{ __('ticket.or_drag_and_drop') }}</p>
                                        </div>
                                        <p class="text-xs text-color-muted/70 mt-1">{{ __('ticket.files_max') }}</p>
                                    </div>
                                </template>
                                <div x-show="selectedFiles.length > 0">
                                    <h4 class="text-sm font-semibold text-color-base">{{ __('ticket.selected_files') }}:</h4>
                                    <div class="flex flex-wrap items-center justify-center gap-2 mt-2">
                                        <template x-for="file in selectedFiles" :key="file.name">
                                            <div
                                                class="text-sm rounded-md bg-gray-100 flex items-center gap-2 dark:bg-gray-800 p-2 py-1 w-fit">
                                                <span class="flex-1 text-color-base" x-text="file.name"></span>
                                                <button type="button"
                                                    class="text-red-500 hover:text-red-700 text-lg h-fit font-bold"
                                                    @click="selectedFiles = selectedFiles.filter(f => f !== file)">
                                                    &times;
                                                </button>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input id="attachments" type="file" multiple name="attachments[]" class="sr-only"
                            wire:model.live="attachments" x-ref="fileInput"
                            @change="selectedFiles = Array.from($event.target.files)" />
                    </div>
                </div>
            </div>

            <div class="flex justify-end mt-6">
                <x-button.primary class="py-3 text-base font-bold transition-all transform rounded-lg shadow-lg hover:bg-primary focus:outline-none focus:ring-4 focus:ring-primary-500 hover:-translate-y-0.5" type="submit">
                    {{ __('ticket.create_ticket') }}
                </x-button.primary>
            </div>
        </div>
    </form>
</div>