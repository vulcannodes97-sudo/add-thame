<div class="mt-12 mx-auto px-8 py-8 rounded-2xl animate-fade-in-up">

    <h1 class="text-3xl lg:text-4xl font-bold text-color-base mt-4 mb-2">
        {{ __('ticket.tickets') }}
    </h1>
    <p class="text-lg text-color-muted font-light max-w-2xl mb-8">
        Ticket #{{ $ticket->id }} - {{ $ticket->subject }}
    </p>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="md:col-span-3 order-2 md:order-1">
            <div class="bg-background-secondary/50 border border-neutral p-6 rounded-2xl shadow-lg mb-6">
                <div class="flex flex-col gap-5 max-h-[60vh] overflow-y-auto pr-4 custom-scrollbar" wire:poll.5s>
                    @foreach ($ticket->messages()->with('user')->get() as $index => $message)
                        <div
                            class="bg-background/10 border border-neutral/20 p-4 rounded-lg
                                   w-full max-w-[80%] {{ $message->user_id === auth()->id() ? 'ml-auto bg-primary/10 border-primary/20' : 'mr-auto' }}
                                   transition-all duration-200"
                            @if ($loop->last) x-data x-init="$nextTick(() => $el.scrollIntoView({ block: 'end' }))" @endif>
                            <div class="flex items-center justify-between mb-2">
                                <div>
                                    <h3 class="font-semibold text-color-base text-lg">{{ $message->user->name }}</h3>
                                    <p class="text-sm text-neutral-400">{{ $message->created_at->diffForHumans() }}</p>
                                </div>
                            </div>
                            <div class="mt-2 prose dark:prose-invert max-w-none text-color-base">
                                {!! Str::markdown($message->message, [
                                    'html_input' => 'escape',
                                    'allow_unsafe_links' => false,
                                    'renderer' => [
                                        'soft_break' => "<br>"
                                    ]
                                ]) !!}
                            </div>
                            
                            <div class="flex flex-wrap gap-x-2">
                                @foreach($message->attachments as $attachment)
                                <div class="mt-2">
                                    <a href="{{ route('tickets.attachments.show', $attachment) }}"
                                        class="text-sm rounded-md bg-gray-100 flex items-center dark:bg-gray-800 p-1 w-fit">
                                        @if($attachment->canPreview())
                                        <img src="{{ route('tickets.attachments.show', $attachment) }}"
                                            alt="{{ $attachment->filename }}" class="max-w-full">
                                        @else
                                        <x-ri-attachment-2 class="inline-block mr-1 size-4" />
                                        {{ $attachment->filename }}
                                        @endif
                                    </a>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            <div class="bg-background-secondary/70 border border-neutral p-6 rounded-2xl shadow-lg mt-6">
                <form wire:submit.prevent="save">
                    <label for="editor" class="block text-sm font-medium text-primary-100 mb-2">
                        {{ __('ticket.reply') }}
                    </label>
                    <div wire:ignore> 
                        <textarea id="editor" class="form-input h-40"></textarea>
                    </div>
                    <x-easymde-editor />

                    <label for="attachments" class="block text-sm font-medium text-primary-100 mt-4 mb-2">
                        {{ __('ticket.attachments') }}
                    </label>
                    <div x-data="{
                            drop: false,
                            selectedFiles: [],
                            handleDrop(event) {
                                this.drop = false;
                                if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
                                    this.selectedFiles = Array.from(event.dataTransfer.files);
                                    this.$refs.fileInput.files = event.dataTransfer.files;
                                    // Trigger the change event to update Livewire
                                    this.$refs.fileInput.dispatchEvent(new Event('change'));
                                }
                            },
                            init() {
                                this.$watch('$wire.attachments', (value) => {
                                    if (value.length == 0) {
                                        this.selectedFiles = [];
                                    }
                                });
                            }                            
                        }">
                        <div class="flex justify-center rounded-lg bg-background-secondary border border-dashed border-neutral px-6 py-4"
                            @dragover.prevent="drop = true" @dragleave.prevent="drop = false"
                            @drop.prevent="handleDrop($event)" :class="{'bg-background-secondary/50': drop}">
                            <div class="text-center">
                                <template x-if="selectedFiles.length === 0">
                                    <div>
                                        <div class="flex text-sm text-primary-100 justify-center">
                                            <label for="attachments"
                                                class="relative cursor-pointer rounded-md font-semibold text-primary hover:text-primary/80">
                                                <span>
                                                    {{ __('ticket.upload_attachments') }}
                                                </span>
                                            </label>
                                            <p class="pl-1 text-base/80">{{ __('ticket.or_drag_and_drop') }}</p>
                                        </div>
                                        <p class="text-xs/5 text-base/50 mt-1">{{ __('ticket.files_max') }}</p>
                                    </div>
                                </template>
                                <div x-show="selectedFiles.length > 0">
                                    <h4 class="text-sm font-semibold text-color-base">{{ __('ticket.selected_files') }}:</h4>
                                    <div class="flex flex-wrap items-center justify-center gap-2 mt-2">
                                        <template x-for="file in selectedFiles" :key="file.name">
                                            <div
                                                class="text-sm rounded-md bg-gray-100 flex items-center gap-2 dark:bg-gray-800 p-2 py-1 w-fit">
                                                <span class="flex-1" x-text="file.name"></span>
                                                <button type="button"
                                                    class="text-red-500 hover:text-red-700 text-lg h-fit font-bold"
                                                    @click="selectedFiles = selectedFiles.filter(f => f !== file)">
                                                    &times;
                                                </button>
                                            </div>
                                        </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input id="attachments" type="file" multiple name="attachments[]" class="sr-only"
                            wire:model.live="attachments" x-ref="fileInput"
                            @change="selectedFiles = Array.from($event.target.files)" />
                    </div>

                    <div class="mt-4 flex flex-col sm:flex-row gap-2 justify-end">
                        @if (!config('settings.ticket_client_closing_disabled', false) && $ticket->status !== 'closed')
                            <x-button.danger type="button" class="sm:!w-fit order-2 sm:order-1"
                                x-on:click.prevent="$store.confirmation.confirm({
                                    title: '{{ __('ticket.close_ticket') }}',
                                    message: '{{ __('ticket.close_ticket_confirmation') }}',
                                    confirmText: '{{ __('common.confirm') }}',
                                    cancelText: '{{ __('common.cancel') }}',
                                    callback: () => $wire.closeTicket()
                                })">
                                {{ __('ticket.close_ticket') }}
                            </x-button.danger>
                        @endif
                        <x-button.primary type="submit" class="sm:!w-fit order-1 sm:order-2" wire:target="save">
                            {{ __('ticket.reply') }}
                        </x-button.primary>
                    </div>
                </form>
            </div>
        </div>

        <div class="md:col-span-1 order-1 md:order-2">
            <div class="bg-background-secondary/50 border border-neutral p-6 rounded-2xl shadow-lg">
                <h2 class="text-xl font-bold text-color-base mb-4">{{ __('ticket.ticket_details') }}</h2>

                <div class="space-y-4"> 
                    <div class="flex flex-col">
                        <span class="text-sm font-medium text-neutral-400">{{ __('ticket.subject') }}:</span>
                        <span class="text-lg font-semibold text-color-base">{{ $ticket->subject }}</span>
                    </div>

                    <div class="flex flex-col">
                        <span class="text-sm font-medium text-neutral-400 mb-1">{{ __('ticket.status') }}:</span>
                        <div class="text-sm font-semibold px-3 py-1 rounded-full w-fit flex items-center gap-1.5
                            @if ($ticket->status == 'open') text-success bg-success/20
                            @elseif($ticket->status == 'closed') text-inactive bg-inactive/20
                            @elseif($ticket->status == 'replied') text-info bg-info/20
                            @else text-warning bg-warning/20 
                            @endif">
                            @if ($ticket->status == 'open')
                                <x-ri-add-circle-fill class="size-4" />
                                Open
                            @elseif($ticket->status == 'closed')
                                <x-ri-forbid-fill class="size-4" />
                                Closed
                            @elseif($ticket->status == 'replied')
                                <x-ri-chat-smile-2-fill class="size-4" />
                                Replied
                            @else
                                <x-ri-error-warning-fill class="size-4" />
                                {{ ucfirst($ticket->status) }}
                            @endif
                        </div>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-sm font-medium text-neutral-400">{{ __('ticket.priority') }}:</span>
                        <span class="text-base text-color-base">{{ ucfirst($ticket->priority) }}</span>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-sm font-medium text-neutral-400">{{ __('ticket.created_at') }}:</span>
                        <span class="text-base text-color-base">{{ $ticket->created_at->format('d M Y, H:i') }} ({{ $ticket->created_at->diffForHumans() }})</span>
                    </div>
                    @if ($ticket->department)
                        <div class="flex flex-col">
                            <span class="text-sm font-medium text-neutral-400">{{ __('ticket.department') }}:</span>
                            <span class="text-base text-color-base">{{ $ticket->department }}</span>
                        </div>
                    @endif
                    @if ($ticket->service)
                        <div class="flex flex-col">
                            <span class="text-sm font-medium text-neutral-400">{{ __('ticket.service') }}:</span>
                            <span class="text-base text-color-base">
                                <a href="{{ route('services.show', $ticket->service) }}" class="text-primary font-bold hover:underline" wire:navigate>
                                    {{ $ticket->service->product->name }}
                                </a>
                            </span>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>