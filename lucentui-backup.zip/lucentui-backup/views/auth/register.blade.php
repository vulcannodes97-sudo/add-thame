<div class="min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-5xl mx-auto mt-20">

        <div class="bg-background-secondary/50 backdrop-blur-lg rounded-2xl shadow-2xl border border-neutral/20 overflow-hidden">
            
            <form wire:submit.prevent="submit" id="register">
                
                <div class="flex flex-col lg:flex-row">
                    
                    <div class="w-full lg:w-5/12 p-8 md:p-10 border-b lg:border-b-0 lg:border-r border-neutral/20 bg-background/30">
                        
                        <div class="mb-8">
                            <h1 class="text-2xl font-bold text-color-base">{{ __('auth.sign_up_title') }}</h1>
                            <p class="text-sm text-color-muted mt-1">Enter your details to create an account.</p>
                        </div>

                        <div class="space-y-4">
                            <div class="grid grid-cols-2 gap-3">
                                <x-form.input 
                                    name="first_name" type="text" 
                                    :label="__('general.input.first_name')" :placeholder="__('general.input.first_name_placeholder')" 
                                    wire:model="first_name" required 
                                    class="w-full px-3 py-2.5 text-sm rounded-lg border border-neutral/30 bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all" 
                                />
                                <x-form.input 
                                    name="last_name" type="text" 
                                    :label="__('general.input.last_name')" :placeholder="__('general.input.last_name_placeholder')" 
                                    wire:model="last_name" required 
                                    class="w-full px-3 py-2.5 text-sm rounded-lg border border-neutral/30 bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all" 
                                />
                            </div>
                            <x-form.input 
                                name="email" type="email" 
                                :label="__('general.input.email')" :placeholder="__('general.input.email_placeholder')" 
                                wire:model="email" required 
                                class="w-full px-3 py-2.5 text-sm rounded-lg border border-neutral/30 bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all" 
                            />
                            <x-form.input 
                                name="password" type="password" 
                                :label="__('general.input.password')" :placeholder="__('general.input.password_placeholder')" 
                                wire:model="password" required 
                                class="w-full px-3 py-2.5 text-sm rounded-lg border border-neutral/30 bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all" 
                            />
                            <x-form.input 
                                name="password_confirmation" type="password" 
                                :label="__('general.input.password_confirmation')" :placeholder="__('general.input.password_confirmation_placeholder')" 
                                wire:model="password_confirmation" required 
                                class="w-full px-3 py-2.5 text-sm rounded-lg border border-neutral/30 bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all" 
                            />
                        </div>
                    </div>

                    <div class="w-full lg:w-7/12 p-8 md:p-10 flex flex-col justify-between bg-background-secondary/20">
                        
                        <div class="space-y-4 mb-6">
                            <h3 class="text-sm font-semibold text-color-base/80 uppercase tracking-wider mb-3 border-b border-neutral/10 pb-2">
                                {{ __('Additional Information') }}
                            </h3>
                            <div class="grid grid-cols-1 gap-4">
                                <x-form.properties :custom_properties="$custom_properties" :properties="$properties" />
                            </div>
                        </div>

                        <div class="mt-auto space-y-5">
                            
                            <div class="flex flex-col gap-4 pt-4 border-t border-neutral/10">
                                @if(config('settings.tos'))
                                    <x-form.checkbox wire:model="tos" name="tos" required class="text-xs text-color-base">
                                        {{ __('product.tos') }}
                                        <a href="{{ config('settings.tos') }}" target="_blank" class="font-medium text-primary hover:text-secondary">
                                            {{ __('product.tos_link') }}
                                        </a>
                                    </x-form.checkbox>
                                @endif
                                
                                <x-captcha :form="'register'" />
                            </div>
                            <div class="flex flex-col sm:flex-row items-center gap-4">
                                <x-button.primary 
                                    class="w-full sm:w-auto flex-1 py-2.5 px-6 rounded-lg bg-primary hover:bg-primary/90 text-white font-bold shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-all hover:-translate-y-0.5" 
                                    type="submit">
                                    {{ __('auth.sign_up') }}
                                </x-button.primary>
                                @if(!config('settings.registration_disabled', false))
                                    <div class="text-xs text-color-muted">
                                        {{ __("auth.already_have_account") }}
                                        <a class="font-bold text-primary hover:text-secondary ml-1" href="{{ route('login') }}" wire:navigate>
                                            {{ __('auth.sign_in') }}
                                        </a>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        
        <p class="mt-6 text-center text-xs text-color-muted">
            © {{ date('Y') }} {{ config('app.name') }}. All rights reserved.
        </p>

    </div>
</div>