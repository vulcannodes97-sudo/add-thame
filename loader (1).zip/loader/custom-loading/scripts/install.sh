#!/usr/bin/env bash
set -euo pipefail

PANEL="${PANEL:-/var/www/pterodactyl}"
ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ADMIN_LAYOUT="$PANEL/resources/views/layouts/admin.blade.php"
ROUTES_FILE="$PANEL/routes/admin.php"
SPINNER_FILE="$PANEL/resources/scripts/components/elements/Spinner.tsx"
SPINNER_BACKUP="$PANEL/storage/addons-backups/custom-loading/Spinner.tsx.bak"

STAMP_BEGIN="<!-- CUSTOM-LOADING:BEGIN -->"
STAMP_END="<!-- CUSTOM-LOADING:END -->"

MENU_BLOCK=$(cat <<'BLADE'
<!-- CUSTOM-LOADING:BEGIN -->
<li class="{{ Route::currentRouteName() !== 'admin.loading' ?: 'active' }}">
    <a href="{{ route('admin.loading') }}">
        <i data-lucide="paintbrush"></i> <span>Loading</span>
    </a>
</li>
<!-- CUSTOM-LOADING:END -->
BLADE
)

ROUTES_BLOCK=$(cat <<'PHP'
/* CUSTOM-LOADING:BEGIN */
Route::get('/loading', [\Pterodactyl\Http\Controllers\Admin\LoadingController::class, 'index'])
    ->name('admin.loading');

Route::post('/loading', [\Pterodactyl\Http\Controllers\Admin\LoadingController::class, 'store'])
    ->name('admin.loading.store');
/* CUSTOM-LOADING:END */
PHP
)

echo "[1/8] Checking panel path: $PANEL"
test -d "$PANEL" || { echo "Panel not found at $PANEL"; exit 1; }

echo "[2/8] Checking spinner path..."
test -f "$SPINNER_FILE" || { echo "Spinner file not found at $SPINNER_FILE"; exit 1; }

echo "[3/8] Backing up original Spinner.tsx..."
mkdir -p "$(dirname "$SPINNER_BACKUP")"
if [ ! -f "$SPINNER_BACKUP" ]; then
    cp "$SPINNER_FILE" "$SPINNER_BACKUP"
fi

echo "[4/8] Copying addon files..."
rsync -a "$ADDON_DIR/files/" "$PANEL/"

echo "[5/8] Ensuring storage/public dirs + perms..."
mkdir -p \
  "$PANEL/storage/app/custom_loading" \
  "$PANEL/storage/app/public/custom-loading" \
  "$PANEL/public/custom-loading"

chown -R www-data:www-data \
  "$PANEL/storage" \
  "$PANEL/bootstrap/cache" \
  "$PANEL/public/custom-loading" || true

chmod -R 775 \
  "$PANEL/storage" \
  "$PANEL/bootstrap/cache" \
  "$PANEL/public/custom-loading" || true

echo "[6/8] Patching admin menu + routes..."
ADMIN_LAYOUT="$ADMIN_LAYOUT" \
ROUTES_FILE="$ROUTES_FILE" \
MENU_BLOCK="$MENU_BLOCK" \
ROUTES_BLOCK="$ROUTES_BLOCK" \
STAMP_BEGIN="$STAMP_BEGIN" \
STAMP_END="$STAMP_END" \
php -r '
$adminLayout = getenv("ADMIN_LAYOUT");
$routesFile  = getenv("ROUTES_FILE");
$menuBlock   = getenv("MENU_BLOCK");
$routesBlock = getenv("ROUTES_BLOCK");
$stampBegin  = getenv("STAMP_BEGIN");
$stampEnd    = getenv("STAMP_END");

function patchAfterNeedle(string $file, string $needle, string $block, string $begin, string $end): void {
    if (!file_exists($file)) { fwrite(STDERR, "Missing file: $file\n"); exit(2); }
    $s = file_get_contents($file);

    $pattern = "/" . preg_quote($begin, "/") . ".*?" . preg_quote($end, "/") . "\n?/s";
    $s = preg_replace($pattern, "", $s);

    $pos = strpos($s, $needle);
    if ($pos === false) { fwrite(STDERR, "Needle not found in $file: $needle\n"); exit(3); }

    $lineEnd = strpos($s, "\n", $pos);
    $lineEnd = ($lineEnd === false) ? ($pos + strlen($needle)) : ($lineEnd + 1);

    $s = substr($s, 0, $lineEnd) . $block . "\n" . substr($s, $lineEnd);
    file_put_contents($file, $s);
}

function patchAppend(string $file, string $block, string $begin, string $end): void {
    if (!file_exists($file)) { fwrite(STDERR, "Missing file: $file\n"); exit(2); }
    $s = file_get_contents($file);

    $pattern = "/" . preg_quote($begin, "/") . ".*?" . preg_quote($end, "/") . "\n?/s";
    $s = preg_replace($pattern, "", $s);

    $s = rtrim($s) . "\n\n" . $block . "\n";
    file_put_contents($file, $s);
}

patchAfterNeedle($adminLayout, "<ul class=\"sidebar-menu\">", $menuBlock, $stampBegin, $stampEnd);
patchAppend($routesFile, $routesBlock, "/* CUSTOM-LOADING:BEGIN */", "/* CUSTOM-LOADING:END */");

echo "Patched OK\n";
'

echo "[7/8] Clearing backend caches..."
cd "$PANEL"
php artisan optimize:clear
php artisan view:clear
php artisan config:clear
php artisan route:clear
php artisan storage:link || true

echo "[8/8] Done."
echo "Now run:"
echo "  cd $PANEL"
echo "  yarn install"
echo "  yarn build"
echo
echo "✅ Custom Loading addon installed."
