#!/usr/bin/env bash
set -euo pipefail

PANEL="${PANEL:-/var/www/pterodactyl}"

ADMIN_LAYOUT="$PANEL/resources/views/layouts/admin.blade.php"
ROUTES_FILE="$PANEL/routes/admin.php"
SPINNER_FILE="$PANEL/resources/scripts/components/elements/Spinner.tsx"
SPINNER_BACKUP="$PANEL/storage/addons-backups/custom-loading/Spinner.tsx.bak"

STAMP_BEGIN="<!-- CUSTOM-LOADING:BEGIN -->"
STAMP_END="<!-- CUSTOM-LOADING:END -->"

echo "[1/5] Unpatching menu + routes..."
ADMIN_LAYOUT="$ADMIN_LAYOUT" \
ROUTES_FILE="$ROUTES_FILE" \
STAMP_BEGIN="$STAMP_BEGIN" \
STAMP_END="$STAMP_END" \
php -r '
$adminLayout = getenv("ADMIN_LAYOUT");
$routesFile  = getenv("ROUTES_FILE");
$stampBegin  = getenv("STAMP_BEGIN");
$stampEnd    = getenv("STAMP_END");

function removeStamped(string $file, string $begin, string $end): void {
    if (!file_exists($file)) return;
    $s = file_get_contents($file);

    $pattern1 = "/" . preg_quote($begin, "/") . ".*?" . preg_quote($end, "/") . "\n?/s";
    $s = preg_replace($pattern1, "", $s);

    $pattern2 = "/\/\* CUSTOM-LOADING:BEGIN \*\/.*?\/\* CUSTOM-LOADING:END \*\/\n?/s";
    $s = preg_replace($pattern2, "", $s);

    file_put_contents($file, $s);
}

removeStamped($adminLayout, $stampBegin, $stampEnd);
removeStamped($routesFile,  $stampBegin, $stampEnd);

echo "Unpatched OK\n";
'

echo "[2/5] Restoring original Spinner.tsx if backup exists..."
if [ -f "$SPINNER_BACKUP" ]; then
    cp "$SPINNER_BACKUP" "$SPINNER_FILE"
fi

echo "[3/5] Removing copied addon files..."
rm -f "$PANEL/app/Http/Controllers/Admin/LoadingController.php" || true
rm -rf "$PANEL/resources/views/admin/loading" || true
rm -f "$PANEL/public/custom-loading/config.json" || true

echo "[4/5] Clearing caches..."
cd "$PANEL"
php artisan optimize:clear
php artisan view:clear
php artisan config:clear
php artisan route:clear

echo "[5/5] Done."
echo "Now rebuild frontend:"
echo "  cd $PANEL"
echo "  yarn build"
echo
echo "✅ Custom Loading addon uninstalled."
