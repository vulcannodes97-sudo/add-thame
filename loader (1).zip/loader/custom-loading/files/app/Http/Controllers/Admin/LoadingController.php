<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;

class LoadingController extends Controller
{
    private function cfgFile(): string
    {
        return storage_path('app/custom_loading/config.json');
    }

    private function publicCfgFile(): string
    {
        return public_path('custom-loading/config.json');
    }

    private function defaultCfg(): array
    {
        return [
            'enabled'  => true,
            'size'     => 120,
            'gif_path' => '',
        ];
    }

    private function readCfg(): array
    {
        $cfg = $this->defaultCfg();

        try {
            $path = $this->cfgFile();

            if (!file_exists($path)) {
                return $cfg;
            }

            $raw = file_get_contents($path);
            $json = json_decode($raw, true);

            if (is_array($json)) {
                $cfg = array_merge($cfg, $json);
            }
        } catch (\Throwable $e) {
            Log::error('custom_loading readCfg failed', [
                'err' => $e->getMessage(),
            ]);
        }

        return $cfg;
    }

    private function writeCfg(array $cfg): void
    {
        $path = $this->cfgFile();
        $dir = dirname($path);

        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }

        $json = json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;

        $ok = file_put_contents($path, $json, LOCK_EX);

        if ($ok === false) {
            throw new \RuntimeException("Failed to write config to: {$path}");
        }
    }

    private function syncPublicCfg(array $cfg): void
    {
        $path = $this->publicCfgFile();
        $dir = dirname($path);

        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }

        $publicCfg = [
            'enabled'  => (bool) ($cfg['enabled'] ?? true),
            'size'     => (int) ($cfg['size'] ?? 120),
            'gif_path' => (string) ($cfg['gif_path'] ?? ''),
        ];

        $json = json_encode($publicCfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;

        $ok = file_put_contents($path, $json, LOCK_EX);

        if ($ok === false) {
            throw new \RuntimeException("Failed to write public config to: {$path}");
        }
    }

    public function index(): View
    {
        $cfg = $this->readCfg();

        return view('admin.loading.index', [
            'loading_enabled'  => (bool) ($cfg['enabled'] ?? true),
            'loading_size'     => (int) ($cfg['size'] ?? 120),
            'loading_gif_path' => (string) ($cfg['gif_path'] ?? ''),
        ]);
    }

    public function store(Request $request)
    {
        Log::info('custom_loading.store hit', [
            'user_id' => optional($request->user())->id,
            'hasFile' => $request->hasFile('gif_file'),
            'keys'    => array_keys($request->all()),
        ]);

        $data = $request->validate([
            'enabled'  => ['nullable', 'in:1'],
            'size'     => ['required', 'integer', 'min:16', 'max:1024'],
            'gif_file' => ['nullable', 'file', 'mimes:gif', 'max:5120'],
        ]);

        $cfg = $this->readCfg();

        $cfg['enabled'] = ($request->input('enabled') === '1');
        $cfg['size']    = (int) $data['size'];

        try {
            // Keep existing gif_path unless user uploads a new gif.
            if ($request->hasFile('gif_file') && $request->file('gif_file')->isValid()) {
                $name = 'loading_' . date('Ymd_His') . '.gif';
                $stored = $request->file('gif_file')->storeAs('custom-loading', $name, 'public');

                $cfg['gif_path'] = Storage::disk('public')->url($stored);
            }

            $this->writeCfg($cfg);
            $this->syncPublicCfg($cfg);

            Log::info('custom_loading saved OK', [
                'cfg_file'        => $this->cfgFile(),
                'public_cfg_file' => $this->publicCfgFile(),
                'gif'             => $cfg['gif_path'] ?? '',
                'size'            => $cfg['size'],
                'enabled'         => $cfg['enabled'],
            ]);
        } catch (\Throwable $e) {
            Log::error('custom_loading save FAILED', [
                'err'      => $e->getMessage(),
                'cfg_file' => $this->cfgFile(),
            ]);

            return redirect()->route('admin.loading')
                ->withErrors(['error' => 'Save failed: ' . $e->getMessage()]);
        }

        return redirect()->route('admin.loading')->with('success', 'Loading settings saved.');
    }
}