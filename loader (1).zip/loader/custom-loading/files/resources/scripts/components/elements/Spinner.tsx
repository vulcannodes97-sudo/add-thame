import React, { Suspense, useEffect, useState } from 'react';
import styled, { css, keyframes } from 'styled-components/macro';
import tw from 'twin.macro';
import ErrorBoundary from '@/components/elements/ErrorBoundary';

export type SpinnerSize = 'small' | 'base' | 'large';

interface Props {
    size?: SpinnerSize;
    centered?: boolean;
    isBlue?: boolean;
}

interface Spinner extends React.FC<Props> {
    Size: Record<'SMALL' | 'BASE' | 'LARGE', SpinnerSize>;
    Suspense: React.FC<React.PropsWithChildren<Props>>;
}

type CustomLoadingConfig = {
    enabled?: boolean;
    size?: number;
    gif_url?: string;
    gif_path?: string;
    css?: string;
};

const CONFIG_URL = '/custom-loading/config.json';
const STORAGE_KEY = 'custom_loading_config_cache';

const spin = keyframes`
    to { transform: rotate(360deg); }
`;

// noinspection CssOverwrittenProperties
const SpinnerComponent = styled.div<Props>`
    ${tw`w-8 h-8`};
    border-width: 3px;
    border-radius: 50%;
    animation: ${spin} 1s cubic-bezier(0.55, 0.25, 0.25, 0.7) infinite;

    ${(props) =>
        props.size === 'small'
            ? tw`w-4 h-4 border-2`
            : props.size === 'large'
            ? css`
                  ${tw`w-16 h-16`};
                  border-width: 6px;
              `
            : null};

    border-color: ${(props) => (!props.isBlue ? 'rgba(255, 255, 255, 0.2)' : 'hsla(212, 92%, 43%, 0.2)')};
    border-top-color: ${(props) => (!props.isBlue ? 'rgb(255, 255, 255)' : 'hsl(212, 92%, 43%)')};
`;

const CenterWrap = styled.div<{ $large?: boolean }>`
    ${tw`flex justify-center items-center`};
    ${({ $large }) => ($large ? tw`m-20` : tw`m-6`)};
`;

const CustomGif = styled.img<{ $size: number }>`
    width: ${({ $size }) => `${$size}px`};
    height: ${({ $size }) => `${$size}px`};
    object-fit: contain;
    display: block;
`;

const fallbackPixelSize = (size?: SpinnerSize): number => {
    if (size === 'small') return 16;
    if (size === 'large') return 64;
    return 32;
};

const applyCustomCss = (cssText?: string) => {
    if (typeof document === 'undefined') return;

    const styleId = 'custom-loading-inline-css';
    const existing = document.getElementById(styleId);

    if (!cssText || !cssText.trim()) {
        if (existing) existing.remove();
        return;
    }

    if (existing) {
        existing.textContent = cssText;
        return;
    }

    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = cssText;
    document.head.appendChild(style);
};

const readCachedConfig = (): CustomLoadingConfig | null => {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return null;
        const parsed = JSON.parse(raw);
        return parsed && typeof parsed === 'object' ? parsed : null;
    } catch {
        return null;
    }
};

const writeCachedConfig = (cfg: CustomLoadingConfig | null) => {
    try {
        if (!cfg) {
            localStorage.removeItem(STORAGE_KEY);
            return;
        }

        localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
    } catch {
        //
    }
};

const Spinner: Spinner = ({ centered, ...props }) => {
    const [cfg, setCfg] = useState<CustomLoadingConfig | null>(() => {
        if (typeof window === 'undefined') return null;
        return readCachedConfig();
    });

    const [checkedRemote, setCheckedRemote] = useState(false);

    useEffect(() => {
        if (cfg?.css) {
            applyCustomCss(cfg.css);
        }
    }, []);

    useEffect(() => {
        let active = true;

        fetch(CONFIG_URL, {
            method: 'GET',
            cache: 'no-store',
            headers: {
                Accept: 'application/json',
            },
        })
            .then((res) => {
                if (!res.ok) {
                    throw new Error(`Failed to load custom spinner config: ${res.status}`);
                }

                return res.json();
            })
            .then((data: CustomLoadingConfig) => {
                if (!active) return;

                const nextCfg = data || null;
                setCfg(nextCfg);
                writeCachedConfig(nextCfg);
                applyCustomCss(nextCfg?.css || '');
            })
            .catch(() => {
                if (!active) return;
            })
            .finally(() => {
                if (active) setCheckedRemote(true);
            });

        return () => {
            active = false;
        };
    }, []);

    const gifSrc = String(cfg?.gif_path || cfg?.gif_url || '').trim();
    const useCustomGif = Boolean(cfg?.enabled && gifSrc);
    const gifSize = Number(cfg?.size && cfg.size > 0 ? cfg.size : fallbackPixelSize(props.size));

    let content: React.ReactNode = null;

    if (useCustomGif) {
        content = <CustomGif src={gifSrc} alt="Loading..." $size={gifSize} />;
    } else if (checkedRemote) {
        content = <SpinnerComponent {...props} />;
    } else {
        content = null;
    }

    return centered ? <CenterWrap $large={props.size === 'large'}>{content}</CenterWrap> : <>{content}</>;
};

Spinner.displayName = 'Spinner';

Spinner.Size = {
    SMALL: 'small',
    BASE: 'base',
    LARGE: 'large',
};

Spinner.Suspense = ({ children, centered = true, size = Spinner.Size.LARGE, ...props }) => (
    <Suspense fallback={<Spinner centered={centered} size={size} {...props} />}>
        <ErrorBoundary>{children}</ErrorBoundary>
    </Suspense>
);

Spinner.Suspense.displayName = 'Spinner.Suspense';

export default Spinner;