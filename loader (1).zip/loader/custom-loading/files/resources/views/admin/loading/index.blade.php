@extends('layouts.admin')

@section('title')
    Loader Settings
@endsection

@section('content')
<style>
    html, body {
        background: #000 !important;
    }

    .content-wrapper,
    .wrapper,
    .main-content,
    .content,
    .container-fluid {
        background: #000 !important;
    }

    .cl-page {
        min-height: calc(100vh - 80px);
        color: #f5f5f5;
        background: #000;
        padding-bottom: 28px;
    }

    .cl-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 22px 0 18px;
        border-bottom: 1px solid rgba(255,255,255,0.08);
        margin-bottom: 22px;
    }

    .cl-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
        min-width: 0;
    }

    .cl-back {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        color: #fff;
        text-decoration: none;
        background: transparent;
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 12px;
        padding: 10px 14px;
        transition: .16s ease;
        white-space: nowrap;
        min-height: 44px;
    }

    .cl-back:hover {
        background: rgba(255,255,255,0.04);
        color: #fff;
        text-decoration: none;
    }

    .cl-title-wrap {
        min-width: 0;
    }

    .cl-title {
        font-size: 28px;
        font-weight: 800;
        color: #fff;
        letter-spacing: -0.02em;
        margin: 0 0 5px;
        line-height: 1.2;
    }

    .cl-subtitle {
        font-size: 13px;
        line-height: 1.6;
        color: #a3a3a3;
        margin: 0;
    }

    .cl-header-right {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-shrink: 0;
    }

    .cl-chip {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        min-height: 42px;
        padding: 10px 14px;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.10);
        background: rgba(255,255,255,0.02);
        color: #fff;
        font-size: 13px;
        font-weight: 700;
        text-align: center;
    }

    .cl-grid {
        display: grid;
        grid-template-columns: minmax(0, 1.15fr) minmax(320px, 0.85fr);
        gap: 18px;
    }

    .cl-stack {
        display: flex;
        flex-direction: column;
        gap: 18px;
    }

    .cl-card {
        background: #000;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 18px;
        padding: 22px;
    }

    .cl-card-header {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 18px;
    }

    .cl-icon-box {
        width: 40px;
        height: 40px;
        border-radius: 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.08);
        color: #fff;
        flex-shrink: 0;
    }

    .cl-card-header h3 {
        margin: 0;
        color: #fff;
        font-size: 17px;
        font-weight: 700;
        line-height: 1.3;
    }

    .cl-card-header p {
        margin: 5px 0 0;
        color: #9a9a9a;
        font-size: 13px;
        line-height: 1.55;
    }

    .cl-switch-wrap {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
        padding: 16px 18px;
        background: #000;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 14px;
    }

    .cl-switch-title {
        font-size: 14px;
        font-weight: 700;
        color: #fff;
        margin-bottom: 4px;
    }

    .cl-switch-sub {
        font-size: 12px;
        color: #9a9a9a;
        line-height: 1.5;
    }

    .cl-toggle {
        position: relative;
        display: inline-flex;
        align-items: center;
        cursor: pointer;
        flex-shrink: 0;
    }

    .cl-toggle-input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
    }

    .cl-toggle-slider {
        position: relative;
        width: 54px;
        height: 30px;
        border-radius: 999px;
        background: rgba(255,255,255,0.14);
        border: 1px solid rgba(255,255,255,0.12);
        transition: .2s ease;
        display: inline-block;
    }

    .cl-toggle-slider::after {
        content: '';
        position: absolute;
        top: 3px;
        left: 3px;
        width: 22px;
        height: 22px;
        border-radius: 999px;
        background: #fff;
        transition: .2s ease;
    }

    .cl-toggle-input:checked + .cl-toggle-slider {
        background: rgba(255,255,255,0.92);
    }

    .cl-toggle-input:checked + .cl-toggle-slider::after {
        transform: translateX(24px);
        background: #000;
    }

    .cl-toggle-input:focus + .cl-toggle-slider {
        box-shadow: 0 0 0 4px rgba(255,255,255,0.06);
    }

    .cl-form-group {
        margin-bottom: 18px;
    }

    .cl-form-group:last-child {
        margin-bottom: 0;
    }

    .cl-label {
        display: block;
        font-size: 13px;
        font-weight: 700;
        color: #e5e5e5;
        margin-bottom: 8px;
    }

    .cl-help {
        font-size: 12px;
        color: #8f8f8f;
        line-height: 1.55;
        margin-top: 8px;
    }

    .cl-input,
    .cl-file {
        width: 100%;
        background: #000;
        border: 1px solid rgba(255,255,255,0.10);
        color: #f5f5f5;
        border-radius: 14px;
        padding: 12px 14px;
        outline: none;
        transition: border-color .16s ease, background .16s ease;
        min-height: 46px;
    }

    .cl-input:focus,
    .cl-file:focus {
        border-color: rgba(255,255,255,0.22);
        background: rgba(255,255,255,0.015);
    }

    .cl-preview-box {
        min-height: 280px;
        border-radius: 16px;
        border: 1px dashed rgba(255,255,255,0.12);
        background: #000;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 24px;
        text-align: center;
    }

    .cl-preview-box img {
        max-width: 100%;
        max-height: 180px;
        object-fit: contain;
        display: block;
        margin-bottom: 14px;
    }

    .cl-preview-title {
        font-size: 14px;
        font-weight: 700;
        color: #fff;
    }

    .cl-preview-sub {
        font-size: 12px;
        color: #9a9a9a;
        margin-top: 6px;
        line-height: 1.55;
    }

    .cl-stats {
        display: grid;
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .cl-stat {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 14px;
        border-radius: 14px;
        background: #000;
        border: 1px solid rgba(255,255,255,0.08);
    }

    .cl-stat-icon {
        width: 34px;
        height: 34px;
        border-radius: 11px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.08);
        color: #fff;
        flex-shrink: 0;
    }

    .cl-stat strong {
        display: block;
        color: #fff;
        font-size: 13px;
        margin-bottom: 4px;
        line-height: 1.35;
    }

    .cl-stat span {
        display: block;
        color: #989898;
        font-size: 12px;
        line-height: 1.55;
    }

    .cl-alert-success,
    .cl-alert-danger {
        border-radius: 14px;
        padding: 14px 16px;
        margin-bottom: 16px;
        border: 1px solid rgba(255,255,255,0.08);
        background: #000;
        color: #f5f5f5;
    }

    .cl-alert-danger ul {
        margin: 8px 0 0 18px;
    }

    .cl-actions {
        display: flex;
        justify-content: flex-end;
    }

    .cl-save-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        min-width: 168px;
        height: 48px;
        padding: 0 18px;
        border: 1px solid rgba(255,255,255,0.14);
        border-radius: 14px;
        background: #fff;
        color: #000;
        font-size: 14px;
        font-weight: 800;
        cursor: pointer;
        transition: .16s ease;
    }

    .cl-save-btn:hover {
        opacity: 0.96;
    }

    .cl-save-btn:disabled {
        opacity: 0.72;
        cursor: not-allowed;
    }

    .cl-save-btn-text,
    .cl-save-btn-loading,
    .cl-save-btn-done {
        display: none;
        align-items: center;
        gap: 8px;
    }

    .cl-save-btn.is-idle .cl-save-btn-text {
        display: inline-flex;
    }

    .cl-save-btn.is-loading .cl-save-btn-loading {
        display: inline-flex;
    }

    .cl-save-btn.is-done .cl-save-btn-done {
        display: inline-flex;
    }

    .cl-spinner {
        width: 18px;
        height: 18px;
        border-radius: 999px;
        border: 2px solid rgba(0,0,0,0.18);
        border-top-color: #000;
        animation: cl-spin .72s linear infinite;
    }

    @keyframes cl-spin {
        to { transform: rotate(360deg); }
    }

    .cl-save-overlay {
        position: fixed;
        inset: 0;
        z-index: 9999;
        display: none;
        align-items: center;
        justify-content: center;
        background: rgba(0,0,0,0.42);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        padding: 20px;
    }

    .cl-save-overlay.is-active {
        display: flex;
    }

    .cl-save-modal {
        width: 180px;
        height: 180px;
        border-radius: 22px;
        background: rgba(0,0,0,0.84);
        border: 1px solid rgba(255,255,255,0.10);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 16px;
    }

    .cl-save-loader {
        width: 54px;
        height: 54px;
        border-radius: 999px;
        border: 3px solid rgba(255,255,255,0.12);
        border-top-color: #fff;
        animation: cl-spin 0.8s linear infinite;
    }

    .cl-save-check {
        width: 58px;
        height: 58px;
        border-radius: 999px;
        border: 2px solid rgba(255,255,255,0.14);
        display: none;
        align-items: center;
        justify-content: center;
        color: #fff;
    }

    .cl-save-overlay.is-success .cl-save-loader {
        display: none;
    }

    .cl-save-overlay.is-success .cl-save-check {
        display: inline-flex;
    }

    .cl-save-label {
        color: #fff;
        font-size: 13px;
        font-weight: 700;
        letter-spacing: 0.01em;
        text-align: center;
    }

    @media (max-width: 1050px) {
        .cl-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .cl-page {
            padding-bottom: 20px;
        }

        .cl-header {
            flex-direction: column;
            align-items: stretch;
            gap: 14px;
            padding: 16px 0 16px;
            margin-bottom: 18px;
        }

        .cl-header-left {
            flex-direction: column;
            align-items: stretch;
            gap: 12px;
        }

        .cl-header-right {
            width: 100%;
        }

        .cl-back {
            width: 100%;
        }

        .cl-chip {
            width: 100%;
        }

        .cl-title {
            font-size: 22px;
            margin-bottom: 6px;
        }

        .cl-subtitle {
            font-size: 12px;
            line-height: 1.55;
        }

        .cl-grid,
        .cl-stack {
            gap: 14px;
        }

        .cl-card {
            padding: 16px;
            border-radius: 14px;
        }

        .cl-card-header {
            gap: 10px;
            margin-bottom: 14px;
        }

        .cl-icon-box {
            width: 36px;
            height: 36px;
            border-radius: 10px;
        }

        .cl-card-header h3 {
            font-size: 15px;
        }

        .cl-card-header p {
            font-size: 12px;
        }

        .cl-switch-wrap {
            padding: 14px;
        }

        .cl-input,
        .cl-file {
            padding: 11px 12px;
            border-radius: 12px;
            font-size: 14px;
        }

        .cl-preview-box {
            min-height: 220px;
            padding: 18px;
            border-radius: 14px;
        }

        .cl-preview-box img {
            max-height: 140px;
        }

        .cl-stat {
            padding: 12px;
            border-radius: 12px;
        }

        .cl-stat-icon {
            width: 32px;
            height: 32px;
            border-radius: 10px;
        }

        .cl-actions {
            width: 100%;
        }

        .cl-save-btn {
            width: 100%;
            min-width: 0;
            border-radius: 12px;
        }

        .cl-save-modal {
            width: 150px;
            height: 150px;
            border-radius: 18px;
            gap: 12px;
        }

        .cl-save-loader {
            width: 44px;
            height: 44px;
        }

        .cl-save-check {
            width: 48px;
            height: 48px;
        }

        .cl-save-label {
            font-size: 12px;
        }
    }

    @media (max-width: 480px) {
        .cl-page {
            padding-left: 2px;
            padding-right: 2px;
        }

        .cl-title {
            font-size: 20px;
        }

        .cl-card {
            padding: 14px;
        }

        .cl-preview-box {
            min-height: 190px;
            padding: 14px;
        }

        .cl-preview-box img {
            max-height: 120px;
        }

        .cl-alert-success,
        .cl-alert-danger {
            padding: 12px 14px;
            font-size: 13px;
        }
    }
</style>

<div class="container-fluid cl-page">
    <div class="cl-header">
        <div class="cl-header-left">
            <a href="{{ url()->previous() }}" class="cl-back">
                <i data-lucide="arrow-left"></i>
                <span>Back</span>
            </a>

            <div class="cl-title-wrap">
                <h1 class="cl-title">Loader Settings</h1>
                <p class="cl-subtitle">
                    Manage the main loading GIF, toggle it on or off, and control the size from one page.
                </p>
            </div>
        </div>

        <div class="cl-header-right">
            <div class="cl-chip">
                <i data-lucide="power"></i>
                <span>{{ $loading_enabled ? 'Enabled' : 'Disabled' }}</span>
            </div>
        </div>
    </div>

    @if(session('success'))
        <div class="cl-alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="cl-alert-danger">
            <strong>Something needs fixing:</strong>
            <ul>
                @foreach ($errors->all() as $e)
                    <li>{{ $e }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="cl-grid">
        <div class="cl-stack">
            <form id="cl-loader-form" action="{{ route('admin.loading.store') }}" method="POST" enctype="multipart/form-data" class="cl-stack">
                @csrf

                <div class="cl-card">
                    <div class="cl-card-header">
                        <div class="cl-icon-box">
                            <i data-lucide="settings-2"></i>
                        </div>
                        <div>
                            <h3>General Settings</h3>
                            <p>Enable or disable the custom loader without removing the currently saved GIF.</p>
                        </div>
                    </div>

                    <div class="cl-switch-wrap">
                        <div>
                            <div class="cl-switch-title">Enable custom loader</div>
                            <div class="cl-switch-sub">When enabled, the uploaded GIF becomes the main loading animation.</div>
                        </div>

                        <label class="cl-toggle">
                            <input type="hidden" name="enabled" value="0">
                            <input class="cl-toggle-input" type="checkbox" name="enabled" value="1" {{ $loading_enabled ? 'checked' : '' }}>
                            <span class="cl-toggle-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="cl-card">
                    <div class="cl-card-header">
                        <div class="cl-icon-box">
                            <i data-lucide="image-up"></i>
                        </div>
                        <div>
                            <h3>Upload Loader GIF</h3>
                            <p>Upload a new GIF only when you want to replace the currently saved loader.</p>
                        </div>
                    </div>

                    <div class="cl-form-group">
                        <label class="cl-label">GIF file</label>
                        <input type="file" name="gif_file" accept="image/gif" class="cl-file">
                        <div class="cl-help">
                            Leave this empty if you only want to change the size or toggle. Your current GIF will remain saved.
                        </div>
                    </div>
                </div>

                <div class="cl-card">
                    <div class="cl-card-header">
                        <div class="cl-icon-box">
                            <i data-lucide="maximize"></i>
                        </div>
                        <div>
                            <h3>Display Size</h3>
                            <p>Control how large the loader appears while the panel is loading.</p>
                        </div>
                    </div>

                    <div class="cl-form-group">
                        <label class="cl-label">Size in pixels</label>
                        <input
                            type="number"
                            name="size"
                            class="cl-input"
                            min="16"
                            max="1024"
                            value="{{ old('size', $loading_size) }}"
                            placeholder="120"
                        >
                        <div class="cl-help">
                            Recommended range: 80px to 180px for most loading GIFs.
                        </div>
                    </div>
                </div>

                <div class="cl-actions">
                    <button id="cl-save-btn" class="cl-save-btn is-idle" type="submit">
                        <span class="cl-save-btn-text">
                            <i data-lucide="save"></i>
                            <span>Save Changes</span>
                        </span>

                        <span class="cl-save-btn-loading">
                            <span class="cl-spinner"></span>
                            <span>Saving...</span>
                        </span>

                        <span class="cl-save-btn-done">
                            <i data-lucide="check"></i>
                            <span>Saved</span>
                        </span>
                    </button>
                </div>
            </form>
        </div>

        <div class="cl-stack">
            <div class="cl-card">
                <div class="cl-card-header">
                    <div class="cl-icon-box">
                        <i data-lucide="sparkles"></i>
                    </div>
                    <div>
                        <h3>Live Preview</h3>
                        <p>Preview of the currently saved loader asset.</p>
                    </div>
                </div>

                <div class="cl-preview-box">
                    @if(!empty($loading_gif_path))
                        <img
                            src="{{ $loading_gif_path }}"
                            alt="Loader preview"
                            style="width: {{ (int) old('size', $loading_size) }}px; height: {{ (int) old('size', $loading_size) }}px;"
                        >
                        <div class="cl-preview-title">Current loader GIF</div>
                        <div class="cl-preview-sub">
                            This uploaded GIF stays saved until you replace it with a new one.
                        </div>
                    @else
                        <i data-lucide="image-off" style="width:40px;height:40px;color:#8a8a8a;margin-bottom:12px;"></i>
                        <div class="cl-preview-title">No GIF uploaded yet</div>
                        <div class="cl-preview-sub">
                            Upload a GIF from the left side to activate your custom loader.
                        </div>
                    @endif
                </div>
            </div>

            <div class="cl-card">
                <div class="cl-card-header">
                    <div class="cl-icon-box">
                        <i data-lucide="layout-dashboard"></i>
                    </div>
                    <div>
                        <h3>Quick Notes</h3>
                        <p>Helpful behavior details for the loader system.</p>
                    </div>
                </div>

                <div class="cl-stats">
                    <div class="cl-stat">
                        <div class="cl-stat-icon">
                            <i data-lucide="badge-check"></i>
                        </div>
                        <div>
                            <strong>GIF stays preserved</strong>
                            <span>Changing only the size or turning the loader on and off will not remove the saved GIF.</span>
                        </div>
                    </div>

                    <div class="cl-stat">
                        <div class="cl-stat-icon">
                            <i data-lucide="scan"></i>
                        </div>
                        <div>
                            <strong>Best size range</strong>
                            <span>Most GIF loaders look clean between 100px and 160px, depending on the GIF design.</span>
                        </div>
                    </div>

                    <div class="cl-stat">
                        <div class="cl-stat-icon">
                            <i data-lucide="shield-check"></i>
                        </div>
                        <div>
                            <strong>Safe fallback</strong>
                            <span>If no GIF is uploaded, the panel can still fall back to the default loading behavior.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="cl-save-overlay" class="cl-save-overlay" aria-hidden="true">
    <div class="cl-save-modal">
        <div class="cl-save-loader"></div>
        <div class="cl-save-check">
            <i data-lucide="check" style="width:28px;height:28px;"></i>
        </div>
        <div id="cl-save-label" class="cl-save-label">Saving changes...</div>
    </div>
</div>

<script>
    (function () {
        const form = document.getElementById('cl-loader-form');
        const overlay = document.getElementById('cl-save-overlay');
        const label = document.getElementById('cl-save-label');
        const saveBtn = document.getElementById('cl-save-btn');

        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }

        if (!form || !overlay || !label || !saveBtn) return;

        form.addEventListener('submit', function () {
            overlay.classList.add('is-active');
            overlay.classList.remove('is-success');

            saveBtn.classList.remove('is-idle', 'is-done');
            saveBtn.classList.add('is-loading');
            saveBtn.disabled = true;

            label.textContent = 'Saving changes...';

            setTimeout(function () {
                overlay.classList.add('is-success');
                label.textContent = 'Saved';
                saveBtn.classList.remove('is-loading');
                saveBtn.classList.add('is-done');

                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            }, 900);
        });
    })();
</script>
@endsection
