<li class="{{ Route::currentRouteName() !== 'admin.loading' ?: 'active' }}">
    <a href="{{ route('admin.loading') }}">
        <i data-lucide="brush"></i> <span>Loading</span>
    </a>
</li>
