Route::get('/loading', [\Pterodactyl\Http\Controllers\Admin\LoadingController::class, 'index'])
    ->name('admin.loading');

Route::post('/loading', [\Pterodactyl\Http\Controllers\Admin\LoadingController::class, 'store'])
    ->name('admin.loading.store');
