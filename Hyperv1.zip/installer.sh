#!/bin/bash

# =============================================
#  HyperV1 Theme Installer / Upgrader for Pterodactyl
#  Author: RolexDev
#  Compatible: Ubuntu, Debian, Fedora, CentOS, Arch, etc.
# =============================================

set -e

# --- Check Root Permission ---
if [[ "$EUID" -ne 0 ]]; then
    echo "Error: This script must be run as root or with sudo privileges."
    exit 1
fi

# --- Define panel path (default /var/www/pterodactyl) ---
read -rp "Enter your Pterodactyl panel path [/var/www/pterodactyl]: " PANEL_PATH
PANEL_PATH=${PANEL_PATH:-/var/www/pterodactyl}

if [[ ! -d "$PANEL_PATH" ]]; then
    echo "Error: Path $PANEL_PATH does not exist!"
    exit 1
fi

echo ""
echo "=============================="
echo "   HyperV1 Theme Installer"
echo "=============================="
echo "1) Install HyperV1 Theme"
echo "2) Upgrade HyperV1 Theme"
echo "3) Restore from Backup"
echo "=============================="
read -rp "Choose an option (1, 2, or 3): " OPTION

# --- Backup function ---
backup_panel() {
    echo "Backing up your panel files..."
    cd /var/www || exit
    tar -czf "pterodactyl_backup_$(date +%Y%m%d_%H%M%S).tar.gz" pterodactyl/
    echo "Backup completed."
}

# --- Manage backups ---
manage_backups() {
    BACKUPS=($(find /var/www -name "pterodactyl_backup_*.tar.gz" | xargs ls -t))
    if [ ${#BACKUPS[@]} -eq 0 ]; then
        return
    fi
    echo "Existing backups (newest first):"
    for i in "${!BACKUPS[@]}"; do
        echo "$((i+1))) ${BACKUPS[$i]}"
    done
    MOST_RECENT="${BACKUPS[0]}"
    echo "The most recent backup is $MOST_RECENT"
    read -rp "Do you want to delete some old backups? (y/N): " DELETE_OLD
    if [[ "$DELETE_OLD" =~ ^[Yy]$ ]]; then
        echo "Enter the numbers of backups to delete (space separated): "
        read -r TO_DELETE
        for num in $TO_DELETE; do
            if [[ "$num" =~ ^[0-9]+$ ]] && [ "$num" -ge 1 ] && [ "$num" -le ${#BACKUPS[@]} ]; then
                SELECTED="${BACKUPS[$((num-1))]}"
                if [ "$SELECTED" = "$MOST_RECENT" ]; then
                    read -rp "Are you sure you want to delete the most recent backup $SELECTED? (y/N): " CONFIRM_DELETE_RECENT
                    if [[ "$CONFIRM_DELETE_RECENT" =~ ^[Yy]$ ]]; then
                        rm "$SELECTED"
                        echo "Deleted $SELECTED"
                    fi
                else
                    rm "$SELECTED"
                    echo "Deleted $SELECTED"
                fi
            fi
        done
    fi
}

# --- Remove old assets ---
remove_old_assets() {
    echo "Removing old build files..."
    find "$PANEL_PATH/public/assets" -type f \( -name "*.js" -o -name "*.json" -o -name "*.js.map" \) -delete
}

# --- Download and extract HyperV1 ---
install_hyperv1_files() {
    echo "Downloading and extracting HyperV1 theme..."
    cd "$PANEL_PATH" || exit
    TAR_FILE="Hyperv1.tar"
    DOWNLOAD_URL="https://r2.rolexdev.tech/hyperv1/Hyperv1.tar"
    # Remove any existing tar to ensure a clean download/overwrite
    rm -f "$TAR_FILE" || true

    # Prefer curl, fall back to wget
    if command -v curl >/dev/null 2>&1; then
        echo "Attempting download with curl..."
        if curl -fsSL --retry 3 --retry-delay 2 -o "$TAR_FILE" "$DOWNLOAD_URL"; then
            echo "Downloaded Hyperv1.tar with curl"
        else
            echo "curl failed, attempting wget..."
            if command -v wget >/dev/null 2>&1 && wget -q -O "$TAR_FILE" "$DOWNLOAD_URL"; then
                echo "Downloaded Hyperv1.tar with wget"
            else
                echo "Error: failed to download Hyperv1.tar with curl and wget"
                rm -f "$TAR_FILE" || true
                exit 1
            fi
        fi
    elif command -v wget >/dev/null 2>&1; then
        echo "curl not found; downloading with wget..."
        if wget -q -O "$TAR_FILE" "$DOWNLOAD_URL"; then
            echo "Downloaded Hyperv1.tar with wget"
        else
            echo "Error: wget failed to download Hyperv1.tar"
            rm -f "$TAR_FILE" || true
            exit 1
        fi
    else
        echo "Error: neither curl nor wget is available to download Hyperv1.tar"
        exit 1
    fi

    # Extract and overwrite files (matches previous behavior)
    tar -xf "$TAR_FILE" --overwrite
}

# --- Set permissions ---
set_permissions() {
    echo "Setting correct permissions..."
    chown -R www-data:www-data "$PANEL_PATH"/*
    chmod -R 755 "$PANEL_PATH"/storage/* "$PANEL_PATH"/bootstrap/cache/
}

# --- Ensure fetch/auto-update scripts are executable and add sudoers entry ---
set_fetch_permissions() {
    echo "Setting executable permissions for hyper_fetch and hyper_auto_update (if present)..."

    if [[ -z "${PANEL_PATH:-}" ]]; then
        echo "PANEL_PATH not set; skipping fetch permission step."
        return
    fi

    FETCH_FILE="$PANEL_PATH/hyper_fetch.sh"
    AUTO_UPDATE_FILE="$PANEL_PATH/hyper_auto_update.sh"

    if [[ -f "$FETCH_FILE" ]]; then
        chmod +x "$FETCH_FILE" || true
        chown www-data:www-data "$FETCH_FILE" || true
        echo "Set executable on $FETCH_FILE"
    else
        echo "Warning: $FETCH_FILE not found; it may be extracted later."
    fi

    if [[ -f "$AUTO_UPDATE_FILE" ]]; then
        chmod +x "$AUTO_UPDATE_FILE" || true
        chown www-data:www-data "$AUTO_UPDATE_FILE" || true
        echo "Set executable on $AUTO_UPDATE_FILE"
    else
        echo "Warning: $AUTO_UPDATE_FILE not found; it may be extracted later."
    fi

    SUDOERS_FILE="/etc/sudoers.d/hyper_update"
    echo "Creating sudoers entry at $SUDOERS_FILE"
    # Use an explicit absolute path in the sudoers entry based on PANEL_PATH
    printf 'www-data ALL=(ALL) NOPASSWD: %s/hyper_fetch.sh, %s/hyper_auto_update.sh\n' "$PANEL_PATH" "$PANEL_PATH" > "$SUDOERS_FILE"
    chmod 0440 "$SUDOERS_FILE" || true

    # Validate sudoers file if visudo is available
    if command -v visudo >/dev/null 2>&1; then
        if visudo -cf "$SUDOERS_FILE" >/dev/null 2>&1; then
            echo "Sudoers file $SUDOERS_FILE validated"
        else
            echo "Warning: sudoers validation failed for $SUDOERS_FILE"
        fi
    else
        echo "Note: visudo not found; skipping sudoers syntax validation"
    fi
}

# --- Run Laravel cache clears ---
clear_cache() {
    echo "Clearing Laravel cache..."
    cd "$PANEL_PATH" || exit
    php artisan config:clear
    php artisan cache:clear
    php artisan route:clear
    php artisan view:clear
}

# --- Migrate database ---
migrate_db() {
    echo "Migrating database..."
    cd "$PANEL_PATH" || exit
    php artisan migrate --force
    php artisan db:seed --class=NestSeeder
    php artisan db:seed --class=EggSeeder
}

# --- Install composer package ---
install_composer_package() {
    echo "Installing required composer package..."
    cd "$PANEL_PATH" || exit
    composer require intervention/image
}

# --- phpBolt Loader Installation ---
install_bolt_loader() {
    echo "Installing phpBolt loader..."
    
    PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION;")
    echo "Detected PHP version: $PHP_VERSION"

    ARCH=$(uname -m)
    echo "Detected CPU architecture: $ARCH"

    if [[ "$ARCH" == "aarch64" ]]; then
        if [[ "$PHP_VERSION" != "8.3" ]]; then
            echo "Error: For aarch64 architecture, only PHP 8.3 is supported."
            exit 1
        fi
        DOWNLOAD_URL="https://r2.rolexdev.tech/hyperv1/loader/bolt-aarch64.so"
    else
        if [[ "$PHP_VERSION" != "8.2" && "$PHP_VERSION" != "8.3" ]]; then
            echo "Error: PHP $PHP_VERSION is not supported. Only 8.2 and 8.3 are supported."
            exit 1
        fi

        URL_82="https://r2.rolexdev.tech/hyperv1/loader/linux-64-8.2-bolt.so"
        URL_83="https://r2.rolexdev.tech/hyperv1/loader/linux-64-8.3-bolt.so"
        if [[ "$PHP_VERSION" == "8.2" ]]; then
            DOWNLOAD_URL="$URL_82"
        else
            DOWNLOAD_URL="$URL_83"
        fi
    fi

    echo "Download URL: $DOWNLOAD_URL"

    EXTENSION_DIR=$(php -i | grep "extension_dir" | head -1 | awk -F'=>' '{print $2}' | xargs)
    TARGET_FILE="$EXTENSION_DIR/bolt.so"

    if [[ -f "$TARGET_FILE" ]]; then
        echo "bolt.so already exists, skipping download."
    else
        echo "Downloading bolt.so..."
        wget -O "$TARGET_FILE" "$DOWNLOAD_URL"
        echo "Downloaded to $TARGET_FILE"
    fi

    PHP_INI_CLI="/etc/php/$PHP_VERSION/cli/php.ini"
    PHP_INI_FPM="/etc/php/$PHP_VERSION/fpm/php.ini"

    add_extension() {
        local INI_FILE="$1"
        if [[ -f "$INI_FILE" ]]; then
            if ! grep -q "extension=bolt.so" "$INI_FILE"; then
                echo "extension=bolt.so" >> "$INI_FILE"
                echo "Added extension to $INI_FILE"
            else
                echo "Extension already exists in $INI_FILE"
            fi
        else
            echo "Warning: $INI_FILE not found"
        fi
    }

    add_extension "$PHP_INI_CLI"
    add_extension "$PHP_INI_FPM"

    echo "Restarting PHP-FPM..."
    systemctl restart "php$PHP_VERSION-fpm" || true

    echo "Restarting web server..."
    if systemctl is-active --quiet nginx; then
        systemctl restart nginx
    elif systemctl is-active --quiet apache2; then
        systemctl restart apache2
    else
        echo "Warning: No web server found (nginx or apache2)"
    fi

    if php -m | grep -q "bolt"; then
        echo "Success: bolt extension is loaded."
    else
        echo "Error: bolt extension not loaded."
        exit 1
    fi

    echo "phpBolt loader installation completed."
}

# --- Restore from backup ---
restore_backup() {
    echo "Finding available backups..."
    BACKUPS=($(find /var/www -name "pterodactyl_backup_*.tar.gz" | sort))
    if [ ${#BACKUPS[@]} -eq 0 ]; then
        echo "No backups found."
        return
    fi
    echo "Available backups:"
    for i in "${!BACKUPS[@]}"; do
        echo "$((i+1))) ${BACKUPS[$i]}"
    done
    read -rp "Select a backup to restore (1-${#BACKUPS[@]}): " CHOICE
    if ! [[ "$CHOICE" =~ ^[0-9]+$ ]] || [ "$CHOICE" -lt 1 ] || [ "$CHOICE" -gt ${#BACKUPS[@]} ]; then
        echo "Invalid choice."
        return
    fi
    SELECTED="${BACKUPS[$((CHOICE-1))]}"
    read -rp "Are you sure you want to restore from $SELECTED? This will overwrite the current panel. (y/N): " CONFIRM
    if [[ "$CONFIRM" =~ ^[Yy]$ ]]; then
        echo "Restoring from $SELECTED..."
        cd /var/www || exit
        mv pterodactyl "pterodactyl_old_$(date +%Y%m%d_%H%M%S)"
        tar -xzf "$SELECTED"
        set_permissions
        clear_cache
        echo "Restore completed."
    else
        echo "Restore cancelled."
    fi
}

# ------------------------
# Execute user choice
# ------------------------

case $OPTION in
1)
    echo "--- Starting HyperV1 Installation ---"
    manage_backups
    backup_panel
    remove_old_assets
    install_hyperv1_files
    install_bolt_loader
    migrate_db
    install_composer_package
    clear_cache
    set_permissions
    set_fetch_permissions
    echo "---- HyperV1 Installation Completed ----"
    ;;
2)
    echo "--- Starting HyperV1 Upgrade ---"
    manage_backups
    backup_panel
    remove_old_assets
    install_hyperv1_files
    migrate_db
    clear_cache
    set_permissions
    set_fetch_permissions
    echo "---- HyperV1 Upgrade Completed ----"
    ;;
3)
    echo "--- Starting Restore from Backup ---"
    restore_backup
    echo "---- Restore Completed ----"
    ;;
*)
    echo "Invalid option. Please choose 1, 2, or 3."
    exit 1
    ;;
esac

echo ""
echo "🎉 Process Finished Successfully!"
