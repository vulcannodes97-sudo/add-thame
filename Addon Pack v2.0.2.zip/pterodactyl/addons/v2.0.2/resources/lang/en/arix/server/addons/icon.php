<?php

return [
    'title' => 'Server Icon',
    'description' => 'Upload a custom icon for your server. This will be displayed in the server list and on the server details page.',
    'upload' => 'Upload Icon',
];