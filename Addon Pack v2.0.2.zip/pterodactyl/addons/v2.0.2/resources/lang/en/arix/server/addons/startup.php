<?php

return [
    'startup-command-switched' => 'Startup command has been switched.',
];