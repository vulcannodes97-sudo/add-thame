<?php

return [
    'mods' => 'Mods',

    'browse' => 'Browse mods',
    'installed' => 'Installed mods',
    'search-for-a' => 'Search for a mod',
    'filters' => 'Filters',
    'reset-filters' => 'Reset filters',

    'by' => 'By',
    'last-updated' => 'Last updated',
    'downloads' => 'Downloads',
    'likes' => 'Likes',
    'item-installed' => 'Mod Installed',
    'no-found' => 'No mods found',

    'platform' => 'Platform',
    'version' => 'Version',
    'loader' => 'Loader',

    'install' => [
        'select-a-version' => 'Select a version',
        'select-version' => 'Select version',
        'install' => 'Install mod',

        'loading-versions' => 'Loading versions...',

        'make-default-world-label' => 'Make it default world',
        'make-default-world-description' => 'Sets this as the active world in server.properties after installing.',

        'installed-successfully' => 'Mod installed successfully',
        'processing-in-background' => 'This is taking longer than expected. The installation is being processed in the background, come back later to check on it.',
    ],

    'delete' => [
        'delete' => 'Delete mod',
        'are-you-sure' => 'Are you sure you want to delete',
        'continue' => 'Delete',
        'deleted-succesfully' => 'Mod deleted succesfully',
    ],
];