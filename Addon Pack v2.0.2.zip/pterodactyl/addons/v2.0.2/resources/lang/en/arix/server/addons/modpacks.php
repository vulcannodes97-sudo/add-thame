<?php

return [
    'modpacks' => 'Modpacks',

    'browse' => 'Browse modpacks',
    'installed' => 'Installed modpacks',
    'search-for-a' => 'Search for a modpack',
    'filters' => 'Filters',
    'reset-filters' => 'Reset filters',

    'by' => 'By',
    'last-updated' => 'Last updated',
    'downloads' => 'Downloads',
    'likes' => 'Likes',
    'item-installed' => 'Modpack Installed',
    'no-found' => 'No modpacks found',

    'platform' => 'Platform',
    'version' => 'Version',
    'loader' => 'Loader',

    'install' => [
        'select-a-version' => 'Select a version',
        'select-version' => 'Select version',
        'install' => 'Install modpack',

        'loading-versions' => 'Loading versions...',

        'make-default-world-label' => 'Make it default world',
        'make-default-world-description' => 'Sets this as the active world in server.properties after installing.',

        'installed-successfully' => 'Modpack installed successfully',
        'processing-in-background' => 'This is taking longer than expected. The installation is being processed in the background, come back later to check on it.',
    ],

    'delete' => [
        'delete' => 'Delete modpack',
        'are-you-sure' => 'Are you sure you want to delete',
        'continue' => 'Delete',
        'deleted-succesfully' => 'Modpack deleted succesfully',
    ],
];