<?php

return [
    'worlds' => 'Worlds',

    'browse' => 'Browse worlds',
    'installed' => 'Installed worlds',
    'search-for-a' => 'Search for a world',
    'filters' => 'Filters',
    'reset-filters' => 'Reset filters',

    'by' => 'By',
    'last-updated' => 'Last updated',
    'downloads' => 'Downloads',
    'likes' => 'Likes',
    'item-installed' => 'World Installed',
    'no-found' => 'No worlds found',

    'platform' => 'Platform',
    'version' => 'Version',
    'loader' => 'Loader',

    'install' => [
        'select-a-version' => 'Select a version',
        'select-version' => 'Select version',
        'install' => 'Install world',

        'loading-versions' => 'Loading versions...',

        'make-default-world-label' => 'Make it default world',
        'make-default-world-description' => 'Sets this as the active world in server.properties after installing.',

        'installed-successfully' => 'World installed successfully',
        'processing-in-background' => 'This is taking longer than expected. The installation is being processed in the background, come back later to check on it.',
    ],

    'delete' => [
        'delete' => 'Delete world',
        'are-you-sure' => 'Are you sure you want to delete',
        'continue' => 'Delete',
        'deleted-succesfully' => 'World deleted succesfully',
    ],
];