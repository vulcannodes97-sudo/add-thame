<?php

return [
    'title' => 'FiveM Utils',
    'txAdmin' => [
        'title' => 'TxAdmin',
        'description' => 'TxAdmin is a web-based management tool for FiveM servers. It provides an easy-to-use interface for managing your server.',

        'activate' => 'Activate TxAdmin',
        'success' => 'TxAdmin has been successfully activated.',
        'deactivate' => 'Deactivate TxAdmin',
        'deactivate_success' => 'TxAdmin has been successfully deactivated.',

        'open_txadmin' => 'Open TxAdmin',
    ],

    'cache' => [
        'title' => 'Clear Cache',
        'description' => 'Clear cache to fix stale files, missing textures, and crashes caused by corrupted or outdated cached data.',

        'clear_cache' => 'Clear Cache',
        'success' => 'Cache has been successfully cleared.',
    ]
];