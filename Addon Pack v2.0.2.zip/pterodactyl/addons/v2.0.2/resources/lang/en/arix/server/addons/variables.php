<?php

return [
    'variables' => 'Variables',
    'create_backup' => 'Create Backup',
    'add_variable' => 'Add Variable',
    'key' => 'Key',
    'value' => 'Value',
    'no_variables_found' => 'No variables found.',
    'no_variables_found_in_file' => 'No variables found in this file.',
    'edit' => 'Edit',
    'move' => 'Move',
    'delete' => 'Delete',

    'backup_create' => 'Backup created successfully:',

    'create' => [
        'title' => 'Add/Edit Variable',
        'environment' => 'Environment',
        'key' => 'Key',
        'value' => 'Value',
        'cancel' => 'Cancel',
        'add' => 'Add Variable',
        'edit' => 'Edit Variable',
    ],

    'moveDialog' => [
        'title' => 'Move Variable',
        'environment' => 'Environment',
        'cancel' => 'Cancel',
        'move' => 'Move Variable',
        'success' => 'Variable {{variable}} has been moved from {{environment}} to {{targetEnvironment}} successfully.'
    ],

    'deleteDialog' => [
        'title' => 'Delete Variable',
        'description' => 'Are you sure you want to delete the variable "{{variable}}" from the "{{environment}}" environment? This action cannot be undone.',
        'confirm' => 'Delete Variable',
        'success' => 'Variable {{variable}} has been deleted successfully.',
    ]
];