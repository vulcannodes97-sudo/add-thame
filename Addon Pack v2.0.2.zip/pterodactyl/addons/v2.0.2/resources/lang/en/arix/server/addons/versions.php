<?php

return[
    'versions' => 'Versions',
    'version-changer' => 'Version changer',
    'easily-switch-version' => 'Easily switch your server to a different Minecraft version with just one click!',
    'you-currently-on' => 'You\'re currently on',
    'select-a-version' => 'Select a version',
    'danger-zone' => 'Danger zone',
    'reset-your-server' => 'Reset the server, and delete all files (worlds, configs, plugins etc)',
    'powered-by' => 'Powered by',
    'install' => 'Install',
    'cancel' => 'Cancel',
    'browse' => 'Browse',
    'browse_versions' => 'Browse versions',
    'browse_versions_desc' => 'Select a version to install on your server.',
    'current' => 'Current',
    'succesfully-installed' => 'has succesfully been installed'
];