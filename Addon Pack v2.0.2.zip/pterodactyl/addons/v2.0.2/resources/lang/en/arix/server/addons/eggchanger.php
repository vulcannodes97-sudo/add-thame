<?php 

return [
    'egg-changer' => 'Egg Changer',

    'select-egg' => 'Select an egg to change to.',
    'switch-egg' => 'Switch Egg',

    'update-startup' => 'Update Startup Command',
    'update-startup-help' => 'After changing the egg, the server\'s startup command will be updated to the new egg\'s default startup command.',

    'reinstall-server' => 'Reinstall Server',
    'reinstall-server-help' => 'After changing the egg, the server will be reinstalled to ensure that the new egg\'s files are properly set up. This will delete all existing files on the server.',
    'cancel' => 'Cancel',

    'success' => 'Successfully changed to egg',

    'failed-to-fetch' => 'Failed to fetch changeable eggs. Please try again later.'
];