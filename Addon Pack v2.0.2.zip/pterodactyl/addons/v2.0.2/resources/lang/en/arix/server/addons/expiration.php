<?php

return [
    'expiration-date' => 'Expiration Date',
];