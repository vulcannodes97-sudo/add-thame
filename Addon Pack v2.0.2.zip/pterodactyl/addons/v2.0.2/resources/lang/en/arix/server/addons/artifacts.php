<?php 

return [
    'current' => 'Current',
    'recommended' => 'Recommended',
    'optional' => 'Optional',
    'install' => 'Install',

    'successfully_installed' => 'Successfully Installed',
    'reinstall_your_server' => 'The startup version has been updated to {{version}}. You need to reinstall your server for the new version to take effect.',
    'reinstall_now' => 'Reinstall Now',
    'close' => 'Close'
];